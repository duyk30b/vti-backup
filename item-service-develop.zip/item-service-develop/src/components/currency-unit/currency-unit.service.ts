import { ResponseCodeEnum } from '@constant/response-code.enum';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { Inject, Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nService } from 'nestjs-i18n';
import { Connection, In } from 'typeorm';
import { CreateCurrencyUnitRequestDto } from './dto/request/create-currency-unit.request.dto';
import { GetCurrencyUnitListRequestDto } from './dto/request/get-currency-unit-list.request.dto';
import { UpdateCurrencyUnitRequestDto } from './dto/request/update-currency-unit.request.dto';
import { CurrencyUnitRepositoryInterface } from './interface/currency-unit.repository.interface';
import { CurrencyUnitServiceInterface } from './interface/currency-unit.service.interface';
import { isEmpty, map, uniq, keyBy, isEqual } from 'lodash';
import { plainToInstance } from 'class-transformer';
import {
  CurrencyUnitResponseDto,
  GetCurrencyUnitDetailResponseDto,
} from './dto/response/get-currency-unit-detail.response.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { warn } from 'console';
import { GetCurrencyUnitListResponseDto } from './dto/response/get-currency-unit-list.response.dto';
import {
  CAN_NOT_UPDATE_CURRENCY_UNIT_STATUS,
  CurrencyUnitStatusEnum,
} from './currency-unit.constant';
import { GetCurrencyUnitsByIdsRequestDto } from './dto/request/get-currency-unit-by-ids.request.dto';
import { DeleteMultipleCurrencyUnitRequestDto } from './dto/request/delete-multiple-currency-unit.request.dto';

@Injectable()
export class CurrencyUnitService implements CurrencyUnitServiceInterface {
  constructor(
    @Inject('CurrencyUnitRepositoryInterface')
    private readonly currencyUnitRepository: CurrencyUnitRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @InjectConnection()
    private readonly connection: Connection,

    private readonly i18n: I18nService,
  ) {}

  async create(request: CreateCurrencyUnitRequestDto): Promise<any> {
    const { code } = request;
    if (
      !isEmpty(
        await this.currencyUnitRepository.findByCondition({
          code,
        }),
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_ALREADY_EXISTS'))
        .build();
    }
    const currencyUnitEntity = await this.currencyUnitRepository.createEntity(
      request,
    );

    return this.save(currencyUnitEntity, request);
  }

  async update(request: UpdateCurrencyUnitRequestDto): Promise<any> {
    const { id, code } = request;
    const data = await this.currencyUnitRepository.findOneById(id);

    if (isEmpty(data)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const currencyUnitEntity = await this.currencyUnitRepository.createEntity(
      request,
      id,
    );

    return this.save(currencyUnitEntity, request);
  }

  async updateStatus(id: number, isActive?: boolean): Promise<any> {
    const currencyUnit = (await this.currencyUnitRepository.findOneById(
      id,
    )) as CurrencyUnitEntity;

    if (isEmpty(currencyUnit)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (CAN_NOT_UPDATE_CURRENCY_UNIT_STATUS.includes(currencyUnit.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }

    isActive
      ? (currencyUnit.status = CurrencyUnitStatusEnum.ACTIVE)
      : (currencyUnit.status = CurrencyUnitStatusEnum.INACTIVE);

    try {
      await this.currencyUnitRepository.create(currencyUnit);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getDetail(id: number): Promise<any> {
    const data = await this.currencyUnitRepository.findOneById(id);

    if (isEmpty(data)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const serializedUser = await this.userService.getUsers(
      [data.createdByUserId],
      true,
    );

    const resData = plainToInstance(
      GetCurrencyUnitDetailResponseDto,
      {
        ...data,
        user: serializedUser[data.createdByUserId],
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(resData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(request: GetCurrencyUnitListRequestDto): Promise<any> {
    const { data, total } = await this.currencyUnitRepository.getList(request);

    const serializedUser = await this.userService.getUsers(
      uniq(map(data, 'createdByUserId')),
      true,
    );

    const resData = plainToInstance(
      GetCurrencyUnitListResponseDto,
      data.map((i) => {
        return {
          ...i,
          user: serializedUser[i.createdByUserId],
        };
      }),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder({
      items: resData,
      meta: { total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getMainCurrencyUnit(): Promise<any> {
    const data = await this.currencyUnitRepository.findOneByCondition({
      isPrimary: true,
    });

    if (isEmpty(data)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const resData = plainToInstance(CurrencyUnitResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(resData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async delete(id: number): Promise<any> {
    const data = await this.currencyUnitRepository.findOneById(id);
    if (isEmpty(data)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    try {
      await this.currencyUnitRepository.remove(id);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async deleteMultiple(
    request: DeleteMultipleCurrencyUnitRequestDto,
  ): Promise<any> {
    const ids = uniq(request.ids.split(','));

    const data = await this.currencyUnitRepository.findAllByCondition({
      id: In(ids),
    });

    if (!isEqual(data.length, ids.length)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();

    try {
      await queryRunner.manager.delete(CurrencyUnitEntity, {
        id: In(ids),
      });
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      console.error('DELETE PAYMENT TYPE ERROR:', err);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  private async save(
    currencyEntity: CurrencyUnitEntity,
    request: CreateCurrencyUnitRequestDto | UpdateCurrencyUnitRequestDto,
  ) {
    try {
      const currencyUnit = await this.currencyUnitRepository.create(
        currencyEntity,
      );

      const resData = plainToInstance(CurrencyUnitResponseDto, currencyUnit, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(resData)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getCurrencyUnitsByIds(
    request: GetCurrencyUnitsByIdsRequestDto,
  ): Promise<any> {
    const { ids } = request;

    const currencyUnits =
      await this.currencyUnitRepository.getCurrencyUnitsByIds(request);

    const resData = plainToInstance(CurrencyUnitResponseDto, currencyUnits, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(resData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
