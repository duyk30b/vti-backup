import { SuccessResponse } from "@components/item-setting/dto/response/success.response.dto";
import { DeleteMultipleDto } from "@core/dto/multiple/delete-multiple.dto";
import { ResponsePayload } from "@utils/response-payload";
import { CreateInventoryNormRequestDto } from "../dto/request/create-inventory-norm.request.dto";
import { GetListInventoryNormByItemIdsRequestDto } from "../dto/request/get-list-inventory-norm-by-item-ids.request.dto";
import { GetListInventoryNormRequestDto } from "../dto/request/get-list-inventory-norm.request.dto";
import { UpdateInventoryNormRequestDto } from "../dto/request/update-inventory-norm.request.dto";
import { GetListInventoryNormResponseDto } from "../dto/response/get-list-work-center.response.dto";
import { InventoryNormResponseDto } from "../dto/response/inventory-norm.response.dto";

export interface InventoryNormServiceInterface {
  create(
    request: CreateInventoryNormRequestDto,
  ): Promise<ResponsePayload<InventoryNormResponseDto | any>>;
  update(
    request: UpdateInventoryNormRequestDto,
  ): Promise<ResponsePayload<InventoryNormResponseDto | any>>;
  delete(id: number): Promise<ResponsePayload<SuccessResponse | any>>;
  deleteMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<SuccessResponse | any>>;
  detail(id: number): Promise<ResponsePayload<InventoryNormResponseDto | any>>;
  getList(
    request: GetListInventoryNormRequestDto
  ): Promise<ResponsePayload<GetListInventoryNormResponseDto | any>>
  getListInventoryNormByItemIds(
    request: GetListInventoryNormByItemIdsRequestDto,
  ): Promise<any>
}