import { BaseInterfaceRepository } from "@core/repository/base.interface.repository";
import { InventoryNorm } from "@entities/inventory-norm/inventory-norm.entity";
import { GetListInventoryNormRequestDto } from "../dto/request/get-list-inventory-norm.request.dto";



export interface InventoryNormRepositoryInterface
  extends BaseInterfaceRepository<InventoryNorm> {
    getList(
      request: GetListInventoryNormRequestDto
    ): Promise<any>
}