import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class GetListInventoryNormByItemIdsRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  itemIds: number[];
}
