import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsInt, Min, IsOptional } from 'class-validator';

export class InventoryNormRequestAbstractDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'mã nhà máy' })
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiPropertyOptional({
    example: 100,
    description: 'Giới hạn tồn kho',
    default: 0,
  })
  @IsOptional()
  @Min(0)
  inventoryLimit: number;

  @ApiPropertyOptional({
    example: 50,
    description: 'Giới hạn tồn kho(cận dưới)',
    default: 0,
  })
  @IsOptional()
  @Min(0)
  minInventoryLimit: number;

  @ApiPropertyOptional({
    example: 150,
    description: 'Giới hạn tồn kho(cận trên)',
    default: 0,
  })
  @IsOptional()
  @Min(0)
  maxInventoryLimit: number;

  @ApiPropertyOptional({
    example: 1,
    description: 'Thời hạn lưu kho',
    default: 0,
  })
  @IsOptional()
  @IsInt()
  expiryWarehouse: number;

  @ApiPropertyOptional({
    example: 1,
    description: 'Thời hạn cảnh báo lưu kho',
    default: 0,
  })
  @IsOptional()
  @IsInt()
  expiryWarningWarehouse: number;
}
