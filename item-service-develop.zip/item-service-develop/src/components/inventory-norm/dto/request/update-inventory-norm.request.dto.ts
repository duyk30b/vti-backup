import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { InventoryNormRequestAbstractDto } from './inventory-norm.request.abstract.dto';

export class UpdateInventoryNormBodyDto extends InventoryNormRequestAbstractDto {}
export class UpdateInventoryNormRequestDto extends UpdateInventoryNormBodyDto {
  @ApiProperty({ example: 1, description: 'id' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
