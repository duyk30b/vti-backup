import { SuccessResponse } from '@components/item-setting/dto/response/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { InventoryNormResponseAbstractDto } from './inventory-norm.response.abstract.dto';

export class InventoryNormResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: InventoryNormResponseAbstractDto;
}