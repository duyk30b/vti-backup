import { ItemResponseDto } from '@components/item/dto/response/item.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class InventoryNormResponseAbstractDto {
  @ApiProperty({ example: 1, description: 'id của giới hạn tồn kho' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: 'id của item' })
  @Expose()
  itemId: number;

  @ApiProperty({ example: 1, description: 'tên của item' })
  @Expose()
  itemName: string;

  @ApiProperty({ example: 1, description: 'mã của item' })
  @Expose()
  itemCode: string;

  @ApiProperty({ type: ItemResponseDto })
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty({ example: 90, description: 'giới hạn tồn kho' })
  @Expose()
  inventoryLimit: number;

  @ApiProperty({ example: 75, description: 'giới hạn tồn kho(cận dưới)' })
  @Expose()
  minInventoryLimit: number;

  @ApiProperty({ example: 115, description: 'giới hạn tồn kho(cận trên)' })
  @Expose()
  maxInventoryLimit: number;

  @ApiProperty({ example: 1, description: 'Thời hạn lưu kho' })
  @Expose()
  expiryWarehouse: number;

  @ApiProperty({ example: 1, description: 'Thời hạn cảnh báo lưu kho' })
  @Expose()
  expiryWarningWarehouse: number;
}
