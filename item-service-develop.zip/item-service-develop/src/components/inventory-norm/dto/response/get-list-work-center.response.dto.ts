import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { InventoryNormResponseAbstractDto } from './inventory-norm.response.abstract.dto';
import { PagingResponse } from '@utils/paging.response';
import { SuccessResponse } from '@components/item-setting/dto/response/success.response.dto';
export class InventoryNormListData extends PagingResponse {
    @ApiProperty({ type: InventoryNormResponseAbstractDto, isArray: true })
    @Expose()
    @IsArray()
    @Type(() => InventoryNormResponseAbstractDto)
    items: InventoryNormResponseAbstractDto[];
}

export class GetListInventoryNormResponseDto extends SuccessResponse {
    @ApiProperty()
    @Expose()
    data: InventoryNormListData;
}
