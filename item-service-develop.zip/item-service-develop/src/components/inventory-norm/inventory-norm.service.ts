import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { isEmpty } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { CreateInventoryNormRequestDto } from './dto/request/create-inventory-norm.request.dto';
import { GetListInventoryNormRequestDto } from './dto/request/get-list-inventory-norm.request.dto';
import { UpdateInventoryNormRequestDto } from './dto/request/update-inventory-norm.request.dto';
import { GetListInventoryNormResponseDto } from './dto/response/get-list-work-center.response.dto';
import { InventoryNormResponseAbstractDto } from './dto/response/inventory-norm.response.abstract.dto';
import { InventoryNormResponseDto } from './dto/response/inventory-norm.response.dto';
import { InventoryNormRepositoryInterface } from './interface/inventory-norm.repository.interface';
import { InventoryNormServiceInterface } from './interface/inventory-norm.service.interface';
import { ItemRepositoryInterface } from '@components/item/interface/item.repository.interface';
import { SuccessResponse } from '@components/item-setting/dto/response/success.response.dto';
import { InventoryNormRequestAbstractDto } from './dto/request/inventory-norm.request.abstract.dto';
import { stringFormat } from '@utils/object.util';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { GetListInventoryNormByItemIdsRequestDto } from './dto/request/get-list-inventory-norm-by-item-ids.request.dto';

@Injectable()
export class InventoryNormService implements InventoryNormServiceInterface {
  constructor(
    @Inject('InventoryNormRepositoryInterface')
    private readonly inventoryNormRepository: InventoryNormRepositoryInterface,

    @Inject('ItemRepositoryInterface')
    private readonly itemRepository: ItemRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  public async create(
    request: CreateInventoryNormRequestDto,
  ): Promise<ResponsePayload<InventoryNormRequestAbstractDto | any>> {
    const {
      itemId,
      inventoryLimit,
      minInventoryLimit,
      maxInventoryLimit,
      expiryWarehouse,
      expiryWarningWarehouse,
    } = request;

    const item = await this.itemRepository.findOneById(itemId);
    if (!item) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (
      minInventoryLimit &&
      maxInventoryLimit &&
      minInventoryLimit > maxInventoryLimit
    ) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.INVALID_INVENTORY_LIMIT'),
      ).toResponse();
    }
    if (inventoryLimit) {
      if (minInventoryLimit && inventoryLimit < minInventoryLimit) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.INVALID_INVENTORY_LIMIT'),
        ).toResponse();
      }

      if (maxInventoryLimit && inventoryLimit > maxInventoryLimit) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.INVALID_INVENTORY_LIMIT'),
        ).toResponse();
      }
    }

    if (expiryWarehouse < expiryWarningWarehouse) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.INVALID_EXPIRY_ERROR'),
      ).toResponse();
    }
    if (item.dayExpire < expiryWarningWarehouse) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.INVALID_EXPIRY_WAREHOUSE'),
      ).toResponse();
    }
    const inventoryNorm = await this.inventoryNormRepository.create(request);
    const response = plainToInstance(
      InventoryNormResponseAbstractDto,
      inventoryNorm,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async update(
    request: UpdateInventoryNormRequestDto,
  ): Promise<ResponsePayload<InventoryNormRequestAbstractDto> | any> {
    const inventoryNorm = await this.inventoryNormRepository.findOneById(
      request.id,
    );
    const {
      minInventoryLimit,
      maxInventoryLimit,
      inventoryLimit,
      expiryWarehouse,
      expiryWarningWarehouse,
    } = request;

    if (
      minInventoryLimit &&
      maxInventoryLimit &&
      minInventoryLimit > maxInventoryLimit
    ) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.INVALID_INVENTORY_LIMIT'),
      ).toResponse();
    }
    if (inventoryLimit) {
      if (minInventoryLimit && inventoryLimit < minInventoryLimit) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.INVALID_INVENTORY_LIMIT'),
        ).toResponse();
      }

      if (maxInventoryLimit && inventoryLimit > maxInventoryLimit) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.INVALID_INVENTORY_LIMIT'),
        ).toResponse();
      }
    }
    if (!inventoryNorm) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (expiryWarehouse < expiryWarningWarehouse) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.INVALID_EXPIRY_ERROR'),
      ).toResponse();
    }

    const item = await this.itemRepository.findOneById(request.itemId);
    if (!item) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    if (item.dayExpire < expiryWarningWarehouse) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.INVALID_EXPIRY_WAREHOUSE'),
      ).toResponse();
    }

    const updatedInventoryNorm = await this.inventoryNormRepository.create(
      request,
    );
    const response = plainToInstance(
      InventoryNormResponseAbstractDto,
      updatedInventoryNorm,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async delete(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const inventoryNorm = await this.inventoryNormRepository.findOneById(id);

    if (!inventoryNorm) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    try {
      await this.inventoryNormRepository.remove(id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    return new ResponseBuilder()
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async deleteMultiple(
    request: DeleteMultipleDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const inventoryNormList =
      await this.inventoryNormRepository.findAllByCondition({
        id: In(ids),
      });

    const inventoryNormIdsList = inventoryNormList.map(
      (inventoryNorm) => inventoryNorm.id,
    );
    if (inventoryNormList.length !== ids.length) {
      ids.forEach((id) => {
        if (!inventoryNormIdsList.includes(id)) failIdsList.push(id);
      });
    }

    const validIds = ids.filter((id) => !failIdsList.includes(id));
    try {
      if (!isEmpty(validIds))
        await this.inventoryNormRepository.multipleRemove(validIds);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async detail(
    id: number,
  ): Promise<ResponsePayload<InventoryNormResponseDto | any>> {
    const inventoryNorm = await this.inventoryNormRepository.findOneById(id);

    console.log({ inventoryNorm });

    if (!inventoryNorm) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const item = await this.itemRepository.findOneWithRelations({
      where: {
        id: inventoryNorm.itemId,
      },
      relations: ['itemType', 'itemUnit'],
    });
    if (item) {
      inventoryNorm.item = item;
    }

    const response = plainToInstance(
      InventoryNormResponseAbstractDto,
      inventoryNorm,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getList(
    request: GetListInventoryNormRequestDto,
  ): Promise<ResponsePayload<GetListInventoryNormResponseDto | any>> {
    const { data, total } = await this.inventoryNormRepository.getList(request);

    const response = plainToInstance(InventoryNormResponseAbstractDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getListInventoryNormByItemIds(
    request: GetListInventoryNormByItemIdsRequestDto,
  ): Promise<any> {
    const { itemIds } = request;
    const results = await this.inventoryNormRepository.findAllByCondition({
      itemId: In(itemIds),
    });
    const response = plainToInstance(
      InventoryNormResponseAbstractDto,
      results,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
