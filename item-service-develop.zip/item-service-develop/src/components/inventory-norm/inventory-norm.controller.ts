import { SuccessResponse } from '@components/item-setting/dto/response/success.response.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty } from 'lodash';
import { CreateInventoryNormRequestDto } from './dto/request/create-inventory-norm.request.dto';
import { GetListInventoryNormRequestDto } from './dto/request/get-list-inventory-norm.request.dto';
import { UpdateInventoryNormBodyDto } from './dto/request/update-inventory-norm.request.dto';
import { GetListInventoryNormResponseDto } from './dto/response/get-list-work-center.response.dto';
import { InventoryNormResponseDto } from './dto/response/inventory-norm.response.dto';
import { InventoryNormServiceInterface } from './interface/inventory-norm.service.interface';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_INVENTORY_NORM_PERMISSION,
  UPDATE_INVENTORY_NORM_PERMISSION,
  DELETE_INVENTORY_NORM_PERMISSION,
  DETAIL_INVENTORY_NORM_PERMISSION,
  LIST_INVENTORY_NORM_PERMISSION,
} from '@utils/permissions/inventory-norm';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { GetListInventoryNormByItemIdsRequestDto } from './dto/request/get-list-inventory-norm-by-item-ids.request.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';

@Controller('inventory-norms')
export class InventoryNormController {
  constructor(
    @Inject('InventoryNormServiceInterface')
    private readonly inventoryNormService: InventoryNormServiceInterface,
  ) {}

  @PermissionCode(CREATE_INVENTORY_NORM_PERMISSION.code)
  @MessagePattern('inventory_norm_create')
  @Post('/create')
  @ApiOperation({
    tags: ['Inventory norm'],
    summary: 'Create new inventory norm',
    description: 'Tạo giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: InventoryNormResponseDto,
  })
  public async create(
    @Body() payload: CreateInventoryNormRequestDto,
  ): Promise<ResponsePayload<InventoryNormResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryNormService.create(request);
  }

  @PermissionCode(UPDATE_INVENTORY_NORM_PERMISSION.code)
  @MessagePattern('inventory_norm_update')
  @Put('/:id')
  @ApiOperation({
    tags: ['Inventory norm'],
    summary: 'Update inventory norm',
    description: 'Cập nhật thông tin giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: InventoryNormResponseDto,
  })
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateInventoryNormBodyDto,
  ): Promise<ResponsePayload<InventoryNormResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryNormService.update({
      id,
      ...request,
    });
  }

  @PermissionCode(DELETE_INVENTORY_NORM_PERMISSION.code)
  @MessagePattern('inventory_norm_delete')
  @Delete('/:id')
  @ApiOperation({
    tags: ['Inventory norm'],
    summary: 'Delete inventory norm',
    description: 'Xóa giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async delete(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    return await this.inventoryNormService.delete(id);
  }

  @PermissionCode(DELETE_INVENTORY_NORM_PERMISSION.code)
  @MessagePattern('inventory_norm_delete_multiple')
  @Delete('/multiple')
  @ApiOperation({
    tags: ['Inventory norm'],
    summary: 'Delete multiple inventory norm',
    description: 'Xóa nhiều giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteMultiple(
    @Query() query: DeleteMultipleDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryNormService.deleteMultiple(request);
  }

  @PermissionCode(DETAIL_INVENTORY_NORM_PERMISSION.code)
  @MessagePattern('inventory_norm_detail')
  @Get('/:id')
  @ApiOperation({
    tags: ['Inventory Norm'],
    summary: 'Detail Inventory Norm',
    description: 'Chi tiết giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: InventoryNormResponseDto,
  })
  public async detail(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<InventoryNormResponseDto | any>> {
    return await this.inventoryNormService.detail(id);
  }

  @PermissionCode(LIST_INVENTORY_NORM_PERMISSION.code)
  @MessagePattern('inventory_norm_list')
  @Get('/list')
  @ApiOperation({
    tags: ['Inventory Norm'],
    summary: 'List Inventory Norm',
    description: 'Danh sách giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListInventoryNormResponseDto,
  })
  public async getList(
    @Query() payload: GetListInventoryNormRequestDto,
  ): Promise<ResponsePayload<GetListInventoryNormResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryNormService.getList(request);
  }

  @PermissionCode(LIST_INVENTORY_NORM_PERMISSION.code)
  @MessagePattern('inventory_norm_list_by_item_ids')
  public async getListInventoryNormByItemIds(
    @Body() payload: GetListInventoryNormByItemIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryNormService.getListInventoryNormByItemIds(
      request,
    );
  }
}
