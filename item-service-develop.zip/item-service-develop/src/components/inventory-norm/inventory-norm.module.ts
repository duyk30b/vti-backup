import { InventoryNorm } from "@entities/inventory-norm/inventory-norm.entity";
import { Item } from "@entities/item/item.entity";
import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { InventoryNormRepository } from "@repositories/inventory-norm.repository";
import { ItemRepository } from "@repositories/item.repository";
import { InventoryNormController } from "./inventory-norm.controller";
import { InventoryNormService } from "./inventory-norm.service";

@Module({
  imports: [
    TypeOrmModule.forFeature([
      InventoryNorm,
      Item
    ]),
  ],
  providers: [
    {
      provide: 'InventoryNormRepositoryInterface',
      useClass: InventoryNormRepository,
    },
    {
      provide: 'InventoryNormServiceInterface',
      useClass: InventoryNormService,
    },
    {
      provide: 'ItemRepositoryInterface',
      useClass: ItemRepository,
    },
  ],
  controllers: [InventoryNormController],
})
export class InventoryNormModule { }