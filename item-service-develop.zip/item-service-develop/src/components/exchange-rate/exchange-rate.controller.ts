import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateExchangeRateRequestDto } from './dto/request/create-exchange-rate.request.dto';
import { ExchangeRateServiceInterface } from './interface/exchange-rate.service.interface';
import { isEmpty } from 'lodash';
import { GetExchangeRateListRequestDto } from './dto/request/get-exchange-rate-list.request.dto';
import { UpdateExchangeRateRequestDto } from './dto/request/update-exchange-rate.request.dto';
import { GetExchangeRateHistoryListRequestDto } from './dto/request/get-exchange-rate-history-list.request.dto';

@Controller('exchange-rates')
export class ExchangeRateController {
  constructor(
    @Inject('ExchangeRateServiceInterface')
    private readonly exchangeRateService: ExchangeRateServiceInterface,
  ) {}

  @Post('/create')
  @ApiOperation({
    tags: ['Exchange rate'],
    summary: 'Create exchange rate',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  public async create(
    @Body() body: CreateExchangeRateRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (!isEmpty(responseError)) {
      return responseError;
    }

    request.createdByUserId = request.userId;
    return await this.exchangeRateService.create(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['Exchange rate'],
    summary: 'Update exchange rate',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async update(
    @Body() body: UpdateExchangeRateRequestDto,
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    const { request, responseError } = body;
    if (!isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    return await this.exchangeRateService.update(request);
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Exchange rate'],
    summary: 'Get exchange rate',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getDetail(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.exchangeRateService.getDetail(id);
  }

  @Get('/list')
  @ApiOperation({
    tags: ['Exchange rate'],
    summary: 'Get exchange rate list',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getList(
    @Query() query: GetExchangeRateListRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (!isEmpty(responseError)) {
      return responseError;
    }

    request.createdByUserId = request.userId;
    return await this.exchangeRateService.getList(request);
  }

  @Get('histories/list')
  @ApiOperation({
    tags: ['Exchange rate history'],
    summary: 'Get exchange rate history list',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getExchangeRateHistoryList(
    @Query() query: GetExchangeRateHistoryListRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (!isEmpty(responseError)) {
      return responseError;
    }

    request.createdByUserId = request.userId;
    return await this.exchangeRateService.getExchagneRateHistoryList(request);
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['Exchange rate'],
    summary: 'Delete exchange rate',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
  })
  public async delete(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.exchangeRateService.delete(id);
  }
}
