import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ExchangeRateHistoryEntity } from '@entities/exchange-rate/exchange-rate-history.entity';
import { GetExchangeRateHistoryListRequestDto } from '../dto/request/get-exchange-rate-history-list.request.dto';
import { GetExchangeRateListRequestDto } from '../dto/request/get-exchange-rate-list.request.dto';

export interface ExchangeRateHistoryRepositoryInterface
  extends BaseInterfaceRepository<any> {
  createEntity(request: any, id?: number): ExchangeRateHistoryEntity;
  getList(request: GetExchangeRateHistoryListRequestDto): Promise<any>;
}
