import { CreateExchangeRateRequestDto } from '../dto/request/create-exchange-rate.request.dto';
import { GetExchangeRateListRequestDto } from '../dto/request/get-exchange-rate-list.request.dto';
import { UpdateExchangeRateRequestDto } from '../dto/request/update-exchange-rate.request.dto';

export interface ExchangeRateServiceInterface {
  create(request: CreateExchangeRateRequestDto): Promise<any>;
  update(request: UpdateExchangeRateRequestDto): Promise<any>;
  getList(request: GetExchangeRateListRequestDto): Promise<any>;
  getExchagneRateHistoryList(
    request: GetExchangeRateListRequestDto,
  ): Promise<any>;
  getDetail(id: number): Promise<any>;
  delete(id: number): Promise<any>;
}
