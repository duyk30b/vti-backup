import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ExchangeRateEntity } from '@entities/exchange-rate/exchange-rate.entity';
import { GetExchangeRateListRequestDto } from '../dto/request/get-exchange-rate-list.request.dto';

export interface ExchangeRateRepositoryInterface
  extends BaseInterfaceRepository<any> {
  createEntity(request: any, id?: number): ExchangeRateEntity;
  getList(request: GetExchangeRateListRequestDto): Promise<any>;
  getByKeys(keys: string[]): Promise<any>;
}
