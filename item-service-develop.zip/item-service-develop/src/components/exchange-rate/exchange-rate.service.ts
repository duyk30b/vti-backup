import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nService } from 'nestjs-i18n';
import { Connection, Not } from 'typeorm';
import { CreateExchangeRateRequestDto } from './dto/request/create-exchange-rate.request.dto';
import { GetExchangeRateListRequestDto } from './dto/request/get-exchange-rate-list.request.dto';
import { UpdateExchangeRateRequestDto } from './dto/request/update-exchange-rate.request.dto';
import { ExchangeRateRepositoryInterface } from './interface/exchange-rate.repository.interface';
import { ExchangeRateServiceInterface } from './interface/exchange-rate.service.interface';
import {
  isEmpty,
  map,
  uniq,
  keyBy,
  compact,
  includes,
  isEqual,
  flatMap,
} from 'lodash';
import { plainToInstance } from 'class-transformer';
import {
  ExchangeRateResponseDto,
  GetExchangeRateDetailResponseDto,
} from './dto/response/get-exchange-rate-detail.response.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { GetExchangeRateListResponse } from './dto/response/get-exchange-rate-list.response.dto';
import { ExchangeRateEntity } from '@entities/exchange-rate/exchange-rate.entity';
import { ExchangeRateHistoryRepositoryInterface } from './interface/exchange-rate-history.repository.interface';
import { minus } from '@utils/helper';
import { GetExchangeRateHistoryListResponseDto } from './dto/response/get-exchange-rate-history-list.response.dto';
import { GetExchangeRateHistoryListRequestDto } from './dto/request/get-exchange-rate-history-list.request.dto';
import { CurrencyUnitRepositoryInterface } from '@components/currency-unit/interface/currency-unit.repository.interface';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';

@Injectable()
export class ExchangeRateService implements ExchangeRateServiceInterface {
  constructor(
    @Inject('ExchangeRateRepositoryInterface')
    private readonly exchangeRateRepository: ExchangeRateRepositoryInterface,

    @Inject('ExchangeRateHistoryRepositoryInterface')
    private readonly exchangeRateHistoryRepository: ExchangeRateHistoryRepositoryInterface,

    @Inject('CurrencyUnitRepositoryInterface')
    private readonly currencyUnitRepository: CurrencyUnitRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @InjectConnection()
    private readonly connection: Connection,

    private readonly i18n: I18nService,
  ) {}

  async create(request: CreateExchangeRateRequestDto): Promise<any> {
    const { fromCurrencyUnitId, toUnits } = request;

    const mainCurrencyUnit = (await this.currencyUnitRepository.findOneById(
      fromCurrencyUnitId,
    )) as CurrencyUnitEntity;

    if (isEmpty(mainCurrencyUnit)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const isDuplicated = !isEqual(
      map(toUnits, 'toCurrencyUnitId').length,
      uniq(map(toUnits, 'toCurrencyUnitId')).length,
    );
    const isSameFromUnit = includes(
      map(toUnits, 'toCurrencyUnitId'),
      fromCurrencyUnitId,
    );
    if (isSameFromUnit || isDuplicated) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const normalizedRequestData = this.normalizeExchangeRates(
      map(toUnits, (i) => {
        return {
          ...i,
          fromCurrencyUnitId: request.fromCurrencyUnitId,
          userId: request['userId'],
          description: request.description,
        };
      }),
    );

    const normalizedExistingData = this.normalizeExchangeRates(
      await this.exchangeRateRepository.getByKeys(
        map(normalizedRequestData, 'key'),
      ),
      true,
    );

    const exchangeRateEntities = [];
    const exchangeRateHistoryEntities = [];
    for (const i of normalizedRequestData) {
      const canMakeHistory =
        normalizedExistingData[i.key] &&
        // normalizedExistingData[i.key]?.id === i?.id &&
        minus(normalizedExistingData[i.key].rate, i.rate) !== 0;
      if (canMakeHistory) {
        exchangeRateHistoryEntities.push(
          this.exchangeRateHistoryRepository.createEntity({
            ...i,
            rate: normalizedExistingData[i.key].rate,
            fromCurrencyUnitId:
              normalizedExistingData[i.key].fromCurrencyUnitId,
            toCurrencyUnitId: normalizedExistingData[i.key].toCurrencyUnitId,
            exchangeRateId: normalizedExistingData[i.key].id,
            newRate: i.rate,
          }),
        );
      }

      // const canCreateExchangeRate =
      //   !normalizedExistingData[i.key] ||
      //   (normalizedExistingData[i.key] &&
      //     normalizedExistingData[i.key]?.id === i?.id);
      // if (canCreateExchangeRate) {
      exchangeRateEntities.push(this.exchangeRateRepository.createEntity(i));
      // }
    }

    const updatedCurrentUnits: CurrencyUnitEntity[] = compact(
      map(
        await this.currencyUnitRepository.findAllByCondition({
          isPrimary: true,
        }),
        (i) => {
          if (i.id !== mainCurrencyUnit.id) {
            i.isPrimary = false;
            return i as CurrencyUnitEntity;
          }
          return;
        },
      ),
    );

    mainCurrencyUnit.isPrimary = true;
    updatedCurrentUnits.push(mainCurrencyUnit);

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.delete(ExchangeRateEntity, { id: Not(0) });
      await queryRunner.manager.save(updatedCurrentUnits);
      await queryRunner.manager.save(exchangeRateEntities);
      await queryRunner.manager.save(exchangeRateHistoryEntities);
      await queryRunner.commitTransaction();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  private normalizeExchangeRates(exchangeRateEntities: any, isKeyBy?: boolean) {
    const result = map(exchangeRateEntities, (i) => {
      return {
        ...i,
        key: [i.fromCurrencyUnitId, i.toCurrencyUnitId].join('-'),
      };
    });

    if (isKeyBy) {
      return keyBy(result, 'key');
    }
    return result;
  }

  async update(request: UpdateExchangeRateRequestDto): Promise<any> {
    const { id } = request;
    const data = await this.exchangeRateRepository.findOneById(id);

    if (isEmpty(data)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const exchangeRateEntity = await this.exchangeRateRepository.createEntity(
      request,
      id,
    );

    return this.save(exchangeRateEntity, request);
  }

  async getDetail(id: number): Promise<any> {
    const data = await this.exchangeRateRepository.findOneById(id);

    if (isEmpty(data)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const serializedUser = await this.userService.getUsers(
      [data.createdByUserId],
      true,
    );

    const resData = plainToInstance(
      GetExchangeRateDetailResponseDto,
      {
        ...data,
        user: serializedUser[data.createdByUserId],
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(resData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(request: GetExchangeRateListRequestDto): Promise<any> {
    const { data, total } = await this.exchangeRateRepository.getList(request);

    const serializedUser = await this.userService.getUsers(
      flatMap([
        uniq(map(data, 'createdByUserId')),
        uniq(map(data, 'updatedByUserId')),
      ]),
      true,
    );

    const resData = plainToInstance(
      GetExchangeRateListResponse,
      data.map((i) => {
        return {
          ...i,
          createdBy: serializedUser[i.createdByUserId],
          updatedBy: serializedUser[i.updatedByUserId],
        };
      }),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder({
      items: resData,
      meta: { total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getExchagneRateHistoryList(
    request: GetExchangeRateHistoryListRequestDto,
  ): Promise<any> {
    const { data, total } = await this.exchangeRateHistoryRepository.getList(
      request,
    );

    const serializedUser = await this.userService.getUsers(
      flatMap([uniq(map(data, 'createdByUserId'))]),
      true,
    );

    const resData = plainToInstance(
      GetExchangeRateHistoryListResponseDto,
      data.map((i) => {
        return {
          ...i,
          createdBy: serializedUser[i.createdByUserId],
        };
      }),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder({
      items: resData,
      meta: { total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async delete(id: number): Promise<any> {
    const data = await this.exchangeRateRepository.findOneById(id);
    if (isEmpty(data)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    try {
      await this.exchangeRateRepository.remove(id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  private async save(
    exchangeRateEntity: ExchangeRateEntity,
    request: CreateExchangeRateRequestDto | UpdateExchangeRateRequestDto,
  ) {
    try {
      const exchangeRate = await this.exchangeRateRepository.create(
        exchangeRateEntity,
      );

      const resData = plainToInstance(ExchangeRateResponseDto, exchangeRate, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(resData)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
}
