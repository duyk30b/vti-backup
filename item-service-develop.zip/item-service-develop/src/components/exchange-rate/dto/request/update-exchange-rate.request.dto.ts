import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsOptional } from 'class-validator';
import { CreateExchangeRateRequestDto } from './create-exchange-rate.request.dto';

export class UpdateExchangeRateRequestDto extends CreateExchangeRateRequestDto {
  @ApiProperty()
  @IsOptional()
  @IsInt()
  id: number;
}
