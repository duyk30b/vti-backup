import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsBoolean } from 'class-validator';
export class GetExchangeRateHistoryListRequestDto extends PaginationQuery {}
