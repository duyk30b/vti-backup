import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

class UnitRequestDto {
  @ApiProperty()
  @IsInt()
  toCurrencyUnitId: number;

  @ApiProperty()
  @IsNumber()
  rate: number;
}

export class CreateExchangeRateRequestDto extends BaseDto {
  @ApiProperty()
  @IsString()
  description: string;

  @ApiProperty()
  @IsInt()
  fromCurrencyUnitId: number;

  @ApiProperty()
  @ArrayNotEmpty()
  @Type(() => UnitRequestDto)
  toUnits: UnitRequestDto[];
}
