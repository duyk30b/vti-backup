import { PaginationQuery } from '@utils/pagination.query';

export class GetExchangeRateListRequestDto extends PaginationQuery {}
