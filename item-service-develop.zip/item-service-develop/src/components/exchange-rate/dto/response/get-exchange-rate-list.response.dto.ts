import { BasicResponseDto } from '@components/user/dto/response/basic-response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { ExchangeRateResponseDto } from './get-exchange-rate-detail.response.dto';

class UserReposneDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  fullName: string;
}

class CurrencyUnitResponseDto extends BasicResponseDto {}

export class GetExchangeRateListResponse extends ExchangeRateResponseDto {
  @ApiProperty()
  @Expose()
  rate: number;

  @ApiProperty()
  @Type(() => UserReposneDto)
  @Expose()
  toUnit: CurrencyUnitResponseDto;

  @ApiProperty()
  @Type(() => UserReposneDto)
  @Expose()
  fromUnit: CurrencyUnitResponseDto;

  @ApiProperty()
  @Type(() => UserReposneDto)
  @Expose()
  createdBy: UserReposneDto;

  @ApiProperty()
  @Type(() => UserReposneDto)
  @Expose()
  updatedBy: UserReposneDto;
}
