import { BasicResponseDto } from '@components/user/dto/response/basic-response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class ExchangeRateResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  rate: number;

  @ApiProperty()
  @Expose()
  createdByUserId: number;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty()
  @Expose()
  updatedAt: string;
}

class UserReposneDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  fullName: string;
}

export class GetExchangeRateDetailResponseDto extends ExchangeRateResponseDto {
  @ApiProperty()
  @Type(() => UserReposneDto)
  @Expose()
  user: UserReposneDto;
}
