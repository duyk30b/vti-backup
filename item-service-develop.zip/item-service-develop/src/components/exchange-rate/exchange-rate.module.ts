import { UserService } from '@components/user/user.service';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { ExchangeRateHistoryEntity } from '@entities/exchange-rate/exchange-rate-history.entity';
import { ExchangeRateEntity } from '@entities/exchange-rate/exchange-rate.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CurrencyUnitRepository } from '@repositories/currency-unit.repository';
import { ExchangeRateHistoryRepository } from '@repositories/exchange-rate-history.repository';
import { ExchangeRateRepository } from '@repositories/exchange-rate.repository';
import { ExchangeRateController } from './exchange-rate.controller';
import { ExchangeRateService } from './exchange-rate.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      ExchangeRateEntity,
      ExchangeRateHistoryEntity,
      CurrencyUnitEntity,
    ]),
  ],
  exports: [],
  providers: [
    {
      provide: 'ExchangeRateServiceInterface',
      useClass: ExchangeRateService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'CurrencyUnitRepositoryInterface',
      useClass: CurrencyUnitRepository,
    },
    {
      provide: 'ExchangeRateRepositoryInterface',
      useClass: ExchangeRateRepository,
    },
    {
      provide: 'ExchangeRateHistoryRepositoryInterface',
      useClass: ExchangeRateHistoryRepository,
    },
  ],
  controllers: [ExchangeRateController],
})
export class ExchangeRateModule {}
