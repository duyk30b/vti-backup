import { GetByItemIdRequestDto } from '@components/sale/dto/request/get-by-item-id.request.dto';

export interface SaleServiceInterface {
  checkItemHasExistOnPurchaseOrder(
    request: GetByItemIdRequestDto,
  ): Promise<any>;
  checkItemHasExistOnSaleOrder(request: GetByItemIdRequestDto): Promise<any>;
  getOrderByWarehouse(
    type: number,
    id: number,
    warehouseId: number,
    user: any,
    warehouseShelfFloorId?: number,
  ): Promise<any>;
  checkItemHasExistOnProductionOrder(
    request: GetByItemIdRequestDto,
  ): Promise<any>;
  getListItemIdByQcStageId(qcStageId: number): Promise<any>;
  getSuggestStoredByPoImportId(poId: number, itemIds?: number[]): Promise<any>;
  getSuggestCollectedBySoExportId(
    soId: number,
    itemIds?: number[],
  ): Promise<any>;
  getSuggestByRoId(roId: number, itemIds?: number[]): Promise<any>;
  getSourceByIds(ids: number[], serilize?: boolean): Promise<any>;
  getSaleOrderExportDetail(id: number): Promise<any>;
  getPurchasedOrderImportDetail(id: number): Promise<any>;
  getListPurchasedOrderImportOpenTransaction(request: any): Promise<any>;
  getListSaleOrderExportOpenTransaction(request: any): Promise<any>;
  getSaleOrderExportByIds(ids: number[], withDetail: boolean): Promise<any>;
  getPurchasedOrderImportByIds(ids: number[]): Promise<any>;
}
