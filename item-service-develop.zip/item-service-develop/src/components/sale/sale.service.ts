import { ResponseCodeEnum } from './../../constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { GetByItemIdRequestDto } from '@components/sale/dto/request/get-by-item-id.request.dto';
import { SaleOrderTypeEnum } from './sale.constant';
import { keyBy, isEmpty } from 'lodash';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { NATS_SALE } from '@config/nats.config';

@Injectable()
export class SaleService implements SaleServiceInterface {
  constructor(
    @Inject('SALE_SERVICE_CLIENT')
    private readonly natsClientService: NatsClientService,
  ) {}

  async checkItemHasExistOnPurchaseOrder(
    request: GetByItemIdRequestDto,
  ): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_SALE}.check_item_has_exist_on_purchase_order`,
      request,
    );
  }

  async checkItemHasExistOnSaleOrder(
    request: GetByItemIdRequestDto,
  ): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_SALE}.check_item_has_exist_on_sale_order`,
      request,
    );
  }

  async checkItemHasExistOnProductionOrder(
    request: GetByItemIdRequestDto,
  ): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_SALE}.check_item_has_exist_on_production_order`,
      request,
    );
  }

  async getOrderByWarehouse(
    type: number,
    id: number,
    warehouseId: number,
    user: any,
    warehouseShelfFloorId?: number,
  ): Promise<any> {
    let sale;

    switch (type) {
      case SaleOrderTypeEnum.PO:
        sale = await this.natsClientService.send(
          `${NATS_SALE}.get_po_import_by_warehouse`,
          {
            id: id,
            warehouseId: warehouseId,
            warehouseShelfFloorId: warehouseShelfFloorId,
            user: user,
            withCompletedOrder: 1,
          },
        );
        break;
      case SaleOrderTypeEnum.IO:
        sale = await this.natsClientService.send(
          `${NATS_SALE}.get_import_order_warehouse`,
          {
            id: id,
            warehouseId: warehouseId,
            warehouseShelfFloorId: warehouseShelfFloorId,
            user: user,
          },
        );
        break;
      case SaleOrderTypeEnum.PRO:
        sale = await this.natsClientService.send(
          `${NATS_SALE}.get_production_order_warehouse`,
          {
            id: id,
            warehouseId: warehouseId,
            warehouseShelfFloorId: warehouseShelfFloorId,
            user: user,
          },
        );
        break;
      default:
        sale = await this.natsClientService.send(
          `${NATS_SALE}.get_sale_order_export_warehouse`,
          {
            id: id,
            warehouseId: warehouseId,
            warehouseShelfFloorId: warehouseShelfFloorId,
            user: user,
          },
        );

        break;
    }

    if (sale.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    } else return sale.data;
  }

  async getListItemIdByQcStageId(qcStageId: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_list_item_id_by_qcstageid`,
      {
        qcStageId: qcStageId,
      },
    );
    return response;
  }

  async getSuggestStoredByPoImportId(
    poId: number,
    itemIds?: number[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_suggest_stored_by_po_import_id`,
      {
        poImportId: poId,
        itemIds,
      },
    );
    return response;
  }

  async getSuggestCollectedBySoExportId(
    soId: number,
    itemIds?: number[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_suggest_collected_by_so_export_id`,
      {
        soExportId: soId,
        itemIds,
      },
    );
    return response;
  }

  async getSuggestByRoId(roId: number, itemIds?: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_suggest_by_ro_id`,
      {
        roId: roId,
        itemIds,
      },
    );
    return response;
  }

  async getSourceByIds(ids: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_source_by_ids`,
      {
        sourceIds: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS)
      return serilize ? {} : [];
    return serilize ? keyBy(response.data, 'id') : response.data;
  }

  async getSaleOrderExportDetail(id: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_sale_order_export_detail`,
      {
        id: id,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return {};
    return response.data;
  }

  async getPurchasedOrderImportDetail(id: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_purchased_order_import_detail`,
      {
        id: id,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return {};
    return response.data;
  }

  async getListSaleOrderExportOpenTransaction(request: any): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_SALE}.get_list_sale_order_export_open_transaction`,
        request,
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }

      return response.data;
    } catch (error) {
      console.error('Get open transaction sale order export error: ', error);
      return [];
    }
  }

  async getListPurchasedOrderImportOpenTransaction(request: any): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_SALE}.get_list_purchased_order_import_open_transaction`,
        request,
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }

      return response.data;
    } catch (error) {
      console.error(
        'Get open transaction purchased order import error: ',
        error,
      );
      return [];
    }
  }

  async getSaleOrderExportByIds(
    ids: number[],
    withDetail = false,
  ): Promise<any> {
    if (isEmpty(ids)) return [];
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_sale_order_export_by_ids`,
      {
        ids: ids,
        withDetail,
      },
    );
    if (response.statusCode === ResponseCodeEnum.SUCCESS) {
      return response.data;
    }
    return [];
  }

  async getPurchasedOrderImportByIds(ids: number[]): Promise<any> {
    if (isEmpty(ids)) return [];
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_purchased_order_import_by_ids`,
      {
        ids: ids,
      },
    );
    if (response.statusCode === ResponseCodeEnum.SUCCESS) {
      return response.data;
    }
    return [];
  }
}
