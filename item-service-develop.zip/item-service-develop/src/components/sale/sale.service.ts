import { ResponseCodeEnum } from './../../constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { ClientProxy } from '@nestjs/microservices';
import { GetByItemIdRequestDto } from '@components/sale/dto/request/get-by-item-id.request.dto';
import { SaleOrderTypeEnum } from './sale.constant';
import { keyBy, isEmpty } from 'lodash';

@Injectable()
export class SaleService implements SaleServiceInterface {
  constructor(
    @Inject('SALE_SERVICE_CLIENT')
    private readonly saleServiceClient: ClientProxy,
  ) {}

  async checkItemHasExistOnPurchaseOrder(
    request: GetByItemIdRequestDto,
  ): Promise<any> {
    return await this.saleServiceClient
      .send('check_item_has_exist_on_purchase_order', request)
      .toPromise();
  }

  async checkItemHasExistOnSaleOrder(
    request: GetByItemIdRequestDto,
  ): Promise<any> {
    return await this.saleServiceClient
      .send('check_item_has_exist_on_sale_order', request)
      .toPromise();
  }

  async checkItemHasExistOnProductionOrder(
    request: GetByItemIdRequestDto,
  ): Promise<any> {
    return await this.saleServiceClient
      .send('check_item_has_exist_on_production_order', request)
      .toPromise();
  }

  async getOrderByWarehouse(
    type: number,
    id: number,
    warehouseId: number,
    user: any,
    warehouseShelfFloorId?: number,
  ): Promise<any> {
    let sale;

    switch (type) {
      case SaleOrderTypeEnum.PO:
        sale = await this.saleServiceClient
          .send('get_po_import_by_warehouse', {
            id: id,
            warehouseId: warehouseId,
            warehouseShelfFloorId: warehouseShelfFloorId,
            user: user,
            withCompletedOrder: 1,
          })
          .toPromise();
        break;
      case SaleOrderTypeEnum.IO:
        sale = await this.saleServiceClient
          .send('get_import_order_warehouse', {
            id: id,
            warehouseId: warehouseId,
            warehouseShelfFloorId: warehouseShelfFloorId,
            user: user,
          })
          .toPromise();
        break;
      case SaleOrderTypeEnum.PRO:
        sale = await this.saleServiceClient
          .send('get_production_order_warehouse', {
            id: id,
            warehouseId: warehouseId,
            warehouseShelfFloorId: warehouseShelfFloorId,
            user: user,
          })
          .toPromise();
        break;
      default:
        sale = await this.saleServiceClient
          .send('get_sale_order_export_warehouse', {
            id: id,
            warehouseId: warehouseId,
            warehouseShelfFloorId: warehouseShelfFloorId,
            user: user,
          })
          .toPromise();

        break;
    }

    if (sale.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    } else return sale.data;
  }

  async getListItemIdByQcStageId(qcStageId: number): Promise<any> {
    const response = await this.saleServiceClient
      .send('get_list_item_id_by_qcstageid', {
        qcStageId: qcStageId,
      })
      .toPromise();
    return response;
  }

  async getSuggestStoredByPoImportId(
    poId: number,
    itemIds?: number[],
  ): Promise<any> {
    const response = await this.saleServiceClient
      .send('get_suggest_stored_by_po_import_id', {
        poImportId: poId,
        itemIds,
      })
      .toPromise();
    return response;
  }

  async getSuggestCollectedBySoExportId(
    soId: number,
    itemIds?: number[],
  ): Promise<any> {
    const response = await this.saleServiceClient
      .send('get_suggest_collected_by_so_export_id', {
        soExportId: soId,
        itemIds,
      })
      .toPromise();
    return response;
  }

  async getSuggestByRoId(roId: number, itemIds?: number[]): Promise<any> {
    const response = await this.saleServiceClient
      .send('get_suggest_by_ro_id', {
        roId: roId,
        itemIds,
      })
      .toPromise();
    return response;
  }

  async getSourceByIds(ids: number[], serilize?: boolean): Promise<any> {
    const response = await this.saleServiceClient
      .send('get_source_by_ids', {
        sourceIds: ids,
      })
      .toPromise();
    if (response.statusCode !== ResponseCodeEnum.SUCCESS)
      return serilize ? {} : [];
    return serilize ? keyBy(response.data, 'id') : response.data;
  }

  async getSaleOrderExportDetail(id: number): Promise<any> {
    const response = await this.saleServiceClient
      .send('get_sale_order_export_detail', {
        id: id,
      })
      .toPromise();
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return {};
    return response.data;
  }

  async getPurchasedOrderImportDetail(id: number): Promise<any> {
    const response = await this.saleServiceClient
      .send('get_purchased_order_import_detail', {
        id: id,
      })
      .toPromise();
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return {};
    return response.data;
  }

  async getListSaleOrderExportOpenTransaction(request: any): Promise<any> {
    try {
      const response = await this.saleServiceClient
        .send('get_list_sale_order_export_open_transaction', request)
        .toPromise();

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }

      return response.data;
    } catch (error) {
      console.error('Get open transaction sale order export error: ', error);
      return [];
    }
  }

  async getListPurchasedOrderImportOpenTransaction(request: any): Promise<any> {
    try {
      const response = await this.saleServiceClient
        .send('get_list_purchased_order_import_open_transaction', request)
        .toPromise();

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }

      return response.data;
    } catch (error) {
      console.error(
        'Get open transaction purchased order import error: ',
        error,
      );
      return [];
    }
  }

  async getSaleOrderExportByIds(
    ids: number[],
    withDetail = false,
  ): Promise<any> {
    if (isEmpty(ids)) return [];
    const response = await this.saleServiceClient
      .send('get_sale_order_export_by_ids', {
        ids: ids,
        withDetail,
      })
      .toPromise();

    if (response.statusCode === ResponseCodeEnum.SUCCESS) {
      return response.data;
    }
    return [];
  }

  async getPurchasedOrderImportByIds(ids: number[]): Promise<any> {
    if (isEmpty(ids)) return [];
    const response = await this.saleServiceClient
      .send('get_purchased_order_import_by_ids', {
        ids: ids,
      })
      .toPromise();

    if (response.statusCode === ResponseCodeEnum.SUCCESS) {
      return response.data;
    }
    return [];
  }
}
