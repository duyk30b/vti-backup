import { IsIn, IsInt, IsNotEmpty } from 'class-validator';

export class GetOrderDetailDto {
  @IsNotEmpty()
  @IsInt()
  id: number;

  @IsNotEmpty()
  @IsInt()
  warehouseId: number;
}
