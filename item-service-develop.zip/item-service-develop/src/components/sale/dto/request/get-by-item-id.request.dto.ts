import { BaseDto } from '@core/dto/base.dto';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class GetByItemIdRequestDto extends BaseDto {
  @IsNotEmpty()
  itemId: any;
}
