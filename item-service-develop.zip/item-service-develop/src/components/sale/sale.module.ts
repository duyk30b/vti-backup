import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { SaleService } from '@components/sale/sale.service';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ConfigService } from '@config/config.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    'SALE_SERVICE_CLIENT',
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'SALE_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const saleServiceOptions = configService.get('saleService');
        return ClientProxyFactory.create(saleServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
  ],
  controllers: [],
})
export class SaleModule {}
