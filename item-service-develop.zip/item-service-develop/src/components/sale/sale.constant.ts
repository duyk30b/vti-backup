export enum SaleOrderTypeEnum {
  PO = 1,
  PRO = 2,
  SO = 3,
  TRANSFER = 4,
  IO = 5,
  EXO = 6,
  RO = 7,
  PROPOSAL = 8,
  SWIFT_LOCATOR = 9,
  INVENTORY_ADJUSTMENT = 10,
}

export const ORDER_TYPE_EXPORT = [
  SaleOrderTypeEnum.SO,
  SaleOrderTypeEnum.TRANSFER,
];

export const ORDER_TYPES: number[] = [
  SaleOrderTypeEnum.PO,
  SaleOrderTypeEnum.PRO,
  SaleOrderTypeEnum.SO,
];

export enum OrderWarehouseActionTypeEnum {
  IMPORT = 0,
  EXPORT = 1,
}

export const ORDER_ACTION_TYPES: number[] = [
  OrderWarehouseActionTypeEnum.IMPORT,
  OrderWarehouseActionTypeEnum.EXPORT,
];
