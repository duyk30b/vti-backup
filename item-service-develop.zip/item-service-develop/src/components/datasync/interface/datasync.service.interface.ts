import { RetryJobRequestDto } from '../dto/request/retry-job.request.dto';

export interface DatasyncServiceInterface {
  createJob(info: any, payload: any): Promise<any>;
  getDetailJob(id: string): Promise<any>;
  updateJobStatus(id: string, status: number): Promise<any>;
  retry(request: RetryJobRequestDto): Promise<any>;
}
