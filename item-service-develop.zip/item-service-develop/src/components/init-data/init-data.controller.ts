import { Controller, Inject, Post } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { InitDataServiceInterface } from './interface/init-data.service.interface';

@Controller('init-data')
export class InitDataController {
  constructor(
    @Inject('InitDataServiceInterface')
    private readonly initDataService: InitDataServiceInterface,
  ) {}

  @MessagePattern('item_service_insert_data')
  public async createSector(payload: any): Promise<any> {
    return await this.initDataService.insertData(payload);
  }

  @Post('currency-units')
  @ApiOperation({
    tags: ['Currency unit'],
    summary: 'Create currency unit',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  public async create(payload: any): Promise<any> {
    return await this.initDataService.initCurrencyUnit();
  }
}
