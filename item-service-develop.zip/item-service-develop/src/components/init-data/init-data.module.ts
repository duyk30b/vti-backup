import { Module } from '@nestjs/common';
import { InitDataController } from './init-data.controller';
import { InitDataService } from './init-data.service';
import { InitDataRepository } from '@repositories/init-data.repository';
import { CurrencyUnitRepository } from '@repositories/currency-unit.repository';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [TypeOrmModule.forFeature([CurrencyUnitEntity])],
  providers: [
    {
      provide: 'InitDataServiceInterface',
      useClass: InitDataService,
    },
    {
      provide: 'InitDataRepositoryInterface',
      useClass: InitDataRepository,
    },
    {
      provide: 'CurrencyUnitRepositoryInterface',
      useClass: CurrencyUnitRepository,
    },
  ],
  exports: [
    {
      provide: 'InitDataServiceInterface',
      useClass: InitDataService,
    },
    {
      provide: 'InitDataRepositoryInterface',
      useClass: InitDataRepository,
    },
    {
      provide: 'CurrencyUnitRepositoryInterface',
      useClass: CurrencyUnitRepository,
    },
  ],
  controllers: [InitDataController],
})
export class InitDataModule {
  constructor() {}
}
