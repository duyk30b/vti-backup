import { SnakeNamingStrategy } from 'typeorm-naming-strategies';
import { Transport } from '@nestjs/microservices';

export class ConfigService {
  private readonly envConfig: { [key: string]: any } = null;

  constructor() {
    process.env.TZ = 'Asia/Ho_Chi_Minh';
    this.envConfig = {
      port: process.env.SERVER_PORT,
      serviceName: process.env.SERVICE_NAME,
      httpPort: process.env.SERVER_HTTP_PORT,
      cpuCores: process.env.CPU_CORES || 1,
      otherGroupId: process.env.OTHER_CODE_GROUP || '001',
      defaultTimeZone: process.env.TZ,
    };
    this.envConfig.internalToken =
      process.env.INTERNAL_TOKEN ||
      't5AQ1il1FtOk6Pp9FEW0VbwYETYqqseisgvo0ZCchayvvsQYFSkNzP7bNZ7vEFr0B1Hd4Ft3KGls1q2Irc20Yv1juslgTgtP4lavfeFiw7qBDDzw5D5Y7vMxoIfkpEqcViZqcPy3K2TCOqzCVGAQjJ4bvmX01xeCqILT5ewBd7fL3hZ4jBlSYmbiIefVIiRzeFhWCYOuVpS4Ng4lPcEBvUorm5zlLAci65UKdKtoXbPtWp2A1jrE5D';
    this.envConfig.baseUri = process.env.BASE_URI;
    this.envConfig.gatewayPort = process.env.API_GATEWAY_PORT;

    this.envConfig.notificationService = {
      options: {
        port: process.env.NOTIFICATION_SERVICE_PORT || 3000,
        host: process.env.NOTIFICATION_SERVICE_HOST || 'notification-service',
      },
      transport: Transport.TCP,
    };

    this.envConfig.fileService = {
      options: {
        port: process.env.FILE_SERVICE_PORT || 3001,
        host: process.env.FILE_SERVICE_HOST || 'file-service',
      },
      transport: Transport.TCP,
    };

    this.envConfig.saleService = {
      options: {
        port: process.env.SALE_SERVICE_PORT || 3000,
        host: process.env.SALE_SERVICE_HOST || 'sale-service',
      },
      transport: Transport.TCP,
    };

    this.envConfig.produceService = {
      options: {
        port: process.env.PRODUCE_SERVICE_PORT || 3000,
        host: process.env.PRODUCE_SERVICE_HOST || 'produce-service',
      },
      transport: Transport.TCP,
    };

    this.envConfig.warehouseService = {
      options: {
        port: process.env.WAREHOUSE_SERVICE_PORT || 3000,
        host: process.env.WAREHOUSE_SERVICE_HOST || 'warehouse-service',
      },
      transport: Transport.TCP,
    };

    this.envConfig.userService = {
      options: {
        port: process.env.USER_SERVICE_PORT || 3000,
        host: process.env.USER_SERVICE_HOST || 'user-service',
      },
      transport: Transport.TCP,
    };
    this.envConfig.warehouseLayoutService = {
      options: {
        port: process.env.WAREHOUSE_LAYOUT_SERVICE_PORT || 3000,
        host:
          process.env.WAREHOUSE_LAYOUT_SERVICE_HOST ||
          'warehouse-layout-service',
      },
      transport: Transport.TCP,
    };

    this.envConfig.settingService = {
      options: {
        port: process.env.SETTING_SERVICE_PORT || 3001,
        host: process.env.SETTING_SERVICE_HOST || 'setting-service',
      },
      transport: Transport.TCP,
    };
    this.envConfig.hqItemService = {
      options: {
        port: process.env.HQ_ITEM_SERVICE_PORT || 3000,
        host: process.env.HQ_ITEM_SERVICE_HOST || 'hq-item-service',
      },
      transport: Transport.TCP,
    };
    this.envConfig.hqReportService = {
      options: {
        port: process.env.HQ_REPORT_SERVICE_PORT || 3001,
        host: process.env.HQ_REPORT_SERVICE_HOST || 'report-service',
      },
      transport: Transport.TCP,
    };
    this.envConfig.reportService = {
      options: {
        port: process.env.REPORT_SERVICE_PORT || 3001,
        host: process.env.REPORT_SERVICE_HOST || 'report-service',
      },
      transport: Transport.TCP,
    };

    this.envConfig.datasyncService = {
      options: {
        port: process.env.DATASYNC_SERVICE_PORT || 3000,
        host: process.env.DATASYNC_SERVICE_HOST || 'datasync-service',
      },
      transport: Transport.TCP,
    };
    this.envConfig.companyDefault = {
      options: {
        name: process.env.COMPANY_NAME_DEFAULT || 'Công ty Thủy điện Buôn Kuốp',
        code: process.env.COMPANY_CODE_DEFAULT || '030400',
      },
    };
    this.envConfig.endpointEcat = {
      endpoint: process.env.ENPOINT_ECAT || 'http://61.28.233.43:8283',
    };
    this.envConfig.databaseConfig = {
      type: 'postgres',
      host: process.env.DATABASE_HOST,
      port: parseInt(process.env.DATABASE_PORT),
      username: process.env.DATABASE_USERNAME,
      password: process.env.DATABASE_PASSWORD,
      database: process.env.DATABASE_NAME,
      logging: process.env.NODE_ENV === 'development',
      entities: ['dist/entities/**/*.entity.js', 'src/entities/*.ts'],
      migrations: ['dist/database/migrations/*.js', 'src/database/migrations'],
      subscribers: ['dist/observers/subscribers/*.subscriber.js'],
      cli: {
        entitiesDir: 'src/entities/*.ts',
        migrationsDir: 'src/database/migrations',
        subscribersDir: 'src/observers/subscribers',
      },
      // We are using migrations, synchronize should be set to false.
      synchronize: false,
      // Run migrations automatically,
      // you can disable this if you prefer running migration manually.
      migrationsRun: false,
      extra: {
        max: 20,
      },
      namingStrategy: new SnakeNamingStrategy(),
    };
  }

  get(key: string): any {
    return this.envConfig[key];
  }
}
