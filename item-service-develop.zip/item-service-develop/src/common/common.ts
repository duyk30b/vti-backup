export enum APIPrefix {
  Version = 'api/v1/items',
}
