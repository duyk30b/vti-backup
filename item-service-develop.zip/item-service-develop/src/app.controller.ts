import { NATS_ITEM, NATS_USER } from '@config/nats.config';
import { Public } from '@core/decorator/set-public.decorator';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Body, Controller, Get } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiBearerAuth } from '@nestjs/swagger';
import { ResponseBuilder } from '@utils/response-builder';
import { AppService } from './app.service';
@Controller()
@ApiBearerAuth('access-token')
export class AppController {
  constructor(
    private readonly appService: AppService,
    private readonly natsClientService: NatsClientService,
  ) {}

  getHello(): string {
    return this.appService.getHello();
  }

  @Public()
  @Get('health')
  getHealth(): string {
    return this.appService.getHealth();
  }

  @MessagePattern(`${NATS_ITEM}.ping`)
  pingServer(@Body() body: any) {
    return new ResponseBuilder()
      .withData({ msg: `${NATS_ITEM}: pong`, data: body })
      .build();
  }

  @Get('ping-nats')
  async pingNats(): Promise<any> {
    const pingUser = await this.natsClientService.send(`${NATS_USER}.ping`, {
      msg: 'ping',
      queue: NATS_USER,
    });
    const pingSelf = await this.natsClientService.send(`${NATS_ITEM}.ping`, {
      msg: 'ping',
      queue: NATS_ITEM,
    });
    return new ResponseBuilder()
      .withData({ data: { pingSelf, pingUser } })
      .build();
  }
}
