import { QUEUES_NAME_ENUM } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsInt, IsOptional, IsString } from 'class-validator';

export class FindJobRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @IsEnum(QUEUES_NAME_ENUM)
  queueName: string;

  @ApiProperty()
  @IsInt()
  jobId: number;
}
