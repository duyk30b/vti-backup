import { DeleteJobRequestDto } from '../dto/request/delete-job.request.dto';
import { GetDetailJobRequestDto } from '../dto/request/get-detail-job.request.dto';
import { GetListJobQueueMonitorRequestDto } from '../dto/request/get-list-job-queue-monitor.request.dto';
import { UpdateJobRequestDto } from '../dto/request/update-job.request.dto';

export interface MonitorQueueServiceInterface {
  getListJob(request: GetListJobQueueMonitorRequestDto): Promise<any>;
  getDetailJob(request: GetDetailJobRequestDto): Promise<any>;
  updateJob(request: UpdateJobRequestDto): Promise<any>;
  deleteJob(request: DeleteJobRequestDto): Promise<any>;
}
