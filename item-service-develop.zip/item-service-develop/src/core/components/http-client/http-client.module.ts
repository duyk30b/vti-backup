import { HttpClientService } from './http-client.service';
import { HttpModule, HttpService } from '@nestjs/axios';
import { Global, Module } from '@nestjs/common';
import { ConfigService } from '@config/config.service';
import { HttpClientCronService } from './http-client.cron.service';

@Global()
@Module({
  imports: [
    HttpModule.register({
      timeout: 5000,
      maxRedirects: 5,
    }),
    HttpModule,
  ],
  providers: [
    HttpClientService,
    HttpClientCronService,
    {
      provide: 'ConfigServiceInterface',
      useClass: ConfigService,
    },
  ],
  exports: [HttpClientService, HttpClientCronService],
})
export class HttpClientModule {}
