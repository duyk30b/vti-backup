import { DashboardModule } from './components/dashboard/dashboard.module';
import { FileModule } from './components/file/file.module';
import { ObjectCategoryModule } from './components/object-category/object-category.module';
import { ItemModule } from '@components/item/item.module';
import { ItemSettingModule } from '@components/item-setting/item-setting.module';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthModule } from './components/auth/auth.module';
import { CoreModule } from './core/core.module';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { BlockModule } from '@components/block/block.module';
import { PackageModule } from '@components/package/package.module';
import { UserModule } from '@components/user/user.module';
import { I18nJsonLoader, I18nModule } from 'nestjs-i18n';
import * as path from 'path';
import { ValidationPipe } from '@core/pipe/validation.pipe';
import { InventoryNormModule } from '@components/inventory-norm/inventory-norm.module';
import { APP_GUARD, APP_PIPE } from '@nestjs/core';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ConfigService } from '@config/config.service';
import { StaticModule } from '@components/static/static.module';
import { UserService } from '@components/user/user.service';
import { QueryResolver } from './i18n/query-resolver';
import { SuspendItemModule } from '@components/suspend-item/suspend-item.module';
import { QrCodeModule } from '@components/qr-code/qr-code.module';
import { PalletModule } from '@components/pallet/pallet.module';
import { ExportModule } from '@components/export/export.module';
import { BootModule } from '@nestcloud/boot';
import { resolve } from 'path';
import { ConsulModule } from '@nestcloud/consul';
import { BOOT, CONSUL } from '@nestcloud/common';
import { ServiceModule } from '@nestcloud/service';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { KongGatewayModule } from '@core/components/kong-gateway/kong-gateway.module';
import { AuthorizationGuard } from '@core/guards/authorization.guard';
import { SnakeNamingStrategy } from 'typeorm-naming-strategies';
import { ItemQualityModule } from '@components/item-quanlity/item-quality.module';
import { ManufacturingCountryModule } from '@components/manufacturing-country/manufacturing-country.module';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { InventoryTimeNormModule } from '@components/inventory-time-norm/inventory-time-norm.module';
import { InventoryQuantityNormModule } from '@components/inventory-quantity-norm/inventory-quantity-norm.module';
import { ItemPlanningQuantityModule } from '@components/item-planning-quantity/item-planning-quantity.module';
import { BullModule } from '@nestjs/bull';
import { ItemWarehouseModule } from '@components/item-warehouse/item-warehouse.module';
import { WarehouseLayoutModule } from '@components/warehouse-layout/warehouse-layout.module';
import { isDevMode } from './utils/helper';
import { ItemStockInformationModule } from '@components/item-stock-information/item-stock-information.module';
import { DatasyncModule } from '@components/datasync/datasync.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    I18nModule.forRoot({
      fallbackLanguage: 'vi',
      loader: I18nJsonLoader,
      loaderOptions: {
        path: path.join(__dirname, '/i18n/'),
        watch: true,
      },
      resolvers: [{ use: QueryResolver, options: ['lang', 'locale', 'l'] }],
    }),
    BootModule.forRoot({
      filePath: resolve(__dirname, '../config.yaml'),
    }),
    ConsulModule.forRootAsync({ inject: [BOOT] }),
    ServiceModule.forRootAsync({ inject: [BOOT, CONSUL] }),
    HttpClientModule,
    KongGatewayModule.forRootAsync(),
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DATABASE_POSTGRES_HOST,
      port: parseInt(process.env.DATABASE_POSTGRES_PORT),
      username: process.env.DATABASE_POSTGRES_USERNAME,
      password: process.env.DATABASE_POSTGRES_PASSWORD,
      database: process.env.DATABASE_NAME,
      logging: isDevMode(),
      entities: [path.join(__dirname, '/entities/**/*.entity.{ts,js}')],
      migrations: [path.join(__dirname, '/database/migrations/*.{ts,js}')],
      subscribers: ['dist/observers/subscribers/*.subscriber.{ts,js}'],
      // We are using migrations, synchronize should be set to false.
      synchronize: false,
      // Run migrations automatically,
      // you can disable this if you prefer running migration manually.
      migrationsRun: !isDevMode(),
      extra: {
        max: parseInt(process.env.DATABASE_MAX_POOL) || 20,
      },
      namingStrategy: new SnakeNamingStrategy(),
    }),
    BullModule.forRoot({
      redis: {
        host: process.env.REDIS_HOST,
        port: Number(process.env.REDIS_PORT),
        password: process.env.REDIS_PASSWORD,
      },
    }),
    EventEmitterModule.forRoot(),
    CoreModule,
    AuthModule,
    ItemModule,
    ItemSettingModule,
    BlockModule,
    PackageModule,
    WarehouseModule,
    InventoryNormModule,
    UserModule,
    StaticModule,
    SuspendItemModule,
    QrCodeModule,
    ExportModule,
    PalletModule,
    ExportModule,
    ObjectCategoryModule,
    ItemQualityModule,
    ManufacturingCountryModule,
    // RequestItemCodeModule,
    InventoryTimeNormModule,
    InventoryQuantityNormModule,
    ItemPlanningQuantityModule,
    ItemWarehouseModule,
    ItemStockInformationModule,
    WarehouseLayoutModule,
    // SyncDataFromHqModule,
    DatasyncModule,
    FileModule,
    DashboardModule,
  ],
  controllers: [AppController],
  providers: [
    ConfigService,
    {
      provide: APP_PIPE,
      useClass: ValidationPipe,
    },
    {
      provide: APP_GUARD,
      useClass: AuthorizationGuard,
    },
    {
      provide: 'USER_SERVICE',
      useFactory: (configService: ConfigService) => {
        const userServiceOptions = configService.get('userService');
        return ClientProxyFactory.create(userServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    AppService,
  ],
})
export class AppModule {}
