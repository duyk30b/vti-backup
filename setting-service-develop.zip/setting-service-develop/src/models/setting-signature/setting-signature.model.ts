import { BaseModel } from "@core/model/base.model";


export interface SettingSignatureModel extends BaseModel {
  typeObject: Number;
  roleId: String;
  signature: String;
}