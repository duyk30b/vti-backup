import { TypeObjectEnum } from '@components/setting-signature/setting-signature.constant';
import { BaseSchema } from '@core/model/base.schema';

export const SettingSignatureSchema = BaseSchema('settingSignature', {
  typeObject: {
    type: Number,
    enum: TypeObjectEnum,
  },
  roleId: {
    type: String,
  },
  signature: {
    type: String,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  updatedAt: {
    type: Date,
    default: Date.now(),
  }
});
