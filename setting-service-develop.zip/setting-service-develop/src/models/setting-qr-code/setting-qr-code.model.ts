import { CreatedFromWareHouseEnum } from '@components/setting-qr-code/setting-qr-code.constant';
import { BaseModel } from '@core/model/base.model';

export class AttributeValue {
  id: string;
  value: string;
  length: number;
}

export class InitializationMethod {
  id: {
    id: string;
    length: number;
  };
  subId1: AttributeValue;
  subId2: AttributeValue;
  subId3: AttributeValue;
}

export interface SettingQrCode extends BaseModel {
  version: AttributeValue;
  initializationMethod: InitializationMethod;
  uniqueId: AttributeValue;
  createdFrom: CreatedFromWareHouseEnum;
  syncStatus: [];
}
