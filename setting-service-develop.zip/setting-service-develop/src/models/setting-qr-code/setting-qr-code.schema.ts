import { CreatedFromWareHouseEnum } from '@components/setting-qr-code/setting-qr-code.constant';
import { BaseSchema } from '@core/model/base.schema';
import { Schema } from 'mongoose';

const AttributeValue = new Schema({
  id: {
    type: String,
    required: true,
  },
  value: {
    type: String,
    required: true,
  },
  length: {
    type: Number,
    required: true,
  },
});

const InitializationMethod = new Schema({
  id: {
    type: {
      id: { type: String },
      length: { type: Number },
    },
  },
  subId1: {
    type: AttributeValue,
  },
  subId2: {
    type: AttributeValue,
  },
  subId3: {
    type: AttributeValue,
  },
});

export const SettingQrCodeSchema = BaseSchema('settingQrCode', {
  version: {
    type: AttributeValue,
  },
  initializationMethod: {
    type: InitializationMethod,
  },
  uniqueId: {
    type: AttributeValue,
  },
  createdFrom: {
    type: Number,
    enum: CreatedFromWareHouseEnum,
  },
  syncStatus: {
    type: Array,
    default: [],
  },
});
