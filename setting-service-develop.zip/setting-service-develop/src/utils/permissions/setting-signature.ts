import { FORMAT_CODE_PERMISSION } from '../../constant/common';
import { StatusPermission } from '../common';

export const CONFIG_SIGNATURE_GROUP_PERMISSION = {
  name: 'Cấu hình chữ ký',
  code: FORMAT_CODE_PERMISSION + 'CONFIG_SIGNATURE_GROUP',
  status: StatusPermission.ACTIVE,
};

export const CREATE_CONFIG_SIGNATURE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CREATE_CONFIG_SIGNATURE',
  name: 'Tạo chữ ký',
  groupPermissionSettingCode: CONFIG_SIGNATURE_GROUP_PERMISSION.code,
  status: StatusPermission.ACTIVE,
};

export const DELETE_CONFIG_SIGNATURE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DELETE_CONFIG_SIGNATURE',
  name: 'Xóa chữ ký',
  groupPermissionSettingCode: CONFIG_SIGNATURE_GROUP_PERMISSION.code,
  status: StatusPermission.INACTIVE,
};

export const LIST_CONFIG_SIGNATURE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'LIST_CONFIG_SIGNATURE',
  name: 'Danh sách chữ ký',
  groupPermissionSettingCode: CONFIG_SIGNATURE_GROUP_PERMISSION.code,
  status: StatusPermission.ACTIVE,
};

export const CONFIG_SIGNATURE_PERMISSION = [
  CREATE_CONFIG_SIGNATURE_PERMISSION,
  DELETE_CONFIG_SIGNATURE_PERMISSION,
  LIST_CONFIG_SIGNATURE_PERMISSION,
]