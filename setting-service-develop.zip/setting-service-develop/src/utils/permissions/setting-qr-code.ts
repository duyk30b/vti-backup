import { FORMAT_CODE_PERMISSION, StatusPermission } from "@constant/common";

export const SETTING_QR_CODE_GROUP_PERMISSION = {
  name:'Cấu hình QRCode vật tư',
  code: FORMAT_CODE_PERMISSION + 'QR_CODE_SETTING_GROUP',
  status:StatusPermission.ACTIVE
}
export const CREATE_QR_CODE_SETTING_PERMISSION = {
  name: 'Tạo qr setting mới',
  code: FORMAT_CODE_PERMISSION + 'CREATE_QR_CODE_SETTING',
  groupPermissionSettingCode: SETTING_QR_CODE_GROUP_PERMISSION.code,
  status: StatusPermission.ACTIVE,
};

export const GET_QR_CODE_SETTING_PERMISSION = {
  name: 'Lấy qr setting mới',
  code: FORMAT_CODE_PERMISSION + 'GET_QR_CODE_SETTING',
  groupPermissionSettingCode: SETTING_QR_CODE_GROUP_PERMISSION.code,
  status: StatusPermission.ACTIVE,
};

export const SETTING_QR_CODE_PERMISSION = [
  CREATE_QR_CODE_SETTING_PERMISSION,
  GET_QR_CODE_SETTING_PERMISSION,
];
