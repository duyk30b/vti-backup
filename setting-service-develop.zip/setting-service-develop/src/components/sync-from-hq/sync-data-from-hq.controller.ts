import { Body, Controller, Inject, Post } from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { SyncDataFromHqServiceInterface } from './interface/sync-data-from-hq.service.interface';
import { isEmpty } from 'lodash';
import { SyncQrSettingFromHqRequest } from './request/sync-qr-setting.request.dto';
@Controller('sync')
export class SyncDataFromHqController {
  constructor(
    @Inject('SyncDataFromHqServiceInterface')
    private readonly syncDataFromHqService: SyncDataFromHqServiceInterface,
  ) {}

  @Post('setting-qr')
  @ApiOperation({
    tags: ['Sync'],
    summary: 'Sync business type data from HQ',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: SuccessResponse,
  })
  async syncBusinessTypeDataFromHQ(
    @Body() payload: SyncQrSettingFromHqRequest,
  ) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.syncDataFromHqService.syncSettingQr(request);
  }
}
