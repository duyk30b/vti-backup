import { SettingQrCodeModule } from '@components/setting-qr-code/setting-qr-code.module';
import { UserModule } from '@components/user/user.module';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { SettingQrCodeSchema } from 'src/models/setting-qr-code/setting-qr-code.schema';
import { SettingQrCodeRepository } from 'src/repository/setting-qr-code.repository';
import { SyncDataFromHqController } from './sync-data-from-hq.controller';
import { SyncDataFromHqService } from './sync-data-from-hq.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'SettingQrCode', schema: SettingQrCodeSchema },
    ]),
    UserModule,
    SettingQrCodeModule,
  ],
  controllers: [SyncDataFromHqController],
  providers: [
    {
      provide: 'SyncDataFromHqServiceInterface',
      useClass: SyncDataFromHqService,
    },
    {
      provide: 'SettingQrCodeRepositoryInterface',
      useClass: SettingQrCodeRepository,
    },
  ],
  exports: [
    {
      provide: 'SyncDataFromHqServiceInterface',
      useClass: SyncDataFromHqService,
    },
  ],
})
export class SyncDataFromHqModule {}
