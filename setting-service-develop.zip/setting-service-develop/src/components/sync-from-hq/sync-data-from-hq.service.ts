import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { SyncDataFromHqServiceInterface } from './interface/sync-data-from-hq.service.interface';

import { SyncQrSettingFromHqRequest } from './request/sync-qr-setting.request.dto';
import { SettingQrCodeRepository } from 'src/repository/setting-qr-code.repository';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { SettingQrCodeServiceInterface } from '@components/setting-qr-code/dto/interface/setting-qr-code.service.interface';

@Injectable()
export class SyncDataFromHqService implements SyncDataFromHqServiceInterface {
  constructor(
    @Inject('SettingQrCodeRepositoryInterface')
    private readonly settingQrCodeRepository: SettingQrCodeRepository,

    @Inject('SettingQrCodeServiceInterface')
    private readonly settingQrCodeService: SettingQrCodeServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async syncSettingQr(request: SyncQrSettingFromHqRequest): Promise<any> {
    for (const item of request.items) {
      const res = this.settingQrCodeService.update(item.data as any);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(res)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
  }
}
