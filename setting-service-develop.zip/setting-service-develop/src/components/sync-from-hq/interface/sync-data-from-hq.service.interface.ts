import { SyncQrSettingFromHqRequest } from '../request/sync-qr-setting.request.dto';

export interface SyncDataFromHqServiceInterface {
  syncSettingQr(request: SyncQrSettingFromHqRequest): Promise<any>;
}
