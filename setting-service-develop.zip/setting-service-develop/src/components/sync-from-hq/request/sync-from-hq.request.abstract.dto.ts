import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsDateString,
  IsDefined,
  IsEnum,
  IsInt,
  IsNotEmptyObject,
  IsObject,
  IsString,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import {
  ActionTypeEnum,
  CompanyCreatedEnum,
  MasterDataTypeEnum,
} from '../sync-data-from-hq.constant';

export enum StatusEnum {
  ACTIVE = 1,
  INACTIVE = 0,
}

export class SyncItem<T> {
  @ApiProperty({ example: 1, description: '' })
  @IsEnum(ActionTypeEnum)
  actionType: ActionTypeEnum;

  @ApiProperty({ example: 0, description: '' })
  @IsEnum(MasterDataTypeEnum)
  masterDataType: MasterDataTypeEnum;

  @ApiProperty({ example: 1, description: '' })
  @IsEnum(CompanyCreatedEnum)
  createdFrom: CompanyCreatedEnum;

  @ApiProperty({ example: '', description: '' })
  @IsObject()
  data: T;
}

export class MetaData {
  @ApiProperty({
    example: 10,
    type: Number,
  })
  @IsInt()
  total: number;

  @ApiProperty({
    example: new Date(),
    type: Date,
  })
  @IsDateString()
  syncTime: Date;
}

export class SyncDataFromHqRequest<T> extends BaseDto {
  @ApiProperty({ description: '', type: SyncItem, isArray: true })
  @IsArray()
  @ValidateNested()
  @Type(() => SyncItem<T>)
  items: SyncItem<T>[];

  @ApiProperty({ example: '', description: '', type: MetaData })
  @IsDefined()
  @IsNotEmptyObject()
  @ValidateNested()
  @Type(() => MetaData)
  meta: MetaData;
}
