import { SyncDataFromHqRequest } from './sync-from-hq.request.abstract.dto';

export class QrSetting {
  id: number;
  version: AttributeValue;
  initializationMethod: InitializationMethod;
  uniqueId: AttributeValue;
  createdAt: Date;
  updatedAt: Date;
}

export class AttributeValue {
  id: string;
  length: number;
  value: string;
}

export class Attribute {
  id: string;
  length: number;
}

export class InitializationMethod {
  id: Attribute;
  subId1: AttributeValue;
  subId2: AttributeValue;
  subId3: AttributeValue;
}

export class SyncQrSettingFromHqRequest extends SyncDataFromHqRequest<QrSetting> {}
