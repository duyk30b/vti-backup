import { GetListFactoryResponseDto } from '@components/user/dto/response/get-list-factory.response.dto';
import { GetUserListResponseDto } from '@components/user/dto/response/get-user-list.response.dto';
import { NATS_USER } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Inject, Injectable } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { Filter, Sort } from '@utils/pagination.query';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { UserServiceInterface } from './interface/user.service.interface';

@Injectable()
export class UserService implements UserServiceInterface {
  constructor(
    private readonly natsClientService: NatsClientService,

    private readonly i18n: I18nRequestScopeService,

    @Inject(REQUEST)
    private readonly request: any,
  ) {}
  getUserListByDepartmentWithPagination(
    filter: Filter[],
    page: number,
    limit: number,
    sort: Sort[],
    keyword: string,
    department: string,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }

  async insertPermission(permissions): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_USER}.insert_permission`,
      permissions,
    );
  }
  async deletePermissionNotActive(): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_USER}.delete_permission_not_active`,
      {},
    );
  }
  async detailUser(id: number, isGetData = false): Promise<any> {
    const res = await this.natsClientService.send(`${NATS_USER}.detail`, {
      id,
    });

    if (isGetData) {
      return res?.data;
    }
    return res;
  }

  async getListUserByIds(userIds: any): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_USER}.get_users_by_ids`,
      userIds,
    );
  }

  async detailFactory(id: number): Promise<any> {
    return await this.natsClientService.send(`${NATS_USER}.detail_factory`, {
      id: id,
      userId: this.request.userId,
    });
  }

  async getUserList(): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.list`,
        {},
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      const result = plainToInstance(
        GetUserListResponseDto,
        response.data.items,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (err) {
      return [];
    }
  }
  async getFactoryList(filter?: any): Promise<any> {
    const params = {
      isGetAll: '1',
      ...filter,
    };
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.list_factories`,
        params,
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      const result = plainToInstance(
        GetListFactoryResponseDto,
        response.data.items,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (err) {
      return [];
    }
  }

  async detailFactoryById(id: number): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.detail_factory`,
        {
          id: id,
        },
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return null;
      }
      return response.data;
    } catch (err) {
      return null;
    }
  }

  async detailCompany(id: number): Promise<any> {
    return await this.natsClientService.send(`${NATS_USER}.company_detail`, {
      id: id,
      userId: this.request.userId,
    });
  }

  async listUserByIds(userIds: number[]): Promise<any> {
    return await this.natsClientService.send(`${NATS_USER}.get_users_by_ids`, {
      userIds,
    });
  }

  async getListByIDs(ids: number[], relation?: string[]): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.get_users_by_ids`,
        {
          userIds: ids,
          relation,
        },
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      return response.data;
    } catch (err) {
      return [];
    }
  }

  async getUserById(id: number): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.detail`,
        {
          id: id,
          userId: 1, //@TODO: pass userId login
        },
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return null;
      }
      return response.data;
    } catch (err) {
      console.log(err);
      return null;
    }
  }
  async getUserListByDepartment(): Promise<any> {
    try {
      const departmentNameFilter = 'IT';
      const request = {
        isGetAll: '1',
        filter: [
          {
            column: 'departmentName',
            text: departmentNameFilter.trim(),
          },
        ],
      };
      const response = await this.natsClientService.send(
        `${NATS_USER}.list`,
        request,
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }

      const result = plainToInstance(
        GetUserListResponseDto,
        response.data.items,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (err) {
      return [];
    }
  }

  async getUsersByUsernames(usernames: string[]): Promise<any[]> {
    try {
      const response = await this.natsClientService.send(`${NATS_USER}.list`, {
        filter: [{ column: 'usernames', text: usernames }],
        isGetAll: '1',
      });

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      return response.data.items;
    } catch (err) {
      return [];
    }
  }

  async getRoleSettingByIds(ids: number[]): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.get_role_setting_by_ids`,
        {
          ids: ids,
        },
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      return response.data;
    } catch (error) {
      return [];
    }
  }
}
