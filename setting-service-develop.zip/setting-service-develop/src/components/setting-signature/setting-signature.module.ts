import { Global, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { UserModule } from '@components/user/user.module';
import { SettingSignatureSchema } from 'src/models/setting-signature/setting-signature.schema';
import { SettingSignatureService } from './setting-signature.service';
import { SettingSignatureController } from './setting-signature.controller';
import { SettingSignatureRepository } from 'src/repository/setting-signature.repository';

@Global()
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'SettingSignature', schema: SettingSignatureSchema },
    ]),
    UserModule,
  ],
  exports: [
    MongooseModule,
    {
      provide: 'SettingSignatureServiceInterface',
      useClass: SettingSignatureService,
    },
    {
      provide: 'SettingSignatureRepositoryInterface',
      useClass: SettingSignatureRepository,
    },
  ],
  controllers: [SettingSignatureController],
  providers: [
    {
      provide: 'SettingSignatureServiceInterface',
      useClass: SettingSignatureService,
    },
    {
      provide: 'SettingSignatureRepositoryInterface',
      useClass: SettingSignatureRepository,
    },
  ],
})
export class SettingSignatureModule {}