import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { CreateSettingSignatureRequestDto } from './dto/request/create-setting-signature.request.dto';
import { SettingSignatureRepositoryInterface } from './interface/setting-signature.repository.interface';
import { SettingSignatureServiceInterface } from './interface/setting-signature.service.interface';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DetailSettingSignatureRequestDto } from './dto/request/delete-setting-signature.request.dto';
import { UserService } from '@components/user/user.service';
import { plainToInstance } from 'class-transformer';
import { GetListSignatureResponseDto } from './dto/response/get-list-signature.response.dto';
import { GetListSettingSignatureRequestDto } from './dto/request/get-list-setting-signature.request.sto';
import { TypeObjectEnum } from './setting-signature.constant';

@Injectable()
export class SettingSignatureService
  implements SettingSignatureServiceInterface
{
  constructor(
    @Inject('SettingSignatureRepositoryInterface')
    private readonly settingSignatureRepository: SettingSignatureRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userServiceInterface: UserService,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async createSettingSignature(
    request: CreateSettingSignatureRequestDto,
  ): Promise<any> {
    const { signatures, typeObject } = request;
    const check = signatures.length;
    if (check > 7) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.QUANTITY_SIGNATURE_INVALID'),
        )
        .build();
    }
    try {
      await this.settingSignatureRepository.deleteAllByCondition({
        typeObject: typeObject,
      });
      const documents = signatures.map((item) => {
        return {
          updateOne: {
            filter: {
              typeObject: typeObject,
              roleId: item?.roleId,
              signature: item?.signature,
            },
            update: {
              typeObject: typeObject || TypeObjectEnum.PURCHASED_ORDER_IMPORT,
              roleId: item?.roleId,
              signature: item?.signature,
            },
            upsert: true,
          },
        };
      });
      await this.settingSignatureRepository.bulkWrite(documents);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder(error?.message)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async deleteDocument(id: DetailSettingSignatureRequestDto): Promise<any> {
    let result = await this.settingSignatureRepository.deleteByCondition({
      _id: id,
    });
    if (result.deletedCount) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } else {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }
  }

  async getAll(request: GetListSettingSignatureRequestDto): Promise<any> {
    const { typeObject } = request;
    if (!typeObject) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
    const signatures = await this.settingSignatureRepository.findAllByCondition(
      {
        typeObject: typeObject,
      },
    );
    const result = signatures.map((el) => {
      const tempObj = {
        _id: el?._id,
        createdAt: el?.createdAt,
        updatedAt: el?.updatedAt,
        typeObject: el?.typeObject,
        signature: el?.signature,
        roleSetting: el?.roleId,
      };
      return tempObj;
    });
    const response = plainToInstance(GetListSignatureResponseDto, result, {
      excludeExtraneousValues: true,
    });
    const count = response.length;
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
