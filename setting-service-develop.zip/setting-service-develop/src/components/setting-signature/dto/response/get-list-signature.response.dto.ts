import { BaseResponseDto } from "@core/dto/base.response.dto";
import { ApiProperty } from "@nestjs/swagger";
import { Expose } from "class-transformer";

class RoleSettingDto {
  @Expose()
  @ApiProperty()
  id: number

  @Expose()
  @ApiProperty()
  code: string

  @Expose()
  @ApiProperty()
  name: string

  @Expose()
  @ApiProperty()
  description: string
}

export class GetListSignatureResponseDto extends BaseResponseDto {
  @Expose()
  @ApiProperty()
  typeObject: number

  @Expose()
  @ApiProperty()
  signature: string

  @Expose()
  @ApiProperty()
  roleSetting: RoleSettingDto[]
}