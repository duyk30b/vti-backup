import { TypeObjectEnum } from '@components/setting-signature/setting-signature.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsInt,
  IsArray,
  IsEnum,
  IsString,
  ValidateNested,
  IsOptional,
} from 'class-validator';

export class Signature {
  @ApiProperty()
  @IsInt()
  @IsOptional()
  @IsEnum(TypeObjectEnum)
  typeObject: number;

  @ApiProperty()
  @IsInt()
  roleId: string;

  @ApiProperty()
  @IsString()
  signature: string;
}

export class CreateSettingSignatureRequestDto extends BaseDto {
  @ApiProperty()
  @IsEnum(TypeObjectEnum)
  typeObject: TypeObjectEnum;

  @ApiProperty({
    example: [{ typeObject: 2, roleId: 'nguoi ky', signature: 'abc' }],
    description: '',
  })
  @IsArray()
  @ValidateNested({ each: true })
  signatures: Signature[];
}
