import {
  Body,
  Controller,
  Get,
  Inject,
  Post,
  Delete,
  Param,
  Query,
} from '@nestjs/common';
import { SettingSignatureServiceInterface } from './interface/setting-signature.service.interface';
import { ApiOperation, ApiResponse, ApiParam } from '@nestjs/swagger';
import { CreateSettingSignatureRequestDto } from './dto/request/create-setting-signature.request.dto';
import { isEmpty } from 'lodash';
import { DetailSettingSignatureRequestDto } from './dto/request/delete-setting-signature.request.dto';
import {
  CREATE_CONFIG_SIGNATURE_PERMISSION,
  DELETE_CONFIG_SIGNATURE_PERMISSION,
  LIST_CONFIG_SIGNATURE_PERMISSION,
} from '@utils/permissions/setting-signature';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { GetListSettingSignatureRequestDto } from './dto/request/get-list-setting-signature.request.sto';
import { MessagePattern } from '@nestjs/microservices';
import { Public } from '@core/decorator/set-public.decorator';
import { GetListSignatureResponseDto } from './dto/response/get-list-signature.response.dto';
import { NATS_SETTING } from '@config/nats.config';

@Controller('setting-signature')
export class SettingSignatureController {
  constructor(
    @Inject('SettingSignatureServiceInterface')
    private readonly settingSignatureService: SettingSignatureServiceInterface,
  ) {}

  @PermissionCode(CREATE_CONFIG_SIGNATURE_PERMISSION.code)
  @ApiOperation({
    tags: ['Setting Signature'],
    summary: 'Create and update Signature',
    description: 'Tạo Signature mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  @Post('/create')
  public async create(
    @Body() body: CreateSettingSignatureRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.settingSignatureService.createSettingSignature(request);
  }

  @PermissionCode(DELETE_CONFIG_SIGNATURE_PERMISSION.code)
  @ApiOperation({
    tags: ['Setting Signature'],
    summary: 'delete Signature',
    description: 'delete',
  })
  @ApiResponse({
    status: 200,
    description: 'successfully',
  })
  @ApiParam({ name: 'id', type: String, example: '63438f9d6086283342731b11' })
  @Delete('/delete/:id')
  async delete(@Param() param: DetailSettingSignatureRequestDto) {
    const { request, responseError } = param;
    if (!isEmpty(responseError)) {
      return responseError;
    }
    return await this.settingSignatureService.deleteDocument(request.id);
  }

  @PermissionCode(LIST_CONFIG_SIGNATURE_PERMISSION.code)
  @ApiOperation({
    tags: ['Setting Signature'],
    summary: 'get list Signature by typeObject',
    description: 'get list',
  })
  @ApiResponse({
    status: 200,
    description: 'successfully',
    type: GetListSignatureResponseDto,
  })
  @Get('/list')
  async getList(@Query() query: GetListSettingSignatureRequestDto) {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.settingSignatureService.getAll(request);
  }

  @Public()
  @MessagePattern(`${NATS_SETTING}.get_list_signature_by_typeObject`)
  public async getListSignatureByTypeObject(
    @Body() query: GetListSettingSignatureRequestDto,
  ) {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.settingSignatureService.getAll(request);
  }
}
