import { CreateSettingSignatureRequestDto } from "../dto/request/create-setting-signature.request.dto";
import { DetailSettingSignatureRequestDto } from "../dto/request/delete-setting-signature.request.dto";
import { GetListSettingSignatureRequestDto } from "../dto/request/get-list-setting-signature.request.sto";

export interface SettingSignatureServiceInterface {
  createSettingSignature(request: CreateSettingSignatureRequestDto): Promise<any>;
  deleteDocument(id: DetailSettingSignatureRequestDto): Promise<any>
  getAll(typeObject: GetListSettingSignatureRequestDto): Promise<any>
}