import { BaseInterfaceRepository } from "@core/repository/base.interface.repository";
import { SettingSignatureModel } from "src/models/setting-signature/setting-signature.model";
import { CreateSettingSignatureRequestDto, Signature } from "../dto/request/create-setting-signature.request.dto";

export interface SettingSignatureRepositoryInterface
  extends BaseInterfaceRepository<SettingSignatureModel> {
  createDocument(data: Signature): Promise<any>
  updateDocument(id: string, data: Signature): Promise<any>
}
