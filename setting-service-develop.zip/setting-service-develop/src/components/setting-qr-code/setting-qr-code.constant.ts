export enum CreatedFromWareHouseEnum {
  HOLDING_COMPANY = 0,
  PHU_MY = 1,
  VINH_TAN = 2,
  EPS = 3,
  MONG_DUONG = 4,
  BUON_KUOP = 5,
}

export enum IsViewEnum {
  ONLY_VIEW = 0,
  ACCEPT_INPUT = 1,
}

export enum QrStatusEnum {
  INACTIVE = 0,
  ACTIVE = 1,
}

export const SETTING_QR_RULES = {
  VERSION: {
    MAX_LENGTH: 3,
  },
  SUB_ID_1: {
    MAX_LENGTH: 4,
  },
  SUB_ID_2: {
    MAX_LENGTH: 4,
  },
  SUB_ID_3: {
    MAX_LENGTH: 4,
  },
  UNIQUE_ID: {
    MAX_LENGTH: 8,
  },
};

export const SETTING_QR_FIXED_INFO = {
  VERSION: {
    ID: '00',
  },
  INITIALIZATION_METHOD: {
    ID: {
      ID: '01',
    },
    SUB_ID_1: {
      ID: '01',
    },
    SUB_ID_2: {
      ID: '02',
    },
    SUB_ID_3: {
      ID: '03',
    },
  },
  UNIQUE_ID: {
    ID: '03',
  },
};

export const NUMBER_CHARACTER_REGEX = /^[0-9]+$/;

export enum MongoSortOrderEnum {
  ASC = 1,
  DESC = -1,
}
