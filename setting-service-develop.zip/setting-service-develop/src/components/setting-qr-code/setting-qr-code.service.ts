import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { SettingQrCodeRepositoryInterface } from './dto/interface/setting-qr-code.repository.interface';
import { SettingQrCodeServiceInterface } from './dto/interface/setting-qr-code.service.interface';
import { CreateSettingQrCodeDto } from './dto/request/update-setting-qr-code.request';
import { SettingQrCodeResponseDto } from './dto/response/setting-qr-code.response.dto';
import { MongoSortOrderEnum } from './setting-qr-code.constant';

@Injectable()
export class SettingQrCodeService implements SettingQrCodeServiceInterface {
  constructor(
    @Inject('SettingQrCodeRepositoryInterface')
    private readonly settingQrCodeRepository: SettingQrCodeRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async update(request: CreateSettingQrCodeDto): Promise<any> {
    const existSetting = await this.settingQrCodeRepository.findOneByCondition({
      'version.value': request.version,
    });
    const document = this.settingQrCodeRepository.updateDocument(
      request,
      existSetting,
    );

    const setting = await this.settingQrCodeRepository.createOrUpdate(document);
    const data = plainToInstance(SettingQrCodeResponseDto, setting, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(data)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async detail(): Promise<any> {
    const newestSetting =
      await this.settingQrCodeRepository.findOneByConditionAndOptions(
        {},
        {},
        { sort: { updatedAt: MongoSortOrderEnum.DESC } },
      );
    if (!newestSetting) {
      const setting = this.settingQrCodeRepository.getDefaultSetting();
      const data = plainToInstance(SettingQrCodeResponseDto, setting, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(data)
        .withMessage(await this.i18n.translate('error.DATA_NOT_INITIALIZED'))
        .build();
    } else {
      const data = plainToInstance(SettingQrCodeResponseDto, newestSetting, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(data)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
  }
}
