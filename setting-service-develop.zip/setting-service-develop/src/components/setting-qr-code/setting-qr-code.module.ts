import { UserModule } from '@components/user/user.module';
import { Global, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { SettingQrCodeSchema } from 'src/models/setting-qr-code/setting-qr-code.schema';
import { SettingQrCodeRepository } from 'src/repository/setting-qr-code.repository';
import { SettingQrCodeController } from './setting-qr-code.controller';
import { SettingQrCodeService } from './setting-qr-code.service';

@Global()
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'SettingQrCode', schema: SettingQrCodeSchema },
    ]),
    UserModule,
  ],
  exports: [
    MongooseModule,
    {
      provide: 'SettingQrCodeServiceInterface',
      useClass: SettingQrCodeService,
    },
    {
      provide: 'SettingQrCodeRepositoryInterface',
      useClass: SettingQrCodeRepository,
    },
  ],
  controllers: [SettingQrCodeController],
  providers: [
    {
      provide: 'SettingQrCodeServiceInterface',
      useClass: SettingQrCodeService,
    },
    {
      provide: 'SettingQrCodeRepositoryInterface',
      useClass: SettingQrCodeRepository,
    },
  ],
})
export class SettingQrCodeModule {}
