import { CreatedFromWareHouseEnum } from '@components/setting-qr-code/setting-qr-code.constant';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class AttributeValue {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  value: string;

  @ApiProperty()
  @Expose()
  length: number;
}

export class AttributeLength {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  length: number;
}

export class InitializationMethod {
  @ApiProperty()
  @Expose()
  @Type(() => AttributeLength)
  id: {
    id: string;
    length: number;
  };

  @ApiProperty()
  @Expose()
  @Type(() => AttributeValue)
  subId1: AttributeValue;

  @ApiProperty()
  @Expose()
  @Type(() => AttributeValue)
  subId2: AttributeValue;

  @ApiProperty()
  @Expose()
  @Type(() => AttributeValue)
  subId3: AttributeValue;
}

export class SettingQrCodeResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => AttributeValue)
  version: AttributeValue;

  @ApiProperty()
  @Expose()
  @Type(() => InitializationMethod)
  initializationMethod: InitializationMethod;

  @ApiProperty()
  @Expose()
  @Type(() => AttributeValue)
  uniqueId: AttributeValue;

  @ApiProperty()
  @Expose()
  createdFrom: string;

  @ApiProperty()
  @Expose()
  syncStatus: any;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty()
  @Expose()
  updatedAt: string;
}
