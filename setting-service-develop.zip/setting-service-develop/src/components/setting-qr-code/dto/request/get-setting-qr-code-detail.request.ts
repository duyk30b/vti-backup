import { BaseDto } from '@core/dto/base.dto';

export class GetSettingQrCode extends BaseDto {}
