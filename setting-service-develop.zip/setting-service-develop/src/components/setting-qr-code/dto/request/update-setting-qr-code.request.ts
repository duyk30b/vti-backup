import {
  NUMBER_CHARACTER_REGEX,
  SETTING_QR_RULES,
} from '@components/setting-qr-code/setting-qr-code.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsObject,
  IsString,
  Matches,
  MaxLength,
  ValidateNested,
} from 'class-validator';

export class InitializationMethod {
  @ApiProperty({ example: '01', description: 'giá trị 1' })
  @IsString()
  @MaxLength(SETTING_QR_RULES.SUB_ID_1.MAX_LENGTH)
  @Matches(NUMBER_CHARACTER_REGEX)
  subId1Value: string;

  @ApiProperty({ example: '01', description: 'giá trị 2' })
  @IsString()
  @MaxLength(SETTING_QR_RULES.SUB_ID_2.MAX_LENGTH)
  @Matches(NUMBER_CHARACTER_REGEX)
  subId2Value: string;

  @ApiProperty({ example: '01', description: 'giá trị 3' })
  @IsString()
  @MaxLength(SETTING_QR_RULES.SUB_ID_3.MAX_LENGTH)
  @Matches(NUMBER_CHARACTER_REGEX)
  subId3Value: string;
}

export class CreateSettingQrCodeDto extends BaseDto {
  @ApiProperty({ example: '01', description: 'Phiên bản dữ liệu ' })
  @IsString()
  @MaxLength(SETTING_QR_RULES.VERSION.MAX_LENGTH)
  @Matches(NUMBER_CHARACTER_REGEX)
  version: string;

  @ApiProperty({ description: 'Phương thức khởi tạo ' })
  @IsObject()
  @ValidateNested()
  @Type(() => InitializationMethod)
  initializationMethod: InitializationMethod;

  @ApiProperty({ description: 'ID phân định duy nhất ' })
  @IsString()
  @MaxLength(SETTING_QR_RULES.UNIQUE_ID.MAX_LENGTH)
  @Matches(NUMBER_CHARACTER_REGEX)
  uniqueId: string;
}
