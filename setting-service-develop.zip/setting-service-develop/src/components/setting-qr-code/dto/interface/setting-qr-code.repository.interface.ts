import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { SettingQrCode } from 'src/models/setting-qr-code/setting-qr-code.model';
import { CreateSettingQrCodeDto } from '../request/update-setting-qr-code.request';

export interface SettingQrCodeRepositoryInterface
  extends BaseInterfaceRepository<SettingQrCode> {
  updateDocument(
    request: CreateSettingQrCodeDto,
    setting: SettingQrCode,
  ): SettingQrCode;
  getDefaultSetting(): SettingQrCode;
}
