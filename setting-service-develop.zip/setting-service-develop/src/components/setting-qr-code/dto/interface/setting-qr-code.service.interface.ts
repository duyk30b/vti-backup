import { CreateSettingQrCodeDto } from '../request/update-setting-qr-code.request';

export interface SettingQrCodeServiceInterface {
  update(request: CreateSettingQrCodeDto): Promise<any>;
  detail(): Promise<any>;
}
