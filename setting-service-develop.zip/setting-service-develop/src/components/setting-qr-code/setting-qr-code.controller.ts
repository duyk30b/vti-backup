import { Body, Controller, Get, Inject, Post, Req } from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateSettingQrCodeDto } from './dto/request/update-setting-qr-code.request';
import { isEmpty } from 'lodash';
import { SettingQrCodeServiceInterface } from './dto/interface/setting-qr-code.service.interface';
import { SettingQrCodeResponseDto } from './dto/response/setting-qr-code.response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { GetSettingQrCode } from './dto/request/get-setting-qr-code-detail.request';

@Controller('setting-qr')
export class SettingQrCodeController {
  constructor(
    @Inject('SettingQrCodeServiceInterface')
    private readonly settingQrCodeService: SettingQrCodeServiceInterface,
  ) {}

  @Post('update')
  @ApiOperation({
    tags: ['Setting QR Code'],
    summary: 'Create qr setting',
    description: 'Tạo qr setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: SettingQrCodeResponseDto,
  })
  public async update(@Body() body: CreateSettingQrCodeDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.settingQrCodeService.update(request);
  }

  @Get()
  @ApiOperation({
    tags: ['Setting QR Code'],
    summary: 'Get qr setting',
    description: 'Lấy qr setting mới',
  })
  @ApiResponse({
    status: 200,
    description: ' successfully',
    type: SuccessResponse,
  })
  public async get(@Req() req: GetSettingQrCode): Promise<any> {
    const { responseError } = req;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.settingQrCodeService.detail();
  }
}
