import { SettingSignatureRepositoryInterface } from '@components/setting-signature/interface/setting-signature.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { SettingSignatureModel } from 'src/models/setting-signature/setting-signature.model';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Signature } from '@components/setting-signature/dto/request/create-setting-signature.request.dto';
import { TypeObjectEnum } from '@components/setting-signature/setting-signature.constant';

@Injectable()
export class SettingSignatureRepository extends BaseAbstractRepository<SettingSignatureModel> implements SettingSignatureRepositoryInterface {
  constructor(
    @InjectModel('SettingSignature')
    private readonly settingSignatureModel: Model<SettingSignatureModel>
  ) {
    super(settingSignatureModel);
  }

  async createDocument(data: Signature): Promise<any> {
    const document = new this.settingSignatureModel();
    document.typeObject = data?.typeObject || TypeObjectEnum.PURCHASED_ORDER_IMPORT;
    document.roleId = data.roleId;
    document.signature = data.signature
    return document;
  }

  updateDocument(id: string, data: Signature): Promise<any> {
    const document = this.settingSignatureModel
      .findOneAndUpdate(
        {
          _id: id,
        },
        {
          signature: data.signature,
        },
      )
      .exec();
    return document;
  }
}