import { SettingQrCodeRepositoryInterface } from '@components/setting-qr-code/dto/interface/setting-qr-code.repository.interface';
import { CreateSettingQrCodeDto } from '@components/setting-qr-code/dto/request/update-setting-qr-code.request';
import { SETTING_QR_FIXED_INFO } from '@components/setting-qr-code/setting-qr-code.constant';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import {
  AttributeValue,
  InitializationMethod,
  SettingQrCode,
} from 'src/models/setting-qr-code/setting-qr-code.model';

@Injectable()
export class SettingQrCodeRepository
  extends BaseAbstractRepository<SettingQrCode>
  implements SettingQrCodeRepositoryInterface
{
  constructor(
    @InjectModel('SettingQrCode')
    private readonly settingQrCodeModel: Model<SettingQrCode>,
  ) {
    super(settingQrCodeModel);
  }
  updateDocument(
    request: CreateSettingQrCodeDto,
    existSetting?: SettingQrCode,
  ): SettingQrCode {
    const document = existSetting
      ? existSetting
      : new this.settingQrCodeModel();
    document.version = new AttributeValue();
    document.version.id = SETTING_QR_FIXED_INFO.VERSION.ID;
    document.version.length = request.version.length;
    document.version.value = request.version;

    document.initializationMethod = new InitializationMethod();
    document.initializationMethod.id = {
      id: SETTING_QR_FIXED_INFO.INITIALIZATION_METHOD.ID.ID,
      length:
        request.initializationMethod.subId1Value.length +
        request.initializationMethod.subId2Value.length +
        request.initializationMethod.subId3Value.length,
    };

    document.initializationMethod.subId1 = {
      id: SETTING_QR_FIXED_INFO.INITIALIZATION_METHOD.SUB_ID_1.ID,
      length: request.initializationMethod.subId1Value.length,
      value: request.initializationMethod.subId1Value,
    };

    document.initializationMethod.subId2 = {
      id: SETTING_QR_FIXED_INFO.INITIALIZATION_METHOD.SUB_ID_2.ID,
      length: request.initializationMethod.subId2Value.length,
      value: request.initializationMethod.subId2Value,
    };

    document.initializationMethod.subId3 = {
      id: SETTING_QR_FIXED_INFO.INITIALIZATION_METHOD.SUB_ID_3.ID,
      length: request.initializationMethod.subId3Value.length,
      value: request.initializationMethod.subId3Value,
    };

    document.uniqueId = {
      id: SETTING_QR_FIXED_INFO.UNIQUE_ID.ID,
      length: request.uniqueId.length,
      value: request.uniqueId,
    };
    return document;
  }
  getDefaultSetting(): SettingQrCode {
    const document = new this.settingQrCodeModel();
    document.version = new AttributeValue();
    document.version.id = SETTING_QR_FIXED_INFO.VERSION.ID;
    document.version.length = null;
    document.version.value = null;

    document.initializationMethod = new InitializationMethod();
    document.initializationMethod.id = {
      id: SETTING_QR_FIXED_INFO.INITIALIZATION_METHOD.ID.ID,
      length: null,
    };

    document.initializationMethod.subId1 = {
      id: SETTING_QR_FIXED_INFO.INITIALIZATION_METHOD.SUB_ID_1.ID,
      length: null,
      value: null,
    };

    document.initializationMethod.subId2 = {
      id: SETTING_QR_FIXED_INFO.INITIALIZATION_METHOD.SUB_ID_2.ID,
      length: null,
      value: null,
    };

    document.initializationMethod.subId3 = {
      id: SETTING_QR_FIXED_INFO.INITIALIZATION_METHOD.SUB_ID_3.ID,
      length: null,
      value: null,
    };

    document.uniqueId = {
      id: SETTING_QR_FIXED_INFO.UNIQUE_ID.ID,
      length: null,
      value: null,
    };
    return document;
  }
}
