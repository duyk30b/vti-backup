export interface ExportResponse {
  nameFile: string;
  result: string;
}
