export interface ReportResponse {
  nameFile: string;
  result: any;
}
