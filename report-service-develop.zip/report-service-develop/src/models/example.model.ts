import { BaseModel } from '@core/model/base.model';
export interface ExampleModel extends BaseModel {
  id: string;
  name: string;
}
