export interface ReOderQuantityModel {
  company: string;
  warehouse: string;
  itemCode: string;
  itemName: string;
  unit: string;
  reorderQuantity: string;
}
