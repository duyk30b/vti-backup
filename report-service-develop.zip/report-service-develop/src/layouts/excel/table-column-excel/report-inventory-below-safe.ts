export const INVENTORY_BELOW_SAFE = [
  {
    name: 'INDEX',
    width: 10,
  },
  {
    name: 'ITEM_CODE',
    width: 19.9,
  },
  {
    name: 'ITEM_NAME',
    width: 39.9,
  },
  {
    name: 'UNIT',
    width: 10,
  },
  {
    name: 'QUANTITY_SAFE',
    width: 14,
  },
  {
    name: 'QUANTITY_STOCK',
    width: 14,
  },
];
