export const ITEM_INVENTORY_IMPORTED_NO_QR_CODE_COLUMN = [
  {
    name: 'INDEX',
    width: 10,
  },
  {
    name: 'ORDER_EXPORT_CODE',
    width: 20,
  },
  {
    name: 'ITEM_CODE',
    width: 20,
  },
  {
    name: 'ITEM_NAME',
    width: 35,
  },
  {
    name: 'UNIT',
    width: 10,
  },
  {
    name: 'LOT',
    width: 10,
  },
  {
    name: 'LOCATION_IMPORT',
    width: 20,
  },
  {
    name: 'QUANTITY',
    width: 10,
  },
  {
    name: 'UNIT_PRICE',
    width: 10,
  },
  {
    name: 'TOTAL_PRICE',
    width: 10,
  },
];
