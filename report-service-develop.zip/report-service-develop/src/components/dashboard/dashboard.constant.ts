export enum ReportType {
  DAY = 0,
  MONTH = 1,
  QUARTER = 2,
}
