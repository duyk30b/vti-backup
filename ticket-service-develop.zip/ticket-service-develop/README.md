### Run project in local
1. Setup env
- Set: NODE_ENV=development
- Start database in local
- Set env: CONTAINER_NETWORK_IP
- Set env: mongo


2. Run compose in local: `make local`
3. Build image: `make build`