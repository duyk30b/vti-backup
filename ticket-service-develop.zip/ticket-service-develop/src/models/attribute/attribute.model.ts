export class Attribute {
  id: string;
  code: string;
  name: string;
  value: any;
  dataType: number;
}
