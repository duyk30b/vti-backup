import {
  DEFAULT_COLLATION,
  TICKET_TYPE_ENUM,
  STATUS_ENUM,
  PICK_UP_TYPE_ENUM,
} from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { ObjectId } from 'mongodb';
import { Types } from 'mongoose';
import { Attribute } from '../attribute/attribute.model';
import { TicketDetail } from './ticket-details.schema';
@Schema()
class Warehouse {
  @Prop({
    type: Number,
    required: false,
  })
  id?: number;
}

@Schema()
class Impersonator {
  @Prop({
    type: Number,
    required: false,
  })
  id?: number;
}
@Schema({
  timestamps: true,
  collection: 'tickets',
  collation: DEFAULT_COLLATION,
})
export class Ticket extends BaseModel {
  @Prop({
    type: String,
    required: true,
  })
  code: string;

  @Prop({
    type: String,
    required: false,
  })
  name: string;

  @Prop({
    type: Types.ObjectId,
    required: false,
  })
  templateId: Types.ObjectId;

  @Prop({
    type: ObjectId,
    required: false,
  })
  requestId: string;

  @Prop({
    type: Number,
    enum: TICKET_TYPE_ENUM,
    required: true,
    default: TICKET_TYPE_ENUM.IMPORT,
  })
  type: number;

  @Prop({
    type: Number,
    required: false,
  })
  warehouseId: number;

  @Prop({
    type: Number,
    required: false,
  })
  warehouseImportId: number;

  @Prop({
    type: Number,
    required: false,
  })
  warehouseExportId: number;

  @Prop({
    type: String,
    required: false,
  })
  description: string;

  @Prop({
    type: Number,
    required: false,
  })
  reasonId: number;

  ticketId: number;

  @Prop({
    type: Number,
    enum: STATUS_ENUM,
    required: true,
    default: STATUS_ENUM.WAITING,
  })
  status: number;

  @Prop({
    type: Date,
    required: false,
  })
  receiptDate: Date;

  @Prop({
    type: Date,
    required: false,
  })
  deliveryDate: Date;

  @Prop({
    type: Number,
    enum: PICK_UP_TYPE_ENUM,
    required: false,
    default: PICK_UP_TYPE_ENUM.FIFO,
  })
  pickUpType: number;

  //Kiểm kê
  //kho
  @Prop({
    type: [SchemaFactory.createForClass(Warehouse)],
    require: false,
  })
  warehouses: Warehouse[];

  //Người thực hiện
  @Prop({
    type: [SchemaFactory.createForClass(Impersonator)],
    require: false,
  })
  impersonators: Impersonator[];

  @Prop({
    type: Number,
    required: false,
  })
  inventoryType: number;

  @Prop({
    type: Date,
    required: false,
  })
  inventoryPeriodDate: Date; //Ngày chốt kỳ

  @Prop({
    type: Date,
    required: false,
  })
  executeExpectFrom: Date; //Ngày kiểm kê dự kiến

  @Prop({
    type: Date,
    required: false,
  })
  executeExpectTo: Date; //Ngày kiểm kê dự kiến

  @Prop({
    type: Boolean,
    required: false,
  })
  blockTicket: boolean; //Chặn nhập xuất

  @Prop({
    type: Number,
    required: false,
  })
  inventoryForm: number; //Hình thức kiểm kê

  @Prop({
    type: Number,
  })
  createdBy: number;

  @Prop({
    type: Number,
    required: false,
  })
  updatedBy: number;

  @Prop({
    type: Number,
    required: false,
  })
  confirmedBy: number;

  @Prop({
    type: Number,
    required: false,
  })
  completedBy: number;

  @Prop({
    type: Date,
    required: false,
  })
  deletedAt: Date;

  @Prop({
    type: Date,
    required: false,
  })
  confirmedAt: Date;

  @Prop({
    type: Date,
    required: false,
  })
  completedAt: Date;

  @Prop({
    type: Attribute,
    require: false,
  })
  attributes: Attribute[];

  ticketDetails: TicketDetail[];
}

export const TicketSchema = SchemaFactory.createForClass(Ticket);
TicketSchema.virtual('ticketDetails', {
  ref: TicketDetail.name,
  localField: '_id',
  foreignField: 'ticketId',
  justOne: false,
});
