import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Types } from 'mongoose';
import { Attribute } from '../attribute/attribute.model';
import { Ticket } from './ticket.schema';

@Schema({
  timestamps: true,
  collection: 'ticketDetails',
  collation: DEFAULT_COLLATION,
})
export class TicketDetail extends BaseModel {
  @Prop({
    type: Types.ObjectId,
    required: true,
    ref: 'Ticket',
  })
  ticketId: Types.ObjectId;

  @Prop({
    type: Number,
    required: true,
  })
  itemId: number;

  @Prop({
    type: String,
    required: false,
  })
  lot: string;

  @Prop({
    type: String,
    required: false,
  })
  groupId: string;

  @Prop({
    type: Types.ObjectId,
    required: false,
  })
  locatorId: Types.ObjectId;

  @Prop({
    type: Number,
    required: false,
  })
  price: number;

  @Prop({
    type: Number,
    required: true,
  })
  quantity: number;

  @Prop({
    type: Number,
    required: false,
  })
  actualQuantity: number;

  @Prop({
    type: Number,
    required: false,
  })
  storedQuantity: number;

  @Prop({
    type: Number,
    required: false,
  })
  amount: number;

  @Prop({
    type: Date,
    required: false,
  })
  mfgDate: Date;

  @Prop({
    type: Date,
    required: false,
  })
  importDate: Date;

  @Prop({
    type: Number,
    required: false,
    default: 0,
  })
  actualPickUpQuantity: number;

  @Prop({
    type: Number,
    required: false,
    default: 0,
  })
  actualPutAwayQuantity: number;

  @Prop({
    type: Attribute,
    require: false,
  })
  attributes: Attribute[];
}

export const TicketDetailSchema = SchemaFactory.createForClass(TicketDetail);
