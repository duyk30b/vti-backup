import {
  ConditionOrder,
  FilterItemByCondition,
} from '@components/receipt/dto/request/get-list-ticket-by-item.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { TicketDetail } from 'src/models/ticket/ticket-details.schema';

export interface TicketDetailRepositoryInterface
  extends BaseInterfaceRepository<TicketDetail> {
  getDetail(id: string): Promise<any>;
  getListTicketByItems(
    conditions: FilterItemByCondition[],
    order?: ConditionOrder,
  ): Promise<any>;
}
