import { GetListTicketRequestDto } from '@utils/dto/request/get-list-ticket.request.dto';
import { GetDetailTicketRequestDto } from '@utils/dto/request/get-detail-ticket.request.dto';
import { CreateTicketRequestDto } from '@utils/dto/request/create-ticket.request.dto';
import { UpdateTicketRequestDto } from '@utils/dto/request/update-ticket.request.dto';
import { DeleteTicketRequestDto } from '@utils/dto/request/delete-ticket.request.dto';
import { GetTicketDetailResponseDto } from '@utils/dto/response/get-ticket-detail.response.dto';

export interface TicketServiceInterface {
  getList(request: GetListTicketRequestDto): Promise<any>;
  getDetail(
    request: GetDetailTicketRequestDto,
  ): Promise<GetTicketDetailResponseDto>;
  create(request: CreateTicketRequestDto): Promise<any>;
  update(request: UpdateTicketRequestDto): Promise<any>;
  delete(request: DeleteTicketRequestDto): Promise<any>;
  updateStatus(request: any): Promise<any>;
}
