import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { Ticket } from 'src/models/ticket/ticket.schema';
import { CreateTicketRequestDto } from '@utils/dto/request/create-ticket.request.dto';
import { UpdateTicketRequestDto } from '@utils/dto/request/update-ticket.request.dto';
import { GetListTicketRequestDto } from '@utils/dto/request/get-list-ticket.request.dto';
import { GetPickingListRequestDto } from '@components/export-receipt/dto/request/get-picking-list.request.dto';
import { GetTicketByKeywordRequestDto } from '@components/receipt/dto/request/get-ticket-by-keyword.dto';
import { CreateInventoryRequestDto } from '@components/inventory/dto/request/create-inventory.request.dto';
export interface TicketRepositoryInterface
  extends BaseInterfaceRepository<Ticket> {
  getDetail(id: string): Promise<any>;
  createDocument(request: CreateTicketRequestDto): Ticket;
  updateDocument(ticket: Ticket, request: CreateTicketRequestDto): Ticket;
  getTicketCode(dateCode: string): Promise<any>;
  createEntity(request: CreateTicketRequestDto): Ticket;
  updateEntity(entity: Ticket, request: UpdateTicketRequestDto): Ticket;
  getList(request: GetListTicketRequestDto, type: number): Promise<any>;
  getTicketByTicketId(ticketId: number): Promise<any>;
  getTicketByRequestIds(requestIds: string[]): Promise<any>;
  getPickingList(request: GetPickingListRequestDto): Promise<any>;
  findTicketByCodeKeyword(request: GetTicketByKeywordRequestDto): Promise<any>;
  createEntityInventory(request: CreateInventoryRequestDto): Ticket;
  updateEntityInventory(ticket: Ticket, data: any): Ticket;
}
