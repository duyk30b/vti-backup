import { ApiProperty } from '@nestjs/swagger';
import { TicketResponseDto } from './ticket.response.dto';
import { Expose } from 'class-transformer';
import { TicketDetailResponseDto } from './ticket-detail.response.dto';

export class GetTicketDetailResponseDto extends TicketResponseDto {
  @ApiProperty()
  @Expose()
  items: TicketDetailResponseDto[];
}
