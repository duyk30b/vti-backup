import { BaseUserResponseDto } from '@components/user/dto/response/base.user.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class Warehouse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

class Attribute {
  @Expose()
  id: string;

  @Expose()
  code: string;

  @Expose()
  value: any;
}

export class TicketResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  requestCode: string;

  @ApiProperty()
  @Expose()
  requestId: number;

  @ApiProperty()
  @Expose()
  @Type(() => BaseResponseDto)
  warehouseImportRequest: BaseResponseDto;

  @ApiProperty()
  @Expose()
  templateId: string;

  @ApiProperty()
  @Expose()
  @Type(() => Attribute)
  attributes: Attribute[];

  @ApiProperty()
  @Expose()
  type: string;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  @Type(() => Warehouse)
  warehouse: Warehouse;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  reasonID: number;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  receiptDate: Date;

  @ApiProperty()
  @Expose()
  createdBy: BaseUserResponseDto;

  @ApiProperty()
  @Expose()
  updatedBy: BaseUserResponseDto;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  @Type(() => BaseResponseDto)
  template: BaseResponseDto;
}
