import { BaseUserResponseDto } from '@components/user/dto/response/base.user.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { ObjectId } from 'bson';
import { Expose, Type } from 'class-transformer';
import { Attribute } from 'src/models/attribute/attribute.model';

class File {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  fileName: string;
}

export class TicketDetailResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => File)
  attachment: File;

  @ApiProperty()
  @Expose()
  @Type(() => Attribute)
  attributes: Attribute[];

  @ApiProperty()
  @Expose()
  ticketId: ObjectId;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  amount: number;

  @ApiProperty()
  @Expose()
  mfgDate: Date;

  @ApiProperty()
  @Expose()
  @Type(() => BaseUserResponseDto)
  createdBy: BaseResponseDto;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}
