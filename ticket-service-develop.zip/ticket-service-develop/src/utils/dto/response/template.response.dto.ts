import { InventoryResponseDto } from '@components/inventory/dto/response/inventory.response.dto';
import { Expose, Type } from 'class-transformer';
export class Table {
  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  uri: string;
}
export class AttributeRule {
  @Expose()
  dataSource: any;

  @Expose()
  isRequired: number;

  @Expose()
  canUpdate: number;

  @Expose()
  display: number;

  @Expose()
  disable: number;

  @Expose()
  @Type(() => Table)
  table: Table;
}
export class Attribute {
  @Expose()
  id: string;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  value: any;

  @Expose()
  dataType: any;
}
export class AttributeHeader {
  @Expose()
  order: number;

  @Expose()
  @Type(() => AttributeRule)
  attributeRule: AttributeRule;

  @Expose()
  @Type(() => Attribute)
  attribute: Attribute;
}
export class AtrtributeGroupBody {
  @Expose()
  id: string;

  @Expose()
  order: number;

  @Expose()
  code: string;

  @Expose()
  @Type(() => AttributeHeader)
  attributes: AttributeHeader[];
}
export class AttributeGroup {
  @Expose()
  @Type(() => AtrtributeGroupBody)
  attributeGroup: AtrtributeGroupBody[];
}

export class TemplateResponse extends InventoryResponseDto {
  @Expose()
  @Type(() => InventoryResponseDto)
  inventory: InventoryResponseDto;

  @Expose()
  @Type(() => AttributeHeader)
  attributeHeaders: AttributeHeader[];

  @Expose()
  @Type(() => AttributeGroup)
  attributeGroups: AttributeGroup[];
}
