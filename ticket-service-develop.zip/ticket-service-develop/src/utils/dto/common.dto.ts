import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';

export class DetailDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
