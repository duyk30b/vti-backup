import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateTicketRequestDto } from './create-ticket.request.dto';

export class UpdateTicketBodyDto extends CreateTicketRequestDto {}
export class UpdateTicketRequestDto extends UpdateTicketBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
