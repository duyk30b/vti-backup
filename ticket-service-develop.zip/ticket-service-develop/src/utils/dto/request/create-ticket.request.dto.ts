import { UNIT_CONST } from '@components/unit/unit.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsPositive,
  IsString,
  MaxLength,
} from 'class-validator';
import { Types } from 'mongoose';
import { Attribute } from 'src/models/attribute/attribute.model';
import { File } from 'src/models/file/file.model';
import { TicketDetail } from 'src/models/ticket/ticket-details.schema';

export class CreateTicketRequestDto extends BaseDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  templateId: Types.ObjectId;

  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  requestId: string;

  @ApiProperty()
  @IsOptional()
  @Type(() => Number)
  type: number;

  @ApiProperty()
  @IsPositive()
  @IsOptional()
  @Type(() => Number)
  warehouseId: number;

  @ApiProperty()
  @IsPositive()
  @IsOptional()
  @Type(() => Number)
  warehouseImportId: number;

  @ApiProperty()
  @IsPositive()
  @IsOptional()
  @Type(() => Number)
  warehouseExportId: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @MaxLength(UNIT_CONST.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ApiProperty()
  @IsPositive()
  @IsOptional()
  @Type(() => Number)
  reasonId: number;

  @ApiProperty()
  @IsOptional()
  @Type(() => Date)
  ticketDate: Date;

  @ApiProperty()
  @IsOptional()
  @Type(() => Date)
  deliveryDate: Date;

  @ApiProperty()
  @IsOptional()
  @Type(() => Number)
  pickUpType: number;

  @ApiProperty()
  @ArrayNotEmpty()
  @Transform(({ value }) => JSON.parse(value))
  @Type(() => TicketDetail)
  items: TicketDetail[];

  @ApiProperty()
  @IsOptional()
  @Type(() => File)
  attachment: File[];

  @ApiProperty()
  @IsOptional()
  status: number;

  @Transform(({ value }) => JSON.parse(value))
  @IsOptional()
  @Type(() => Attribute)
  attributes: Attribute[];
}
