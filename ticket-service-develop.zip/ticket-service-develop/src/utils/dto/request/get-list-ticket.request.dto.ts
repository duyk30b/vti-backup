import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsOptional } from 'class-validator';

export class GetListTicketRequestDto extends PaginationQuery {
  @IsOptional()
  filterObj: any;
}
