
import { UNIT_GROUP_PERMISSION, UNIT_PERMISSION } from './unit';

export const PERMISSION = [
  UNIT_PERMISSION,
];

export const GROUP_PERMISSION = [
  UNIT_GROUP_PERMISSION,
];

export const INSERT_PERMISSION = {
  permission: PERMISSION,
  groupPermission: GROUP_PERMISSION,
};
