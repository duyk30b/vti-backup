import { CODE_DEFAULT } from '@utils/constant';
import { isEmpty } from 'lodash';

export function generateCode(
  latestObj: any,
  defaultCode: string,
  maxLength: number,
  padChar: string,
  gap = 1,
): string {
  let generatedCode;
  if (latestObj) generatedCode = (+latestObj.code + gap).toString();
  else generatedCode = defaultCode;

  return generatedCode.padStart(maxLength, padChar);
}

export function generatedCode(latestObj: any, constant: any, gap = 1): string {
  let generatedCode;

  if (latestObj)
    generatedCode = (Number.parseInt(latestObj.code) + gap).toString();
  else generatedCode = constant.DEFAULT_CODE;

  return generatedCode.padStart(constant.MAX_LENGTH - 1, constant.PAD_CHAR);
}

export function generateCodeByPreviousCode(
  prefix: string,
  currentCode: number,
  maxLength = CODE_DEFAULT.CODE_LENGTH,
  gap = CODE_DEFAULT.GAP,
  padChar = CODE_DEFAULT.PAD_CHAR,
): string {
  return prefix.concat(
    (currentCode + gap).toString().padStart(maxLength, padChar),
  );
}

export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function getCurrentCodeByLastRecord(codePrefix = '', lastRecord) {
  return +lastRecord.code?.replace(codePrefix, '') || 0;
}

/**
 * Generate the ticket code
 * @returns
 */
export function generateTicketCode(
  prefix: any,
  lastCode: string,
  dateTime: string,
) {
  if (!isEmpty(lastCode)) {
    const lastIncreaseId = Number(lastCode.slice(-3));
    const newIncreaseId = lastIncreaseId + 1;
    return `${prefix}${dateTime}${newIncreaseId.toString().padStart(3, '0')}`;
  }

  return `${prefix}${dateTime}000`;
}
