import { FileRepositoryInterface } from '@components/file/interface/file.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { File } from 'src/models/file/file.schema';

export class FileRepository
  extends BaseAbstractRepository<File>
  implements FileRepositoryInterface
{
  constructor(
    @InjectModel(File.name)
    private readonly fileModel: Model<File>,
  ) {
    super(fileModel);
  }

  createDocument(data: any): File {
    const { resource, resourceId, fileId, filename } = data;

    const file = new this.fileModel();
    file.resource = resource;
    file.resourceId = resourceId;
    file.fileId = fileId;
    file.filename = filename;

    return file;
  }
}
