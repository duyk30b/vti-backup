import {
  ConditionOrder,
  FilterItemByCondition,
} from '@components/receipt/dto/request/get-list-ticket-by-item.dto';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { TicketDetailRepositoryInterface } from '@utils/interface/ticket-detail.repository.interface';
import { Model } from 'mongoose';
import { TicketDetail } from 'src/models/ticket/ticket-details.schema';

export class TicketDetailRepository
  extends BaseAbstractRepository<TicketDetail>
  implements TicketDetailRepositoryInterface
{
  constructor(
    @InjectModel('TicketDetail')
    private readonly ticketDetailModel: Model<TicketDetail>,
  ) {
    super(ticketDetailModel);
  }
  getDetail(id: string): Promise<any> {
    throw new Error('Method not implemented.');
  }

  async getListTicketByItems(
    conditions: FilterItemByCondition[],
    order?: ConditionOrder,
  ): Promise<any> {
    let condition = {} as any;
    if (order) {
      condition = {
        type: order?.orderType,
      };
    }
    return await this.ticketDetailModel
      .find({
        $or: conditions,
      })
      .populate({
        match: { ...condition },
        path: 'ticketId',
      })
      .exec();
  }
}
