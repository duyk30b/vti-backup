import { GetPickingListRequestDto } from '@components/export-receipt/dto/request/get-picking-list.request.dto';
import { CreateInventoryRequestDto } from '@components/inventory/dto/request/create-inventory.request.dto';
import { GetTicketByKeywordRequestDto } from '@components/receipt/dto/request/get-ticket-by-keyword.dto';
import { STATUS_ENUM, TICKET_TYPE_ENUM } from '@constant/common';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { CreateTicketRequestDto } from '@utils/dto/request/create-ticket.request.dto';
import { GetListTicketRequestDto } from '@utils/dto/request/get-list-ticket.request.dto';
import { UpdateTicketRequestDto } from '@utils/dto/request/update-ticket.request.dto';
import { TicketRepositoryInterface } from '@utils/interface/ticket.repository.interface';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import * as mongoose from 'mongoose';
import { Model } from 'mongoose';
import { Ticket } from 'src/models/ticket/ticket.schema';

export class TicketRepository
  extends BaseAbstractRepository<Ticket>
  implements TicketRepositoryInterface
{
  constructor(
    @InjectModel('Ticket')
    private readonly ticketModel: Model<Ticket>,
  ) {
    super(ticketModel);
  }
  getDetail(id: string): Promise<any> {
    throw new Error('Method not implemented.');
  }

  createDocument(request: CreateTicketRequestDto): Ticket {
    const {
      templateId,
      requestId,
      warehouseId,
      warehouseImportId,
      warehouseExportId,
      description,
      type,
      reasonId,
      ticketDate,
      deliveryDate,
      pickUpType,
      userId,
      attributes,
    } = request;
    const ticketImport = new this.ticketModel();
    ticketImport.templateId = templateId;
    ticketImport.requestId = requestId;
    ticketImport.warehouseId = warehouseId;
    ticketImport.warehouseImportId = warehouseImportId;
    ticketImport.warehouseExportId = warehouseExportId;
    ticketImport.description = description;
    ticketImport.type = type;
    ticketImport.reasonId = reasonId;
    ticketImport.receiptDate = ticketDate;
    ticketImport.deliveryDate = deliveryDate;
    ticketImport.pickUpType = pickUpType;
    ticketImport.status = STATUS_ENUM.WAITING;
    ticketImport.attributes = attributes;
    ticketImport.createdBy = userId;
    return ticketImport;
  }

  createEntityInventory(request: CreateInventoryRequestDto): Ticket {
    const {
      code,
      name,
      type,
      templateId,
      inventoryType,
      warehouses,
      impersonators,
      inventoryPeriodDate,
      executeExpectFrom,
      executeExpectTo,
      blockTicket,
      inventoryForm,
      description,
      attributes,
      userId,
    } = request;
    const ticket = new this.ticketModel();
    ticket.code = code;
    ticket.name = name;
    ticket.type = type;
    ticket.templateId = templateId;
    ticket.inventoryType = inventoryType;
    ticket.warehouses = warehouses;
    ticket.impersonators = impersonators;
    ticket.inventoryPeriodDate = inventoryPeriodDate;
    ticket.executeExpectFrom = executeExpectFrom;
    ticket.executeExpectFrom = executeExpectFrom;
    ticket.blockTicket = blockTicket;
    ticket.executeExpectTo = executeExpectTo;
    ticket.inventoryForm = inventoryForm;
    ticket.status = STATUS_ENUM.WAITING;
    ticket.attributes = attributes;
    ticket.description = description;
    ticket.createdBy = userId;
    ticket.confirmedBy = null;
    ticket.confirmedAt = null;
    ticket.completedAt = null;
    ticket.completedBy = null;

    return ticket;
  }
  updateEntityInventory(ticket: Ticket, data: any): Ticket {
    const {
      code,
      name,
      type,
      inventoryType,
      warehouses,
      impersonators,
      inventoryPeriodDate,
      executeExpectFrom,
      executeExpectTo,
      blockTicket,
      inventoryForm,
      description,
      attributes,
    } = data;
    ticket.code = code;
    ticket.name = name;
    ticket.type = type;
    ticket.inventoryType = inventoryType;
    ticket.warehouses = warehouses;
    ticket.impersonators = impersonators;
    ticket.inventoryPeriodDate = inventoryPeriodDate;
    ticket.executeExpectFrom = executeExpectFrom;
    ticket.executeExpectFrom = executeExpectFrom;
    ticket.blockTicket = blockTicket;
    ticket.executeExpectTo = executeExpectTo;
    ticket.inventoryForm = inventoryForm;
    ticket.status = STATUS_ENUM.WAITING;
    ticket.attributes = attributes;
    ticket.description = description;
    return ticket;
  }

  updateDocument(ticket: Ticket, request: CreateTicketRequestDto): Ticket {
    const {
      warehouseId,
      warehouseImportId,
      warehouseExportId,
      description,
      type,
      reasonId,
      ticketDate,
      deliveryDate,
      pickUpType,
      userId,
      status,
      attributes,
    } = request;
    ticket.warehouseId = warehouseId;
    ticket.warehouseImportId = warehouseImportId;
    ticket.warehouseExportId = warehouseExportId;
    ticket.description = description;
    ticket.type = type;
    ticket.reasonId = reasonId;
    ticket.receiptDate = ticketDate;
    ticket.deliveryDate = deliveryDate;
    ticket.pickUpType = pickUpType;
    ticket.attributes = attributes;
    ticket.updatedBy = userId;
    ticket.status = status;
    return ticket;
  }

  async getTicketCode(dateCode: string): Promise<any> {
    return await this.ticketModel
      .findOne({ code: { $regex: dateCode + '.*', $options: 'i' } })
      .sort({ code: -1 })
      .exec();
  }

  createEntity(request: CreateTicketRequestDto): Ticket {
    throw new Error('Method not implemented.');
  }
  updateEntity(entity: Ticket, request: UpdateTicketRequestDto): Ticket {
    throw new Error('Method not implemented.');
  }

  /**
   * Get list receipt ticket
   * @param request
   * @returns
   */
  public async getList(
    request: GetListTicketRequestDto,
    type: number,
  ): Promise<any> {
    const { keyword, sort, filter, take, skip } = request;
    let filterObj = request.filterObj || {};
    let sortObj = {};

    if (keyword?.length) {
      filterObj = {
        $or: [
          { code: { $regex: `.* ${keyword} .*`, $options: 'i' } },
          {
            items: {
              $elemMatch: {
                code: { $regex: `.* ${keyword} .*`, $options: 'i' },
              },
            },
          },
        ],
      };
    }
    // Filter by type of ticket
    filterObj = {
      ...filterObj,
      type: type,
    };

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: `.*${item.text}.*`,
                $options: 'i',
              },
            };
            break;
          case 'templateId':
            filterObj = {
              ...filterObj,
              templateId: {
                $in: item.text.split(',')?.map((e) => e),
              },
            };
            break;
          case 'requestId':
            filterObj = {
              ...filterObj,
              requestId: {
                $regex: `.*${item.text}.*`,
                $options: 'i',
              },
            };
            break;
          case 'requestIds': // Filter by multiple request
            filterObj = {
              ...filterObj,
              requestIds: {
                $in: item.text
                  .split(',')
                  .map((e) => new mongoose.Types.ObjectId(e)),
              },
            };
            break;
          case 'warehouseId': // Filter by multiple warehouseticketDate
            filterObj = {
              ...filterObj,
              warehouseId: {
                $in: item.text.split(',').map((id) => parseInt(id)),
              },
            };
            break;
          case 'receiptDate':
            filterObj = {
              ...filterObj,
              receiptDate: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'status':
            filterObj = {
              ...filterObj,
              status: {
                $in: item.text?.split(',')?.map((e) => +e),
              },
            };
            break;
          default:
            break;
        }
      });
    }

    // Sort
    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const sort = item.order == 'DESC' ? -1 : 1;
        switch (item.column) {
          case 'code':
            sortObj = { ...sortObj, code: sort };
            break;
          case 'warehouseId':
            sortObj = { ...sortObj, warehouseName: sort };
            break;
          case 'receiptDate':
            sortObj = { ...sortObj, receiptDate: sort };
            break;
          case 'createdAt':
            sortObj = { ...sortObj, createdAt: sort };
            break;
          default:
            break;
        }
      });
    } else {
      // Default sort by the created at and id
      sortObj = { createdAt: -1, _id: -1 };
    }

    const data = await this.ticketModel
      .aggregate()
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();
    const count = await this.ticketModel
      .find({ ...filterObj })
      .countDocuments()
      .exec();

    return {
      data,
      count,
    };
  }

  async getTicketByTicketId(ticketId: number): Promise<any> {
    return await this.ticketModel.findOne({ ticketId: ticketId });
  }

  async getTicketByRequestIds(requestIds: string[]): Promise<any> {
    const filterObj = {
      requestId: {
        $in: requestIds.map((e) => e),
      },
    };
    return await this.ticketModel.find({ ...filterObj }).lean();
  }

  async getPickingList(request: GetPickingListRequestDto): Promise<any> {
    const {
      isPickWaiting,
      skip,
      take,
      receiptDate,
      ticketCode,
      warehouseId,
      itemIds,
    } = request;
    let filterObj = {};
    if (ticketCode) {
      filterObj = {
        ...filterObj,
        code: {
          $regex: `.*${ticketCode}.*`,
          $options: 'i',
        },
      };
    }

    if (receiptDate) {
      filterObj = {
        ...filterObj,
        receiptDate: receiptDate,
      };
    }
    if (isPickWaiting === '1') {
      filterObj = {
        ...filterObj,
        $expr: {
          $gt: [
            '$ticketDetails.quantity',
            { $ifNull: ['$ticketDetails.actualPickUpQuantity', 0] },
          ],
        },
      };
    }
    if (isPickWaiting === '0') {
      filterObj = {
        ...filterObj,
        $expr: { $gt: ['$ticketDetails.actualPickUpQuantity', 0] },
      };
    }
    if (warehouseId) {
      filterObj = {
        ...filterObj,
        'ticketDetails.warehouseId': warehouseId,
      };
    }
    if (itemIds && !isEmpty(itemIds)) {
      filterObj = {
        ...filterObj,
        'ticketDetails.itemId': {
          $in: itemIds,
        },
      };
    }

    const pipeline = [
      {
        $lookup: {
          from: 'ticketDetails',
          localField: '_id',
          foreignField: 'ticketId',
          as: 'ticketDetails',
        },
      },
      { $unwind: '$ticketDetails' },
      {
        $match: {
          type: { $in: [TICKET_TYPE_ENUM.EXPORT, TICKET_TYPE_ENUM.TRANSFER] },
          ...filterObj,
        },
      },
      {
        $group: {
          _id: {
            warehouseId: '$warehouseId',
            itemId: '$ticketDetails.itemId',
            lot: '$ticketDetails.lot',
            mfgDateFormat: {
              $dateToString: {
                format: '%d/%m/%Y',
                date: '$ticketDetails.mfgDate',
              },
            },
            importDateFormat: {
              $dateToString: {
                format: '%d/%m/%Y',
                date: '$ticketDetails.importDate',
              },
            },
            locatorId: '$ticketDetails.locatorId',
          },
          mfgDate: { $first: '$ticketDetails.mfgDate' },
          importDate: { $first: '$ticketDetails.importDate' },
          quantity: { $sum: '$ticketDetails.quantity' },
          actualQuantity: { $sum: '$ticketDetails.actualQuantity' },
          actualPickUpQuantity: { $sum: '$ticketDetails.actualPickUpQuantity' },
          tickets: {
            $push: {
              code: '$code',
              name: '$name',
              ticketId: '$_id',
              quantity: '$ticketDetails.quantity',
            },
          },
        },
      },
      {
        $project: {
          _id: 0,
          warehouseId: '$_id.warehouseId',
          itemId: '$_id.itemId',
          lot: '$_id.lot',
          mfgDateFormat: '$_id.mfgDateFormat',
          importDateFormat: '$_id.importDateFormat',
          locatorId: '$_id.locatorId',
          mfgDate: 1,
          importDate: 1,
          quantity: 1,
          actualQuantity: 1,
          actualPickUpQuantity: 1,
          tickets: 1,
        },
      },
    ];

    const data = await this.ticketModel
      .aggregate(pipeline)
      .skip(skip)
      .limit(take)
      .sort({ updatedAt: -1 })
      .exec();

    const countResult = await this.ticketModel.aggregate(pipeline).exec();
    const count = countResult.length;
    return {
      data,
      count,
    };
  }

  async findTicketByCodeKeyword(
    request: GetTicketByKeywordRequestDto,
  ): Promise<any> {
    const { codeKeyword, type } = request;
    let keywordObj = {};
    keywordObj = {
      $and: [
        {
          code: { $regex: '.*' + codeKeyword + '.*', $options: 'i' },
          type: +type,
        },
      ],
    };
    return await this.ticketModel.find(keywordObj);
  }
}
