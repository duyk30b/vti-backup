import { CreatePurchasedOrderImportReceiveTicketRequestDto } from '../dto/request/create-ticket-receive-request.dto';

export interface SaleServiceInterface {
  createPoImportReceive(
    request: CreatePurchasedOrderImportReceiveTicketRequestDto,
  ): Promise<any>;
  getReasonByIds(ids: number[], serilize?: boolean): Promise<any>;
}
