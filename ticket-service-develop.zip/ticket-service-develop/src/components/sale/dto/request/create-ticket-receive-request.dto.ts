import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsBoolean,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsPositive,
  ValidateNested,
} from 'class-validator';

export class PurchasedOrderImportReceiveTicketItemRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @IsPositive()
  actualQuantity: number;
}

export class CreatePurchasedOrderImportReceiveTicketRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  ticketId: number;

  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsBoolean()
  isComplete: boolean;

  @ApiProperty({
    type: PurchasedOrderImportReceiveTicketItemRequestDto,
    isArray: true,
  })
  @IsArray()
  @ArrayUnique<PurchasedOrderImportReceiveTicketItemRequestDto>(
    (item) => item.itemId,
  )
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => PurchasedOrderImportReceiveTicketItemRequestDto)
  items: PurchasedOrderImportReceiveTicketItemRequestDto[];
}
