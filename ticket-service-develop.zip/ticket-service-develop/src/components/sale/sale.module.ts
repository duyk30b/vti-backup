import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { SaleService } from './sale.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
  ],
  controllers: [],
})
export class SaleModule {}
