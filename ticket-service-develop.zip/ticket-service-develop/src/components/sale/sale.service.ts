import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Injectable } from '@nestjs/common';
import { plainToInstance } from 'class-transformer';
import { keyBy } from 'lodash';
import { CreatePurchasedOrderImportReceiveTicketRequestDto } from './dto/request/create-ticket-receive-request.dto';
import { ReasonResponseDto } from './dto/response/reason.response.dto';
import { SaleServiceInterface } from './interface/sale.service.interface';
import { NATS_SALE } from '@config/nats.config';

@Injectable()
export class SaleService implements SaleServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async createPoImportReceive(
    request: CreatePurchasedOrderImportReceiveTicketRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.create_purchased_order_import_receive_ticket`,
      request,
    );
    return response;
  }
  async getReasonByIds(ids: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_reason_by_ids`,
      {
        reasonIds: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const dataReturn = plainToInstance(
      ReasonResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );
    return serilize ? keyBy(dataReturn, 'id') : dataReturn;
  }
}
