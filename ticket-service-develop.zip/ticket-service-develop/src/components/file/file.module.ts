import { ConfigService } from '@config/config.service';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { FileSchema } from 'src/models/file/file.schema';
import { FileRepository } from 'src/repository/file/file.repository';
import { FileService } from './file.service';

@Module({
  imports: [
    ConfigModule,
    HttpClientModule,
    MongooseModule.forFeature([
      {
        name: 'File',
        schema: FileSchema,
      },
    ]),
  ],
  providers: [
    ConfigService,
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
    {
      provide: 'FileRepositoryInterface',
      useClass: FileRepository,
    },
  ],
  exports: [
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
    {
      provide: 'FileRepositoryInterface',
      useClass: FileRepository,
    },
  ],
})
export class FileModule {}
