export interface FileServiceInterface {
  saveFiles(resource: any, resourceId: any, files: any[]): Promise<any>;
  uploadFiles(files: any[], resource: string): Promise<any>;
  uploadFile(file: any, resource: string): Promise<any>;
  getFileById(fileId: string): Promise<any>;
}
