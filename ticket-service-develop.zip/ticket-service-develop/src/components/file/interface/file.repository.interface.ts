import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { File } from 'src/models/file/file.schema';

export interface FileRepositoryInterface extends BaseInterfaceRepository<File> {
  createDocument(data: any): File;
}
