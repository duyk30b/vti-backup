import { ConfigService } from '@config/config.service';
import { APIPrefix } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { HttpClientService } from '@core/components/http-client/http-client.service';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import * as FormData from 'form-data';
import { isEmpty } from 'lodash';
import { I18nService } from 'nestjs-i18n';
import { UPLOAD_FILE_ENPOINT } from './file.constant';
import { FileRepositoryInterface } from './interface/file.repository.interface';
import { FileServiceInterface } from './interface/file.service.interface';

@Injectable()
export class FileService implements FileServiceInterface {
  protected readonly urlConfig: any;
  protected readonly url: string;

  constructor(
    private readonly configService: ConfigService,
    private readonly httpClientService: HttpClientService,

    @Inject('FileRepositoryInterface')
    private readonly fileRepository: FileRepositoryInterface,

    private readonly i18n: I18nService,
  ) {
    this.configService = new ConfigService();
    this.urlConfig = this.configService.get('fileService');
    this.url = `http://${
      this.urlConfig?.options?.host + ':' + this.urlConfig?.options?.port
    }`;
  }

  async saveFiles(resourceId: any, resource: any, files: any): Promise<any> {
    // Delete Old Files
    if (resourceId != null) {
      await this.fileRepository.deleteManyByCondition({
        resourceId: resourceId,
      });
    }
    // Save New Files
    if (!isEmpty(files)) {
      const fileResponse = await this.uploadFiles(files, resource);
      if (fileResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(fileResponse.statusCode)
          .withMessage(fileResponse.message)
          .build();
      }
      const fileDocuments = fileResponse.data.map((fileId, index) =>
        this.fileRepository.createDocument({
          resourceId: resourceId,
          resource: resource,
          fileId,
          filename: files[index].filename,
        }),
      );

      await this.fileRepository.create(fileDocuments);
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private generateUrlFileService(type: string): string {
    return `${this.url}/${APIPrefix.Version}/${type}`;
  }

  async uploadFiles(files: any[], resource: string): Promise<any> {
    const form = new FormData();
    form.append('service', 'ticket-service');
    form.append('resource', resource);
    files.forEach((file) => {
      form.append('files', Buffer.from(file.data), {
        filename: file.filename,
      });
    });
    return await this.httpClientService.post(
      this.generateUrlFileService(UPLOAD_FILE_ENPOINT.MULTIPLE),
      form,
      {
        ...form.getHeaders(),
        callInternalService: true,
      },
    );
  }

  async uploadFile(file: any, resource: string): Promise<any> {
    const form = new FormData();
    form.append('service', 'ticket-service');
    form.append('resource', resource);
    form.append('file', Buffer.from(file.data), {
      filename: file.filename,
    });

    return await this.httpClientService.post(
      this.generateUrlFileService(UPLOAD_FILE_ENPOINT.SINGLE),
      form,
      {
        ...form.getHeaders(),
        callInternalService: true,
      },
    );
  }

  async getFileById(fileId: string): Promise<any> {
    const response = await this.httpClientService.get(
      this.generateUrlFileService(
        UPLOAD_FILE_ENPOINT.GET_FILE.replace(':id', fileId),
      ),
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return response.data;
  }
}
