export const FILE_RESOURCE = {
  RI: 'RI',
  EXPORT_RECEIPT: 'EXPORT_RECEIPT',
};

export const UPLOAD_FILE_ENPOINT = {
  MULTIPLE: 'files/multiple-files',
  SINGLE: 'files/single-file',
  GET_FILE: 'files/:id',
};
