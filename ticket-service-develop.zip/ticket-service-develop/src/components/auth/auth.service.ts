import { Injectable } from '@nestjs/common';
import { AuthServiceInterface } from '@components/auth/interface/auth.service.interface';
import { HttpService } from '@nestjs/axios';
import { InjectService } from '@nestcloud/service';
import { catchError, firstValueFrom, map, of, retry } from 'rxjs';
import { genericRetryStrategy } from '@utils/rxjs-util';
import { NATS_AUTH } from '@config/nats.config';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';

@Injectable()
export class AuthService implements AuthServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async validateToken(token: string, permissionCode: string): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_AUTH}.validate_token`,
      {
        permissionCode,
        token,
      },
    );
    return response;
  }
}
