import { isEmpty } from 'lodash';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
  Req,
} from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { DeliveryService } from './delivery.service';
import { ApiConsumes, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { GetListTicketRequestDto } from '@utils/dto/request/get-list-ticket.request.dto';
import { TicketResponseDto } from '@utils/dto/response/ticket.response.dto';
import { CreateTicketRequestDto } from '@utils/dto/request/create-ticket.request.dto';
import { UpdateTicketBodyDto } from '@utils/dto/request/update-ticket.request.dto';
import { GetDetailTicketRequestDto } from '@utils/dto/request/get-detail-ticket.request.dto';
import { DeleteTicketRequestDto } from '@utils/dto/request/delete-ticket.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { STATUS_ENUM } from '@constant/common';
import { GetTicketDetailResponseDto } from '@utils/dto/response/get-ticket-detail.response.dto';
import { DetailDto } from '@utils/dto/common.dto';

@Controller('deliveries')
export class DeliveryController {
  constructor(
    @Inject('DeliveryServiceInterface')
    private readonly service: DeliveryService,
  ) {}

  // @MessagePattern('ping')
  @Get('ping')
  public async get(@Req() request): Promise<any> {
    return new ResponseBuilder('Delivery Ticket: PONG')
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  /**
   * Get List delivery tickets
   * @param payload
   * @returns
   */
  @Get('')
  @ApiOperation({
    tags: ['Delivery Ticket'],
    summary: 'Get List of Delivery Tickets',
    description: 'Danh sách phiếu xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List of delivery tickets successfully',
    type: GetListTicketRequestDto,
  })
  public async getList(
    @Query() payload: GetListTicketRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.service.getList(request);
  }

  /**
   * Create new Delivery Ticket
   * @param payload
   * @returns
   */
  @Post()
  @ApiOperation({
    tags: ['Delivery Ticket'],
    summary: 'Create the Delivery Ticket',
    description: 'Create the Delivery Ticket',
  })
  @ApiResponse({
    status: 200,
    description: 'Create the Delivery Ticket successfully',
    type: TicketResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  public async create(@Body() body: CreateTicketRequestDto): Promise<any> {
    const { request, responseError } = body;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.create(request);
  }

  /**
   * Update Delivery Ticket
   * @param DetailDto
   * @param UpdateTicketBodyDto
   * @returns
   */
  @Put('/:id')
  @ApiOperation({
    tags: ['Delivery Ticket'],
    summary: 'Edit the Delivery Ticket',
    description: 'Edit the Delivery Ticket',
  })
  @ApiResponse({
    status: 200,
    description: 'Edit the Delivery Ticket successfully',
    type: TicketResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  public async update(
    @Param() param: DetailDto,
    @Body() body: UpdateTicketBodyDto,
  ): Promise<any> {
    const {
      request: { id },
      responseError: paramError,
    } = param;
    const { request, responseError } = body;
    if (paramError && !isEmpty(paramError)) {
      return responseError;
    }
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.service.update({ ...request, id });
  }

  /**
   * Detail Delivery Ticket
   * @param param
   * @returns
   */
  @Get('/:id')
  @ApiOperation({
    tags: ['Delivery Ticket'],
    summary: 'Detail Delivery Ticket',
    description: 'Chi tiết phiếu xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail Successfully',
    type: GetTicketDetailResponseDto,
  })
  public async getDetail(
    @Param() param: GetDetailTicketRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.service.getDetail(request);
  }

  /**
   * Delete delivery ticket
   * @param param
   * @returns
   */
  @Delete('/:id')
  @ApiOperation({
    tags: ['Delivery Ticket'],
    summary: 'Delete Delivery Ticket',
    description: 'Xoá phiếu xuất hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async delete(@Param() param: DeleteTicketRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.delete(request);
  }

  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Delivery Ticket'],
    summary: 'Confirm Delivery Ticket',
    description: 'Xác nhận phiếu xuất hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm Successfully',
    type: TicketResponseDto,
  })
  public async confirm(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.updateStatus({
      ...request,
      status: STATUS_ENUM.CONFIRM,
    });
  }

  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Delivery Ticket'],
    summary: 'Reject Delivery Ticket',
    description: 'Từ chối phiếu xuất hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject Successfully',
    type: TicketResponseDto,
  })
  public async reject(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.updateStatus({
      ...request,
      status: STATUS_ENUM.REJECT,
    });
  }
}
