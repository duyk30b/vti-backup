import { GetDetailTicketRequestDto } from '@utils/dto/request/get-detail-ticket.request.dto';
import { GetTicketDetailResponseDto } from '@utils/dto/response/get-ticket-detail.response.dto';
import { TicketServiceInterface } from '@utils/interface/ticket.service.interface';

export interface DeliveryServiceInterface extends TicketServiceInterface {
  getDetail(
    request: GetDetailTicketRequestDto,
  ): Promise<GetTicketDetailResponseDto | any>;
}
