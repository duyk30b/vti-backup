import { FileModule } from '@components/file/file.module';
import { Global, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { TicketSchema } from 'src/models/ticket/ticket.schema';
import { TicketDetailSchema } from 'src/models/ticket/ticket-details.schema';
import { TicketDetailRepository } from 'src/repository/ticket/ticket-detail.repository';
import { TicketRepository } from 'src/repository/ticket/ticket.repository';
import { UserService } from '@components/user/user.service';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { DeliveryController } from './delivery.controller';
import { DeliveryService } from './delivery.service';
import { AttributeService } from '@components/attribute/attribute.service';

@Global()
@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: 'Ticket',
        schema: TicketSchema,
      },
      {
        name: 'TicketDetail',
        schema: TicketDetailSchema,
      },
    ]),
    FileModule,
  ],
  providers: [
    {
      provide: 'DeliveryServiceInterface',
      useClass: DeliveryService,
    },
    {
      provide: 'TicketRepositoryInterface',
      useClass: TicketRepository,
    },
    {
      provide: 'TicketDetailRepositoryInterface',
      useClass: TicketDetailRepository,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'TicketDetailRepositoryInterface',
      useClass: TicketDetailRepository,
    },
    {
      provide: 'AttributeServiceInterface',
      useClass: AttributeService,
    },
  ],
  controllers: [DeliveryController],
  exports: [],
})
export class DeliveryModule {}
