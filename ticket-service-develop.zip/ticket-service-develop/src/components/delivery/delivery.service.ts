import { AttributeServiceInterface } from '@components/attribute/interface/attribute.service.interface';
import { FILE_RESOURCE } from '@components/file/file.constant';
import { FileRepositoryInterface } from '@components/file/interface/file.repository.interface';
import { FileServiceInterface } from '@components/file/interface/file.service.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import {
  DATA_TYPE_ENUM,
  MAX_FILE_SIZE,
  TICKET_TYPE_ENUM,
  STATUS_ENUM,
  IS_OPTIONAL,
} from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/mongoose';
import { CreateTicketRequestDto } from '@utils/dto/request/create-ticket.request.dto';
import { DeleteTicketRequestDto } from '@utils/dto/request/delete-ticket.request.dto';
import { GetDetailTicketRequestDto } from '@utils/dto/request/get-detail-ticket.request.dto';
import { GetListTicketRequestDto } from '@utils/dto/request/get-list-ticket.request.dto';
import { UpdateTicketRequestDto } from '@utils/dto/request/update-ticket.request.dto';
import { GetTicketDetailResponseDto } from '@utils/dto/response/get-ticket-detail.response.dto';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { TicketDetailResponseDto } from '@utils/dto/response/ticket-detail.response.dto';
import { TicketResponseDto } from '@utils/dto/response/ticket.response.dto';
import { compareDate } from '@utils/helper';
import { TicketDetailRepositoryInterface } from '@utils/interface/ticket-detail.repository.interface';
import { TicketRepositoryInterface } from '@utils/interface/ticket.repository.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { find, forEach, isEmpty, keyBy, map, uniq } from 'lodash';
import * as Moment from 'moment';
import { Connection, Types } from 'mongoose';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { Ticket } from 'src/models/ticket/ticket.schema';
import { DeliveryServiceInterface } from './interface/delivery.service.interface';
import {
  ALLOW_MIME_TYPE_ENUM,
  DELIVERY_CODE_PREFIX,
} from './delivery.constant';
import { generateTicketCode } from 'src/helper/code.helper';

@Injectable()
export class DeliveryService implements DeliveryServiceInterface {
  constructor(
    @Inject('TicketRepositoryInterface')
    private readonly ticketRepository: TicketRepositoryInterface,

    @Inject('TicketDetailRepositoryInterface')
    private readonly ticketDetailRepository: TicketDetailRepositoryInterface,

    @Inject('FileServiceInterface')
    private readonly fileService: FileServiceInterface,

    @Inject('FileRepositoryInterface')
    private readonly fileRepository: FileRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,

    @InjectConnection()
    private readonly connection: Connection,
    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('AttributeServiceInterface')
    protected readonly attributeService: AttributeServiceInterface,
  ) {}

  /**
   * Delete the Delivery Ticket
   * @param request
   * @returns
   */
  public async delete(request: DeleteTicketRequestDto): Promise<any> {
    const { id } = request;
    const ticket = await this.ticketRepository.findOneById(id);
    if (isEmpty(ticket)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    // Check status ticket
    if (
      ticket.status !== STATUS_ENUM.WAITING &&
      ticket.status !== STATUS_ENUM.REJECT
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }

    // File
    const file = await this.fileRepository.findOneByCondition({
      resourceId: id,
      resource: FILE_RESOURCE.RI,
    });

    // Start transaction
    const session = await this.connection.startSession();
    session.startTransaction();
    try {
      // Delete TicketDetails
      await this.ticketDetailRepository.deleteManyByCondition({
        ticketId: id,
      });

      // Delete file
      if (!isEmpty(file)) {
        await this.fileRepository.deleteById(file.id);
      }

      // Delete Ticket
      await this.ticketRepository.deleteById(id);

      // Commit transaction
      await session.commitTransaction();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch {
      // Abort transaction
      await session.abortTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  /**
   * Get delivery ticket detail
   * @param request
   * @returns
   */
  public async getDetail(
    request: GetDetailTicketRequestDto,
  ): Promise<GetTicketDetailResponseDto | any> {
    const { id } = request;
    const deliveryTicket = await this.ticketRepository.findOneById(id);

    if (isEmpty(deliveryTicket)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    // Items
    const items = await this.ticketDetailRepository.findAllByCondition({
      ticketId: new Types.ObjectId(id),
    });

    // Attachment
    const file = await this.fileRepository.findOneByCondition({
      resourceId: new Types.ObjectId(id),
      resource: FILE_RESOURCE.RI,
    });

    // Request info
    // TODO: waiting request service api
    // toandd.doanduc(GITS.BU2)

    // Created By User
    const createdByUser = await this.userService.getDetailUser(
      deliveryTicket.createdBy,
    );

    const dataReturn = plainToInstance(
      TicketDetailResponseDto,
      {
        ...deliveryTicket,
        attachment: file,
        items: items,
        createdBy: {
          id: createdByUser?.id,
          username: createdByUser?.username,
          fullName: createdByUser?.fullName,
        },
      },
      {
        exposeDefaultValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /* Get list delivery ticket
   * @param request
   * @returns
   */
  public async getList(request: GetListTicketRequestDto): Promise<any> {
    const { page } = request;
    if (!request.filter) request.filter = [];

    const userWarehouses = await this.userService.getUserWarehousesById(
      request.userId,
    );

    if (isEmpty(userWarehouses)) {
      return new ResponseBuilder<PaginationResponse>({
        items: [],
        meta: { total: 0, page: 1 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const { data, count } = await this.ticketRepository.getList(
      request,
      TICKET_TYPE_ENUM.EXPORT,
    );
    if (count === 0) {
      return new ResponseBuilder<PaginationResponse>({
        items: [],
        meta: { total: 0, page: 1 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    let dataSortWarehouseId = data.map((i) => ({
      ...i,
    }));

    // Warehouse
    const warehouseIds = uniq(map(data, 'warehouseId'));
    const warehouseList = await this.warehouseService.getList([
      {
        column: 'ids',
        text: warehouseIds.join(','),
      },
    ]);
    const warehouseKeyByIds = keyBy(warehouseList, 'id');

    const createdByIds = uniq(map(data, 'createdBy'));
    // Filter by fullname of created by
    const userFilters = [
      {
        column: 'userIds',
        text: createdByIds.join(','),
      },
    ];

    const filterByUser = request.filter.find((item) => item.column === 'user');
    if (filterByUser) {
      userFilters.push({
        column: 'fullName',
        text: filterByUser.text,
      });
    }

    let users = await this.userService.getList(userFilters);
    if (filterByUser) {
      const userIdsFiltered = users.map((user) => user.id);

      dataSortWarehouseId = dataSortWarehouseId.filter((item) =>
        userIdsFiltered.includes(item.createdByUserId),
      );
    }
    // convert users for assign to respose data
    users = keyBy(users, 'id');

    const dataReturn = plainToInstance(
      TicketResponseDto,
      dataSortWarehouseId.map((item) => ({
        ...item,
        warehouse: {
          id: warehouseKeyByIds[item.warehouseId]?.id,
          code: warehouseKeyByIds[item.warehouseId]?.code,
          name: warehouseKeyByIds[item.warehouseId].name,
        },
        createdBy: {
          id: users[item.createdBy]?.id,
          username: users[item.createdBy]?.username,
          fullName: users[item.createdBy]?.fullName,
        },
      })),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PaginationResponse>({
      items: dataReturn,
      meta: {
        total: count,
        page: page,
      },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Update ticket status
   * @param request
   * @returns
   */
  public async updateStatus(request: any): Promise<any> {
    const { id } = request;
    const ticket = await this.ticketRepository.findOneByCondition({
      _id: id,
      deletedAt: null,
    });
    // Check ticket is existed
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.NOT_FOUND', {
            args: { code: ticket.code },
          }),
        )
        .build();
    }

    // Check ticket status
    if (ticket.status !== STATUS_ENUM.WAITING) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }

    // Update status
    const updateTicket = this.ticketRepository.updateDocument(ticket, request);
    try {
      const result = await this.ticketRepository.findByIdAndUpdate(
        id,
        updateTicket,
      );

      const response = plainToInstance(TicketResponseDto, result, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withData(response)
        .build();
    } catch (e) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  /**
   * Create new Delivery Ticket
   * @param request
   * @returns
   */
  async create(request: CreateTicketRequestDto): Promise<any> {
    const { items, attachment, templateId, attributes } = request;

    if (!isEmpty(attachment)) {
      const resultValidateAttachments = await this.validateAttachments(
        attachment,
      );

      if (resultValidateAttachments.statusCode !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttachments;
      }
    }

    if (!isEmpty(attributes)) {
      const resultValidateAttributes = await this.validateAttributes(
        templateId,
        attributes,
      );

      if (resultValidateAttributes.statusCode !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttributes;
      }
    }

    const ticket = this.ticketRepository.createDocument(request);

    // Auto generate ticket code
    const currentDate = Moment().utcOffset(7).format('DDMMYYYY');
    const latestTicket = await this.ticketRepository.getTicketCode(
      `${DELIVERY_CODE_PREFIX}${currentDate}`,
    );
    const lastCode = !isEmpty(latestTicket) ? latestTicket.code : '';
    ticket.code = generateTicketCode(
      DELIVERY_CODE_PREFIX,
      lastCode,
      currentDate,
    );

    forEach(items, (item) => {
      item.ticketId = ticket._id;
    });

    if (!isEmpty(attachment)) {
      await this.fileService.saveFiles(
        ticket._id,
        FILE_RESOURCE.RI,
        attachment,
      );
    }

    await this.ticketDetailRepository.create(items);

    return await this.save(ticket);
  }

  /**
   * Update the delivery ticket
   * @param request
   * @returns
   */
  async update(request: UpdateTicketRequestDto): Promise<any> {
    const { id, attachment, templateId, attributes, items } = request;

    if (!isEmpty(attachment)) {
      const resultValidateAttachments = await this.validateAttachments(
        attachment,
      );

      if (resultValidateAttachments.statusCode !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttachments;
      }
    }

    if (!isEmpty(attributes)) {
      const resultValidateAttributes = await this.validateAttributes(
        templateId,
        attributes,
      );

      if (resultValidateAttributes.statusCode !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttributes;
      }
    }

    const ticket = await this.ticketRepository.findOneById(id);
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    this.ticketDetailRepository.deleteManyByCondition({ ticketId: ticket._id });

    forEach(items, (item) => {
      item.ticketId = ticket._id;
    });

    if (!isEmpty(attachment)) {
      await this.fileService.saveFiles(
        ticket._id,
        FILE_RESOURCE.RI,
        attachment,
      );
    }

    await this.ticketDetailRepository.create(items);

    const ticketUpdate = this.ticketRepository.updateDocument(ticket, request);
    return await this.save(ticketUpdate, true);
  }

  /**
   * Validate the uploaded file
   * @param attachment
   * @returns
   */
  private async validateAttachments(attachment: any): Promise<any> {
    for (let i = 0; i < attachment?.length; i++) {
      const file = attachment[i];

      if (Object.values(ALLOW_MIME_TYPE_ENUM).indexOf(file?.mimetype) === -1) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.FILE_WRONG_TYPE'))
          .build();
      }

      if (file?.data.byteLength > MAX_FILE_SIZE) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.FILE_SIZE_IS_TOO_BIG'))
          .build();
      }
    }

    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }
  /**
   * Validate Attributes
   * @param templateId
   * @param attributes
   * @returns
   */
  private async validateAttributes(
    templateId: any,
    attributes: any,
  ): Promise<any> {
    const template = await this.attributeService.getTemplateById(templateId);
    const attributeTemplates = template['attributes'];

    for (let i = 0; i < attributes.length; i++) {
      const attribute = find(attributeTemplates, ['_id', attributes[i]['id']]);
      const rule = attribute ? attribute['attributeRule'] : null;
      const min = rule?.min;
      const max = rule?.max;
      const dataType = attribute?.attribute?.dataType;
      const attributeName = attributes[i].name;
      const attributeValue = attributes[i].value;

      if (rule && rule?.isRequired === IS_OPTIONAL.NO) {
        if (
          attributeValue === undefined ||
          isEmpty(attributeValue?.toString())
        ) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(
              await this.i18n.translate('error.ATTRIBUTE_IS_EMPTY', {
                args: { attribute: attributeName },
              }),
            )
            .build();
        }
      }

      switch (dataType) {
        case DATA_TYPE_ENUM.NUMBER:
          if (!isEmpty(min?.toString()) && attributeValue < min) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_SMALLER_THAN_MIN',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          if (!isEmpty(max?.toString()) && attributeValue > max) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_BIGGER_THAN_MAX',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          break;
        case DATA_TYPE_ENUM.DATE:
          if (
            !isEmpty(min?.toString()) &&
            compareDate(new Date(attributeValue), new Date(min))
          ) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_SMALLER_THAN_MIN',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          if (
            !isEmpty(max?.toString()) &&
            compareDate(new Date(max), new Date(attributeValue))
          ) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_BIGGER_THAN_MAX',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          break;
        default:
          break;
      }
    }

    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  /**
   * Save data of delivery ticket
   * @param ticketImport
   * @param isUpdate
   * @returns
   */
  async save(ticketImport: Ticket, isUpdate = false): Promise<any> {
    try {
      let result;
      if (isUpdate) {
        result = await this.ticketRepository.findByIdAndUpdate(
          ticketImport._id,
          ticketImport,
        );
      } else {
        result = await this.ticketRepository.create(ticketImport);
      }
      const response = plainToInstance(TicketResponseDto, ticketImport, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            isUpdate
              ? 'message.deliveryTicket.updateDeliveryTicketSuccess'
              : 'message.deliveryTicket.createDeliveryTicketSuccess',
          ),
        )
        .withData(response)
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
}
