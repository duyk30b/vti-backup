import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { plainToInstance } from 'class-transformer';
import { I18nService } from 'nestjs-i18n';
import { WarehouseServiceInterface } from './interface/warehouse.service.interface';
import { WarehouseResponseDto } from './response/warehouse.dto.response';
import * as dotenv from 'dotenv';
import { NATS_WAREHOUSE } from '@config/nats.config';
dotenv.config();
@Injectable()
export class WarehouseService implements WarehouseServiceInterface {
  constructor(
    private readonly natsClientService: NatsClientService,
    private readonly i18n: I18nService,
  ) {}

  async getWarehouses(warehouseIds: number[]): Promise<WarehouseResponseDto[]> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE}.get_warehouses_by_ids`,
      {
        warehouseIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return <any>[];
    }

    const dataReturn = plainToInstance(
      WarehouseResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );

    return dataReturn;
  }

  async getList(filter: any): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_WAREHOUSE}.list`,
        {
          filter,
        },
      );
      return response?.data?.items || [];
    } catch (err) {
      return [];
    }
  }

  async getDetail(id: number): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_WAREHOUSE}.detail_warehouse`,
        {
          id: +id,
        },
      );
      return response.data || {};
    } catch (e) {
      return [];
    }
  }

  async getListByIDs(
    ids: number[],
    serilize?: boolean,
    relation?: string[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE}.get_warehouses_by_ids`,
      {
        warehouseIds: ids,
        relation,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    const serilizeWarehouses = {};
    if (serilize) {
      response.data.forEach((warehouse) => {
        serilizeWarehouses[warehouse.id] = warehouse;
      });

      return serilizeWarehouses;
    }

    return response.data;
  }
}
