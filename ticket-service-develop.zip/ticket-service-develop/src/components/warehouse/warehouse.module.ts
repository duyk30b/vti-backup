import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { WarehouseService } from './warehouse.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
  ],
  controllers: [],
})
export class WarehouseModule {}
