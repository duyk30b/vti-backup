import { WarehouseResponseDto } from '../response/warehouse.dto.response';

export interface WarehouseServiceInterface {
  getList(filter: any): Promise<WarehouseResponseDto[]>;
  getDetail(id: number): Promise<any>;
  getListByIDs(
    ids: number[],
    serilize?: boolean,
    relation?: string[],
  ): Promise<any>;
}
