import { Expose, Type } from 'class-transformer';
class BaseResponse {
  @Expose()
  code: string;

  @Expose()
  name: string;
}

class WarehouseResponse extends BaseResponse {
  @Expose()
  id: number;
  @Expose()
  manageByLot: number;
}
class LocatorResponse extends BaseResponse {
  @Expose()
  id: string;
}
export class ItemStockWarehouseLocatorHistoryResponseDto {
  @Expose()
  id: number;

  @Expose()
  itemMovementId: number;

  @Expose()
  orderType: number;

  @Expose()
  ticketId: number;

  @Expose()
  quantity: number;
}
export class GetListItemStockWarehouseLocatorResponse {
  @Expose()
  itemId: number;

  @Expose()
  itemName: string;

  @Expose()
  itemCode: string;

  @Expose()
  itemTypeName: string;

  @Expose()
  itemUnitName: string;

  @Expose()
  lotNumber: string;

  @Expose()
  mfg: Date;

  @Expose()
  storageDate: Date;

  @Expose()
  stock: number;

  @Expose()
  quantity: number;

  @Expose()
  @Type(() => WarehouseResponse)
  warehouse: WarehouseResponse;

  @Expose()
  @Type(() => LocatorResponse)
  locator: LocatorResponse;

  @Expose()
  @Type(() => ItemStockWarehouseLocatorHistoryResponseDto)
  histories: ItemStockWarehouseLocatorHistoryResponseDto[];
}
