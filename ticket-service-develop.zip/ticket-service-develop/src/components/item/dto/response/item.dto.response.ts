import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class ItemType {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ItemUnit {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ItemGroup {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class Package {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: number;
}

class ItemWarehouseSource {
  @Expose()
  warehouseId: number;

  @ApiProperty({})
  @Expose()
  accounting: string;
}
export class ItemResponseDto {
  @Expose({ name: 'id' })
  itemId: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  price: string;

  @Expose()
  description: string;

  @Expose()
  itemGroupId: number;

  @Expose()
  itemTypeId: number;

  @Expose()
  itemUnitId: number;

  @Expose()
  status: number;

  @Expose()
  dayExpire: number;

  @ApiProperty({ type: ItemType })
  @Expose()
  @Type(() => ItemType)
  itemType: ItemType;

  @ApiProperty()
  @Expose()
  @Type(() => ItemGroup)
  itemGroup: ItemGroup;

  @ApiProperty({ type: ItemUnit })
  @Expose()
  @Type(() => ItemUnit)
  itemUnit: ItemUnit;

  @ApiProperty({ type: Package })
  @Expose()
  @Type(() => Package)
  packages: Package;

  @Expose()
  details: any;

  @Expose()
  @Type(() => ItemWarehouseSource)
  itemWarehouseSources: ItemWarehouseSource[];
}
