import { ResponseService } from '@utils/response-service';
import { Expose } from 'class-transformer';

export class ItemMovementResponseDto {
  @Expose()
  itemId: number;

  @Expose()
  warehouseId: number;

  @Expose()
  locatorId: string;

  @Expose()
  ticketId: string;

  @Expose()
  storedQuantity: number;

  @Expose()
  exportedQuantity: number;

  @Expose()
  quantity: number;

  @Expose()
  lotNumber: string;

  @Expose()
  mfg: Date;

  @Expose()
  importDate: Date;
}

export class ItemStockMovementsResponseDto extends ResponseService {
  @Expose()
  data: ItemMovementResponseDto[];
}
