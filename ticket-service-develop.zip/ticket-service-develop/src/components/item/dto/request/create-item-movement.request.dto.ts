import { Expose, Type } from 'class-transformer';
import { IsArray, IsNotEmpty, ValidateNested } from 'class-validator';

export class CreateItemMovementDto {
  itemId: number;

  warehouseId: number;

  ticketId: string;

  locatorId?: string;

  warehouseLocatorId?: number;

  quantity: number;

  lotNumber: string;

  type: number;

  storedQuantity?: number;

  exportedQuantity?: number;

  mfg: Date;

  importDate: Date;
  constructor(request) {
    this.itemId = request.itemId;
    this.warehouseId = request.warehouseId;
    this.ticketId = request.ticketId;
    this.locatorId = request.locatorId;
    this.warehouseLocatorId = request.warehouseLocatorId;
    this.type = request.type;
    this.mfg = request.mfg || null;
    this.lotNumber = request.lotNumber || null;
    this.quantity = request.quantity;
    this.storedQuantity = request?.storedQuantity;
    this.importDate = request.importDate;
    this.exportedQuantity = request?.exportedQuantity || 0;
  }
}
export class CreateItemStockMovementsRequestDto {
  @Expose()
  @IsNotEmpty()
  @ValidateNested()
  @IsArray()
  @Type(() => CreateItemMovementDto)
  items: CreateItemMovementDto[];
}
