import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsOptional } from 'class-validator';

export class getItemStockWarehouseLocatorByDateRangeRequestDto {
  @ApiProperty()
  @IsOptional()
  @IsArray()
  itemIds: number[];

  @ApiProperty()
  @IsOptional()
  @IsArray()
  warehouseIds: number[];

  @ApiProperty()
  @IsOptional()
  @IsArray()
  locatorIds: number[];

  @ApiProperty()
  @IsOptional()
  isFlatLots: string;
}
