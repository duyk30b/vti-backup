import {
  TYPE_ENUM_MOVEMENT,
  WarehouseByLotManagementEnum,
} from '@components/receipt/receipt.constant';
import { Expose, Type } from 'class-transformer';

export class CreateItemStockMovementSwiftLocatorDto {
  @Expose()
  itemId: number;

  @Expose()
  lotNumber: string;

  @Expose()
  locatorId: string;

  @Expose()
  quantityStored: number;

  constructor(
    itemId?: number,
    lotNumber?: string,
    locatorId?: string,
    quantityStored?: number,
  ) {
    this.itemId = itemId;
    this.lotNumber = lotNumber;
    this.locatorId = locatorId;
    this.quantityStored = quantityStored;
  }
}
export class CreateItemSwiftLocatorTicket {
  @Expose()
  movementIds: number[];

  @Expose()
  orderType: TYPE_ENUM_MOVEMENT;

  @Expose()
  warehouseId: number;

  @Expose()
  ticketId: string;

  @Expose()
  items: CreateItemStockMovementSwiftLocatorDto[];

  constructor(
    movementIds?: number[],
    warehouseId?: number,
    orderType?: TYPE_ENUM_MOVEMENT,
    ticketId?: string,
    items?: CreateItemStockMovementSwiftLocatorDto[],
  ) {
    this.movementIds = movementIds;
    this.warehouseId = warehouseId;
    this.orderType = orderType;
    this.ticketId = ticketId;
    this.items = items;
  }
}
