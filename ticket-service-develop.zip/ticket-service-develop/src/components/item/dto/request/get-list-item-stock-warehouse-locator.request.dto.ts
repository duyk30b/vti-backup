import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsOptional, IsArray } from 'class-validator';

export class GetListItemStockWarehouseLocatorByCondition extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsArray()
  itemIds: number[];

  @ApiProperty()
  @IsOptional()
  @IsArray()
  locatorIds: string[];
}
