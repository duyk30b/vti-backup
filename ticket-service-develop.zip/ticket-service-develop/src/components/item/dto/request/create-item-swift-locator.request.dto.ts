import { Expose, Type } from 'class-transformer';
import { IsArray, IsNotEmpty, ValidateNested } from 'class-validator';

export class CreateItemStockSwiftLocatorHistoryDto {
  itemId: number;
  quantity: number;
  lotNumber: string;
  // sourceLocatorId: number;
  // destinationLocatorId: number;
  constructor(
    quantity: number,
    itemId: number,
    lotNumber: string | null,
    sourceLocatorId: number,
    destinationLocatorId: number,
  ) {
    this.quantity = quantity;
    this.itemId = itemId;
    this.lotNumber = lotNumber || null;
    // this.sourceLocatorId = sourceLocatorId;
    // this.destinationLocatorId = destinationLocatorId;
  }
}
export class CreateItemStockMovementSwiftLocatorDto {
  @Expose()
  itemId: number;

  @Expose()
  lotNumber: string;

  // @Expose()
  // movementOrderDetailId: number;

  // @Expose()
  // movementOrderWarehouseDetailId: number;

  @Expose()
  quantity: number;

  // @Expose()
  // itemsStockMovementHistories: CreateItemStockSwiftLocatorHistoryDto[];

  constructor(
    itemId: number,
    movementOrderDetailId: number,
    movementOrderWarehouseDetailId: number,
    quantity: number,
    // itemsStockMovementHistories: CreateItemStockSwiftLocatorHistoryDto[],
  ) {
    this.itemId = itemId;
    // this.movementOrderDetailId = movementOrderDetailId;
    // this.movementOrderWarehouseDetailId = movementOrderWarehouseDetailId;
    this.quantity = quantity;
    // this.itemsStockMovementHistories = itemsStockMovementHistories;
  }
}

export class CreateItemSwiftLocatorRequestDto {
  // @Expose()
  // warehouseStockMovementExportId: number;

  // @Expose()
  // warehouseStockMovementImportId: number;

  @Expose()
  warehouseId: number;

  // @Expose()
  // destinationWarehouseId: number;

  @Expose()
  userId: number;

  @Expose()
  orderId: number;

  @Expose()
  ticketId: string;

  @Expose()
  purpose?: string;

  @Expose()
  saleOrderType: number;

  @Expose()
  @IsNotEmpty()
  @ValidateNested()
  @IsArray()
  @Type(() => CreateItemStockMovementSwiftLocatorDto)
  items: CreateItemStockMovementSwiftLocatorDto[];
}
