import { TYPE_ENUM_MOVEMENT } from '@components/receipt/receipt.constant';
import { Expose } from 'class-transformer';

export class ItemPutAwayReceipts {
  @Expose()
  itemId: number;

  @Expose()
  lotNumber: string;

  @Expose()
  locatorId: string;

  @Expose()
  ticketId: string;

  @Expose()
  mfg: Date;

  @Expose()
  warehouseId: number;

  @Expose()
  quantityStored: number;

  constructor(
    itemId?: number,
    warehouseId?: number,
    ticketId?: string,
    lotNumber?: string,
    locatorId?: string,
    quantityStored?: number,
    mfg?: Date,
  ) {
    this.itemId = itemId;
    this.warehouseId = warehouseId;
    this.ticketId = ticketId;
    this.lotNumber = lotNumber;
    this.locatorId = locatorId;
    this.quantityStored = quantityStored;
    this.mfg = mfg;
  }
}

export class CreateItemPutAwayReceiptDto {
  @Expose()
  movementIds: number[];

  @Expose()
  orderType: TYPE_ENUM_MOVEMENT;

  @Expose()
  items: ItemPutAwayReceipts[];

  constructor(
    movementIds?: number[],
    orderType?: TYPE_ENUM_MOVEMENT,
    items?: ItemPutAwayReceipts[],
  ) {
    this.movementIds = movementIds;
    this.orderType = orderType;
    this.items = items;
  }
}
