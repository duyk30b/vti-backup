import {
  TYPE_ENUM_MOVEMENT,
  WarehouseByLotManagementEnum,
} from '@components/receipt/receipt.constant';
import { Expose } from 'class-transformer';
class ItemStockWarehousePrice {
  @Expose()
  itemId: number;

  @Expose()
  warehouseId: number;

  @Expose()
  quantity: number;

  @Expose()
  price: number;

  @Expose()
  totalPrice: number;
}
export class UpdateStockFromTicketRequestDto {
  @Expose()
  movementIds: number[];

  @Expose()
  orderType: TYPE_ENUM_MOVEMENT;

  @Expose()
  ticketId: string;

  @Expose()
  manageByLot: WarehouseByLotManagementEnum;

  @Expose()
  itemStockWarehousePrices?: ItemStockWarehousePrice[];

  constructor(
    movementIds?: number[],
    orderType?: TYPE_ENUM_MOVEMENT,
    ticketId?: string,
    itemStockWarehousePrices?: ItemStockWarehousePrice[],
    manageByLot?: number,
  ) {
    this.movementIds = movementIds;
    this.orderType = orderType;
    this.ticketId = ticketId;
    this.itemStockWarehousePrices = itemStockWarehousePrices;
    this.manageByLot = manageByLot;
  }
}
