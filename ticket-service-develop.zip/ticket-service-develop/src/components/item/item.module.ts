import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ItemService } from './item.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
  ],
  controllers: [],
})
export class ItemModule {}
