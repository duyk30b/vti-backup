import { NATS_ITEM } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { plainToInstance } from 'class-transformer';
import { CreateItemStockMovementsRequestDto } from './dto/request/create-item-movement.request.dto';
import { CreateItemSwiftLocatorTicket } from './dto/request/create-item-swift-locator-ticket.request.dto';
import { GetItemMovementByConditionRequestDto } from './dto/request/get-item-movement-by-condition.request.dto';
import { GetListItemStockWarehouseLocatorByCondition } from './dto/request/get-list-item-stock-warehouse-locator.request.dto';
import { CreateItemPutAwayReceiptDto } from './dto/request/put-away-receipt.request.dto';
import { UpdateStockFromTicketRequestDto } from './dto/request/update-stock-from-ticket-request.request.dto';
import { GetListItemStockWarehouseLocatorResponse } from './dto/response/item-warehouse-stock-locator.response.dto';
import { ItemResponseDto } from './dto/response/item.dto.response';
import { ItemServiceInterface } from './interface/item.service.interface';
import { UpdateItemWarehouseLocatorRequestDto } from './dto/request/update-item-stock-warehouse-locator.request.dto';
import { getItemStockWarehouseLocatorByDateRangeRequestDto } from './dto/request/get-item-stock-warehouse-locators.request.dto';
import { ConfirmExportRequestDto } from '@components/export-receipt/dto/request/confirm-export.request.dto';

@Injectable()
export class ItemService implements ItemServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async createItemStockMovement(
    request: CreateItemStockMovementsRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.create_item_movements`,
      request,
    );
    return response;
  }
  async updateStockFromTicket(
    request: UpdateStockFromTicketRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.update_stock_from_ticket`,
      request,
    );
    return response;
  }
  async getItems(itemIds: number[]): Promise<ItemResponseDto[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_items_by_ids`,
      { itemIds },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const dataReturn = plainToInstance(ItemResponseDto, <any[]>response.data, {
      excludeExtraneousValues: true,
    });

    return dataReturn;
  }

  async getItemMovementByCondition(
    request: GetItemMovementByConditionRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_items_by_ids`,
      {
        request,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const dataReturn = plainToInstance(ItemResponseDto, <any[]>response.data, {
      excludeExtraneousValues: true,
    });

    return dataReturn;
  }
  async getListItemWarehouseLocators(
    itemIds?: number[],
    ticketIds?: string[],
    ticketLocatorIds?: string[],
    isSameWarehouse?: string,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_list_item_stock_warehouse_locator`,
      {
        itemIds,
        ticketIds,
        ticketLocatorIds,
        isSameWarehouse,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const dataReturn = plainToInstance(
      GetListItemStockWarehouseLocatorResponse,
      <any[]>response.data.items,
      {
        excludeExtraneousValues: true,
      },
    );

    return dataReturn;
  }

  async createItemStockSwiftLocator(
    request: CreateItemSwiftLocatorTicket,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.create_item_stock_swift_locator_ticket`,
      request,
    );
    return response;
  }
  async createItemStockPutAwayLocator(
    request: CreateItemPutAwayReceiptDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.create_item_stock_swift_locator_ticket`,
      request,
    );
    return response;
  }

  async getItemByIds(itemIds: number[], serilize?: boolean): Promise<any> {
    const response = await await this.natsClientService.send(
      `${NATS_ITEM}.get_items_by_ids`,
      {
        itemIds,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    const serilizeItems = {};
    if (serilize) {
      response.data.forEach((item) => {
        serilizeItems[item.id] = item;
      });

      return serilizeItems;
    }
    return response.data;
  }

  async pickUpItemStockWarehouseLocators(
    request: UpdateItemWarehouseLocatorRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.pick_up_item_stock_warehouse_locators`,
      request,
    );
    return response;
  }

  async getItemStockInWarehouseLocators(
    request: UpdateItemWarehouseLocatorRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_in_warehouse_locator`,
      { items: request },
    );
    return response?.data || [];
  }

  async getItemStockWarehouseLocatorByDateRange(
    request: getItemStockWarehouseLocatorByDateRangeRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_locator_storage_dates`,
      request,
    );
    return response.data.items || [];
  }

  async confirmExportReceiptItems(
    request: ConfirmExportRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.confirm_export_receipt_items`,
      request,
    );
    return response;
  }

  async getListItem(payload: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_list`,
      payload,
    );
    return response.data.items || [];
  }

  async updateItemStockInWarehouseLocators(payload: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.update_item_stock_warehouse_locator`,
      payload,
    );
    return response;
  }
}
