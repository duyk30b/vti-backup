import { ConfirmExportRequestDto } from '@components/export-receipt/dto/request/confirm-export.request.dto';
import { CreateItemStockMovementsRequestDto } from '../dto/request/create-item-movement.request.dto';
import { CreateItemSwiftLocatorTicket } from '../dto/request/create-item-swift-locator-ticket.request.dto';
import { GetItemMovementByConditionRequestDto } from '../dto/request/get-item-movement-by-condition.request.dto';
import { getItemStockWarehouseLocatorByDateRangeRequestDto } from '../dto/request/get-item-stock-warehouse-locators.request.dto';
import { UpdateItemWarehouseLocatorRequestDto } from '../dto/request/update-item-stock-warehouse-locator.request.dto';
import { GetListItemStockWarehouseLocatorByCondition } from '../dto/request/get-list-item-stock-warehouse-locator.request.dto';
import { CreateItemPutAwayReceiptDto } from '../dto/request/put-away-receipt.request.dto';
import { UpdateStockFromTicketRequestDto } from '../dto/request/update-stock-from-ticket-request.request.dto';
import { ItemResponseDto } from '../dto/response/item.dto.response';

export interface ItemServiceInterface {
  createItemStockMovement(
    request: CreateItemStockMovementsRequestDto,
  ): Promise<any>;

  getListItem(payload: any): Promise<any>;

  getItems(itemIds: number[]): Promise<ItemResponseDto[]>;

  updateStockFromTicket(request: UpdateStockFromTicketRequestDto): Promise<any>;

  getItemMovementByCondition(
    request: GetItemMovementByConditionRequestDto,
  ): Promise<any>;

  createItemStockSwiftLocator(
    request: CreateItemSwiftLocatorTicket,
  ): Promise<any>;

  createItemStockPutAwayLocator(
    request: CreateItemPutAwayReceiptDto,
  ): Promise<any>;

  getItemByIds(itemIds: number[], serilize?: boolean): Promise<any>;

  pickUpItemStockWarehouseLocators(
    request: UpdateItemWarehouseLocatorRequestDto,
  ): Promise<any>;

  getItemStockWarehouseLocatorByDateRange(
    request: getItemStockWarehouseLocatorByDateRangeRequestDto,
  ): Promise<any>;

  confirmExportReceiptItems(request: ConfirmExportRequestDto): Promise<any>;

  getListItemWarehouseLocators(
    itemIds?: number[],
    ticketIds?: string[],
    ticketLocatorIds?: string[],
    isSameWarehouse?: string,
  ): Promise<any>;

  getItemStockInWarehouseLocators(request: any): Promise<any>;

  updateItemStockInWarehouseLocators(request: any): Promise<any>;
}
