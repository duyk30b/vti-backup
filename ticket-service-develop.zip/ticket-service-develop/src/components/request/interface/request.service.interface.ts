export interface RequestServiceInterface {
  getListRequestByIds(requestIds: string[], serialize?: boolean): Promise<any>;
  getRequestOrdersByCodeKeyword(
    codeKeyword: any,
    onlyId?: boolean,
  ): Promise<any>;
  getDetail(id: string): Promise<any>;
  updateStatusWarehouseRequest(id: string, status?: number): Promise<any>;
}
