import { NATS_REQUEST } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Inject, Injectable } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { isEmpty, keyBy, map, uniq } from 'lodash';
import { I18nService } from 'nestjs-i18n';
import { RequestServiceInterface } from './interface/request.service.interface';

@Injectable()
export class RequestService implements RequestServiceInterface {
  constructor(
    private readonly natsClientService: NatsClientService,

    private readonly i18n: I18nService,
  ) {}

  public async getTicketsByRequestIdsNats(
    ids: string[],
    serialize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send('get_request_by_ids', {
      ids,
    });
    if (response.statusCode != ResponseCodeEnum.SUCCESS) {
      return [];
    }
    if (serialize) {
      return keyBy(response?.data, '_id');
    }
    return response?.data;
  }
  public async getListRequestByIds(
    requestIds: string[],
    serialize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_REQUEST}.get_list_request_warehouse_order_by_ids`,
      { filter: [{ column: 'requestIds', text: requestIds.join(',') }] },
    );
    if (response.statusCode != ResponseCodeEnum.SUCCESS) {
      return [];
    }
    if (serialize) {
      return keyBy(response?.data.items, 'id');
    }
    return response?.data?.items;
  }

  async getRequestOrdersByCodeKeyword(
    codeKeyword,
    onlyId?: boolean,
  ): Promise<any> {
    if (isEmpty(codeKeyword)) {
      return [];
    }

    const response = await this.natsClientService.send(
      `${NATS_REQUEST}.get_list_request_warehouse_order_by_ids`,
      {
        filter: JSON.stringify([
          {
            column: 'code',
            text: codeKeyword,
          },
        ]),
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (onlyId) {
      return uniq(map(response.data.items, 'id'));
    }
    return response.data.items;
  }

  async getDetail(id: string): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_REQUEST}.get_warehouse_request_order_import`,
        {
          id: id,
        },
      );
      return response.data || {};
    } catch (e) {
      return [];
    }
  }

  async updateStatusWarehouseRequest(
    id?: string,
    status?: number,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_REQUEST}.update_status_warehouse_request`,
      {
        id,
        status,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return true;
    }
    return false;
  }
}
