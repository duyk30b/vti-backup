import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ConfigService } from '@config/config.service';
import { RequestService } from './request.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    {
      provide: 'RequestServiceInterface',
      useClass: RequestService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'RequestServiceInterface',
      useClass: RequestService,
    },
  ],
  controllers: [],
})
export class RequestModule {}
