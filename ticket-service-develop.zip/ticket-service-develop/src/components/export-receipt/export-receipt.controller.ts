import { isEmpty } from 'lodash';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
  Req,
} from '@nestjs/common';
import { ApiConsumes, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { GetListTicketRequestDto } from '@utils/dto/request/get-list-ticket.request.dto';
import { TicketResponseDto } from '@utils/dto/response/ticket.response.dto';
import { CreateTicketRequestDto } from '@utils/dto/request/create-ticket.request.dto';
import { UpdateTicketBodyDto } from '@utils/dto/request/update-ticket.request.dto';
import { GetDetailTicketRequestDto } from '@utils/dto/request/get-detail-ticket.request.dto';
import { DeleteTicketRequestDto } from '@utils/dto/request/delete-ticket.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { STATUS_ENUM } from '@constant/common';
import { GetTicketDetailResponseDto } from '@utils/dto/response/get-ticket-detail.response.dto';
import { DetailDto } from '@utils/dto/common.dto';
import { ExportReceiptService } from './export-receipt.service';
import { GetPickingListRequestDto } from './dto/request/get-picking-list.request.dto';
import { PickUpMultipleReceiptItemsRequestDto } from './dto/request/pick-up-items.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { ExportReceiptStatusEnum } from './export-receipt.constant';

@Controller('export-receipts')
export class ExportReceiptController {
  constructor(
    @Inject('ExportReceiptServiceInterface')
    private readonly exportReceiptService: ExportReceiptService,
  ) {}

  /**
   * Get List receipt tickets
   * @param payload
   * @returns
   */
  @Get('')
  @ApiOperation({
    tags: ['Export Receipt'],
    summary: 'Get List Export Receipts',
    description: 'Danh sách phiếu xuat',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List of receipt tickets successfully',
    type: GetListTicketRequestDto,
  })
  public async getList(
    @Query() payload: GetListTicketRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.exportReceiptService.getList(request);
  }

  /**
   * Create new Receip Ticket
   * @param payload
   * @returns
   */
  @Post()
  @ApiOperation({
    tags: ['Export Receipt'],
    summary: 'Create the Receipt Ticket',
    description: 'Create the Receipt Ticket',
  })
  @ApiResponse({
    status: 200,
    description: 'Create the Receipt Ticket successfully',
    type: TicketResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  public async create(@Body() body: CreateTicketRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.exportReceiptService.create(request);
  }

  /**
   * Update Receipt Ticket
   * @param DetailDto
   * @param UpdateTicketBodyDto
   * @returns
   */
  @Put('/:id')
  @ApiOperation({
    tags: ['Export Receipt'],
    summary: 'Edit the Receipt Ticket',
    description: 'Edit the Receipt Ticket',
  })
  @ApiResponse({
    status: 200,
    description: 'Edit the Receipt Ticket successfully',
    type: TicketResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  public async update(
    @Param() param: DetailDto,
    @Body() body: UpdateTicketBodyDto,
  ): Promise<any> {
    const {
      request: { id },
      responseError: paramError,
    } = param;
    const { request, responseError } = body;
    if (paramError && !isEmpty(paramError)) {
      return responseError;
    }
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.exportReceiptService.update({ ...request, id });
  }

  /**
   * Detail Receipt Ticket
   * @param param
   * @returns
   */
  @Get('/:id')
  @ApiOperation({
    tags: ['Export Receipt'],
    summary: 'Detail Receipt Ticket',
    description: 'Chi tiết phiếu xuat',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail Successfully',
    type: GetTicketDetailResponseDto,
  })
  public async getDetail(
    @Param() param: GetDetailTicketRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.exportReceiptService.getDetail(request);
  }

  /**
   * Delete receipt ticket
   * @param param
   * @returns
   */
  @Delete('/:id')
  @ApiOperation({
    tags: ['Export Receipt'],
    summary: 'Delete Receipt Ticket',
    description: 'Xoá phiếu xuat hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async delete(@Param() param: DeleteTicketRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.exportReceiptService.delete(request);
  }

  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Export Receipt'],
    summary: 'Confirm Receipt Ticket',
    description: 'Xác nhận phiếu xuat hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm Successfully',
    type: TicketResponseDto,
  })
  public async confirm(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.exportReceiptService.updateStatus({
      ...request,
      status: ExportReceiptStatusEnum.CONFIRMED,
    });
  }

  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Export Receipt'],
    summary: 'Reject Receipt Ticket',
    description: 'Từ chối phiếu nhập hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject Successfully',
    type: TicketResponseDto,
  })
  public async reject(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.exportReceiptService.updateStatus({
      ...request,
      status: ExportReceiptStatusEnum.REJECTED,
    });
  }

  @Get('/picking-list')
  @ApiOperation({
    tags: ['Export Receipt'],
    summary: 'Get picking list',
    description: 'Danh sách lấy hàng ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List of receipt tickets successfully',
    type: GetPickingListRequestDto,
  })
  public async getPickingList(
    @Query() payload: GetPickingListRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.exportReceiptService.getPickingList(request);
  }

  @Post('pick-up/multiple')
  @ApiOperation({
    tags: ['Export Receipt'],
    summary: 'Pick up items Receipt Ticket',
    description: 'Pick up items Receipt Ticket',
  })
  @ApiResponse({
    status: 200,
    description: 'Pick up items Receipt Ticket',
    type: SuccessResponse,
  })
  public async pickUpMultipleReceiptItems(
    @Body() body: PickUpMultipleReceiptItemsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.exportReceiptService.pickUpMultipleReceiptItems(request);
  }

  @Put('/:id/confirm-export')
  @ApiOperation({
    tags: ['Export Receipt'],
    summary: 'Confirm Export Receipt Ticket',
    description: 'Xác nhận xuat kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm Successfully',
    type: TicketResponseDto,
  })
  public async confirmExport(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.exportReceiptService.confirmExport(request);
  }
}
