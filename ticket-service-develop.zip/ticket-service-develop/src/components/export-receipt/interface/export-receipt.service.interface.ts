import { GetDetailTicketRequestDto } from '@utils/dto/request/get-detail-ticket.request.dto';
import { GetTicketDetailResponseDto } from '@utils/dto/response/get-ticket-detail.response.dto';
import { TicketServiceInterface } from '@utils/interface/ticket.service.interface';
import { GetPickingListRequestDto } from '../dto/request/get-picking-list.request.dto';
import { PickUpMultipleReceiptItemsRequestDto } from '../dto/request/pick-up-items.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';

export interface ExportReceiptServiceInterface extends TicketServiceInterface {
  getDetail(
    request: GetDetailTicketRequestDto,
  ): Promise<GetTicketDetailResponseDto>;
  getPickingList(request: GetPickingListRequestDto): Promise<any>;
  pickUpMultipleReceiptItems(
    request: PickUpMultipleReceiptItemsRequestDto,
  ): Promise<any>;
  confirmExport(request: IdParamMongoDto): Promise<any>;
}
