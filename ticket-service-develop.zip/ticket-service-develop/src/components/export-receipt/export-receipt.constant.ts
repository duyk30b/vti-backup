import { STATUS_ENUM } from '@constant/common';
export const EXPORT_RECEIPT_PREFIX = 'X';

export enum ALLOW_MIME_TYPE_ENUM {
  PDF = 'application/pdf',
  DOC = 'application/msword',
  DOCX = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  XLS = 'application/vnd.ms-excel',
  XLSX = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  XLSX_OFFICE = 'application/wps-office.xlsx',
}

export const EXPORT_RECEIPT_TICKET_FIELD_CODE = {
  REQUEST_CODE: 'requestCode',
  TEMPLATE_CODE: 'wmsxTemplateCode',
  STATUS: 'wmsxStatus',
  CREATED_AT: 'wmsxCreatedAt',
  CREATED_BY: 'wmsxCreatedBy',
  TEMPLATE_NAME: 'wmsxTemplateName',
  DEPARTMENT_SETTING: 'departmentCode',
  DESCRIPTION: 'wmsxDescription',
  WAREHOUSE_EXPORT_CODE: 'warehouseExportCode',
  ITEM_CODE: 'wmsxItemCode',
  ITEM_NAME: 'wmsxItemName',
  ITEM_UNIT_NAME: 'wmsxItemUnitName',
  ACTUAL_QUANTITY: 'wmsxQuantityActual',
  REQUEST_QUANTITY: 'wmsxQuantityRequest',
  REQUEST_USER_NOTE: 'wmsxUserNote',
  PLAN_DELIVERY_DATE: 'wmsxPlanDeliveryDate',
  CREATED_RECEIPT_DATE: 'wmsxCreateReceiptDate',
  REASON: 'wmsxReason',
  MFG: 'wmsxManufactureDate',
  GEN_PRICE: 'wmsxGeneralPrice',
  GEN_AMOUNT: 'wmsxGeneralAmount',
  LOT_NUMBER: 'wmsxLotNumber',
  REMAINING_QUANTITY: 'wmsxRemainingQuantity',
  LOCATOR: 'wmsxLocator',
  EXPORT_RECEIPT_CODE: 'wmsxSoCode',
  FILE: 'wmsxFile',
  REQUEST_PRICE: 'wmsxPrice',
  PICK_ITEM_METHOD: 'wmsxPickItemMethod',
  PLAN_EXPORT_QUANTITY: 'wmsxPlanExportQuantity',
  TRANSFER_UNIT: 'wmsxTransferUnit',
  REQUEST_DEPARTMENT: 'wmsxRequestDepartment',
  REQUEST_DESCRIPTION: 'wmsxRequestDescription',
  IMPORT_DATE: 'wmsxImportDate',
};

export enum ReceiptTypeEnum {
  IMPORT = 0,
  EXPORT = 1,
  TRANSFER = 2,
  INVENTORY = 3,
}

export enum ExportReceiptStatusEnum {
  PENDING = 0,
  CONFIRMED = 1,
  REJECTED = 2,
  PICKING = 3,
  COMPLETE_PICK = 4,
  COMPLETED = 5,
}

export const CAN_CONFIRM_EXPORT_STATUSES = [
  ExportReceiptStatusEnum.PICKING,
  ExportReceiptStatusEnum.COMPLETE_PICK,
];
