import { AttributeServiceInterface } from '@components/attribute/interface/attribute.service.interface';
import { FILE_RESOURCE } from '@components/file/file.constant';
import { FileRepositoryInterface } from '@components/file/interface/file.repository.interface';
import { FileServiceInterface } from '@components/file/interface/file.service.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import {
  DATA_TYPE_ENUM,
  MAX_FILE_SIZE,
  TICKET_TYPE_ENUM,
  STATUS_ENUM,
  plus,
  IS_OPTIONAL,
  minus,
} from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { InjectConnection } from '@nestjs/mongoose';
import { CreateTicketRequestDto } from '@utils/dto/request/create-ticket.request.dto';
import { DeleteTicketRequestDto } from '@utils/dto/request/delete-ticket.request.dto';
import { GetDetailTicketRequestDto } from '@utils/dto/request/get-detail-ticket.request.dto';
import { GetListTicketRequestDto } from '@utils/dto/request/get-list-ticket.request.dto';
import { UpdateTicketRequestDto } from '@utils/dto/request/update-ticket.request.dto';
import { GetTicketDetailResponseDto } from '@utils/dto/response/get-ticket-detail.response.dto';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { TicketResponseDto } from '@utils/dto/response/ticket.response.dto';
import { compareDate } from '@utils/helper';
import { TicketDetailRepositoryInterface } from '@utils/interface/ticket-detail.repository.interface';
import { TicketRepositoryInterface } from '@utils/interface/ticket.repository.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';

import {
  find,
  forEach,
  isEmpty,
  keyBy,
  map,
  uniq,
  flatMap,
  compact,
  filter,
  isEqual,
  first,
} from 'lodash';
import * as Moment from 'moment';
import { Connection, Types } from 'mongoose';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { Ticket } from 'src/models/ticket/ticket.schema';
import { ExportReceiptServiceInterface } from './interface/export-receipt.service.interface';
import {
  ALLOW_MIME_TYPE_ENUM,
  CAN_CONFIRM_EXPORT_STATUSES,
  EXPORT_RECEIPT_PREFIX,
  EXPORT_RECEIPT_TICKET_FIELD_CODE,
  ExportReceiptStatusEnum,
  ReceiptTypeEnum,
} from './export-receipt.constant';
import { generateTicketCode } from 'src/helper/code.helper';
import { WarehouseLayoutServiceInterface } from '@components/warehouse-layout/interface/warehouse-layout.service.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { Attribute } from 'src/models/attribute/attribute.model';
import { RequestServiceInterface } from '@components/request/interface/request.service.interface';
import { getRegexByValue } from '@utils/common';
import { GetPickingListRequestDto } from './dto/request/get-picking-list.request.dto';
import { GetPickingListResponseDto } from './dto/response/get-picking-list.response.dto';
import { PickUpMultipleReceiptItemsRequestDto } from './dto/request/pick-up-items.request.dto';
import {
  CAN_NOT_CREATE_UPDATE_TICKET,
  CAN_UPDATE_TICKET,
  REQUEST_EXPORT_IMPORT_STATUS,
  TYPE_ENUM_MOVEMENT,
} from '@components/receipt/receipt.constant';
import { getItemStockWarehouseLocatorByDateRangeRequestDto } from '@components/item/dto/request/get-item-stock-warehouse-locators.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { ConfirmExportRequestDto } from './dto/request/confirm-export.request.dto';
import { SyncImportExportWarehouseQuantityRequestDto } from '@components/receipt/dto/request/sync-actual-import-export-warehouse-quantity.request.dto';
import { Producer } from 'kafkajs';

@Injectable()
export class ExportReceiptService implements ExportReceiptServiceInterface {
  private readonly logger = new Logger(ExportReceiptService.name);
  constructor(
    @Inject('TicketRepositoryInterface')
    private readonly ticketRepository: TicketRepositoryInterface,

    @Inject('TicketDetailRepositoryInterface')
    private readonly ticketDetailRepository: TicketDetailRepositoryInterface,

    @Inject('FileServiceInterface')
    private readonly fileService: FileServiceInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('SaleServiceInterface')
    protected readonly saleService: SaleServiceInterface,

    @Inject('RequestServiceInterface')
    protected readonly requestService: RequestServiceInterface,

    @Inject('WarehouseLayoutServiceInterface')
    private readonly warehouseLayoutService: WarehouseLayoutServiceInterface,

    @Inject('FileRepositoryInterface')
    private readonly fileRepository: FileRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,

    @InjectConnection()
    private readonly connection: Connection,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('AttributeServiceInterface')
    protected readonly attributeService: AttributeServiceInterface,

    @Inject('KAFKA_PRODUCER')
    private kafkaProducer: Producer,
  ) {}

  public async delete(request: DeleteTicketRequestDto): Promise<any> {
    const { id } = request;
    const ticket = await this.ticketRepository.findOneById(id);
    if (isEmpty(ticket)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const ticketsUseRequest = await this.ticketRepository.findAllByCondition({
      requestId: ticket?.requestId,
    });
    if (!isEmpty(ticketsUseRequest)) {
      if (ticketsUseRequest.length === 1) {
        await this.requestService.updateStatusWarehouseRequest(
          ticket.requestId,
          REQUEST_EXPORT_IMPORT_STATUS.CONFIRM,
        );
      }
    }

    // Check status ticket
    if (
      ticket.status !== STATUS_ENUM.WAITING &&
      ticket.status !== STATUS_ENUM.REJECT
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }

    // File
    const file = await this.fileRepository.findOneByCondition({
      resourceId: id,
      resource: FILE_RESOURCE.EXPORT_RECEIPT,
    });

    // Start transaction
    const session = await this.connection.startSession();
    session.startTransaction();
    try {
      // Delete TicketDetails
      await this.ticketDetailRepository.deleteManyByCondition({
        ticketId: id,
      });

      // Delete file
      if (!isEmpty(file)) {
        await this.fileRepository.deleteById(file.id);
      }

      // Delete Ticket
      await this.ticketRepository.deleteById(id);

      // Commit transaction
      await session.commitTransaction();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch {
      // Abort transaction
      await session.abortTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  /**
   * Get receipt ticket detail
   * @param request
   * @returns
   */
  public async getDetail(
    request: GetDetailTicketRequestDto,
  ): Promise<GetTicketDetailResponseDto | any> {
    const { id } = request;
    const exportReceiptTicket = await this.ticketRepository.findOneWithPopulate(
      {
        _id: id,
      },
      'ticketDetails',
    );
    const templateResponse = await this.attributeService.getTemplateById(
      exportReceiptTicket.templateId,
    );
    const template = await this.attributeService.getTemplateByCode(
      templateResponse.code,
    );

    if (isEmpty(template)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.TEMPLATE_NOT_FOUND'))
        .build();
    }
    if (isEmpty(exportReceiptTicket)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const concatnatedAttributeValues = [
      ...exportReceiptTicket.attributes,
      ...flatMap(exportReceiptTicket.ticketDetails, (i) => {
        return i.attributes;
      }),
    ];
    const userIds = [exportReceiptTicket?.createdBy] || [];
    const [itemIds, departmentSettingIds, warehouseExportIds, reasonIds] =
      this.getValueOfAttributesByCode(
        concatnatedAttributeValues,
        [
          EXPORT_RECEIPT_TICKET_FIELD_CODE.ITEM_CODE,
          EXPORT_RECEIPT_TICKET_FIELD_CODE.REQUEST_DEPARTMENT,
          EXPORT_RECEIPT_TICKET_FIELD_CODE.WAREHOUSE_EXPORT_CODE,
          EXPORT_RECEIPT_TICKET_FIELD_CODE.REASON,
        ],
        true,
      );

    const [
      serializedUser,
      serializedItem,
      serializedDepartment,
      serilizedWarehouse,
      serilizeReason,
    ] = await Promise.all([
      this.userService.getUserByIds(userIds, true),
      this.itemService.getItemByIds(itemIds, true),
      this.userService.getDepartmentSettingByIds(departmentSettingIds, true),
      this.warehouseService.getListByIDs(warehouseExportIds, true),
      this.saleService.getReasonByIds(reasonIds, true),
    ]);
    let serilizeRequest;
    if (!isEmpty(exportReceiptTicket.requestId)) {
      const requestIds = [exportReceiptTicket.requestId.toString()];
      serilizeRequest = await this.requestService.getListRequestByIds(
        requestIds,
        true,
      );
    }
    const file = await this.fileRepository.findOneByCondition({
      resourceId: new Types.ObjectId(id),
      resource: FILE_RESOURCE.EXPORT_RECEIPT,
    });
    let beautifiedData = first(
      this.beautifyExportReceipt([exportReceiptTicket]),
    );

    beautifiedData = {
      ...beautifiedData,
      [EXPORT_RECEIPT_TICKET_FIELD_CODE.EXPORT_RECEIPT_CODE]: {
        value: exportReceiptTicket?.code,
      },
      [EXPORT_RECEIPT_TICKET_FIELD_CODE.REQUEST_CODE]: {
        value: serilizeRequest
          ? serilizeRequest[
              beautifiedData[EXPORT_RECEIPT_TICKET_FIELD_CODE.REQUEST_CODE]
                ?.value
            ]
          : {},
      },
      [EXPORT_RECEIPT_TICKET_FIELD_CODE.TEMPLATE_CODE]: {
        value: {
          id: templateResponse._id,
          name: templateResponse.name,
          code: templateResponse.code,
        },
      },

      // [EXPORT_RECEIPT_TICKET_FIELD_CODE.REQUEST_DEPARTMENT]: {
      //   value:
      //      serilizeRequestOrder[
      //         beautifiedData[EXPORT_RECEIPT_TICKET_FIELD_CODE.REQUEST_CODE]
      //           ?.value
      //       ]
      //     : {},
      // },
      [EXPORT_RECEIPT_TICKET_FIELD_CODE.FILE]: {
        value: file,
      },
      [EXPORT_RECEIPT_TICKET_FIELD_CODE.CREATED_AT]: {
        value: exportReceiptTicket?.createdAt,
      },
      [EXPORT_RECEIPT_TICKET_FIELD_CODE.REASON]: {
        value:
          serilizeReason[
            beautifiedData[EXPORT_RECEIPT_TICKET_FIELD_CODE.REASON]?.value
          ],
      },
      [EXPORT_RECEIPT_TICKET_FIELD_CODE.CREATED_BY]: {
        value: serializedUser[exportReceiptTicket?.createdBy],
      },
      [EXPORT_RECEIPT_TICKET_FIELD_CODE.STATUS]: {
        value: beautifiedData.status,
      },
      [EXPORT_RECEIPT_TICKET_FIELD_CODE.WAREHOUSE_EXPORT_CODE]: {
        value:
          serilizedWarehouse[
            beautifiedData[
              EXPORT_RECEIPT_TICKET_FIELD_CODE.WAREHOUSE_EXPORT_CODE
            ]?.value
          ],
      },
      [EXPORT_RECEIPT_TICKET_FIELD_CODE.CREATED_RECEIPT_DATE]: {
        value:
          beautifiedData[EXPORT_RECEIPT_TICKET_FIELD_CODE.CREATED_RECEIPT_DATE]
            ?.value,
      },
      [EXPORT_RECEIPT_TICKET_FIELD_CODE.CREATED_AT]: {
        value: exportReceiptTicket?.createdAt,
      },
      [EXPORT_RECEIPT_TICKET_FIELD_CODE.REQUEST_DEPARTMENT]: {
        value:
          serializedDepartment[
            beautifiedData[EXPORT_RECEIPT_TICKET_FIELD_CODE.REQUEST_DEPARTMENT]
              ?.value
          ],
      },
      [EXPORT_RECEIPT_TICKET_FIELD_CODE.PICK_ITEM_METHOD]: {
        value:
          beautifiedData[EXPORT_RECEIPT_TICKET_FIELD_CODE.PICK_ITEM_METHOD]
            ?.value,
      },
      [EXPORT_RECEIPT_TICKET_FIELD_CODE.TRANSFER_UNIT]: {
        value:
          beautifiedData[EXPORT_RECEIPT_TICKET_FIELD_CODE.TRANSFER_UNIT]?.value,
      },
      ticketDetails: beautifiedData.ticketReceiptDetails?.map((detail) => {
        return {
          ...detail,
          [EXPORT_RECEIPT_TICKET_FIELD_CODE.ITEM_CODE]: {
            value:
              serializedItem[
                detail[EXPORT_RECEIPT_TICKET_FIELD_CODE.ITEM_CODE]?.value
              ],
          },
          [EXPORT_RECEIPT_TICKET_FIELD_CODE.ITEM_NAME]: {
            value:
              serializedItem[
                detail[EXPORT_RECEIPT_TICKET_FIELD_CODE.ITEM_CODE]?.value
              ]?.name,
          },
          [EXPORT_RECEIPT_TICKET_FIELD_CODE.ITEM_UNIT_NAME]: {
            value:
              serializedItem[
                detail[EXPORT_RECEIPT_TICKET_FIELD_CODE.ITEM_CODE]?.value
              ]?.itemUnit,
          },
        };
      }),
    };
    const ticketDetails = exportReceiptTicket.ticketDetails?.map((item) => {
      return {
        ...item,
        itemResponse: serializedItem[item.itemId],
      };
    });
    return this.makeResponse(template, beautifiedData, ticketDetails);
  }
  private makeResponse(
    template: any,
    beautifiedData: any,
    ticketDetails?: any,
  ) {
    let { attributeHeaders, attributeGroups } = template;
    attributeHeaders = attributeHeaders.map((attributeHeader) => {
      return {
        ...attributeHeader,
        attribute: {
          ...attributeHeader.attribute,
          value: beautifiedData[attributeHeader.attribute?.code]?.value,
        },
      };
    });
    const ticketReceiptDetails = beautifiedData.ticketDetails;

    attributeGroups = attributeGroups?.map((attributeGroup) => {
      return compact(
        ticketReceiptDetails?.map((requestOrderDetail) => {
          if (
            isEqual(
              requestOrderDetail.groupId.toString(),
              attributeGroup.attributes[0].attributeGroup.id.toString(),
            )
          ) {
            const attributes = attributeGroup.attributes.map((attribute) => {
              return {
                ...attribute,
                attribute: {
                  ...attribute.attribute,
                  value: requestOrderDetail[attribute.attribute?.code]?.value,
                },
              };
            });
            return { ...attributeGroup, attributes };
          }
          return;
        }),
      );
    });
    const dataReturn = {
      ...template,
      attributeHeaders,
      attributeGroups: attributeGroups,
      items: ticketDetails,
    };
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
  private getValueOfAttributesByCode(
    attributeValues: Attribute[],
    codes: string[],
    isNotNumber?: boolean,
  ): any[] {
    return codes.map((code) => {
      return uniq(
        map(
          filter(
            attributeValues,
            (attributeValue) => attributeValue.code === code,
          ),
          (i) => {
            if (isNotNumber) {
              return i.value;
            }
            return +i.value;
          },
        ),
      );
    });
  }
  private beautifyExportReceipt(data: any[]): any[] {
    return data?.map((ticketReceipt) => {
      const generalInfo = keyBy(
        ticketReceipt.attributes.map((attributeValue) => {
          return { key: attributeValue.code, value: attributeValue.value };
        }),
        'key',
      );

      let ticketReceiptDetails = ticketReceipt.ticketDetails;
      if (!isEmpty(ticketReceiptDetails)) {
        ticketReceiptDetails = ticketReceiptDetails.map(
          (ticketReceiptDetail) => {
            const generalInfo = keyBy(
              ticketReceiptDetail.attributes.map((attributeValue) => {
                return {
                  key: attributeValue.code,
                  value: attributeValue.value,
                };
              }),
              'key',
            );
            return { ...ticketReceiptDetail, ...generalInfo };
          },
        );
      }
      return { ...ticketReceipt, ...generalInfo, ticketReceiptDetails };
    });
  }

  /* Get list receipt ticket
   * @param request
   * @returns
   */
  public async getList(request: GetListTicketRequestDto): Promise<any> {
    const { page, filter } = request;
    let filterObj = {};
    if (!request.filter) request.filter = [];

    const createdByUserFullname = filter?.find(
      (item) => item.column === 'createdBy',
    )?.text;

    let filterCreatedByUserIds = [];
    if (!isEmpty(createdByUserFullname)) {
      filterCreatedByUserIds = await this.userService.getUsersByNameKeyword(
        createdByUserFullname,
        true,
      );

      if (isEmpty(filterCreatedByUserIds)) {
        return new ResponseBuilder({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    const filterRequestCode = filter?.find(
      (item) => item.column === 'requestCode',
    )?.text;

    let filterRequestIds = [];
    if (!isEmpty(filterRequestCode)) {
      filterRequestIds =
        await this.requestService.getRequestOrdersByCodeKeyword(
          filterRequestCode,
          true,
        );

      if (isEmpty(filterRequestIds)) {
        return new ResponseBuilder({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'createdBy':
            filterObj = {
              ...filterObj,
              createdBy: {
                $in: filterCreatedByUserIds,
              },
            };
            break;
          case 'requestCode':
            filterObj = {
              ...filterObj,
              requestId: {
                $in: filterRequestIds,
              },
            };
            break;
          default:
            break;
        }
      });
    }

    request.filterObj = filterObj;

    const { data, count } = await this.ticketRepository.getList(
      request,
      TICKET_TYPE_ENUM.EXPORT,
    );
    if (count === 0) {
      return new ResponseBuilder<PaginationResponse>({
        items: [],
        meta: { total: 0, page: 1 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const requestIds = uniq(compact(map(data, 'requestId')));
    const userIds = uniq(compact(map(data, 'createdBy')));
    const warehouseIds = uniq(map(data, 'warehouseId'));
    const templateIds = uniq(map(data, 'templateId'));
    let serilizeRequestOrder = {};
    if (!isEmpty(requestIds)) {
      serilizeRequestOrder = await this.requestService.getListRequestByIds(
        requestIds,
        true,
      );
    }
    const [serilizeUser, serializeWarehouse, templates] = await Promise.all([
      this.userService.getUserByIds(userIds, true),
      this.warehouseService.getListByIDs(warehouseIds, true),
      this.attributeService.getTemplatesByIds(templateIds),
    ]);
    const serializedTemplate = keyBy(templates, '_id');

    const ticketResponseFormated = data.map((exportReceipt) => {
      const receiptDate = find(
        exportReceipt.attributes,
        (attr) =>
          attr.code === EXPORT_RECEIPT_TICKET_FIELD_CODE.CREATED_RECEIPT_DATE,
      )?.value;

      return {
        ...exportReceipt,
        warehouse: serializeWarehouse[exportReceipt?.warehouseId],
        requestCode: serilizeRequestOrder[exportReceipt.requestId]?.code,
        createdBy: serilizeUser[exportReceipt.createdBy],
        template: serializedTemplate[exportReceipt.templateId],
        receiptDate,
      };
    });

    const dataReturn = plainToInstance(
      TicketResponseDto,
      ticketResponseFormated,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PaginationResponse>({
      items: dataReturn,
      meta: {
        total: count,
        page: page,
      },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Update ticket status
   * @param request
   * @returns
   */
  public async updateStatus(request: any): Promise<any> {
    const { id } = request;
    const ticket = await this.ticketRepository.findOneByCondition({
      _id: id,
      deletedAt: null,
    });
    // Check ticket is existed
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.NOT_FOUND', {
            args: { code: ticket.code },
          }),
        )
        .build();
    }

    // Check ticket status
    if (ticket.status !== STATUS_ENUM.WAITING) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }

    // Update status
    const updateTicket = this.ticketRepository.updateDocument(ticket, request);
    try {
      const result = await this.ticketRepository.findByIdAndUpdate(
        id,
        updateTicket,
      );

      const response = plainToInstance(TicketResponseDto, result, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withData(response)
        .build();
    } catch (e) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async create(request: CreateTicketRequestDto): Promise<any> {
    const { items, attachment, templateId, requestId, attributes } = request;
    if (!isEmpty(attachment)) {
      const resultValidateAttachments = await this.validateAttachments(
        attachment,
      );
      if (resultValidateAttachments.statusCode !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttachments;
      }
    }
    const requestResponse = await this.requestService.getDetail(requestId);
    if (CAN_NOT_CREATE_UPDATE_TICKET.includes(requestResponse.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.STATUS_REQUEST_INVALID'))
        .build();
    }
    if (!isEmpty(attributes)) {
      const resultValidateAttributes = await this.validateAttributes(
        templateId,
        attributes,
      );

      if (resultValidateAttributes.statusCode !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttributes;
      }
    }

    const ticket = this.ticketRepository.createDocument({
      ...request,
      type: ReceiptTypeEnum.EXPORT,
    });
    // Auto generate ticket code
    const currentDate = Moment().utcOffset(7).format('DDMMYYYY');
    const latestTicket = await this.ticketRepository.getTicketCode(
      `${EXPORT_RECEIPT_PREFIX}${currentDate}`,
    );
    const lastCode = !isEmpty(latestTicket) ? latestTicket.code : '';
    ticket.code = generateTicketCode(
      EXPORT_RECEIPT_PREFIX,
      lastCode,
      currentDate,
    );

    forEach(items, (item) => {
      item.ticketId = ticket._id;
    });

    if (!isEmpty(attachment)) {
      await this.fileService.saveFiles(
        ticket._id,
        FILE_RESOURCE.RI,
        attachment,
      );
    }
    await this.ticketDetailRepository.create(items);

    return await this.save(ticket);
  }

  /**
   * Update the receipt ticket
   * @param request
   * @returns
   */
  async update(request: UpdateTicketRequestDto): Promise<any> {
    const { id, attachment, templateId, attributes, items } = request;

    if (!isEmpty(attachment)) {
      const resultValidateAttachments = await this.validateAttachments(
        attachment,
      );

      if (resultValidateAttachments.statusCode !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttachments;
      }
    }

    if (!isEmpty(attributes)) {
      const resultValidateAttributes = await this.validateAttributes(
        templateId,
        attributes,
      );

      if (resultValidateAttributes.statusCode !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttributes;
      }
    }

    const ticket = await this.ticketRepository.findOneById(id);
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_UPDATE_TICKET.includes(ticket.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
        .build();
    }
    this.ticketDetailRepository.deleteManyByCondition({ ticketId: ticket._id });

    forEach(items, (item) => {
      item.ticketId = ticket._id;
    });

    if (!isEmpty(attachment)) {
      await this.fileService.saveFiles(
        ticket._id,
        FILE_RESOURCE.RI,
        attachment,
      );
    }

    let updateStatus = ticket.status;
    await this.ticketDetailRepository.create(items);
    if (ticket.status === ExportReceiptStatusEnum.REJECTED) {
      updateStatus = ExportReceiptStatusEnum.PENDING;
    }
    const ticketUpdate = this.ticketRepository.updateDocument(ticket, {
      ...request,
      status: updateStatus,
    });
    return await this.save(ticketUpdate, true);
  }

  async validateAttachments(attachment: any): Promise<any> {
    for (let i = 0; i < attachment?.length; i++) {
      const file = attachment[i];
      if (Object.values(ALLOW_MIME_TYPE_ENUM).indexOf(file?.mimetype) === -1) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.FILE_WRONG_TYPE'))
          .build();
      }

      if (file?.data.byteLength > MAX_FILE_SIZE) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.FILE_SIZE_IS_TOO_BIG'))
          .build();
      }
    }

    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async validateAttributes(templateId: any, attributes: any): Promise<any> {
    const template = await this.attributeService.getTemplateById(templateId);
    const attributeTemplates = template['attributes'];

    for (let i = 0; i < attributes.length; i++) {
      const attribute = find(attributeTemplates, ['_id', attributes[i]['id']]);
      const rule = attribute ? attribute['attributeRule'] : null;
      const min = rule?.min;
      const max = rule?.max;
      const dataType = attribute?.attribute?.dataType;
      const attributeName = attributes[i].name;
      const attributeValue = attributes[i].value;

      if (rule && rule?.isRequired === IS_OPTIONAL.NO) {
        if (
          attributeValue === undefined ||
          isEmpty(attributeValue?.toString())
        ) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(
              await this.i18n.translate('error.ATTRIBUTE_IS_EMPTY', {
                args: { attribute: attributeName },
              }),
            )
            .build();
        }
      }

      switch (dataType) {
        case DATA_TYPE_ENUM.NUMBER:
          if (!isEmpty(min?.toString()) && attributeValue < min) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_SMALLER_THAN_MIN',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          if (!isEmpty(max?.toString()) && attributeValue > max) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_BIGGER_THAN_MAX',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          break;
        case DATA_TYPE_ENUM.DATE:
          if (
            !isEmpty(min?.toString()) &&
            compareDate(new Date(attributeValue), new Date(min))
          ) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_SMALLER_THAN_MIN',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          if (
            !isEmpty(max?.toString()) &&
            compareDate(new Date(max), new Date(attributeValue))
          ) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_BIGGER_THAN_MAX',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          break;
        default:
          break;
      }
    }

    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  /**
   * Save data of receipt ticket
   * @param ticketExport
   * @param isUpdate
   * @returns
   */
  async save(ticketExport: Ticket, isUpdate = false): Promise<any> {
    try {
      let result;
      if (isUpdate) {
        result = await this.ticketRepository.findByIdAndUpdate(
          ticketExport._id,
          ticketExport,
        );
      } else {
        result = await this.ticketRepository.create(ticketExport);
        await this.requestService.updateStatusWarehouseRequest(
          result.requestId,
          REQUEST_EXPORT_IMPORT_STATUS.IN_PROGRESS,
        );
      }
      const response = plainToInstance(TicketResponseDto, ticketExport, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            isUpdate
              ? 'message.deliveryTicket.updateDeliveryTicketSuccess'
              : 'message.deliveryTicket.createDeliveryTicketSuccess',
          ),
        )
        .withData(response)
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  public async getPickingList(request: GetPickingListRequestDto): Promise<any> {
    const { page, filter } = request;
    if (!isEmpty(filter)) {
      const filterByItemName = filter.find(
        (item) => item.column === 'itemName',
      )?.text;
      if (filterByItemName) {
        const filterItemName = {
          filter: [{ column: 'name', text: filterByItemName }],
        };
        const items = await this.itemService.getListItem(filterItemName);
        request.itemIds = map(items, 'id');
      }
    }
    const { data, count } = await this.ticketRepository.getPickingList(request);

    const itemIds = uniq(compact(map(data, 'itemId')));
    const warehouseIds = uniq(compact(map(data, 'warehouseId')));
    const locatorIds = uniq(compact(map(data, 'locatorId')));

    let serializeItem = {};
    let serializeWarehouse = {};
    let serializeLocator = {};

    if (!isEmpty(itemIds)) {
      const itemRes = await this.itemService.getItems(itemIds);
      serializeItem = keyBy(itemRes, 'itemId');
    }

    if (!isEmpty(warehouseIds)) {
      const warehouseRes = await this.warehouseService.getList([
        {
          column: 'ids',
          text: warehouseIds.join(','),
        },
      ]);

      serializeWarehouse = keyBy(warehouseRes, 'id');
    }

    if (!isEmpty(locatorIds)) {
      const locatorRes = await this.warehouseLayoutService.getListLocatorByIds(
        locatorIds,
      );

      serializeLocator = keyBy(locatorRes, 'id');
    }

    const getItemStockLocatorConditions =
      new getItemStockWarehouseLocatorByDateRangeRequestDto();
    if (!isEmpty(itemIds)) {
      getItemStockLocatorConditions.itemIds = itemIds;
    }
    if (!isEmpty(warehouseIds)) {
      getItemStockLocatorConditions.warehouseIds = warehouseIds;
    }
    getItemStockLocatorConditions.isFlatLots = '1';

    const itemStockWarehouseLocators =
      await this.itemService.getItemStockWarehouseLocatorByDateRange(
        getItemStockLocatorConditions,
      );

    const serializeItemStockLocators = keyBy(
      itemStockWarehouseLocators,
      (item) =>
        [
          item.itemId,
          item.warehouseId,
          item.lotNumber || '',
          Moment(item.mfg).format('DD/MM/YYYY'),
        ].join('_'),
    );

    const dataReturn = plainToInstance(
      GetPickingListResponseDto,
      data?.map((pickingItem) => {
        const key = [
          pickingItem.itemId,
          pickingItem.warehouseId,
          pickingItem.lot || '',
          Moment(pickingItem.mfgDate).format('DD/MM/YYYY') || '',
        ].join('_');
        return {
          ...pickingItem,
          warehouse: serializeWarehouse[pickingItem.warehouseId],
          locators: serializeItemStockLocators[key]?.locators,
          item: serializeItem[pickingItem.itemId],
          tickets: pickingItem?.tickets.map((ticket) => ({
            ...ticket,
            _id: ticket.ticketId,
          })),
          uniqKey: key,
          remainningQuantityPickUp:
            minus(
              pickingItem?.quantity || 0,
              pickingItem.actualPickUpQuantity || 0,
            ) || 0,
        };
      }),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PaginationResponse>({
      items: dataReturn,
      meta: {
        total: count,
        page: page,
      },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async pickUpMultipleReceiptItems(
    request: PickUpMultipleReceiptItemsRequestDto,
  ): Promise<any> {
    const { pickUpReceiptItems } = request;
    const characterSeparator = '_';

    const ticketIds = map(pickUpReceiptItems, 'ticketId');
    const tickets = await this.ticketRepository.findAllWithPopulate(
      { _id: { $in: ticketIds } },
      'ticketDetails',
    );

    if (!isEqual(ticketIds.length, tickets.length) || isEmpty(tickets)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.TICKET_NOT_FOUND'))
        .build();
    }

    if (pickUpReceiptItems.some((receiptItem) => isEmpty(receiptItem.items))) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.ITEM_NOT_EXIST_IN_TICKET'),
        )
        .build();
    }

    const requestItemIds = uniq(
      compact(map(flatMap(pickUpReceiptItems, 'items'), 'itemId')),
    );

    const requestWarehouseIds = uniq(
      compact(map(flatMap(pickUpReceiptItems, 'items'), 'warehouseId')),
    );

    const getItemStockLocatorConditions =
      new getItemStockWarehouseLocatorByDateRangeRequestDto();
    if (!isEmpty(requestItemIds)) {
      getItemStockLocatorConditions.itemIds = requestItemIds;
    }

    if (!isEmpty(requestWarehouseIds)) {
      getItemStockLocatorConditions.warehouseIds = requestWarehouseIds;
    }
    getItemStockLocatorConditions.isFlatLots = '1';

    let validateItemInTicket = true;
    tickets.forEach((ticket) => {
      const requestPickUpTicket = find(
        pickUpReceiptItems,
        (receiptItem) => receiptItem.ticketId === ticket._id.toString(),
      );

      const ticketDetailItemKeys = new Set(
        ticket?.ticketDetails?.map((ticketDetail) =>
          [
            ticketDetail.itemId,
            ticketDetail?.lot?.toUpperCase() || '',
            Moment(ticketDetail?.mfgDate || '').format('DD/MM/YYYY'),
            Moment(ticketDetail?.importDate || '').format('DD/MM/YYYY'),
          ].join(characterSeparator),
        ),
      );

      for (const item of requestPickUpTicket.items) {
        const key = [
          item.itemId,
          item?.lotNumber?.toUpperCase() || '',
          Moment(item?.mfg || '').format('DD/MM/YYYY'),
          Moment(item?.importDate || '').format('DD/MM/YYYY'),
        ].join(characterSeparator);
        if (!ticketDetailItemKeys.has(key)) {
          validateItemInTicket = false;
        }
      }
    });

    if (!validateItemInTicket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.ITEM_NOT_EXIST_IN_TICKET'),
        )
        .build();
    }

    try {
      const bulkOps = [];
      const detailBulkOps = [];
      const itemMovements = [];
      for (const ticket of tickets) {
        const requestPickUpTicket = find(
          pickUpReceiptItems,
          (receiptItem) => receiptItem.ticketId === ticket._id.toString(),
        );

        const modifiedTicketDetails = [];
        for (const item of requestPickUpTicket.items) {
          const key = [
            item.itemId,
            item?.lotNumber?.toUpperCase(),
            Moment(item?.mfg || '').format('DD/MM/YYYY'),
            Moment(item?.importDate || '').format('DD/MM/YYYY'),
          ].join(characterSeparator);

          const matchingTicketDetail = ticket.ticketDetails.find(
            (ticketDetail) =>
              [
                ticketDetail.itemId,
                ticketDetail?.lot?.toUpperCase() || '',
                Moment(ticketDetail?.mfgDate || '').format('DD/MM/YYYY'),
                Moment(ticketDetail?.importDate || '').format('DD/MM/YYYY'),
              ].join(characterSeparator) === key,
          );

          if (matchingTicketDetail) {
            const quantityToAdd = item.quantity || 0;
            matchingTicketDetail.actualPickUpQuantity = plus(
              matchingTicketDetail.actualPickUpQuantity || 0,
              quantityToAdd,
            );

            itemMovements.push({
              itemId: matchingTicketDetail.itemId,
              lotNumber: matchingTicketDetail.lot,
              mfg: matchingTicketDetail.mfgDate,
              importDate: matchingTicketDetail.importDate,
              warehouseId: ticket.warehouseId,
              ticketId: ticket._id,
              locatorId: item.locatorId || null,
              quantity: quantityToAdd,
              type: TYPE_ENUM_MOVEMENT.PICK_UP,
            });
          }
          modifiedTicketDetails.push(matchingTicketDetail);
        }

        const invalidRequestPickUpItems = [];
        modifiedTicketDetails.forEach((ticketDetail) => {
          if (+ticketDetail.actualPickUpQuantity > +ticketDetail.quantity) {
            invalidRequestPickUpItems.push(ticketDetail);
          }
        });

        if (!isEmpty(invalidRequestPickUpItems)) {
          return new ResponseBuilder({
            inValidItems: invalidRequestPickUpItems,
          })
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(
              await this.i18n.translate('error.INVALID_PICK_UP_QUANTITY'),
            )
            .build();
        }

        const canCompletePickUp = modifiedTicketDetails.every(
          (ticketDetail) =>
            +ticketDetail.actualPickUpQuantity >= ticketDetail.quantity,
        );

        ticket.status = canCompletePickUp
          ? ExportReceiptStatusEnum.COMPLETE_PICK
          : ExportReceiptStatusEnum.PICKING;
        const movementResponse = await this.itemService.createItemStockMovement(
          {
            items: itemMovements,
          },
        );

        if (movementResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
          return new ResponseBuilder()
            .withCode(movementResponse?.statusCode)
            .withMessage(await this.i18n.translate(movementResponse?.message))
            .build();
        }

        const updateItemStockLocatorsResponse =
          await this.itemService.pickUpItemStockWarehouseLocators({
            itemWarehouseLocators: itemMovements,
          });

        if (
          updateItemStockLocatorsResponse.statusCode !==
          ResponseCodeEnum.SUCCESS
        ) {
          return new ResponseBuilder()
            .withCode(updateItemStockLocatorsResponse?.statusCode)
            .withMessage(
              await this.i18n.translate(
                updateItemStockLocatorsResponse?.message,
              ),
            )
            .build();
        }

        bulkOps.push({
          updateOne: {
            filter: { _id: ticket._id },
            update: {
              $set: {
                ticketDetails: ticket.ticketDetails,
                status: ticket.status,
              },
            },
          },
        });

        if (modifiedTicketDetails.length > 0) {
          detailBulkOps.push(
            ...modifiedTicketDetails.map((modifiedDetail) => ({
              updateOne: {
                filter: { _id: modifiedDetail._id },
                update: {
                  $set: modifiedDetail,
                },
              },
            })),
          );
        }

        if (bulkOps.length > 0 && detailBulkOps.length > 0) {
          await Promise.all([
            this.ticketRepository.bulkWrite(
              bulkOps.filter((op) => op.updateOne.filter._id),
            ),
            this.ticketDetailRepository.bulkWrite(
              detailBulkOps.filter((op) => op.updateOne.filter._id),
            ),
          ]);
        }
      }

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.error(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  public async confirmExport(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const exportReceiptTicket = await this.ticketRepository.findOneWithPopulate(
      {
        _id: id,
      },
      'ticketDetails',
    );

    const { ticketDetails } = exportReceiptTicket;

    // Check status ticket
    if (!CAN_CONFIRM_EXPORT_STATUSES.includes(exportReceiptTicket.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
        .build();
    }

    const confirmExportRequest = new ConfirmExportRequestDto();
    confirmExportRequest.ticketId = exportReceiptTicket._id;
    confirmExportRequest.items = ticketDetails?.map((detail) => ({
      itemId: detail.itemId,
      warehouseId: exportReceiptTicket.warehouseId,
      lotNumber: detail.lot,
      mfg: detail.mfgDate,
      locatorId: detail?.locatorId?.toString() || null,
      importDate: detail.importDate,
      quantity: detail.actualPickUpQuantity,
    }));

    // Start transaction
    const session = await this.connection.startSession();
    session.startTransaction();
    try {
      exportReceiptTicket.status = ExportReceiptStatusEnum.COMPLETED;

      const confirmExportItemsResponse =
        await this.itemService.confirmExportReceiptItems(confirmExportRequest);

      if (confirmExportItemsResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(confirmExportItemsResponse?.statusCode)
          .withMessage(
            await this.i18n.translate(confirmExportItemsResponse?.message),
          )
          .build();
      }

      const bulkOps = ticketDetails.map((detail) => ({
        updateOne: {
          filter: { _id: detail._id },
          update: {
            $set: {
              actualQuantity: detail.actualPickUpQuantity,
            },
          },
        },
      }));

      if (bulkOps.length > 0) {
        await Promise.all([
          this.ticketRepository.findByIdAndUpdate(
            exportReceiptTicket._id,
            exportReceiptTicket,
          ),
          this.ticketDetailRepository.bulkWrite(bulkOps),
        ]);
      }

      if (exportReceiptTicket.requestId) {
        const requests = await this.requestService.getListRequestByIds([
          exportReceiptTicket.requestId,
        ]);
        const request = requests ? requests[0] : null;
        if (request) {
          const syncImportExportQuantityRequest =
            new SyncImportExportWarehouseQuantityRequestDto(
              0,
              request.id,
              request.code,
              confirmExportRequest.items.map((item) => ({
                itemId: item.itemId,
                actualQuantity: item.quantity,
              })),
            );
          await this.syncImportExportQuantity(syncImportExportQuantityRequest);
        }
      }

      // Commit transaction
      await session.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch {
      // Abort transaction
      await session.abortTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  private async syncImportExportQuantity(
    data: SyncImportExportWarehouseQuantityRequestDto,
  ): Promise<any> {
    await this.kafkaProducer.send({
      topic: 'sync_actual_import_export_warehouse_quantity_by_request',
      messages: [
        {
          key: 'data',
          value: JSON.stringify(data),
        },
      ],
    });
  }
}
