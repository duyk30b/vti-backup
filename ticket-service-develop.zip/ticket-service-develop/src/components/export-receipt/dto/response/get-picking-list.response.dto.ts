import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { BaseResponseDto } from '@core/dto/base.response.dto';

class TicketResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  quantity: number;
}
class LocatorResponseDto {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}
class WarehouseResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}
class ItemResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  @Type(() => BaseResponseDto)
  itemUnit: BaseResponseDto;
}

export class GetPickingListResponseDto {
  @ApiProperty()
  @Expose()
  uniqKey: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  actualPickUpQuantity: number;

  @ApiProperty()
  @Expose()
  remainningQuantityPickUp: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  locatorId: string;

  @ApiProperty()
  @Expose()
  lot: string;

  @ApiProperty()
  @Expose()
  mfgDate: string;

  @ApiProperty()
  @Expose()
  importDate: string;

  @ApiProperty()
  @Expose()
  @Type(() => TicketResponseDto)
  tickets: TicketResponseDto[];

  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => WarehouseResponseDto)
  warehouse: WarehouseResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => LocatorResponseDto)
  locators: LocatorResponseDto[];
}
