import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsOptional } from 'class-validator';

export class GetPickingListRequestDto extends PaginationQuery {
  @ApiProperty()
  @IsOptional()
  ticketCode: string;

  @ApiProperty()
  @IsOptional()
  itemIds: number[];

  @ApiProperty()
  @IsOptional()
  receiptDate: Date;

  @ApiProperty()
  @IsOptional()
  itemName: string;

  @ApiProperty()
  @IsOptional()
  isPickWaiting: string;

  @ApiProperty()
  @IsOptional()
  warehouseId: number;
}
