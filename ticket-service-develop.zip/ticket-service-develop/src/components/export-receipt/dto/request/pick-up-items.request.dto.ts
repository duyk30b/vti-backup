import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsArray,
  IsDateString,
  IsInt,
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsPositive,
  IsString,
  ValidateNested,
} from 'class-validator';

class PickUpItemRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsPositive()
  @IsInt()
  quantity: number;

  @ApiProperty()
  @IsMongoId()
  locatorId: string;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  mfg: Date;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  importDate: Date;
}

export class PickUpReceiptItemsRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  ticketId: string;

  @ApiProperty()
  @IsArray()
  @ArrayNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => PickUpItemRequestDto)
  items: PickUpItemRequestDto[];
}

export class PickUpMultipleReceiptItemsRequestDto extends BaseDto {
  @ApiProperty()
  @IsArray()
  @ArrayNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => PickUpReceiptItemsRequestDto)
  pickUpReceiptItems: PickUpReceiptItemsRequestDto[];
}
