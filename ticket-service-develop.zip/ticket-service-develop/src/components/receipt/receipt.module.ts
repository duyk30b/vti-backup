import { FileModule } from '@components/file/file.module';
import { Global, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { TicketSchema } from 'src/models/ticket/ticket.schema';
import { TicketDetailSchema } from 'src/models/ticket/ticket-details.schema';
import { TicketDetailRepository } from 'src/repository/ticket/ticket-detail.repository';
import { TicketRepository } from 'src/repository/ticket/ticket.repository';
import { UserService } from '@components/user/user.service';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { ReceiptController } from './receipt.controller';
import { ReceiptService } from './receipt.service';
import { AttributeService } from '@components/attribute/attribute.service';
import { ItemService } from '@components/item/item.service';
import { ItemModule } from '@components/item/item.module';
import { WarehouseLayoutModule } from '@components/warehouse-layout/warehouse-layout.module';
import { WarehouseLayoutService } from '@components/warehouse-layout/warehouse-layout.service';
import { SaleService } from '@components/sale/sale.service';
import { RequestService } from '@components/request/request.service';
import { ClientKafka, ClientsModule, Transport } from '@nestjs/microservices';
import * as fs from 'fs';
import * as path from 'path';

@Global()
@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: 'Ticket',
        schema: TicketSchema,
      },
      {
        name: 'TicketDetail',
        schema: TicketDetailSchema,
      },
    ]),
    ClientsModule.register([
      {
        name: 'CLIENT_KAFKA',
        transport: Transport.KAFKA,
        options: {
          client: {
            clientId: 'item_sync_report',
            brokers: process.env.KAFKA_BROKERS.split(','),
            ssl: {
              rejectUnauthorized: false,
              ca: [
                fs.readFileSync(
                  path.join(__dirname, '/../../cert/kafka.crt'),
                  'utf-8',
                ),
              ],
              key: fs.readFileSync(
                path.join(__dirname, '/../../cert/kafka.key'),
                'utf-8',
              ),
              cert: fs.readFileSync(
                path.join(__dirname, '/../../cert/kafka.pem'),
                'utf-8',
              ),
            },
          },
        },
      },
    ]),
    FileModule,
    ItemModule,
    WarehouseLayoutModule,
  ],
  providers: [
    {
      provide: 'ReceiptServiceInterface',
      useClass: ReceiptService,
    },
    {
      provide: 'TicketRepositoryInterface',
      useClass: TicketRepository,
    },
    {
      provide: 'TicketDetailRepositoryInterface',
      useClass: TicketDetailRepository,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
    {
      provide: 'RequestServiceInterface',
      useClass: RequestService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'TicketDetailRepositoryInterface',
      useClass: TicketDetailRepository,
    },
    {
      provide: 'AttributeServiceInterface',
      useClass: AttributeService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseLayoutServiceInterface',
      useClass: WarehouseLayoutService,
    },
    {
      provide: 'KAFKA_PRODUCER',
      useFactory: async (kafkaClient: ClientKafka) => {
        return kafkaClient.connect();
      },
      inject: ['CLIENT_KAFKA'],
    },
  ],
  controllers: [ReceiptController],
  exports: [],
})
export class ReceiptModule {}
