import { GetDetailTicketRequestDto } from '@utils/dto/request/get-detail-ticket.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { GetTicketDetailResponseDto } from '@utils/dto/response/get-ticket-detail.response.dto';
import { TicketServiceInterface } from '@utils/interface/ticket.service.interface';
import { GetListTicketByItemRequestDto } from '../dto/request/get-list-ticket-by-item.dto';
import { GetTicketByItemRequestDto } from '../dto/request/get-ticket-by-item.dto';
import { GetTicketByKeywordRequestDto } from '../dto/request/get-ticket-by-keyword.dto';
import { GetTicketByIdsRequestDto } from '../dto/request/get-ticket-receipt-by-ids.request.dto';
import { GetTicketByRequestIdsRequestDto } from '../dto/request/get-ticket-receipt-by-request-ids.request.dto';
import { GetTicketReceiptByTicketIdRequestDto } from '../dto/request/get-ticket-receipt-by-ticket-id.request.dto';
import { PutAwayReceiptRequestDto } from '../dto/request/receipt-put-away.request.dto';
import { TicketReceiveRequestDto } from '../dto/request/receive-ticket.request.dto';
import { StoredTicketReceiptRequestDto } from '../dto/request/stored-ticket-receipt.request.dto';
import { WarehouseImportStoreRequestDto } from '../dto/request/warehouse-import-store.request.dto';

export interface ReceiptServiceInterface extends TicketServiceInterface {
  getDetail(
    request: GetDetailTicketRequestDto,
  ): Promise<GetTicketDetailResponseDto>;
  warehouseImportStore(request: WarehouseImportStoreRequestDto): Promise<any>;
  getTicketReceiptByTicketId(
    request: GetTicketReceiptByTicketIdRequestDto,
  ): Promise<any>;
  getTicketByRequestIds(request: GetTicketByRequestIdsRequestDto): Promise<any>;
  receiveTicket(request: TicketReceiveRequestDto): Promise<any>;
  receiptStore(request: StoredTicketReceiptRequestDto): Promise<any>;
  getTicketReceiptByCondition(
    request: GetTicketByRequestIdsRequestDto,
  ): Promise<any>;
  putAwayReceipt(request: PutAwayReceiptRequestDto): Promise<any>;
  getTicketReceiptByIds(request: GetTicketByIdsRequestDto): Promise<any>;
  getTicketCodeKeyword(request: GetTicketByKeywordRequestDto): Promise<any>;
  confirm(request: IdParamMongoDto): Promise<any>;
  reject(request: IdParamMongoDto): Promise<any>;
  getListTicketByItem(request: GetListTicketByItemRequestDto): Promise<any>;
  getDetailReceipt(request: GetDetailTicketRequestDto): Promise<any>;
}
