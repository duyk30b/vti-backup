import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsNotEmpty,
  IsInt,
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsOptional,
  IsString,
  ValidateNested,
  IsNumber,
  IsPositive,
  IsEnum,
} from 'class-validator';
class ItemImportDto {
  @ApiProperty({ example: 2 })
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty({ example: 2.2 })
  @IsPositive()
  @Transform(({ value }) => Number(value))
  @IsNumber()
  quantity: number;

  @ApiProperty({ example: 2 })
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty({ example: 1, description: 'Id tầng' })
  @IsNotEmpty()
  locatorId: string;

  @ApiProperty({ example: 1, description: 'Id tầng' })
  @IsOptional()
  mfg: Date;

  // @ApiProperty()
  // @ValidateNested({ each: true })
  // @ArrayUnique<LocationItemImportDto>((i) => i.locatorId)
  // @IsNotEmpty()
  // @IsArray()
  // @Type(() => LocationItemImportDto)
  // locations: LocationItemImportDto[];
}

class LocationItemImportDto {
  @ApiProperty({ example: 2.2 })
  @IsPositive()
  @Transform(({ value }) => Number(value))
  @IsNumber()
  quantity: number;

  @ApiProperty({ example: 1, description: 'Id tầng' })
  @IsNotEmpty()
  locatorId: string;
}
export class WarehouseImportStoreRequestDto extends BaseDto {
  @ApiProperty({
    example: 1,
    description:
      'Tùy theo movementType mà objectId sẽ là purchasedOrderId || productionOrderId || saleOrderId',
  })
  @IsNotEmpty()
  orderId: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  warehouseId: number;

  @ApiProperty({ type: ItemImportDto })
  @ArrayNotEmpty()
  @IsArray()
  @Type(() => ItemImportDto)
  items: ItemImportDto[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum([0, 1])
  autoCreateReceive: number;
}
