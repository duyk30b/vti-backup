import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsInt,
  IsOptional,
  IsString,
  IsPositive,
  ArrayNotEmpty,
  IsArray,
  ValidateNested,
  IsNotEmpty,
} from 'class-validator';
class ItemPutAway extends BaseDto {
  @ApiProperty({ example: 2 })
  @Transform(({ value }) => Number(value))
  @IsInt()
  itemId: number;

  @ApiProperty({ example: 2.2 })
  @IsPositive()
  @IsInt()
  storedQuantity: number; //Số Lượng cất

  @ApiProperty({ example: 2.2 })
  @IsString()
  locatorId: string;

  @ApiProperty({ example: 2.2 })
  @IsOptional()
  @IsString()
  ticketId: string;

  @ApiProperty({ example: 2.2 })
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty({ example: 2 })
  @Transform(({ value }) => Number(value))
  @IsInt()
  warehouseId: number;

  @ApiProperty({ example: 2.2 })
  @Transform(({ value }) => Number(value))
  @IsOptional()
  @IsInt()
  warehouseLocatorId: number;

  @ApiProperty({ example: 1, description: 'Id tầng' })
  @IsOptional()
  mfg: Date;
}
export class PutAwayReceiptRequestDto extends BaseDto {
  @ApiProperty({ type: ItemPutAway })
  @IsArray()
  @ArrayNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => ItemPutAway)
  items: ItemPutAway[];
}
