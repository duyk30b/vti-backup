import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsInt,
  IsOptional,
  IsString,
  IsPositive,
  IsBoolean,
  ArrayNotEmpty,
  IsArray,
} from 'class-validator';
class ItemStoredDto {
  @ApiProperty({ example: 2 })
  @Transform(({ value }) => Number(value))
  @IsInt()
  itemId: number;

  @ApiProperty({ example: 2 })
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty({ example: 2.2 })
  @IsPositive()
  @IsInt()
  storedQuantity: number; //Số Lượng cất

  @ApiProperty({ example: 2.2 })
  @IsString()
  locatorId: string; //Số Lượng cất

  @ApiProperty({ example: 2.2 })
  @Transform(({ value }) => Number(value))
  @IsInt()
  warehouseLocatorId: number; //Số Lượng cất

  @ApiProperty({ example: 1, description: 'Id tầng' })
  @IsOptional()
  mfg: Date;
}
export class StoredTicketReceiptRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsInt()
  orderId: number;

  @ApiProperty()
  ticketId: string;

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsInt()
  warehouseId: number;

  @ApiProperty({
    description: 'Xác nhận hoàn thành cất',
  })
  @IsOptional()
  @IsBoolean()
  isComplete: boolean;

  @ApiProperty({ type: ItemStoredDto })
  @ArrayNotEmpty()
  @IsArray()
  @Type(() => ItemStoredDto)
  items: ItemStoredDto[];
}
