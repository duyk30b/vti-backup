export class ItemSwiftLocator {
  itemId: number;
  lotNumber: string | null;
  quantity: number;
  // movementOrderDetailId?: number;
  // movementOrderWarehouseDetailId?: number;
  // sourceLocatorId?: number;
  // destinationLocatorId?: number;
  itemStockLocationId: string;

  constructor(
    itemId: number,
    lotNumber: string | null,
    quantity: number,
    // movementOrderDetailId: number,
    // movementOrderWarehouseDetailId: number,
    // sourceLocatorId: number,
    // destinationLocatorId: number,
    itemStockLocationId: string,
  ) {
    this.itemId = itemId;
    this.lotNumber = lotNumber;
    this.quantity = quantity;
    // this.movementOrderDetailId = movementOrderDetailId;
    // this.movementOrderWarehouseDetailId = movementOrderWarehouseDetailId;
    // this.sourceLocatorId = sourceLocatorId;
    // this.destinationLocatorId = destinationLocatorId;
    this.itemStockLocationId = itemStockLocationId;
  }
}
export class SwiftItemInLocatorRequestDto {
  items: ItemSwiftLocator[];
  warehouseId: number;
  userId: number;
  orderId: number;
  orderCode: string;
  orderType: number;
  movementTypeImport: number;
  movementTypeExport: number;
  destinationWarehouseId: number;
  purpose?: string;
  departmentReceiptId?: number;

  constructor(
    warehouseId: number,
    destinationWarehouseId: number,
    userId: number,
    orderId: number,
    orderCode: string,
    orderType: number,
    movementTypeImport: number,
    movementTypeExport: number,
    items: ItemSwiftLocator[],
    purpose?: string,
    departmentReceiptId?: number,
  ) {
    this.items = items;
    this.userId = userId;
    this.orderId = orderId;
    this.orderCode = orderCode;
    this.orderType = orderType;
    this.movementTypeImport = movementTypeImport;
    this.movementTypeExport = movementTypeExport;
    this.warehouseId = warehouseId;
    this.destinationWarehouseId = destinationWarehouseId;
    this.purpose = purpose;
    this.departmentReceiptId = departmentReceiptId;
  }
}
