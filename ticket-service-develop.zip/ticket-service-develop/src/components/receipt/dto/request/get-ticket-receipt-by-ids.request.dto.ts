import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray } from 'class-validator';

export class GetTicketByIdsRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsArray()
  ticketIds: string[];
}
