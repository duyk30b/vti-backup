import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

export class FilterItemByCondition extends BaseDto {
  @ApiProperty()
  @Transform(({ value }) => +value)
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  lot: string;

  @ApiProperty()
  @IsDateString()
  @IsOptional()
  mfg: Date;

  @ApiProperty()
  @IsDateString()
  @IsOptional()
  storageDate: Date;
}
export class ConditionOrder {
  @ApiProperty()
  @IsOptional()
  @IsString()
  orderId: string;

  @ApiProperty()
  @IsInt()
  orderType: number;
}

export class GetListTicketByItemRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => ConditionOrder)
  @ValidateNested()
  order: ConditionOrder;

  @ApiProperty()
  @ValidateNested()
  @ArrayNotEmpty()
  @Type(() => FilterItemByCondition)
  items: FilterItemByCondition[];
}
