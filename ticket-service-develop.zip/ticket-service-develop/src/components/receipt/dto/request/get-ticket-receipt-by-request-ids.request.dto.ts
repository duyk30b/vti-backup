import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsArray } from 'class-validator';

export class GetTicketByRequestIdsRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsArray()
  requestIds: string[];
}
