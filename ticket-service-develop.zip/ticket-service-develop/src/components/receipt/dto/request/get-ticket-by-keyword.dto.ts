import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional } from 'class-validator';

export class GetTicketByKeywordRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  codeKeyword: string;

  @ApiPropertyOptional()
  @IsOptional()
  type: number;
}
