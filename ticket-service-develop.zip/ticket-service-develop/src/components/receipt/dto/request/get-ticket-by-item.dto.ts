import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import {
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
} from 'class-validator';

export class GetTicketByItemDto extends BaseDto {
  @ApiProperty()
  @Transform(({ value }) => +value)
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  lot: string;

  @ApiProperty()
  @IsDateString()
  @IsOptional()
  mfg: Date;

  @ApiProperty()
  @IsDateString()
  @IsOptional()
  storageDate: Date;
}

export class GetTicketByItemRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  orderType: number;

  items: GetTicketByItemDto[];
}
