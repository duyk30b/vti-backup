import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsArray,
  IsBoolean,
  IsDateString,
  IsInt,
  IsOptional,
  IsPositive,
  IsString,
} from 'class-validator';

class ItemReceiveDto {
  @ApiProperty({ example: 2 })
  @IsInt()
  itemId: number;

  @ApiProperty({ example: 2 })
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty({ example: 2.2 })
  @IsPositive()
  @IsInt()
  quantity: number;

  @ApiProperty({ example: 1, description: 'Id tầng' })
  @IsOptional()
  @IsDateString()
  mfg: Date;
}

export class TicketReceiveRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsInt()
  orderId: number;

  @ApiProperty()
  ticketId: string;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseId: number;

  @ApiProperty({
    description: 'Xác nhận hoàn thành cất',
  })
  @IsOptional()
  @IsBoolean()
  isComplete: boolean;

  @ApiProperty({ type: ItemReceiveDto })
  @ArrayNotEmpty()
  @IsArray()
  @Type(() => ItemReceiveDto)
  items: ItemReceiveDto[];
}
