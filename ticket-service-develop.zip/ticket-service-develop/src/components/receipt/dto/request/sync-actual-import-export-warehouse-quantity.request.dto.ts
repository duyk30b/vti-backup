class ItemDetail {
  itemId: number;
  actualQuantity: number;
}
export class SyncImportExportWarehouseQuantityRequestDto {
  type: number; //loai yc nhap, xuat
  requestId: string;
  requestCode: string;
  items: ItemDetail[];

  constructor(
    type: number, //loai yc nhap, xuat
    requestId: string,
    requestCode: string,
    items: ItemDetail[],
  ) {
    this.type = type;
    this.requestId = requestId;
    this.requestCode = requestCode;
    this.items = items;
  }
}
