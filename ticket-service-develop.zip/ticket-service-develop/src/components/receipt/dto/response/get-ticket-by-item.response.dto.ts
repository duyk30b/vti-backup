import { minusBigNumber } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { Expose, Transform } from 'class-transformer';

export class GetTicketByItemResponseDto extends BaseDto {
  @Expose()
  @Transform(({ obj }) => obj?.ticketId?._id?.toString())
  id: string;

  @Expose()
  quantity: number;

  @Expose()
  itemId: number;

  @Expose()
  lot: string;

  @Expose()
  mfgDate: string;

  @Expose()
  importDate: string;

  @Expose()
  @Transform(
    ({ obj }) =>
      +minusBigNumber(
        obj?.actualQuantity || 0,
        obj?.actualPutAwayQuantity || 0,
      ),
  )
  actualQuantity: number;

  @Expose()
  actualPutAwayQuantity: number;

  @Expose()
  actualPickUpQuantity: number;

  @Expose()
  @Transform(
    ({ obj }) =>
      +minusBigNumber(
        obj?.actualQuantity || 0,
        obj?.actualPutAwayQuantity || 0,
      ),
  )
  remainPutQuantity: number;

  @Expose()
  @Transform(
    ({ obj }) =>
      +minusBigNumber(obj?.actualQuantity || 0, obj?.actualPickUpQuantity || 0),
  )
  remainPickUpQuantity: number;

  @Expose()
  @Transform(({ obj }) => obj?.ticketId?.code)
  code: string;
}
