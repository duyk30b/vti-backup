import { BaseUserResponseDto } from '@components/user/dto/response/base.user.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose, Type } from 'class-transformer';
class ItemResponse {
  @Expose()
  id: string;

  @Expose({ name: 'code' })
  code: string;

  @Expose({ name: 'name' })
  name: string;
}

class WarehouseResponse {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;
}
export class TicketDetailResponseDto {
  @Expose()
  itemId: number;

  @Expose()
  @Type(() => ItemResponse)
  item: ItemResponse;

  @Expose()
  quantity: number;

  @Expose()
  price: number;

  @Expose()
  amount: number;

  @Expose()
  mfgDate: Date;

  @Expose()
  importDate: Date;

  @Expose()
  actualPickUpQuantity: number;

  @Expose()
  actualPutAwayQuantity: number;

  @Expose()
  actualQuantity: number;
}
export class TicketAbstractResponseDto extends BaseResponseDto {
  @Expose()
  status: number;

  @Expose()
  type: number;

  @Expose()
  warehouseId: number;

  @Expose()
  @Type(() => WarehouseResponse)
  warehouse: WarehouseResponse;

  @Expose()
  receiptDate: Date;

  @Expose()
  @Type(() => BaseUserResponseDto)
  createdBy: BaseUserResponseDto;

  @Expose()
  @Type(() => BaseUserResponseDto)
  approver: BaseUserResponseDto;

  @Expose()
  @Type(() => BaseUserResponseDto)
  completer: BaseUserResponseDto;

  @Expose()
  @Type(() => TicketDetailResponseDto)
  ticketDetails: TicketDetailResponseDto[];
}
