import { ObjectId } from 'mongodb';
import { AttributeServiceInterface } from '@components/attribute/interface/attribute.service.interface';
import { FILE_RESOURCE } from '@components/file/file.constant';
import { FileRepositoryInterface } from '@components/file/interface/file.repository.interface';
import { FileServiceInterface } from '@components/file/interface/file.service.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import {
  DATA_TYPE_ENUM,
  MAX_FILE_SIZE,
  TICKET_TYPE_ENUM,
  STATUS_ENUM,
  divBigNumber,
  mulBigNumber,
  IS_OPTIONAL,
  plusBigNumber,
  minusBigNumber,
} from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { InjectConnection } from '@nestjs/mongoose';
import { CreateTicketRequestDto } from '@utils/dto/request/create-ticket.request.dto';
import { DeleteTicketRequestDto } from '@utils/dto/request/delete-ticket.request.dto';
import { GetDetailTicketRequestDto } from '@utils/dto/request/get-detail-ticket.request.dto';
import { GetListTicketRequestDto } from '@utils/dto/request/get-list-ticket.request.dto';
import { UpdateTicketRequestDto } from '@utils/dto/request/update-ticket.request.dto';
import { GetTicketDetailResponseDto } from '@utils/dto/response/get-ticket-detail.response.dto';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { TicketResponseDto } from '@utils/dto/response/ticket.response.dto';
import { compareDate, minus } from '@utils/helper';
import { TicketDetailRepositoryInterface } from '@utils/interface/ticket-detail.repository.interface';
import { TicketRepositoryInterface } from '@utils/interface/ticket.repository.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import {
  find,
  forEach,
  isEmpty,
  keyBy,
  map,
  uniq,
  flatMap,
  has,
  compact,
  groupBy,
  sumBy,
  filter,
  isEqual,
  first,
  at,
} from 'lodash';
import * as moment from 'moment';
import { Connection, Types } from 'mongoose';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { Ticket } from 'src/models/ticket/ticket.schema';
import { ReceiptServiceInterface } from './interface/receipt.service.interface';
import {
  ALLOW_MIME_TYPE_ENUM,
  CAN_NOT_CREATE_UPDATE_TICKET,
  CAN_NOT_RECEIVE_PO_IMPORT,
  CAN_UPDATE_TICKET,
  ImportReceiptStatusEnum,
  RECEIPT_IMPORT_CODE_PREFIX,
  RECEIPT_TICKET_FIELD_CODE,
  REQUEST_EXPORT_IMPORT_STATUS,
  statusObject,
  TICKET_RECEIPT_DETAIL_TEMPLATE_CODE,
  TYPE_ENUM_MOVEMENT,
  WarehouseByLotManagementEnum,
} from './receipt.constant';
import { generateTicketCode } from 'src/helper/code.helper';
import { WarehouseImportStoreRequestDto } from './dto/request/warehouse-import-store.request.dto';
import { ItemService } from '@components/item/item.service';
import { WarehouseLayoutServiceInterface } from '@components/warehouse-layout/interface/warehouse-layout.service.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { CreateItemMovementDto } from '@components/item/dto/request/create-item-movement.request.dto';
import * as mongoose from 'mongoose';
import { UpdateStockFromTicketRequestDto } from '@components/item/dto/request/update-stock-from-ticket-request.request.dto';
import { GetTicketReceiptByTicketIdRequestDto } from './dto/request/get-ticket-receipt-by-ticket-id.request.dto';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { CreatePurchasedOrderImportReceiveTicketRequestDto } from '@components/sale/dto/request/create-ticket-receive-request.dto';
import { GetTicketByRequestIdsRequestDto } from './dto/request/get-ticket-receipt-by-request-ids.request.dto';
import {
  ItemSwiftLocator,
  SwiftItemInLocatorRequestDto,
} from './dto/request/swift-item-in-locator.request.dto';
import { TicketReceiveRequestDto } from './dto/request/receive-ticket.request.dto';
import { StoredTicketReceiptRequestDto } from './dto/request/stored-ticket-receipt.request.dto';
import { CreateItemSwiftLocatorTicket } from '@components/item/dto/request/create-item-swift-locator-ticket.request.dto';
import { RequestServiceInterface } from '@components/request/interface/request.service.interface';
import { PutAwayReceiptRequestDto } from './dto/request/receipt-put-away.request.dto';
import { GetTicketByIdsRequestDto } from './dto/request/get-ticket-receipt-by-ids.request.dto';
import { GetTicketByKeywordRequestDto } from './dto/request/get-ticket-by-keyword.dto';
import { CreateItemPutAwayReceiptDto } from '@components/item/dto/request/put-away-receipt.request.dto';
import { GetTicketByItemResponseDto } from './dto/response/get-ticket-by-item.response.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { GetTicketByItemRequestDto } from './dto/request/get-ticket-by-item.dto';
import { GetListTicketByItemRequestDto } from './dto/request/get-list-ticket-by-item.dto';
import { Producer } from '@nestjs/microservices/external/kafka.interface';
import { SyncImportExportWarehouseQuantityRequestDto } from './dto/request/sync-actual-import-export-warehouse-quantity.request.dto';
import { TicketAbstractResponseDto } from './dto/response/receipt-ticket.response.dto';

@Injectable()
export class ReceiptService implements ReceiptServiceInterface {
  private readonly logger = new Logger(ReceiptService.name);
  constructor(
    @Inject('TicketRepositoryInterface')
    private readonly ticketRepository: TicketRepositoryInterface,

    @Inject('TicketDetailRepositoryInterface')
    private readonly ticketDetailRepository: TicketDetailRepositoryInterface,

    @Inject('FileServiceInterface')
    private readonly fileService: FileServiceInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('SaleServiceInterface')
    protected readonly saleService: SaleServiceInterface,

    @Inject('RequestServiceInterface')
    protected readonly requestService: RequestServiceInterface,

    @Inject('WarehouseLayoutServiceInterface')
    private readonly warehouseLayoutService: WarehouseLayoutServiceInterface,

    @Inject('FileRepositoryInterface')
    private readonly fileRepository: FileRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('AttributeServiceInterface')
    protected readonly attributeService: AttributeServiceInterface,

    @InjectConnection()
    private readonly connection: Connection,

    @Inject('KAFKA_PRODUCER')
    private kafkaProducer: Producer,
  ) {}

  public async delete(request: DeleteTicketRequestDto): Promise<any> {
    const { id } = request;
    const ticket = await this.ticketRepository.findOneById(id);
    if (isEmpty(ticket)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const ticketsUseRequest = await this.ticketRepository.findAllByCondition({
      requestId: ticket?.requestId,
    });
    if (!isEmpty(ticketsUseRequest)) {
      if (ticketsUseRequest.length === 1) {
        await this.requestService.updateStatusWarehouseRequest(
          ticket.requestId,
          REQUEST_EXPORT_IMPORT_STATUS.CONFIRM,
        );
      }
    }
    // Check status ticket
    if (
      ticket.status !== STATUS_ENUM.WAITING &&
      ticket.status !== STATUS_ENUM.REJECT
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }

    // File
    const file = await this.fileRepository.findOneByCondition({
      resourceId: id,
      resource: FILE_RESOURCE.RI,
    });

    // Start transaction
    const session = await this.connection.startSession();
    session.startTransaction();
    try {
      // Delete TicketDetails
      await this.ticketDetailRepository.deleteManyByCondition({
        ticketId: id,
      });

      // Delete file
      if (!isEmpty(file)) {
        await this.fileRepository.deleteById(file.id);
      }

      // Delete Ticket
      await this.ticketRepository.deleteById(id);

      // Commit transaction
      await session.commitTransaction();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch {
      // Abort transaction
      await session.abortTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
  async getDetailReceipt(request: GetDetailTicketRequestDto): Promise<any> {
    const { id } = request;
    const receiptTicket = await this.ticketRepository.findOneWithPopulate(
      { _id: id },
      'ticketDetails',
    );
    if (!receiptTicket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.TICKET_NOT_FOUND'))
        .build();
    }
    const warehouseIds = [receiptTicket.warehouseId];
    const itemIds = map(receiptTicket.ticketDetails, 'itemId');
    const userIds = [receiptTicket.createdBy];
    const [serilizeUser, serilizeWarehouse, serilizeItem] = await Promise.all([
      this.userService.getUserByIds(userIds, true),
      this.warehouseService.getListByIDs(warehouseIds, true),
      this.itemService.getItemByIds(itemIds, true),
    ]);
    const ticketDetails = receiptTicket.ticketDetails?.map((item) => {
      return {
        ...item,
        item: serilizeItem[item.itemId],
      };
    });
    const dataFormat = plainToInstance(
      TicketAbstractResponseDto,
      {
        ...receiptTicket,
        warehouse: serilizeWarehouse[receiptTicket.warehouseId],
        createdBy: serilizeUser[receiptTicket.createdBy],
        ticketDetails: ticketDetails,
      },
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(dataFormat)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  /**
   * Get receipt ticket detail
   * @param request
   * @returns
   */
  public async getDetail(
    request: GetDetailTicketRequestDto,
  ): Promise<GetTicketDetailResponseDto | any> {
    const { id } = request;
    const receiptTicket = await this.ticketRepository.findOneWithPopulate(
      { _id: id },
      'ticketDetails',
    );
    if (!receiptTicket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.TICKET_NOT_FOUND'))
        .build();
    }

    const template = await this.attributeService.getTemplateById(
      receiptTicket.templateId,
    );
    if (!template) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.TEMPLATE_NOT_FOUND'))
        .build();
    }
    const templateResponse = await this.attributeService.getTemplateByCode(
      template?.code,
    );

    const concatNestedAttributeValues = [
      ...receiptTicket.attributes,
      ...flatMap(receiptTicket.ticketDetails, (i) => {
        return i.attributes;
      }),
    ];

    const userIds = [receiptTicket?.createdBy] || [];
    const itemIds = [];
    const departmentSettingIds = [];
    const warehouseImportIds = [];
    const requestIds = [];
    const reasonIds = [];
    concatNestedAttributeValues.forEach((attributeValue) => {
      const { code, value } = attributeValue;
      switch (code) {
        case RECEIPT_TICKET_FIELD_CODE.ITEM_CODE:
          if (value) itemIds.push(value);
          break;
        case RECEIPT_TICKET_FIELD_CODE.DEPARTMENT_SETTING:
          if (value) departmentSettingIds.push(value);
          break;
        case RECEIPT_TICKET_FIELD_CODE.WAREHOUSE_IMPORT_CODE:
          if (value) warehouseImportIds.push(value);
          break;
        case RECEIPT_TICKET_FIELD_CODE.REQUEST_CODE:
          if (value && !isEmpty(value)) requestIds.push(value);
          break;
        case RECEIPT_TICKET_FIELD_CODE.REASON:
          if (value) reasonIds.push(value);
          break;
        default:
          break;
      }
    });
    const [
      serializedUser,
      serializedItem,
      serializedDepartment,
      serializedWarehouse,
      serializedReason,
    ] = await Promise.all([
      this.userService.getUserByIds(userIds, true),
      this.itemService.getItemByIds(itemIds, true),
      this.userService.getDepartmentSettingByIds(departmentSettingIds, true),
      this.warehouseService.getListByIDs(warehouseImportIds, true),
      this.saleService.getReasonByIds(reasonIds, true),
    ]);
    let serializedRequestOrder;
    if (!isEmpty(requestIds)) {
      serializedRequestOrder = await this.requestService.getListRequestByIds(
        requestIds,
        true,
      );
    }
    const file = await this.fileRepository.findOneByCondition({
      resourceId: new Types.ObjectId(id),
      resource: FILE_RESOURCE.RI,
    });
    let beautifiedData = first(this.beautifyRequestOrder([receiptTicket]));
    beautifiedData = {
      ...beautifiedData,
      [TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.PO_CODE]: {
        value: receiptTicket?.code,
      },
      [TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.TEMPLATE_CODE]: {
        value: {
          id: template._id,
          name: template.name,
          code: template.code,
        },
      },
      [TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.REQUEST_CODE]: {
        value: serializedRequestOrder
          ? serializedRequestOrder[
              beautifiedData[RECEIPT_TICKET_FIELD_CODE.REQUEST_CODE]?.value
            ]
          : {},
      },
      [TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.FILE]: {
        value: file,
      },
      [TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.CREATED_AT]: {
        value: receiptTicket?.createdAt,
      },
      [TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.REASON]: {
        value:
          serializedReason[
            beautifiedData[RECEIPT_TICKET_FIELD_CODE.REASON]?.value
          ],
      },
      [TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.CREATED_BY]: {
        value: serializedUser[receiptTicket?.createdBy],
      },
      [TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.STATUS]: {
        value: beautifiedData.status,
      },
      [TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.WAREHOUSE_IMPORT_CODE]: {
        value:
          serializedWarehouse[
            beautifiedData[RECEIPT_TICKET_FIELD_CODE.WAREHOUSE_IMPORT_CODE]
              ?.value
          ],
      },
      [TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.DEPARTMENT_CODE]: {
        value:
          serializedDepartment[
            beautifiedData[RECEIPT_TICKET_FIELD_CODE.DEPARTMENT_SETTING]?.value
          ],
      },
      ticketDetails: beautifiedData.ticketReceiptDetails?.map((i) => {
        return {
          ...i,
          [TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.DETAIL.ITEM_CODE]: {
            value:
              serializedItem[i[RECEIPT_TICKET_FIELD_CODE.ITEM_CODE]?.value],
          },
          [TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.DETAIL.ITEM_NAME]: {
            value:
              serializedItem[i[RECEIPT_TICKET_FIELD_CODE.ITEM_CODE]?.value]
                ?.name,
          },
          [TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.DETAIL.ITEM_UNIT_NAME]: {
            value:
              serializedItem[i[RECEIPT_TICKET_FIELD_CODE.ITEM_CODE]?.value]
                ?.itemUnit,
          },
          [TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.DETAIL.ENTRY_QUANTITY]: {
            value: i?.actualQuantity,
          },
        };
      }),
    };
    const ticketDetails = receiptTicket.ticketDetails?.map((item) => {
      return {
        ...item,
        itemResponse: serializedItem[item.itemId],
      };
    });
    return this.makeResponse(templateResponse, beautifiedData, ticketDetails);
  }

  private makeResponse(
    template: any,
    beautifiedData: any,
    ticketDetails?: any,
  ) {
    let { attributeHeaders, attributeGroups } = template;
    attributeHeaders = attributeHeaders?.map((attributeHeader) => {
      return {
        ...attributeHeader,
        attribute: {
          ...attributeHeader.attribute,
          value: beautifiedData[attributeHeader.attribute?.code]?.value,
        },
      };
    });
    const ticketReceiptDetails = beautifiedData.ticketDetails;

    attributeGroups = attributeGroups?.map((attributeGroup) => {
      return compact(
        ticketReceiptDetails?.map((requestOrderDetail) => {
          if (
            isEqual(
              requestOrderDetail.groupId.toString(),
              attributeGroup.attributes[0].attributeGroup.id.toString(),
            )
          ) {
            const attributes = attributeGroup.attributes.map((attribute) => {
              return {
                ...attribute,
                attribute: {
                  ...attribute.attribute,
                  value: requestOrderDetail[attribute.attribute?.code]?.value,
                },
              };
            });
            return { ...attributeGroup, attributes };
          }
          return;
        }),
      );
    });
    const dataReturn = {
      ...template,
      attributeHeaders,
      attributeGroups: attributeGroups,
      items: ticketDetails,
    };
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private beautifyRequestOrder(data: any[]): any[] {
    return data?.map((ticketReceipt) => {
      const generalInfo = keyBy(
        ticketReceipt.attributes.map((attributeValue) => {
          return { key: attributeValue.code, value: attributeValue.value };
        }),
        'key',
      );

      let ticketReceiptDetails = ticketReceipt.ticketDetails;
      if (!isEmpty(ticketReceiptDetails)) {
        ticketReceiptDetails = ticketReceiptDetails.map(
          (ticketReceiptDetail) => {
            const generalInfo = keyBy(
              ticketReceiptDetail.attributes.map((attributeValue) => {
                return {
                  key: attributeValue.code,
                  value: attributeValue.value,
                };
              }),
              'key',
            );
            return { ...ticketReceiptDetail, ...generalInfo };
          },
        );
      }
      return { ...ticketReceipt, ...generalInfo, ticketReceiptDetails };
    });
  }

  /* Get list receipt ticket
   * @param request
   * @returns
   */
  public async getList(request: GetListTicketRequestDto): Promise<any> {
    const { page, filter } = request;
    let filterObj = {};
    if (!request.filter) request.filter = [];

    const createdByUserFullname = filter?.find(
      (item) => item.column === 'createdBy',
    )?.text;

    let filterCreatedByUserIds = [];
    if (!isEmpty(createdByUserFullname)) {
      filterCreatedByUserIds = await this.userService.getUsersByNameKeyword(
        createdByUserFullname,
        true,
      );

      if (isEmpty(filterCreatedByUserIds)) {
        return new ResponseBuilder({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    const filterRequestCode = filter?.find(
      (item) => item.column === 'requestCode',
    )?.text;

    let filterRequestIds = [];
    if (!isEmpty(filterRequestCode)) {
      filterRequestIds =
        await this.requestService.getRequestOrdersByCodeKeyword(
          filterRequestCode,
          true,
        );

      if (isEmpty(filterRequestIds)) {
        return new ResponseBuilder({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'createdBy':
            filterObj = {
              ...filterObj,
              createdBy: {
                $in: filterCreatedByUserIds,
              },
            };
            break;
          case 'requestCode':
            filterObj = {
              ...filterObj,
              requestId: {
                $in: filterRequestIds,
              },
            };
            break;
          default:
            break;
        }
      });
    }

    request.filterObj = filterObj;
    const { data, count } = await this.ticketRepository.getList(
      request,
      TICKET_TYPE_ENUM.IMPORT,
    );
    if (count === 0) {
      return new ResponseBuilder<PaginationResponse>({
        items: [],
        meta: { total: 0, page: 1 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const requestIds = uniq(compact(map(data, 'requestId')));
    const userIds = uniq(compact(map(data, 'createdBy')));
    const warehouseIds = uniq(map(data, 'warehouseId'));
    const templateIds = uniq(map(data, 'templateId'));
    let serilizeRequestOrder = {};
    if (!isEmpty(requestIds)) {
      serilizeRequestOrder = await this.requestService.getListRequestByIds(
        requestIds,
        true,
      );
    }
    const [serilizeUser, warehouseList, templates] = await Promise.all([
      this.userService.getUserByIds(userIds, true),
      this.warehouseService.getList([
        {
          column: 'ids',
          text: warehouseIds.join(','),
        },
      ]),
      this.attributeService.getTemplatesByIds(templateIds),
    ]);
    const serializedTemplate = keyBy(templates, '_id');
    const serializeWarehouse = keyBy(warehouseList, 'id');

    const ticketResponseFormated = data.map((poImport) => {
      const receiptDate = find(
        poImport.attributes,
        (attr) => attr.code === RECEIPT_TICKET_FIELD_CODE.RECEIPT_DATE,
      )?.value;

      return {
        ...poImport,
        warehouse: serializeWarehouse[poImport?.warehouseId],
        warehouseImportRequest: serilizeRequestOrder[poImport.requestId],
        createdBy: serilizeUser[poImport.createdBy],
        template: serializedTemplate[poImport.templateId],
        receiptDate,
      };
    });
    const dataReturn = plainToInstance(
      TicketResponseDto,
      ticketResponseFormated,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PaginationResponse>({
      items: dataReturn,
      meta: {
        total: count,
        page: page,
      },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Update ticket status
   * @param request
   * @returns
   */
  public async updateStatus(request: any): Promise<any> {
    const { id } = request;
    const ticket = await this.ticketRepository.findOneByCondition({
      _id: id,
      deletedAt: null,
    });
    // Check ticket is existed
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.NOT_FOUND', {
            args: { code: ticket.code },
          }),
        )
        .build();
    }

    // Check ticket status
    if (ticket.status !== STATUS_ENUM.WAITING) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }

    // Update status
    const updateTicket = this.ticketRepository.updateDocument(ticket, request);
    try {
      const result = await this.ticketRepository.findByIdAndUpdate(
        id,
        updateTicket,
      );

      const response = plainToInstance(TicketResponseDto, result, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withData(response)
        .build();
    } catch (e) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async confirm(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const ticket = await this.ticketRepository.findOneById(id);
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (ticket.status !== STATUS_ENUM.WAITING) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }
    try {
      ticket.attributes.find(
        (attributeValue) =>
          attributeValue.code === RECEIPT_TICKET_FIELD_CODE.STATUS,
      ).value = STATUS_ENUM.CONFIRM;

      ticket.status = STATUS_ENUM.CONFIRM;
      await this.ticketRepository.findByIdAndUpdate(id, ticket);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
  async reject(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const ticket = await this.ticketRepository.findOneById(id);
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (ticket.status !== STATUS_ENUM.WAITING) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }
    try {
      ticket.attributes.find(
        (attributeValue) =>
          attributeValue.code === TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.STATUS,
      ).value = STATUS_ENUM.REJECT;

      ticket.status = STATUS_ENUM.REJECT;
      await this.ticketRepository.findByIdAndUpdate(id, ticket);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async create(request: CreateTicketRequestDto): Promise<any> {
    const { items, attachment, templateId, requestId, attributes } = request;
    if (!isEmpty(attachment)) {
      const resultValidateAttachments = await this.validateAttachments(
        attachment,
      );
      if (resultValidateAttachments.statusCode !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttachments;
      }
    }
    const requestResponse = await this.requestService.getDetail(requestId);
    if (CAN_NOT_CREATE_UPDATE_TICKET.includes(requestResponse.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.STATUS_REQUEST_INVALID'))
        .build();
    }
    if (!isEmpty(attributes)) {
      const resultValidateAttributes = await this.validateAttributes(
        templateId,
        attributes,
      );

      if (resultValidateAttributes.statusCode !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttributes;
      }
    }
    attributes.push(statusObject as any);
    const ticket = this.ticketRepository.createDocument(request);
    // Auto generate ticket code
    const currentDate = moment().utcOffset(7).format('DDMMYYYY');
    const latestTicket = await this.ticketRepository.getTicketCode(
      `${RECEIPT_IMPORT_CODE_PREFIX}${currentDate}`,
    );
    const lastCode = !isEmpty(latestTicket) ? latestTicket.code : '';
    ticket.code = generateTicketCode(
      RECEIPT_IMPORT_CODE_PREFIX,
      lastCode,
      currentDate,
    );

    forEach(items, (item) => {
      item.ticketId = ticket._id;
      item.mfgDate = item.mfgDate
        ? new Date(moment(item.mfgDate).format('YYYY-MM-DD'))
        : null;
    });
    if (!isEmpty(attachment)) {
      await this.fileService.saveFiles(
        ticket._id,
        FILE_RESOURCE.RI,
        attachment,
      );
    }
    await this.ticketDetailRepository.create(items);

    return await this.save(ticket);
  }

  /**
   * Update the receipt ticket
   * @param request
   * @returns
   */
  async update(request: UpdateTicketRequestDto): Promise<any> {
    const { id, attachment, templateId, attributes, items } = request;

    if (!isEmpty(attachment)) {
      const resultValidateAttachments = await this.validateAttachments(
        attachment,
      );

      if (resultValidateAttachments.statusCode !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttachments;
      }
    }

    if (!isEmpty(attributes)) {
      const resultValidateAttributes = await this.validateAttributes(
        templateId,
        attributes,
      );

      if (resultValidateAttributes.statusCode !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttributes;
      }
    }

    const ticket = await this.ticketRepository.findOneById(id);
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_UPDATE_TICKET.includes(ticket.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
        .build();
    }

    const requestResponse = await this.requestService.getDetail(
      ticket.requestId,
    );
    if (CAN_NOT_CREATE_UPDATE_TICKET.includes(requestResponse.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.STATUS_REQUEST_INVALID'))
        .build();
    }
    this.ticketDetailRepository.deleteManyByCondition({ ticketId: ticket._id });

    forEach(items, (item) => {
      item.ticketId = ticket._id;
      item.mfgDate = item.mfgDate
        ? new Date(moment(item.mfgDate).format('YYYY-MM-DD'))
        : null;
    });

    if (!isEmpty(attachment)) {
      await this.fileService.saveFiles(
        ticket._id,
        FILE_RESOURCE.RI,
        attachment,
      );
    }
    if (!CAN_UPDATE_TICKET.includes(ticket.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
        .build();
    }

    await this.ticketDetailRepository.create(items);
    const statusAttribute = ticket.attributes.find(
      (attributeValue) =>
        attributeValue.code === TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.STATUS,
    );
    const status = statusAttribute ? +statusAttribute.value : null;
    if (status === STATUS_ENUM.REJECT) {
      ticket.attributes.find(
        (attributeValue) =>
          attributeValue.code === TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.STATUS,
      ).value = STATUS_ENUM.WAITING;
    }

    if (ticket.status === STATUS_ENUM.REJECT) {
      ticket.status = STATUS_ENUM.WAITING;
    }
    const bulkOps = [];
    bulkOps.push({
      updateOne: {
        filter: { _id: ticket._id },
        update: {
          $set: {
            ticket,
            status: ticket.status,
            attributes: ticket.attributes,
          },
        },
      },
    });
    if (!isEmpty(bulkOps)) {
      await this.ticketRepository.bulkWrite(bulkOps);
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(
        await this.i18n.translate(
          'message.receiptImport.updateReceiptImportSuccess',
        ),
      )
      .build();
  }

  async validateAttachments(attachment: any): Promise<any> {
    for (let i = 0; i < attachment?.length; i++) {
      const file = attachment[i];
      if (Object.values(ALLOW_MIME_TYPE_ENUM).indexOf(file?.mimetype) === -1) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.FILE_WRONG_TYPE'))
          .build();
      }

      if (file?.data.byteLength > MAX_FILE_SIZE) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.FILE_SIZE_IS_TOO_BIG'))
          .build();
      }
    }

    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async validateAttributes(templateId: any, attributes: any): Promise<any> {
    const template = await this.attributeService.getTemplateById(templateId);
    const attributeTemplates = template['attributes'];

    for (let i = 0; i < attributes.length; i++) {
      const attribute = find(attributeTemplates, ['_id', attributes[i]['id']]);
      const rule = attribute ? attribute['attributeRule'] : null;
      const min = rule?.min;
      const max = rule?.max;
      const dataType = attribute?.attribute?.dataType;
      const attributeName = attributes[i].name;
      const attributeValue = attributes[i].value;

      if (rule && rule?.isRequired === IS_OPTIONAL.NO) {
        if (
          attributeValue === undefined ||
          isEmpty(attributeValue?.toString())
        ) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(
              await this.i18n.translate('error.ATTRIBUTE_IS_EMPTY', {
                args: { attribute: attributeName },
              }),
            )
            .build();
        }
      }

      switch (dataType) {
        case DATA_TYPE_ENUM.NUMBER:
          if (!isEmpty(min?.toString()) && attributeValue < min) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_SMALLER_THAN_MIN',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          if (!isEmpty(max?.toString()) && attributeValue > max) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_BIGGER_THAN_MAX',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          break;
        case DATA_TYPE_ENUM.DATE:
          if (
            !isEmpty(min?.toString()) &&
            compareDate(new Date(attributeValue), new Date(min))
          ) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_SMALLER_THAN_MIN',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          if (
            !isEmpty(max?.toString()) &&
            compareDate(new Date(max), new Date(attributeValue))
          ) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_BIGGER_THAN_MAX',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          break;
        default:
          break;
      }
    }

    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  /**
   * Save data of receipt ticket
   * @param ticketImport
   * @param isUpdate
   * @returns
   */
  async save(ticketImport: Ticket, isUpdate = false): Promise<any> {
    try {
      let result;
      if (isUpdate) {
        result = await this.ticketRepository.findByIdAndUpdate(
          ticketImport._id,
          ticketImport,
        );
      } else {
        result = await this.ticketRepository.create(ticketImport);
      }
      const response = plainToInstance(TicketResponseDto, ticketImport, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            isUpdate
              ? 'message.receiptImport.updateReceiptImportSuccess'
              : 'message.receiptImport.createReceiptImportSuccess',
          ),
        )
        .withData(response)
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async warehouseImportStore(
    request: WarehouseImportStoreRequestDto,
  ): Promise<any> {
    const { orderId, warehouseId, items, autoCreateReceive } = request;
    const characterPrefix = '__';
    const ticket = await this.ticketRepository.findOneWithPopulate(
      {
        _id: orderId,
      },
      'ticketDetails',
    );
    const warehouse = await this.warehouseService.getDetail(warehouseId);
    const itemIds = uniq(map(items, 'itemId'));
    const locatorIds = uniq(map(items, 'locatorId'));
    if (!ticket || !warehouse) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const itemRes = await this.itemService.getItems(itemIds);
    const locators = await this.warehouseLayoutService.getListLocatorByIds(
      locatorIds,
    );
    if (isEmpty(locators)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!itemRes || itemIds.length !== itemRes.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }
    const ticketDetailsMap = keyBy(ticket.ticketDetails, (item) =>
      [
        item?.itemId,
        item.lot ? item?.lot?.toUpperCase() : null,
        moment(item?.mfgDate).format('DD/MM/YYYY'),
      ].join(characterPrefix),
    );
    const itemRequestMap = keyBy(items, (item) =>
      [
        item?.itemId,
        item?.lotNumber?.toUpperCase() || null,
        moment(item?.mfg).format('DD/MM/YYYY'),
      ].join(characterPrefix),
    );
    let isValidActualQuantity = true;
    const ticketDetailEntities = [];
    const itemSwiftLocators: ItemSwiftLocator[] = [];
    for (let i = 0; i < ticket?.ticketDetails.length; i++) {
      const item = ticket?.ticketDetails[i];
      const key = [
        item?.itemId,
        item?.lot ? item?.lot?.toUpperCase() : null,
        moment(item?.mfgDate).format('DD/MM/YYYY'),
      ].join(characterPrefix);

      if (!has(ticketDetailEntities, key)) {
        ticketDetailEntities.push({
          ...item,
          actualQuantity: itemRequestMap[key]?.quantity,
          locatorId: new mongoose.Types.ObjectId(
            itemRequestMap[key]?.locatorId,
          ),
          lot: itemRequestMap[key]?.lotNumber || null,
        });
      }
      if (itemRequestMap[key]?.quantity !== ticketDetailsMap[key]?.quantity) {
        isValidActualQuantity = false;
      }

      const itemSwiftLocator = new ItemSwiftLocator(
        item.itemId,
        item.lot,
        item.quantity,
        new mongoose.Types.ObjectId(item.locatorId) as any,
      );
      itemSwiftLocators.push(itemSwiftLocator);
    }
    const requestSwiftItem = new SwiftItemInLocatorRequestDto(
      warehouseId,
      warehouseId,
      request.userId,
      ticket._id,
      ticket.code,
      ticket.type,
      TYPE_ENUM_MOVEMENT.POI,
      TYPE_ENUM_MOVEMENT.SOE,
      itemSwiftLocators,
    );
    if (!isValidActualQuantity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate(
            'error.ACTUAL_QUANTITY_NOT_LESS_OR_MORE_THAN_PLAN_QUANTITY',
          ),
        )
        .build();
    }
    const bulkOps = ticketDetailEntities.map((ticketDetail) => {
      return {
        updateOne: {
          filter: { _id: ticketDetail._id },
          update: {
            ...ticketDetail,
          },
          upsert: false,
        },
      };
    });
    if (autoCreateReceive && +autoCreateReceive === 1) {
      const requestCreatePoImportReceive =
        new CreatePurchasedOrderImportReceiveTicketRequestDto();
      requestCreatePoImportReceive.userId = request.userId;
      requestCreatePoImportReceive.ticketId = ticket?.ticketId;
      requestCreatePoImportReceive.warehouseId = warehouseId;
      requestCreatePoImportReceive.isComplete = false;
      requestCreatePoImportReceive.items = items.map((item) => {
        return {
          itemId: item.itemId,
          lotNumber: item.lotNumber || null,
          actualQuantity: item.quantity,
        };
      });
      const responseCreateReceive =
        await this.saleService.createPoImportReceive(
          requestCreatePoImportReceive,
        );
      if (responseCreateReceive.statusCode !== ResponseCodeEnum.SUCCESS) {
        return responseCreateReceive;
      }
    }

    await this.ticketDetailRepository.bulkWrite(bulkOps);
    const itemMovements: CreateItemMovementDto[] = [];
    const itemStockWarehousePrices = [];
    switch (warehouse?.manageByLot) {
      case WarehouseByLotManagementEnum.NO_LOT:
        ticketDetailEntities?.forEach((item) => {
          const ticketDetailsNoLotMap = keyBy(ticketDetailEntities, (item) =>
            [item.itemId, moment(item.mfgDate).format('DD/MM/YYYY')].join(
              characterPrefix,
            ),
          );
          const key = [
            item.itemId,
            moment(item.mfgDate).format('DD/MM/YYYY'),
          ].join(characterPrefix);
          //Đơn giá mới
          const price = divBigNumber(
            ticketDetailsNoLotMap[key]?.amount || 0,
            ticketDetailsNoLotMap[key]?.quantity || 1,
          );
          itemStockWarehousePrices.push({
            itemId: item.itemId,
            quantity: ticketDetailsNoLotMap[key]?.quantity,
            warehouseId,
            price: price,
            totalPrice: mulBigNumber(
              price,
              ticketDetailsNoLotMap[key]?.quantity,
            ),
          });
          itemMovements.push({
            itemId: item.itemId,
            warehouseId: warehouseId,
            ticketId: item.ticketId.toString(),
            locatorId: ticketDetailsNoLotMap[key]?.locatorId.toString() || null,
            type: TYPE_ENUM_MOVEMENT.POI,
            mfg: ticketDetailsNoLotMap[key]?.mfgDate,
            lotNumber: ticketDetailsNoLotMap[key]?.lot,
            quantity: ticketDetailsNoLotMap[key]?.quantity,
            storedQuantity: ticketDetailsNoLotMap[key]?.actualQuantity,
            importDate: new Date(),
          });
        });
        break;
      case WarehouseByLotManagementEnum.LOT:
        const ticketDetailsLotMap = keyBy(ticketDetailEntities, (item) =>
          [
            item.itemId,
            item?.lot ? item?.lot?.toUpperCase() : null,
            moment(item.mfgDate).format('DD/MM/YYYY'),
          ].join(characterPrefix),
        );
        ticketDetailEntities.forEach((item) => {
          const key = [
            item.itemId,
            item?.lot ? item?.lot?.toUpperCase() : null,
            moment(item?.mfgDate).format('DD/MM/YYYY'),
          ].join(characterPrefix);
          const price = divBigNumber(
            ticketDetailsLotMap[key]?.amount || 0,
            ticketDetailsLotMap[key]?.quantity || 1,
          );
          itemStockWarehousePrices.push({
            itemId: item.itemId,
            quantity: ticketDetailsLotMap[key]?.quantity,
            warehouseId,
            lotNumber: item?.lot,
            price: price,
            totalPrice: mulBigNumber(price, ticketDetailsLotMap[key]?.quantity),
          });
        });
        break;
      default:
        break;
    }
    try {
      const movementResponse = await this.itemService.createItemStockMovement({
        items: itemMovements,
      });
      const movementIds = map(movementResponse?.data, 'id') || [];
      const itemServiceResponse = await this.itemService.updateStockFromTicket(
        new UpdateStockFromTicketRequestDto(
          movementIds,
          TYPE_ENUM_MOVEMENT.POI,
          orderId,
          itemStockWarehousePrices,
        ),
      );
      if (itemServiceResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(itemServiceResponse?.statusCode)
          .withMessage(await this.i18n.translate(itemServiceResponse?.message))
          .build();
      }
      // const itemRes = await this.swiftItemInLocator(requestSwiftItem);
      // if (itemRes.statusCode !== ResponseCodeEnum.SUCCESS) {
      //   throw itemRes.message;
      // }
    } catch (error) {
      this.logger.error(
        'ERROR CREATE ITEM STOCK MOVEMENT:',
        JSON.stringify(error),
      );
    }
    //Cất hàng

    ticket.status = STATUS_ENUM.COMPLETED;
    const ticketUpdate = await this.ticketRepository.findByIdAndUpdate(
      ticket?._id,
      ticket,
    );
    if (!ticketUpdate) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    return new ResponseBuilder(ticketUpdate)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  async getTicketReceiptByTicketId(
    request: GetTicketReceiptByTicketIdRequestDto,
  ): Promise<any> {
    const ticket = await this.ticketRepository.findOneWithPopulate(
      {
        ticketId: request.ticketId,
      },
      'ticketDetails',
    );
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    return new ResponseBuilder(ticket)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  async getTicketByRequestIds(
    request: GetTicketByRequestIdsRequestDto,
  ): Promise<any> {
    const { requestIds } = request;
    const tickets = await this.ticketRepository.getTicketByRequestIds(
      requestIds,
    );
    if (isEmpty(tickets)) {
      return new ResponseBuilder([])
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    return new ResponseBuilder(tickets)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getTicketReceiptByCondition(
    request: GetTicketByRequestIdsRequestDto,
  ): Promise<any> {
    const { requestIds } = request;
    const tickets = await this.ticketRepository.findAllWithPopulate(
      {
        requestId: {
          $in: requestIds.map((e) => e),
        },
        status: {
          $in: [
            ImportReceiptStatusEnum.PENDING,
            ImportReceiptStatusEnum.CONFIRMED,
            ImportReceiptStatusEnum.COMPLETED,
            ImportReceiptStatusEnum.STORED,
            ImportReceiptStatusEnum.STORING,
          ],
        },
      },
      'ticketDetails',
    );
    if (isEmpty(tickets)) {
      return new ResponseBuilder([])
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    return new ResponseBuilder(tickets)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async receiveTicket(request: TicketReceiveRequestDto): Promise<any> {
    const { ticketId, items, warehouseId } = request;
    const characterPrefix = '__';
    const ticketResponse = await this.ticketRepository.findOneWithPopulate(
      {
        _id: ticketId,
      },
      'ticketDetails',
    );
    const warehouse = await this.warehouseService.getDetail(warehouseId);
    const locatorResponse = await this.warehouseLayoutService.getLocatorByCode({
      code: warehouse.code,
      warehouseId,
    });
    const itemIds = uniq(map(items, 'itemId'));
    if (!ticketResponse || !warehouse || !locatorResponse) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const itemRes = await this.itemService.getItems(itemIds);
    if (!itemRes || itemIds.length !== itemRes.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }

    if (CAN_NOT_RECEIVE_PO_IMPORT.includes(ticketResponse.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.STATUS_INVALID'))
        .build();
    }
    const ticketItemDetailKeyBy = keyBy(ticketResponse.ticketDetails, 'itemId');
    const itemRequestMap = keyBy(items, (item) =>
      [
        item?.itemId,
        item?.lotNumber?.toUpperCase() || null,
        moment(item?.mfg).format('DD/MM/YYYY'),
      ].join(characterPrefix),
    );
    let isValidActualQuantity = true;
    const ticketDetailEntities = [];
    const itemQuantityMap = items.reduce((acc, item) => {
      const itemId = item.itemId;
      const quantity = item.quantity;
      acc[itemId] = (acc[itemId] || 0) + quantity;
      return acc;
    }, {});
    for (let i = 0; i < items?.length; i++) {
      const item = items[i];
      const key = [
        item?.itemId,
        item?.lotNumber ? item?.lotNumber?.toUpperCase() : null,
        moment(item?.mfg).format('DD/MM/YYYY'),
      ].join(characterPrefix);
      const itemId = item.itemId;
      const attributeMfg = ticketItemDetailKeyBy[itemId]?.attributes.find(
        (attribute) => attribute.code === RECEIPT_TICKET_FIELD_CODE.MFG_DATE,
      );
      const attributeLotNumber = ticketItemDetailKeyBy[itemId]?.attributes.find(
        (attribute) => attribute.code === RECEIPT_TICKET_FIELD_CODE.LOT_NUMBER,
      );
      const attributeActualQuantity = ticketItemDetailKeyBy[
        itemId
      ]?.attributes.find(
        (attribute) =>
          attribute.code === RECEIPT_TICKET_FIELD_CODE.ACTUAL_QUANTITY,
      );
      if (attributeMfg || attributeLotNumber || attributeActualQuantity) {
        const attributes = ticketItemDetailKeyBy[itemId]?.attributes;
        const mfgDateAttribute = attributes?.find(
          (attribute) => attribute.code === RECEIPT_TICKET_FIELD_CODE.MFG_DATE,
        );
        const lotNumberAttribute = attributes?.find(
          (attribute) =>
            attribute.code === RECEIPT_TICKET_FIELD_CODE.LOT_NUMBER,
        );
        const actualQuantityAttribute = attributes?.find(
          (attribute) =>
            attribute.code === RECEIPT_TICKET_FIELD_CODE.ACTUAL_QUANTITY,
        );

        if (attributes && mfgDateAttribute) {
          mfgDateAttribute.value = itemRequestMap[key]?.mfg || null;
        }
        if (attributes && lotNumberAttribute) {
          lotNumberAttribute.value = itemRequestMap[key]?.lotNumber || null;
        }
        if (attributes && actualQuantityAttribute) {
          actualQuantityAttribute.value = itemRequestMap[key]?.quantity || null;
        }
      }
      if (!has(ticketDetailEntities, key)) {
        ticketDetailEntities.push({
          ...item,
          _id: ticketItemDetailKeyBy[itemId]._id,
          groupId: ticketItemDetailKeyBy[itemId]?.groupId,
          ticketId: ticketItemDetailKeyBy[itemId]?.ticketId,
          quantity: ticketItemDetailKeyBy[itemId]?.quantity,
          amount: ticketItemDetailKeyBy[itemId]?.amount,
          price: ticketItemDetailKeyBy[itemId]?.price,
          attributes: ticketItemDetailKeyBy[itemId].attributes,
          //Cập nhật mới
          actualQuantity: itemRequestMap[key]?.quantity,
          lot: itemRequestMap[key]?.lotNumber || null,
          mfgDate: itemRequestMap[key]?.mfg
            ? new Date(moment(itemRequestMap[key]?.mfg).format('YYYY-MM-DD'))
            : null,
          importDate: new Date().toISOString(),
        });
      }
      if (itemQuantityMap[itemId] !== ticketItemDetailKeyBy[itemId]?.quantity) {
        isValidActualQuantity = false;
      }
    }
    const detailBulkOps = ticketDetailEntities.map((ticketDetailEntity) => {
      return {
        updateOne: {
          filter: { _id: ticketDetailEntity._id },
          update: {
            ...ticketDetailEntity,
          },
          upsert: false,
        },
      };
    });
    if (detailBulkOps.length > 0) {
      await this.ticketDetailRepository.bulkWrite(detailBulkOps);
    }
    const itemMovements: CreateItemMovementDto[] = [];
    const itemStockWarehousePrices = [];
    switch (warehouse?.manageByLot) {
      case WarehouseByLotManagementEnum.NO_LOT:
        ticketDetailEntities?.forEach((item) => {
          const ticketDetailsNoLotMap = keyBy(ticketDetailEntities, (item) =>
            [item.itemId, moment(item.mfgDate).format('DD/MM/YYYY')].join(
              characterPrefix,
            ),
          );
          const key = [
            item.itemId,
            moment(item.mfgDate).format('DD/MM/YYYY'),
          ].join(characterPrefix);
          //Đơn giá mới
          const price = divBigNumber(
            ticketDetailsNoLotMap[key]?.amount || 0,
            ticketDetailsNoLotMap[key]?.quantity || 1,
          );
          itemStockWarehousePrices.push({
            itemId: item.itemId,
            quantity: ticketDetailsNoLotMap[key]?.quantity,
            warehouseId,
            price: price,
            totalPrice: mulBigNumber(
              price,
              ticketDetailsNoLotMap[key]?.quantity || 0,
            ),
          });
          itemMovements.push({
            itemId: item.itemId,
            warehouseId: warehouseId,
            ticketId: item.ticketId.toString(),
            warehouseLocatorId: warehouseId || null,
            locatorId: locatorResponse.id,
            type: TYPE_ENUM_MOVEMENT.POI,
            mfg: ticketDetailsNoLotMap[key]?.mfgDate,
            lotNumber: ticketDetailsNoLotMap[key]?.lot,
            quantity: ticketDetailsNoLotMap[key]?.actualQuantity,
            storedQuantity: ticketDetailsNoLotMap[key]?.actualQuantity,
            importDate: ticketDetailsNoLotMap[key]?.importDate,
          });
        });
        break;
      case WarehouseByLotManagementEnum.LOT:
        const ticketDetailsLotMap = keyBy(ticketDetailEntities, (item) =>
          [
            item.itemId,
            item?.lot ? item?.lot?.toUpperCase() : null,
            moment(item.mfgDate).format('DD/MM/YYYY'),
          ].join(characterPrefix),
        );
        ticketDetailEntities.forEach((item) => {
          const key = [
            item.itemId,
            item?.lot ? item?.lot?.toUpperCase() : null,
            moment(item?.mfgDate).format('DD/MM/YYYY'),
          ].join(characterPrefix);
          const price = divBigNumber(
            ticketDetailsLotMap[key]?.amount || 0,
            ticketDetailsLotMap[key]?.quantity || 1,
          );
          itemMovements.push({
            itemId: item.itemId,
            warehouseId: warehouseId,
            ticketId: item.ticketId.toString(),
            warehouseLocatorId: warehouseId || null, //Nhập vào vị trí bằng mã kho
            locatorId: locatorResponse.id,
            type: TYPE_ENUM_MOVEMENT.POI,
            mfg: ticketDetailsLotMap[key]?.mfgDate,
            lotNumber: ticketDetailsLotMap[key]?.lot,
            quantity: ticketDetailsLotMap[key]?.actualQuantity,
            storedQuantity: ticketDetailsLotMap[key]?.actualQuantity,
            importDate: ticketDetailsLotMap[key]?.importDate,
          });
          itemStockWarehousePrices.push({
            itemId: item.itemId,
            quantity: ticketDetailsLotMap[key]?.quantity,
            warehouseId,
            lotNumber: item?.lot,
            price: price,
            totalPrice: mulBigNumber(
              price,
              ticketDetailsLotMap[key]?.quantity || 0,
            ),
          });
        });
        break;
      default:
        break;
    }
    try {
      const movementResponse = await this.itemService.createItemStockMovement({
        items: itemMovements,
      });
      if (movementResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(movementResponse?.statusCode)
          .withMessage(await this.i18n.translate(movementResponse?.message))
          .build();
      }
      const movementIds = map(movementResponse?.data, 'id') || [];
      const itemServiceResponse = await this.itemService.updateStockFromTicket(
        new UpdateStockFromTicketRequestDto(
          movementIds,
          TYPE_ENUM_MOVEMENT.POI,
          ticketId,
          itemStockWarehousePrices,
        ),
      );
      if (itemServiceResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(itemServiceResponse?.statusCode)
          .withMessage(await this.i18n.translate(itemServiceResponse?.message))
          .build();
      }

      if (ticketResponse.requestId) {
        const requests = await this.requestService.getListRequestByIds([
          ticketResponse.requestId,
        ]);
        const request = requests ? requests[0] : null;
        if (request) {
          const syncImportExportQuantityRequest =
            new SyncImportExportWarehouseQuantityRequestDto(
              0,
              request.id,
              request.code,
              itemMovements.map((itemMovement) => ({
                itemId: itemMovement.itemId,
                actualQuantity: itemMovement.quantity,
              })),
            );
          await this.syncImportExportQuantity(syncImportExportQuantityRequest);
        }
      }
    } catch (error) {
      console.log('error', error);
      this.logger.error(
        'ERROR CREATE ITEM STOCK MOVEMENT:',
        JSON.stringify(error),
      );
    }
    ticketResponse.attributes.find(
      (attributeValue) =>
        attributeValue.code === TICKET_RECEIPT_DETAIL_TEMPLATE_CODE.STATUS,
    ).value = STATUS_ENUM.COMPLETED;
    ticketResponse.status = STATUS_ENUM.COMPLETED;
    const ticketUpdate = await this.ticketRepository.findByIdAndUpdate(
      ticketResponse?._id,
      ticketResponse,
    );
    if (!ticketUpdate) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    return new ResponseBuilder(ticketUpdate)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  async receiptStore(request: StoredTicketReceiptRequestDto): Promise<any> {
    const { orderId, ticketId, items, warehouseId } = request;
    const characterPrefix = '__';
    const ticketResponse = await this.ticketRepository.findOneWithPopulate(
      {
        _id: ticketId,
      },
      'ticketDetails',
    );
    const warehouse = await this.warehouseService.getDetail(warehouseId);
    const locatorResponse = await this.warehouseLayoutService.getLocatorByCode({
      code: warehouse.code,
      warehouseId,
    });
    const itemIds = uniq(map(items, 'itemId'));
    if (!ticketResponse || !warehouse) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const itemRes = await this.itemService.getItems(itemIds);
    if (!itemRes || itemIds.length !== itemRes.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }
    const ticketItemDetailKeyBy = keyBy(ticketResponse.ticketDetails, 'itemId');
    const ticketDetailKeyBy = keyBy(
      ticketResponse.ticketDetails,
      (itemDetail) =>
        [
          itemDetail?.itemId,
          moment(itemDetail?.mfgDate).format('DD/MM/YYYY'),
        ].join(characterPrefix),
    );
    const itemRequestMap = keyBy(items, (item) =>
      [item?.itemId, moment(item?.mfg).format('DD/MM/YYYY')].join(
        characterPrefix,
      ),
    );
    const ticketResponseGroup = groupBy(ticketResponse.ticketDetails, 'itemId');
    const ticketDetailEntities = [];
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const itemId = item.itemId;
      const key = [item?.itemId, moment(item?.mfg).format('DD/MM/YYYY')].join(
        characterPrefix,
      );
      ticketDetailEntities.push({
        ...item,
        ticketId: ticketItemDetailKeyBy[itemId].ticketId,
        quantity: ticketDetailKeyBy[key].quantity,
        amount: ticketItemDetailKeyBy[itemId]?.amount,
        price: ticketItemDetailKeyBy[itemId]?.price,
        attributes: ticketItemDetailKeyBy[itemId].attributes,
        actualQuantity: ticketDetailKeyBy[key]?.actualQuantity,
        //Cập nhật mới
        storedQuantity: itemRequestMap[key].storedQuantity,
        lot: itemRequestMap[key]?.lotNumber || null,
        mfgDate: itemRequestMap[key]?.mfg,
        locatorId: new mongoose.Types.ObjectId(itemRequestMap[key].locatorId),
      });
      //TODO validate storedQuantity with Remaining Quantity
      if (has(ticketResponseGroup, itemId)) {
        const sumStoredQuantity = sumBy(
          ticketResponseGroup[itemId],
          (item) => +item.actualQuantity,
        );
      }
    }
    const bulkOps = [];
    for (const ticketDettail of ticketDetailEntities) {
      bulkOps.push({
        updateOne: {
          filter: { _id: ticketDettail._id },
          update: {
            $setOnInsert: { ...ticketDettail },
          },
          upsert: false,
        },
      });
    }
    if (bulkOps.length > 0) {
      await Promise.all([
        this.ticketRepository.bulkWrite(
          bulkOps.filter((op) => op.updateOne.filter._id),
        ),
      ]);
    }
    const itemMovements: CreateItemMovementDto[] = [];
    switch (warehouse?.manageByLot) {
      case WarehouseByLotManagementEnum.NO_LOT:
        ticketDetailEntities?.forEach((item) => {
          const ticketDetailsNoLotMap = keyBy(ticketDetailEntities, (item) =>
            [item.itemId, moment(item.mfgDate).format('DD/MM/YYYY')].join(
              characterPrefix,
            ),
          );
          const key = [
            item.itemId,
            moment(item.mfgDate).format('DD/MM/YYYY'),
          ].join(characterPrefix);
          itemMovements.push({
            itemId: item.itemId,
            warehouseId: warehouseId,
            ticketId: item.ticketId.toString(),
            locatorId: ticketDetailsNoLotMap[key].locatorId,
            type: TYPE_ENUM_MOVEMENT.POI,
            mfg: ticketDetailsNoLotMap[key]?.mfgDate,
            lotNumber: ticketDetailsNoLotMap[key]?.lot,
            quantity: minus(
              ticketDetailsNoLotMap[key]?.actualQuantity,
              ticketDetailsNoLotMap[key]?.storedQuantity,
            ),
            storedQuantity: ticketDetailsNoLotMap[key]?.storedQuantity,
            importDate: new Date(),
          });
        });
        break;
      case WarehouseByLotManagementEnum.LOT:
        const ticketDetailsLotMap = keyBy(ticketDetailEntities, (item) =>
          [
            item.itemId,
            item?.lot ? item?.lot?.toUpperCase() : null,
            moment(item.mfgDate).format('DD/MM/YYYY'),
          ].join(characterPrefix),
        );
        ticketDetailEntities.forEach((item) => {
          const key = [
            item.itemId,
            item?.lot ? item?.lot?.toUpperCase() : null,
            moment(item?.mfgDate).format('DD/MM/YYYY'),
          ].join(characterPrefix);
          itemMovements.push({
            itemId: item.itemId,
            warehouseId: warehouseId,
            ticketId: item.ticketId.toString(),
            locatorId: ticketDetailsLotMap[key].locatorId,
            type: TYPE_ENUM_MOVEMENT.POI,
            mfg: ticketDetailsLotMap[key]?.mfgDate,
            lotNumber: ticketDetailsLotMap[key]?.lot,
            quantity: minus(
              ticketDetailsLotMap[key]?.actualQuantity,
              ticketDetailsLotMap[key]?.storedQuantity,
            ),
            storedQuantity: ticketDetailsLotMap[key]?.storedQuantity,
            importDate: new Date(),
          });
        });
        break;
      default:
        break;
    }
    try {
      const movementResponse = await this.itemService.createItemStockMovement({
        items: itemMovements,
      });
      if (movementResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(movementResponse?.statusCode)
          .withMessage(await this.i18n.translate(movementResponse?.message))
          .build();
      }
      const itemReceives = [];
      itemMovements.forEach((item) => {
        itemReceives.push({
          itemId: item.itemId,
          lotNumber: item.lotNumber,
          locatorId: locatorResponse.id,
          quantityStored: item.storedQuantity,
        });
      });
      const itemSwiftLocatorTicketResponse =
        await this.itemService.createItemStockSwiftLocator({
          movementIds: map(movementResponse?.data, 'id') || [],
          warehouseId: warehouseId,
          orderType: TYPE_ENUM_MOVEMENT.POI,
          ticketId: ticketId,
          items: itemReceives,
        } as CreateItemSwiftLocatorTicket);
      if (
        itemSwiftLocatorTicketResponse.statusCode !== ResponseCodeEnum.SUCCESS
      ) {
        return new ResponseBuilder()
          .withCode(itemSwiftLocatorTicketResponse?.statusCode)
          .withMessage(
            await this.i18n.translate(itemSwiftLocatorTicketResponse?.message),
          )
          .build();
      }
    } catch (error) {
      console.log('error', error);
      this.logger.error(
        'ERROR CREATE ITEM STOCK MOVEMENT:',
        JSON.stringify(error),
      );
    }

    ticketResponse.status = STATUS_ENUM.COMPLETED;
    const ticketUpdate = await this.ticketRepository.findByIdAndUpdate(
      ticketResponse?._id,
      ticketResponse,
    );
    if (!ticketUpdate) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    return new ResponseBuilder(ticketUpdate)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  // cất hàng
  async putAwayReceipt(request: PutAwayReceiptRequestDto): Promise<any> {
    const { items: payload } = request;
    const itemInLocators = [];
    const itemInLocatorMap = {};
    const storingItemQuantities = [];
    const locatorInventoryUpdated = [];
    const totalPutItem = {};
    const itemMovements: CreateItemMovementDto[] = [];
    const warehouseIds = uniq(map(payload, 'warehouseId'));
    const totalStoredByItems = {};
    const locatorIds = [];
    const requestKeys = {};

    //start: check warehouse exists
    const warehouses = await this.warehouseService.getListByIDs(warehouseIds);
    if (warehouses.length !== warehouseIds.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
        .build();
    }

    const warehouseCodes = map(warehouses, 'code');
    //end: check warehouse exists
    const rootLocators = await this.warehouseLayoutService.getLocatorByCodes({
      codes: warehouseCodes,
    });
    const locatorWarehouseMap = keyBy(rootLocators, 'rootId');
    const rootLocatorMap = keyBy(rootLocators, 'id');
    for (let i = 0; i < payload.length; i++) {
      const item = payload[i];

      const {
        itemId,
        locatorId,
        lotNumber,
        mfg,
        warehouseId,
        storedQuantity,
        ticketId,
      } = item;

      const storingKey = lotNumber
        ? `${itemId}-${locatorId}-${lotNumber}-${moment(mfg).format(
            'DD/MM/YYYY',
          )}-${warehouseId}`
        : `${itemId}-${locatorId}-${moment(mfg).format(
            'DD/MM/YYYY',
          )}-${warehouseId}`;

      const minusKey = lotNumber
        ? `${itemId}-${lotNumber}-${moment(mfg).format(
            'DD/MM/YYYY',
          )}-${warehouseId}`
        : `${itemId}-${moment(mfg).format('DD/MM/YYYY')}-${warehouseId}`;

      const putKey = lotNumber
        ? `${itemId}-${lotNumber}-${moment(mfg).format(
            'DD/MM/YYYY',
          )}-${ticketId}`
        : `${itemId}-${moment(mfg).format('DD/MM/YYYY')}-${ticketId}`;
      const requestKey = lotNumber
        ? `${itemId}-${lotNumber}-${moment(mfg).format(
            'DD/MM/YYYY',
          )}-${ticketId}-${locatorId}`
        : `${itemId}-${moment(mfg).format(
            'DD/MM/YYYY',
          )}-${ticketId}-${locatorId}`;
      if (requestKeys[requestKey]) {
        // check trùng thông tin ở các dòng
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.LOCATOR_INVALID'))
          .build();
      }
      requestKeys[requestKey] = requestKey;

      if (rootLocatorMap[locatorId]) {
        // không được cất vào vị trí có mã = mã kho
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.LOCATOR_INVALID'))
          .build();
      }

      locatorIds.push(locatorId);
      const rootLocator = locatorWarehouseMap[warehouseId]; // vị trí có mã = mã kho
      itemInLocators.push({
        itemId,
        ticketLocatorId: rootLocator?.id,
        lotNumber,
        mfg,
        warehouseId,
      });

      itemInLocators.push({
        itemId,
        ticketLocatorId: item.locatorId,
        lotNumber,
        mfg,
        warehouseId,
      });

      itemInLocatorMap[storingKey] = {
        itemId,
        ticketId,
        ticketLocatorId: item.locatorId,
        lotNumber,
        mfg,
        warehouseId,
      };

      storingItemQuantities[storingKey] = storedQuantity;
      totalStoredByItems[minusKey] = plusBigNumber(
        totalPutItem[putKey] || 0,
        storedQuantity,
      );

      totalPutItem[putKey] = plusBigNumber(
        totalPutItem[putKey] || 0,
        storedQuantity,
      );

      itemMovements.push({
        itemId: itemId,
        warehouseId: warehouseId,
        ticketId: item.ticketId?.toString() || null,
        locatorId: locatorId.toString() || null,
        type: TYPE_ENUM_MOVEMENT.POI,
        mfg,
        lotNumber: lotNumber,
        quantity: storedQuantity,
        storedQuantity: storedQuantity,
        importDate: new Date(),
      });
    }

    //start: check ticket exists
    const ticketIds = uniq(map(payload, 'ticketId'));
    const tickets = await this.ticketRepository.findAllWithPopulate(
      { _id: { $in: ticketIds } },
      'ticketDetails',
    );
    if (ticketIds.length !== tickets.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.TICKET_NOT_FOUND'))
        .build();
    }
    const ticketMap = keyBy(tickets, '_id');
    //end: check ticket exists

    //start: check số lượng cất & số lượng đã cất không vượt quá số lượng kế hoạch
    const ticketDetails = flatMap(tickets, 'ticketDetails');
    for (let i = 0; i < ticketDetails.length; i++) {
      const ticketDetail = ticketDetails[i];
      const {
        itemId,
        lot,
        mfgDate,
        quantity,
        actualPutAwayQuantity,
        ticketId,
      } = ticketDetail;
      const itemKey = lot
        ? `${itemId}-${lot?.toUpperCase()}-${moment(mfgDate).format(
            'DD/MM/YYYY',
          )}-${ticketId}`
        : `${itemId}-${moment(mfgDate).format('DD/MM/YYYY')}-${ticketId}`;
      if (
        +plusBigNumber(totalPutItem[itemKey] || 0, actualPutAwayQuantity || 0) >
        +quantity
      ) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.PUT_QUANTITY_OVER_REQUEST_QUANTITY',
            ),
          )
          .build();
      }

      //start: cập nhật số lượng đã cất vào vị trí
      ticketDetail.actualPutAwayQuantity = +plusBigNumber(
        totalPutItem[itemKey] || 0,
        actualPutAwayQuantity || 0,
      );
      console.log(ticketDetail.actualPutAwayQuantity);
      //end: cập nhật số lượng đã cất vào vị trí
    }
    //end: check số lượng cất & số lượng đã cất không vượt quá số lượng kế hoạch

    //start: check locator exists
    const locators = await this.warehouseLayoutService.getListLocatorByIds(
      locatorIds,
    );
    if (uniq(locatorIds).length !== locators.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.LOCATOR_NOT_FOUND'))
        .build();
    }
    //end: check locator exists

    //start: check item exists
    const itemIds = uniq(map(payload, 'itemId'));
    const items = await this.itemService.getItemByIds(itemIds);
    if (itemIds.length !== items.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.ITEM_NOT_FOUND'))
        .build();
    }
    //end: check item exists

    //start: lấy số lượng item tồn kho trên vị trí
    const locatorInventories =
      await this.itemService.getItemStockInWarehouseLocators(itemInLocators);
    const locatorInventoryMap = keyBy(locatorInventories, (inventory) => {
      const { itemId, ticketLocatorId, lotNumber, mfg, warehouseId } =
        inventory;
      return lotNumber
        ? `${itemId}-${ticketLocatorId}-${lotNumber}-${moment(mfg).format(
            'DD/MM/YYYY',
          )}-${warehouseId}`
        : `${itemId}-${ticketLocatorId}-${moment(mfg).format(
            'DD/MM/YYYY',
          )}-${warehouseId}`;
    });
    //end: lấy số lượng item tồn kho trên vị trí

    //start: cập nhật số lượng tồn kho trên vị trí
    for (const storingKey in storingItemQuantities) {
      const itemQuantity = storingItemQuantities[storingKey]; // số lượng cất
      const itemStoredQuantity = locatorInventoryMap[storingKey]?.quantity || 0; // số lượng tồn kho trên vị trí

      locatorInventoryUpdated.push({
        ...itemInLocatorMap[storingKey],
        ...locatorInventoryMap[storingKey],
        quantity: plusBigNumber(itemStoredQuantity, itemQuantity),
      });
    }

    for (const minusKey in totalStoredByItems) {
      const minusValue = totalStoredByItems[minusKey];
      const minusKeyElement = minusKey.split('-');
      const itemId = minusKeyElement[0];

      let lotNumber;
      let mfg = minusKeyElement[1];
      const warehouseId = minusKeyElement[minusKeyElement.length - 1];
      if (minusKeyElement.length === 4) {
        lotNumber = minusKeyElement[1];
        mfg = minusKeyElement[2];
      }
      const rootLocatorId = locatorWarehouseMap[warehouseId]?.id;

      const storingKey = lotNumber
        ? `${itemId}-${rootLocatorId}-${lotNumber}-${mfg}-${warehouseId}`
        : `${itemId}-${rootLocatorId}-${mfg}-${warehouseId}`;

      const itemStoredQuantity = locatorInventoryMap[storingKey]?.quantity || 0; // số lượng tồn kho trên vị trí

      if (+itemStoredQuantity >= +minusValue) {
        locatorInventoryUpdated.push({
          id: locatorInventoryMap[storingKey]?.id,
          itemId,
          lotNumber,
          mfg: locatorInventoryMap[storingKey]?.mfg,
          warehouseId,
          ticketLocatorId: rootLocatorId,
          locatorId: warehouseId,
          quantity: minusBigNumber(itemStoredQuantity, minusValue),
        });
      }
    }
    if (!isEmpty(locatorInventoryUpdated)) {
      const res = await this.itemService.updateItemStockInWarehouseLocators({
        items: locatorInventoryUpdated,
      });
      if (res?.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(res?.statusCode)
          .withMessage(res?.message)
          .build();
      }
    }
    //end: cập nhật số lượng tồn kho trên vị trí

    //start: cập nhật trạng thái phiếu
    const ticketDetailMap = groupBy(ticketDetails, 'ticketId');
    const updateTicket = [];
    const updateTicketDetails = [];
    for (const key in ticketDetailMap) {
      const ticketDetail = ticketDetailMap[key];
      // nếu số lượng thực cất >= số lượng cần cất của phiếu => chuyển trạng thái phiếu sang hoàn thành cất hàng
      // nếu số lượng thực cất < số lượng cần cất của phiếu => chuyển trạng thái phiếu sang đang cất hàng
      const isTicketStored = ticketDetail.every(
        (detail) => +detail.actualPutAwayQuantity >= detail.quantity,
      );

      ticketMap[key].status = isTicketStored
        ? ImportReceiptStatusEnum.STORED
        : ImportReceiptStatusEnum.STORING;

      updateTicket.push({
        updateOne: {
          filter: { _id: key },
          update: {
            $set: {
              status: isTicketStored
                ? ImportReceiptStatusEnum.STORED
                : ImportReceiptStatusEnum.STORING,
            },
          },
        },
      });

      const updateDetails = ticketDetail.map((detail) => {
        return {
          updateOne: {
            filter: { _id: detail._id },
            update: { $set: { ...detail } },
          },
        };
      });
      updateTicketDetails.push(...updateDetails);
    }
    await Promise.all([
      this.ticketRepository.bulkWrite(updateTicket),
      this.ticketDetailRepository.bulkWrite(updateTicketDetails),
    ]);
    //end: cập nhật trạng thái phiếu

    //start: tạo giao dịch cất hàng
    await this.itemService.createItemStockMovement({
      items: itemMovements,
    });
    //end: tạo giao dịch cất hàng
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  async getTicketReceiptByIds(request: GetTicketByIdsRequestDto): Promise<any> {
    const result = await this.ticketRepository.findAllByCondition({
      _id: { $in: request.ticketIds.map((e) => e) },
    });
    if (isEmpty(result)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const dataReturn = plainToInstance(TicketResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  async getTicketCodeKeyword(
    request: GetTicketByKeywordRequestDto,
  ): Promise<any> {
    const warehouses = await this.ticketRepository.findTicketByCodeKeyword(
      request,
    );

    const response = plainToInstance(TicketResponseDto, warehouses, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async getTicketByItems(request) {
    const { itemId, lot, mfg, storageDate } = request;
    const conditions: any = {};

    if (itemId) {
      conditions.itemId = itemId;
    }
    if (lot) {
      conditions.lot = lot;
    }
    if (mfg) {
      conditions.mfgDate = { $eq: mfg };
    }
    if (storageDate) {
      conditions.importDate = { $eq: storageDate };
    }
    const ticketDetails = await this.ticketDetailRepository.findAllWithPopulate(
      conditions,
      'ticketId',
    );
    const res = plainToInstance(GetTicketByItemResponseDto, ticketDetails, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(res)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async getListTicketByItem(
    request: GetListTicketByItemRequestDto,
  ): Promise<any> {
    const { items, order } = request;
    const conditionFilterItem = items.map((item) => {
      const condition = {} as any;
      if (item.itemId) {
        condition.itemId = item.itemId;
      }
      if (item.lot) {
        condition.lot = item?.lot?.toUpperCase();
      }
      if (item.mfg) {
        condition.mfgDate = { $eq: item.mfg };
      }
      if (item.storageDate) {
        condition.importDate = { $eq: item.storageDate };
      }
      return condition;
    });
    const ticketDetails =
      await this.ticketDetailRepository.getListTicketByItems(
        conditionFilterItem,
        order,
      );
    const listTicketFilConditon = ticketDetails.filter(
      (e) => e.ticketId !== null,
    );
    const res = plainToInstance(
      GetTicketByItemResponseDto,
      !isEmpty(listTicketFilConditon) ? listTicketFilConditon : [],
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(res)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async syncImportExportQuantity(
    data: SyncImportExportWarehouseQuantityRequestDto,
  ): Promise<any> {
    await this.kafkaProducer.send({
      topic: 'sync_actual_import_export_warehouse_quantity_by_request',
      messages: [
        {
          key: 'data',
          value: JSON.stringify(data),
        },
      ],
    });
  }
}
