import { isEmpty } from 'lodash';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Req,
} from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ReceiptService } from './receipt.service';
import { ApiConsumes, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { GetListTicketRequestDto } from '@utils/dto/request/get-list-ticket.request.dto';
import { TicketResponseDto } from '@utils/dto/response/ticket.response.dto';
import { CreateTicketRequestDto } from '@utils/dto/request/create-ticket.request.dto';
import { UpdateTicketBodyDto } from '@utils/dto/request/update-ticket.request.dto';
import { GetDetailTicketRequestDto } from '@utils/dto/request/get-detail-ticket.request.dto';
import { DeleteTicketRequestDto } from '@utils/dto/request/delete-ticket.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { STATUS_ENUM } from '@constant/common';
import { GetTicketDetailResponseDto } from '@utils/dto/response/get-ticket-detail.response.dto';
import { DetailDto } from '@utils/dto/common.dto';
import { WarehouseImportStoreRequestDto } from './dto/request/warehouse-import-store.request.dto';
import { GetTicketReceiptByTicketIdRequestDto } from './dto/request/get-ticket-receipt-by-ticket-id.request.dto';
import { MessagePattern } from '@nestjs/microservices';
import { GetTicketByRequestIdsRequestDto } from './dto/request/get-ticket-receipt-by-request-ids.request.dto';
import { TicketReceiveRequestDto } from './dto/request/receive-ticket.request.dto';
import { StoredTicketReceiptRequestDto } from './dto/request/stored-ticket-receipt.request.dto';
import { NATS_TICKET } from '@config/nats.config';
import { PutAwayReceiptRequestDto } from './dto/request/receipt-put-away.request.dto';
import { GetTicketByIdsRequestDto } from './dto/request/get-ticket-receipt-by-ids.request.dto';
import { GetTicketByKeywordRequestDto } from './dto/request/get-ticket-by-keyword.dto';
import {
  GetTicketByItemDto,
  GetTicketByItemRequestDto,
} from './dto/request/get-ticket-by-item.dto';
import { GetListTicketByItemRequestDto } from './dto/request/get-list-ticket-by-item.dto';
@Controller('receipts')
export class ReceiptController {
  constructor(
    @Inject('ReceiptServiceInterface')
    private readonly service: ReceiptService,
  ) {}

  @Get('ping')
  public async get(@Req() request): Promise<any> {
    return new ResponseBuilder('Receipt Ticket: PONG')
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  @Get('')
  @ApiOperation({
    tags: ['Receipt Ticket'],
    summary: 'Get List of Receipt Tickets',
    description: 'Danh sách phiếu nhập',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List of receipt tickets successfully',
    type: GetListTicketRequestDto,
  })
  public async getList(
    @Query() payload: GetListTicketRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.service.getList(request);
  }

  @Post()
  @ApiOperation({
    tags: ['Receipt Ticket'],
    summary: 'Create the Receipt Ticket',
    description: 'Create the Receipt Ticket',
  })
  @ApiResponse({
    status: 200,
    description: 'Create the Receipt Ticket successfully',
    type: TicketResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  public async create(@Body() body: CreateTicketRequestDto): Promise<any> {
    const { request, responseError } = body;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.create(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['Receipt Ticket'],
    summary: 'Edit the Receipt Ticket',
    description: 'Edit the Receipt Ticket',
  })
  @ApiResponse({
    status: 200,
    description: 'Edit the Receipt Ticket successfully',
    type: TicketResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  public async update(
    @Param() param: DetailDto,
    @Body() body: UpdateTicketBodyDto,
  ): Promise<any> {
    const {
      request: { id },
      responseError: paramError,
    } = param;
    const { request, responseError } = body;
    if (paramError && !isEmpty(paramError)) {
      return responseError;
    }
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.service.update({ ...request, id });
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Receipt Ticket'],
    summary: 'Detail Receipt Ticket',
    description: 'Chi tiết phiếu nhập',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail Successfully',
    type: GetTicketDetailResponseDto,
  })
  public async getDetail(
    @Param() param: GetDetailTicketRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.service.getDetail(request);
  }

  @Get('/:id/mobile')
  @ApiOperation({
    tags: ['Receipt Ticket'],
    summary: 'Detail Receipt Ticket',
    description: 'Chi tiết phiếu nhập mobile',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail Successfully',
    type: GetTicketDetailResponseDto,
  })
  public async getDetailReceipt(
    @Param() param: GetDetailTicketRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.service.getDetailReceipt(request);
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['Receipt Ticket'],
    summary: 'Delete Receipt Ticket',
    description: 'Xoá phiếu nhập hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async delete(@Param() param: DeleteTicketRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.delete(request);
  }

  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Receipt Ticket'],
    summary: 'Confirm Receipt Ticket',
    description: 'Xác nhận phiếu nhập hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm Successfully',
    type: TicketResponseDto,
  })
  public async confirm(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.confirm({
      ...request,
    });
  }

  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Receipt Ticket'],
    summary: 'Reject Receipt Ticket',
    description: 'Từ chối phiếu nhập hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject Successfully',
    type: TicketResponseDto,
  })
  public async reject(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.reject({
      ...request,
    });
  }

  @Post('/import')
  public async import(
    @Body() payload: WarehouseImportStoreRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.warehouseImportStore(request);
  }

  @Post('/receive')
  public async receive(@Body() payload: TicketReceiveRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.receiveTicket(request);
  }

  @Post('/store')
  public async storeReceipt(
    @Body() payload: StoredTicketReceiptRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.receiptStore(request);
  }

  @Post('/put-away')
  public async putAwayReceipt(
    @Body() payload: PutAwayReceiptRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.putAwayReceipt(request);
  }

  @MessagePattern(`${NATS_TICKET}.get_ticket_receipt_by_ticket_id`)
  async getTicketReceiptByTicketId(
    @Body() payload: GetTicketReceiptByTicketIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.getTicketReceiptByTicketId(request);
  }

  @MessagePattern(`${NATS_TICKET}.get_tickets_by_request_ids`)
  public async getTicketsByRequestIds(
    @Body() body: GetTicketByRequestIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.service.getTicketByRequestIds(request);
  }

  @MessagePattern(`${NATS_TICKET}.get_tickets_by_condition`)
  public async getTicketReceiptByCondition(
    @Body() body: GetTicketByRequestIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.service.getTicketReceiptByCondition(request);
  }

  @MessagePattern(`${NATS_TICKET}.get_tickets_by_ids`)
  public async getTicketReceiptByIds(
    @Body() body: GetTicketByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.service.getTicketReceiptByIds(request);
  }

  @MessagePattern(`${NATS_TICKET}.get_ticket_by_keyword`)
  public async getItemByConditions(
    @Body() payload: GetTicketByKeywordRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.service.getTicketCodeKeyword(request);
  }

  @Get('/ticket-by-items')
  public async getTicketByItems(
    @Query() param: GetTicketByItemDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.service.getTicketByItems(request);
  }
  @Post('items/ticket')
  public async getListTicketByItems(
    @Body() body: GetListTicketByItemRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.service.getListTicketByItem(request);
  }
}
