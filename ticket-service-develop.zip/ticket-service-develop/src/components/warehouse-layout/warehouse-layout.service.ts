import { NATS_WAREHOUSE_LAYOUT } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { plainToInstance } from 'class-transformer';
import { keyBy } from 'lodash';
import { LocatorResponseDto } from './dto/response/locator.response.dto';
import { WarehouseLayoutServiceInterface } from './interface/warehouse-layout.service.interface';
@Injectable()
export class WarehouseLayoutService implements WarehouseLayoutServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getLocators(condition: {
    ids?: string[];
    warehouseId?: number;
  }): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE_LAYOUT}.get_locators`,
      {
        ids: condition.ids,
        warehouseId: condition.warehouseId,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    return response.data;
  }

  async getListLocatorByIds(ids: string[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE_LAYOUT}.get_locators_by_ids`,
      {
        ids: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];

    const dataReturn = plainToInstance(
      LocatorResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );

    return serilize ? keyBy(dataReturn, 'locatorId') : dataReturn;
  }

  public async getLocatorByCode(payload: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE_LAYOUT}.get_locator_by_code`,
      payload,
    );
    if (response.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return response.data;
  }

  public async getLocatorByCodes(payload: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE_LAYOUT}.get_locator_by_codes`,
      payload,
    );
    if (response.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return response.data;
  }
}
