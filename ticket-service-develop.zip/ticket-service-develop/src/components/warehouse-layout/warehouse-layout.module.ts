import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { WarehouseLayoutService } from './warehouse-layout.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    {
      provide: 'WarehouseLayoutServiceInterface',
      useClass: WarehouseLayoutService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'WarehouseLayoutServiceInterface',
      useClass: WarehouseLayoutService,
    },
  ],
})
export class WarehouseLayoutModule {}
