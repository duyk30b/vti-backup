export interface WarehouseLayoutServiceInterface {
  getLocators(condition: {
    ids?: string[];
    warehouseId?: number;
  }): Promise<any>;
  getListLocatorByIds(ids: string[], serilize?: boolean): Promise<any>;
  getLocatorByCode(payload: any): Promise<any>;
  getLocatorByCodes(payload: any): Promise<any>;
}
