import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsPositive,
} from 'class-validator';
import { Types } from 'mongoose';
import { File } from 'src/models/file/file.model';
import { TicketDetail } from 'src/models/ticket/ticket-details.schema';

export class Attribute {
  code: string;
  value: any;
}

export class TicketTransferWarehouseUpsertRequest extends BaseDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  templateId: Types.ObjectId;

  @ApiProperty()
  @IsPositive()
  @Type(() => Number)
  warehouseImportId: number;

  @ApiProperty()
  @IsPositive()
  @Type(() => Number)
  warehouseExportId: number;

  @ApiProperty()
  @IsOptional()
  @Type(() => File)
  attachment: File[];

  @Transform(({ value }) => JSON.parse(value))
  @IsOptional()
  @Type(() => Attribute)
  attributes: Attribute[];

  @ApiProperty()
  @ArrayNotEmpty()
  @Transform(({ value }) => JSON.parse(value))
  @Type(() => TicketDetail)
  items: TicketDetail[];
}
