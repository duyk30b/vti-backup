export const TRANSFER_CODE_PREFIX = 'C';

export enum ALLOW_MIME_TYPE_ENUM {
  PDF = 'application/pdf',
  DOC = 'application/msword',
  DOCX = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  XLS = 'application/vnd.ms-excel',
  XLSX = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  XLSX_OFFICE = 'application/wps-office.xlsx',
}

export enum TICKET_TRANSFER_STATUS {
  PENDING = 0,
  CONFIRMED = 1,
  REJECTED = 2,
  WAITING_PICKUP = 3,
  WAITING_EXPORT = 4,
  COMPLETE_EXPORT = 5,
  SUCCESS = 6,
}

export const ATTRIBUTE_CODE = {
  // attribute for header
  TEMPLATE_CODE: 'wmsxTemplateCode', // loai nghiep vu
  ORDER_TYPE: 'wmsxOrderType', // loai lenh
  REQUEST_CODE: 'requestCode', // ma yeu cau
  CREATED_RECEIPT_DATE: 'wmsxCreateReceiptDate', // ngay chung tu
  WAREHOUSE_EXPORT_CODE: 'warehouseExportCode', // Kho xuat
  WAREHOUSE_IMPORT_CODE: 'warehouseImportCode', // Kho nhap
  REASON: 'wmsxReason', // ly do
  EXPECTED_RELEASE_DATE: 'wmsxExpectedReleaseDate', // ngay xuat du kien
  PICK_ITEM_METHOD: 'wmsxPickItemMethod', // chien thuat lay hang
  DESCRIPTION: 'wmsxDescription', // mo ta yeu cau

  // attribute for item
  ITEM_CODE: 'wmsxItemCode', // ma san pham
  ITEM_NAME: 'wmsxItemName', // ten san pham
  ITEM_UNIT_NAME: 'wmsxItemUnitName', // ten don vi tinh
  LOT_NUMBER: 'wmsxLotNumber', // so lo
  MANUFACTURE_DATE: 'wmsxManufactureDate', // ngay san xuat'
  IMPORT_DATE: 'wmsxImportDate', // ngay nhap kho
  LOCATOR_EXPORT: 'wmsxLocatorExport', // vi tri xuat
  LOCATOR_IMPORT: 'wmsxLocatorImport', // vi tri nhap
  REMAINING_QUANTITY_REQUEST: 'wmsxRemainningQuantityRequest', // so luong yeu cau
  QUANTITY_AVAILABLE: 'wmsxQuantityAvailable', // so luong kha dung
  CUSTOMER_TRANSFER: 'wmsxCustomerTransfer', // so luong khach hang chuyen
};

export const TICKET_TRANSFER_ATTRIBUTE = {
  TEMPLATE_CODE: ATTRIBUTE_CODE.TEMPLATE_CODE, //text
  ORDER_TYPE: ATTRIBUTE_CODE.ORDER_TYPE, // text
  REQUEST_CODE: ATTRIBUTE_CODE.REQUEST_CODE, // select
  CREATED_RECEIPT_DATE: ATTRIBUTE_CODE.CREATED_RECEIPT_DATE, // date
  WAREHOUSE_EXPORT_CODE: ATTRIBUTE_CODE.WAREHOUSE_EXPORT_CODE, // select
  WAREHOUSE_IMPORT_CODE: ATTRIBUTE_CODE.WAREHOUSE_IMPORT_CODE, // select
  REASON: ATTRIBUTE_CODE.REASON, // select
  EXPECTED_RELEASE_DATE: ATTRIBUTE_CODE.EXPECTED_RELEASE_DATE, // date
  PICK_ITEM_METHOD: ATTRIBUTE_CODE.PICK_ITEM_METHOD, // select
  DESCRIPTION: ATTRIBUTE_CODE.DESCRIPTION, // text

  items: {
    ITEM_CODE: ATTRIBUTE_CODE.ITEM_CODE, // select
    ITEM_NAME: ATTRIBUTE_CODE.ITEM_NAME, // text
    ITEM_UNIT_NAME: ATTRIBUTE_CODE.ITEM_UNIT_NAME, // text
    LOT_NUMBER: ATTRIBUTE_CODE.LOT_NUMBER, // text
    MANUFACTURE_DATE: ATTRIBUTE_CODE.MANUFACTURE_DATE, // date
    IMPORT_DATE: ATTRIBUTE_CODE.IMPORT_DATE, // date
    LOCATOR_EXPORT: ATTRIBUTE_CODE.LOCATOR_EXPORT, // select
    LOCATOR_IMPORT: ATTRIBUTE_CODE.LOCATOR_IMPORT, // select
    REMAINING_QUANTITY_REQUEST: ATTRIBUTE_CODE.REMAINING_QUANTITY_REQUEST, // number
    QUANTITY_AVAILABLE: ATTRIBUTE_CODE.QUANTITY_AVAILABLE, // number
    CUSTOMER_TRANSFER: ATTRIBUTE_CODE.CUSTOMER_TRANSFER, // number
  },
};
