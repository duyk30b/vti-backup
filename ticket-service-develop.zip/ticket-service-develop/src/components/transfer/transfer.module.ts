import { AttributeService } from '@components/attribute/attribute.service';
import { ExportReceiptService } from '@components/export-receipt/export-receipt.service';
import { FileModule } from '@components/file/file.module';
import { ItemModule } from '@components/item/item.module';
import { ItemService } from '@components/item/item.service';
import { RequestService } from '@components/request/request.service';
import { SaleService } from '@components/sale/sale.service';
import { UserService } from '@components/user/user.service';
import { WarehouseLayoutModule } from '@components/warehouse-layout/warehouse-layout.module';
import { WarehouseLayoutService } from '@components/warehouse-layout/warehouse-layout.service';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { Global, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { TicketDetailSchema } from 'src/models/ticket/ticket-details.schema';
import { TicketSchema } from 'src/models/ticket/ticket.schema';
import { TicketDetailRepository } from 'src/repository/ticket/ticket-detail.repository';
import { TicketRepository } from 'src/repository/ticket/ticket.repository';
import { TransferController } from './transfer.controller';
import { TicketTransferService } from './transfer.service';

@Global()
@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: 'Ticket',
        schema: TicketSchema,
      },
      {
        name: 'TicketDetail',
        schema: TicketDetailSchema,
      },
    ]),
    FileModule,
    ItemModule,
    WarehouseLayoutModule,
  ],
  providers: [
    TicketTransferService,
    {
      provide: 'TicketRepositoryInterface',
      useClass: TicketRepository,
    },
    {
      provide: 'TicketDetailRepositoryInterface',
      useClass: TicketDetailRepository,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
    {
      provide: 'RequestServiceInterface',
      useClass: RequestService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'TicketDetailRepositoryInterface',
      useClass: TicketDetailRepository,
    },
    {
      provide: 'AttributeServiceInterface',
      useClass: AttributeService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseLayoutServiceInterface',
      useClass: WarehouseLayoutService,
    },
    {
      provide: 'ExportReceiptServiceInterface',
      useClass: ExportReceiptService,
    },
  ],
  controllers: [TransferController],
  exports: [],
})
export class TransferModule {}
