import { GetTicketTransferByRequestIdsRequestDto } from '../dto/request/get-ticket-transfer-by-request-ids.request.dto';
import { GetTicketTransferByTicketIdRequestDto } from '../dto/request/get-ticket-transfer-by-ticket-id.request.dto';

export interface TransferServiceInterface {
  getTicketTransferByTicketId(
    request: GetTicketTransferByTicketIdRequestDto,
  ): Promise<any>;
  getTicketTransferByRequestIds(
    request: GetTicketTransferByRequestIdsRequestDto,
  ): Promise<any>;
}
