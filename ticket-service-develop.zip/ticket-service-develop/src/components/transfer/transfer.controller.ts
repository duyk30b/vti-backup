import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiConsumes,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import { DetailDto } from '@utils/dto/common.dto';
import { DeleteTicketRequestDto } from '@utils/dto/request/delete-ticket.request.dto';
import { GetDetailTicketRequestDto } from '@utils/dto/request/get-detail-ticket.request.dto';
import { GetListTicketRequestDto } from '@utils/dto/request/get-list-ticket.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { isEmpty } from 'lodash';
import { TicketTransferWarehouseUpsertRequest } from './dto/request/ticket-transfer-warehouse-upsert.request';
import { TicketTransferService } from './transfer.service';

@Controller('transfer')
@ApiBearerAuth('access-token')
@ApiTags('Transfer Ticket')
export class TransferController {
  constructor(private readonly service: TicketTransferService) {}

  @Get('')
  @ApiOperation({
    summary: 'Get List of Transfer Tickets',
    description: 'Danh sách phiếu chuyển kho',
  })
  public async getList(@Query() payload: GetListTicketRequestDto) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.service.getList(request);
  }

  @Post()
  @ApiOperation({
    summary: 'Create the Transfer Ticket',
    description: 'Tạo phiếu chuyển kho',
  })
  @ApiConsumes('multipart/form-data')
  public async create(@Body() body: TicketTransferWarehouseUpsertRequest) {
    const { request, responseError } = body;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.create(request);
  }

  @Put('/:id')
  @ApiOperation({
    summary: 'Edit the Transfer Ticket',
    description: 'Edit the Transfer Ticket',
  })
  @ApiConsumes('multipart/form-data')
  public async update(
    @Param() param: DetailDto,
    @Body() body: TicketTransferWarehouseUpsertRequest,
  ) {
    const {
      request: { id },
      responseError: paramError,
    } = param;
    const { request, responseError } = body;
    if (paramError && !isEmpty(paramError)) {
      return responseError;
    }
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.service.update(id, request);
  }

  @Get('/:id')
  @ApiOperation({
    summary: 'Detail Transfer Ticket',
    description: 'Chi tiết phiếu chuyển kho',
  })
  public async getDetail(@Param() param: GetDetailTicketRequestDto) {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.service.getDetail(request);
  }

  @Delete('/:id')
  @ApiOperation({
    summary: 'Delete Transfer Ticket',
    description: 'Xoá phiếu chuyển kho hàng',
  })
  public async delete(@Param() param: DeleteTicketRequestDto) {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.delete(request);
  }

  @Patch('/:id/confirm')
  @ApiOperation({
    summary: 'Confirm Transfer Ticket',
    description: 'Xác nhận phiếu chuyển kho hàng',
  })
  public async confirm(@Param() payload: IdParamMongoDto) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.service.confirmTicket(request.id);
  }

  @Patch('/:id/reject')
  @ApiOperation({
    summary: 'Reject Transfer Ticket',
    description: 'Từ chối phiếu chuyển kho hàng',
  })
  public async reject(@Param() payload: IdParamMongoDto) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.rejectTicket(request.id);
  }

  @Patch('/:id/refund-ticket')
  @ApiOperation({
    summary: 'Reject Transfer Ticket',
    description: 'Từ chối phiếu chuyển kho hàng',
  })
  public async refundTicket(@Param() payload: IdParamMongoDto) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.service.refundTicket(request.id);
  }

  @Post('/:id/pick-up-items')
  @ApiOperation({
    summary: 'Pickup items and export items',
    description: 'Lấy hàng',
  })
  public async pickupItems(@Param() payload: IdParamMongoDto) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.service.startPickupItem(request.id);
  }
}
