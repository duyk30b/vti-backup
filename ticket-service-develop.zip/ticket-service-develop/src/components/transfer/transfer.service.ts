import { AttributeServiceInterface } from '@components/attribute/interface/attribute.service.interface';
import { ExportReceiptStatusEnum } from '@components/export-receipt/export-receipt.constant';
import { ExportReceiptServiceInterface } from '@components/export-receipt/interface/export-receipt.service.interface';
import { FILE_RESOURCE } from '@components/file/file.constant';
import { FileRepositoryInterface } from '@components/file/interface/file.repository.interface';
import { FileServiceInterface } from '@components/file/interface/file.service.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { RequestServiceInterface } from '@components/request/interface/request.service.interface';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { WarehouseLayoutServiceInterface } from '@components/warehouse-layout/interface/warehouse-layout.service.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import {
  DATA_TYPE_ENUM,
  IS_OPTIONAL,
  MAX_FILE_SIZE,
  TICKET_TYPE_ENUM,
} from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { InjectConnection } from '@nestjs/mongoose';
import { DeleteTicketRequestDto } from '@utils/dto/request/delete-ticket.request.dto';
import { GetDetailTicketRequestDto } from '@utils/dto/request/get-detail-ticket.request.dto';
import { GetListTicketRequestDto } from '@utils/dto/request/get-list-ticket.request.dto';
import { GetTicketDetailResponseDto } from '@utils/dto/response/get-ticket-detail.response.dto';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { TicketResponseDto } from '@utils/dto/response/ticket.response.dto';
import { compareDate } from '@utils/helper';
import { TicketDetailRepositoryInterface } from '@utils/interface/ticket-detail.repository.interface';
import { TicketRepositoryInterface } from '@utils/interface/ticket.repository.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import {
  compact,
  find,
  first,
  flatMap,
  forEach,
  isEmpty,
  isEqual,
  keyBy,
  map,
  uniq,
} from 'lodash';
import * as Moment from 'moment';
import { Connection, Types } from 'mongoose';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { generateTicketCode } from 'src/helper/code.helper';
import { TicketDetail } from 'src/models/ticket/ticket-details.schema';
import { GetTicketTransferByRequestIdsRequestDto } from './dto/request/get-ticket-transfer-by-request-ids.request.dto';
import { GetTicketTransferByTicketIdRequestDto } from './dto/request/get-ticket-transfer-by-ticket-id.request.dto';
import { TicketTransferWarehouseUpsertRequest } from './dto/request/ticket-transfer-warehouse-upsert.request';
import {
  ALLOW_MIME_TYPE_ENUM,
  ATTRIBUTE_CODE,
  TICKET_TRANSFER_ATTRIBUTE,
  TICKET_TRANSFER_STATUS,
  TRANSFER_CODE_PREFIX,
} from './transfer.constant';

@Injectable()
export class TicketTransferService {
  private readonly logger = new Logger(TicketTransferService.name);
  constructor(
    @Inject('TicketRepositoryInterface')
    private readonly ticketRepository: TicketRepositoryInterface,

    @Inject('TicketDetailRepositoryInterface')
    private readonly ticketDetailRepository: TicketDetailRepositoryInterface,

    @Inject('FileServiceInterface')
    private readonly fileService: FileServiceInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('SaleServiceInterface')
    protected readonly saleService: SaleServiceInterface,

    @Inject('RequestServiceInterface')
    protected readonly requestService: RequestServiceInterface,

    @Inject('WarehouseLayoutServiceInterface')
    private readonly warehouseLayoutService: WarehouseLayoutServiceInterface,

    @Inject('ExportReceiptServiceInterface')
    private readonly exportReceiptService: ExportReceiptServiceInterface,

    @Inject('FileRepositoryInterface')
    private readonly fileRepository: FileRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,

    @InjectConnection()
    private readonly connection: Connection,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('AttributeServiceInterface')
    protected readonly attributeService: AttributeServiceInterface,
  ) {}
  updateStatus(request: any): Promise<any> {
    throw new Error('Method not implemented.');
  }

  public async delete(request: DeleteTicketRequestDto): Promise<any> {
    const { id } = request;
    const ticket = await this.ticketRepository.findOneById(id);
    if (isEmpty(ticket)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    // Check status ticket
    if (
      ticket.status !== TICKET_TRANSFER_STATUS.PENDING &&
      ticket.status !== TICKET_TRANSFER_STATUS.REJECTED
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }

    // File
    const file = await this.fileRepository.findOneByCondition({
      resourceId: id,
      resource: FILE_RESOURCE.RI,
    });

    // Start transaction
    const session = await this.connection.startSession();
    session.startTransaction();
    try {
      // Delete TicketDetails
      await this.ticketDetailRepository.deleteManyByCondition({
        ticketId: id,
      });

      // Delete file
      if (!isEmpty(file)) {
        await this.fileRepository.deleteById(file.id);
      }

      // Delete Ticket
      await this.ticketRepository.deleteById(id);

      // Commit transaction
      await session.commitTransaction();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch {
      // Abort transaction
      await session.abortTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  public async getDetail(
    request: GetDetailTicketRequestDto,
  ): Promise<GetTicketDetailResponseDto | any> {
    const { id } = request;
    const transferTicket = await this.ticketRepository.findOneWithPopulate(
      { _id: id },
      'ticketDetails',
    );
    if (!transferTicket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.TICKET_NOT_FOUND'))
        .build();
    }

    const template = await this.attributeService.getTemplateById(
      transferTicket.templateId,
    );
    if (!template) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.TEMPLATE_NOT_FOUND'))
        .build();
    }
    const templateResponse = await this.attributeService.getTemplateByCode(
      template?.code,
    );

    const concatNestedAttributeValues = [
      ...transferTicket.attributes,
      ...flatMap(transferTicket.ticketDetails, (i) => {
        return i.attributes;
      }),
    ];
    const userIds = [transferTicket?.createdBy] || [];

    const itemIds = [];
    const warehouseIds = [];
    const requestIds = [];
    const reasonIds = [];
    const locatorIds: string[] = [];

    if (transferTicket.warehouseImportId) {
      warehouseIds.push(transferTicket.warehouseImportId);
    }
    if (transferTicket.warehouseExportId) {
      warehouseIds.push(transferTicket.warehouseExportId);
    }

    concatNestedAttributeValues.forEach((attributeValue) => {
      const { code, value } = attributeValue;
      switch (code) {
        case ATTRIBUTE_CODE.ITEM_CODE:
          if (value) itemIds.push(value);
          break;
        case ATTRIBUTE_CODE.REQUEST_CODE:
          if (value && !isEmpty(value)) requestIds.push(value);
          break;
        case ATTRIBUTE_CODE.REASON:
          if (value) reasonIds.push(value);
          break;
        case ATTRIBUTE_CODE.LOCATOR_IMPORT:
          if (value && !isEmpty(value)) locatorIds.push(value);
          break;
        case ATTRIBUTE_CODE.LOCATOR_EXPORT:
          if (value && !isEmpty(value)) locatorIds.push(value);
          break;
        default:
          break;
      }
    });

    const extendsServicePromise = await Promise.allSettled([
      this.itemService.getItemByIds(itemIds, true),
      this.warehouseService.getListByIDs(warehouseIds, true),
      this.saleService.getReasonByIds(reasonIds, true),
      this.requestService.getListRequestByIds(requestIds, true),
      locatorIds.length
        ? this.warehouseLayoutService.getLocators({ ids: uniq(locatorIds) })
        : [],
    ]);
    const [
      serializedItem,
      warehouseMap,
      serializeReason,
      serializedRequestOrder,
      locators,
    ] = extendsServicePromise.map((i, index) => {
      if (i.status === 'fulfilled') {
        return i.value;
      } else {
        this.logger.error('Get info from Nats failed: ' + index);
        this.logger.error(i);
        return {};
      }
    });

    transferTicket['data'] = {
      warehouseImport: warehouseMap[transferTicket.warehouseImportId],
      warehouseExport: warehouseMap[transferTicket.warehouseExportId],
      warehouse: warehouseMap,
      reason: Object.values(serializeReason)[0],
      request: Object.values(serializedRequestOrder)[0],
      locators: keyBy(locators, 'id'),
    };

    const file = await this.fileRepository.findOneByCondition({
      resourceId: new Types.ObjectId(id),
      resource: FILE_RESOURCE.RI,
    });

    let beautifiedData = first(this.beautifyRequestOrder([transferTicket]));

    beautifiedData = {
      ...beautifiedData,
      [TICKET_TRANSFER_ATTRIBUTE.TEMPLATE_CODE]: {
        value: {
          id: templateResponse._id,
          name: templateResponse.name,
          code: templateResponse.code,
        },
      },
      [TICKET_TRANSFER_ATTRIBUTE.REQUEST_CODE]: {
        value:
          serializedRequestOrder?.[
            beautifiedData[ATTRIBUTE_CODE.REQUEST_CODE]?.value
          ],
      },

      [TICKET_TRANSFER_ATTRIBUTE.REASON]: {
        value: serializeReason[beautifiedData[ATTRIBUTE_CODE.REASON]?.value],
      },

      ticketDetails: beautifiedData.ticketReceiptDetails.map((i) => {
        return {
          ...i,
          [TICKET_TRANSFER_ATTRIBUTE.items.ITEM_CODE]: {
            value: serializedItem[i[ATTRIBUTE_CODE.ITEM_CODE]?.value],
          },
          [TICKET_TRANSFER_ATTRIBUTE.items.ITEM_NAME]: {
            value: serializedItem[i[ATTRIBUTE_CODE.ITEM_CODE]?.value]?.name,
          },
          [TICKET_TRANSFER_ATTRIBUTE.items.ITEM_UNIT_NAME]: {
            value: serializedItem[i[ATTRIBUTE_CODE.ITEM_CODE]?.value]?.itemUnit,
          },
        };
      }),
    };

    const ticketDetails = transferTicket.ticketDetails?.map((item) => {
      return {
        ...item,
        itemResponse: serializedItem[item.itemId],
      };
    });

    return this.makeResponse(
      templateResponse,
      beautifiedData,
      ticketDetails,
      transferTicket,
    );
  }

  private makeResponse(
    template: any,
    beautifiedData: any,
    ticketDetails?: any,
    transferTicket?: any,
  ) {
    let { attributeHeaders, attributeGroups } = template;
    attributeHeaders = attributeHeaders.map((attributeHeader) => {
      return {
        ...attributeHeader,
        attribute: {
          ...attributeHeader.attribute,
          value: beautifiedData[attributeHeader.attribute?.code]?.value,
        },
      };
    });
    const ticketReceiptDetails = beautifiedData.ticketDetails;

    attributeGroups = attributeGroups.map((attributeGroup) => {
      return compact(
        ticketReceiptDetails.map((requestOrderDetail) => {
          if (
            isEqual(
              requestOrderDetail.groupId.toString(),
              attributeGroup.attributes[0].attributeGroup.id.toString(),
            )
          ) {
            const attributes = attributeGroup.attributes.map((attribute) => {
              return {
                ...attribute,
                attribute: {
                  ...attribute.attribute,
                  value: requestOrderDetail[attribute.attribute?.code]?.value,
                },
              };
            });
            return { ...attributeGroup, attributes };
          }
          return;
        }),
      );
    });
    const dataReturn = {
      ...transferTicket,
      attributeHeaders,
      attributeGroups: attributeGroups,
      items: ticketDetails,
      template,
      id: transferTicket._id,
    };
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private beautifyRequestOrder(data: any[]): any[] {
    return data?.map((ticketReceipt) => {
      const generalInfo = keyBy(
        ticketReceipt.attributes.map((attributeValue) => {
          return { key: attributeValue.code, value: attributeValue.value };
        }),
        'key',
      );

      let ticketReceiptDetails = ticketReceipt.ticketDetails;
      if (!isEmpty(ticketReceiptDetails)) {
        ticketReceiptDetails = ticketReceiptDetails.map(
          (ticketReceiptDetail) => {
            const generalInfo = keyBy(
              ticketReceiptDetail.attributes.map((attributeValue) => {
                return {
                  key: attributeValue.code,
                  value: attributeValue.value,
                };
              }),
              'key',
            );
            return { ...ticketReceiptDetail, ...generalInfo };
          },
        );
      }
      return { ...ticketReceipt, ...generalInfo, ticketReceiptDetails };
    });
  }

  public async getList(request: GetListTicketRequestDto): Promise<any> {
    const { page } = request;
    if (!request.filter) request.filter = [];

    const { data, count } = await this.ticketRepository.getList(
      request,
      TICKET_TYPE_ENUM.TRANSFER,
    );
    if (count === 0) {
      return new ResponseBuilder<PaginationResponse>({
        items: [],
        meta: { total: 0, page: 1 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    let dataSortWarehouseId = data.map((i) => ({
      ...i,
    }));

    // Warehouse
    let warehouseIds = [];
    data.forEach((item) => {
      if (item.warehouseImportId) {
        warehouseIds.push(item.warehouseImportId);
      }
      if (item.warehouseExportId) {
        warehouseIds.push(item.warehouseExportId);
      }
    });
    warehouseIds = uniq(warehouseIds);
    const warehouseList = await this.warehouseService.getList([
      {
        column: 'ids',
        text: warehouseIds.join(','),
      },
    ]);
    const warehouseKeyByIds = keyBy(warehouseList, 'id');

    // Filter by fullName of created by
    const createdByIds = uniq(map(data, 'createdBy'));
    const userFilters = [
      {
        column: 'userIds',
        text: createdByIds.join(','),
      },
    ];

    const filterByUser = request.filter.find((item) => item.column === 'user');
    if (filterByUser) {
      userFilters.push({
        column: 'fullName',
        text: filterByUser.text,
      });
    }

    let users = await this.userService.getList(userFilters);
    if (filterByUser) {
      const userIdsFiltered = users.map((user) => user.id);

      dataSortWarehouseId = dataSortWarehouseId.filter((item) =>
        userIdsFiltered.includes(item.createdByUserId),
      );
    }
    // convert users for assign to respose data
    users = keyBy(users, 'id');
    const requestIds = uniq(compact(map(data, 'requestId')));
    const userIds = uniq(compact(map(data, 'createdBy')));

    const extendsServicePromise = await Promise.allSettled([
      requestIds.length
        ? this.requestService.getListRequestByIds(requestIds, true)
        : [],
      this.userService.getUserByIds(userIds, true),
    ]);
    const [requestOrder, serializeUser] = extendsServicePromise.map(
      (i, index) => {
        if (i.status === 'fulfilled') {
          return i.value;
        } else {
          this.logger.error('Get info from Nats failed: ' + index);
          throw new Error(JSON.stringify(i));
        }
      },
    );

    const dataReturn = dataSortWarehouseId.map((item) => ({
      ...item,
      data: {
        warehouseImport: warehouseKeyByIds[item.warehouseImportId],
        warehouseExport: warehouseKeyByIds[item.warehouseExportId],
      },
      warehouseTransferRequest: requestOrder[item.requestId],
      id: item._id,
      createdBy: {
        id: users[item.createdBy]?.id,
        username: users[item.createdBy]?.username,
        fullName: users[item.createdBy]?.fullName,
      },
    }));

    return new ResponseBuilder<PaginationResponse>({
      items: dataReturn,
      meta: {
        total: count,
        page: page,
      },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async confirmTicket(id: string) {
    const ticket = await this.ticketRepository.findOneByCondition({
      _id: id,
      deletedAt: null,
    });
    // Check ticket is existed
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.NOT_FOUND', {
            args: { code: ticket.code },
          }),
        )
        .build();
    }

    // Check ticket status
    if (ticket.status !== TICKET_TRANSFER_STATUS.PENDING) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }

    // Update status
    try {
      const result = await this.ticketRepository.findByIdAndUpdate(id, {
        status: TICKET_TRANSFER_STATUS.CONFIRMED,
      });
      result.id = result._id;

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withData(result)
        .build();
    } catch (e) {
      this.logger.error(e);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  public async rejectTicket(id: string) {
    const ticket = await this.ticketRepository.findOneByCondition({
      _id: id,
      deletedAt: null,
    });
    // Check ticket is existed
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.NOT_FOUND', {
            args: { code: ticket.code },
          }),
        )
        .build();
    }

    // Check ticket status
    if (ticket.status !== TICKET_TRANSFER_STATUS.PENDING) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }

    // Update status
    try {
      const result = await this.ticketRepository.findByIdAndUpdate(id, {
        status: TICKET_TRANSFER_STATUS.REJECTED,
      });
      result.id = result._id;

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withData(result)
        .build();
    } catch (e) {
      this.logger.error(e);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  public async refundTicket(id: string) {
    const ticket = await this.ticketRepository.findOneByCondition({
      _id: id,
      deletedAt: null,
    });
    // Check ticket is existed
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.NOT_FOUND', {
            args: { code: ticket.code },
          }),
        )
        .build();
    }

    // Check ticket status
    if (ticket.status !== TICKET_TRANSFER_STATUS.CONFIRMED) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }

    // Update status
    try {
      const result = await this.ticketRepository.findByIdAndUpdate(id, {
        status: TICKET_TRANSFER_STATUS.PENDING,
      });
      result.id = result._id;

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withData(result)
        .build();
    } catch (e) {
      this.logger.error(e);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  public async startPickupItem(id: string) {
    const ticket = await this.ticketRepository.findOneByCondition({
      _id: id,
      deletedAt: null,
    });
    // Check ticket is existed
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.NOT_FOUND', {
            args: { code: ticket.code },
          }),
        )
        .build();
    }

    // Check ticket status
    if (ticket.status !== TICKET_TRANSFER_STATUS.CONFIRMED) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }

    // Update status
    try {
      const result = await this.ticketRepository.findByIdAndUpdate(id, {
        status: TICKET_TRANSFER_STATUS.WAITING_PICKUP,
      });
      result.id = result._id;

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withData(result)
        .build();
    } catch (e) {
      this.logger.error(e);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async create(request: TicketTransferWarehouseUpsertRequest) {
    const { items, attachment, templateId, attributes } = request;

    if (!isEmpty(attachment)) {
      const resultValidateAttachments = await this.validateAttachments(
        attachment,
      );

      if (resultValidateAttachments.statusCode !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttachments;
      }
    }

    if (!isEmpty(attributes)) {
      const resultValidateAttributes = await this.validateAttributes(
        templateId,
        attributes,
      );

      if (resultValidateAttributes.statusCode !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttributes;
      }
    }

    const ticket = this.ticketRepository.createDocument(request as any);
    ticket.type = TICKET_TYPE_ENUM.TRANSFER;
    ticket.status = TICKET_TRANSFER_STATUS.PENDING;

    // Auto generate ticket code
    const currentDate = Moment().utcOffset(7).format('DDMMYYYY');
    const latestTicket = await this.ticketRepository.getTicketCode(
      `${TRANSFER_CODE_PREFIX}${currentDate}`,
    );
    const lastCode = !isEmpty(latestTicket) ? latestTicket.code : '';
    ticket.code = generateTicketCode(
      TRANSFER_CODE_PREFIX,
      lastCode,
      currentDate,
    );

    forEach(items, (item) => {
      item.ticketId = ticket._id;
    });

    try {
      if (!isEmpty(attachment)) {
        await this.fileService.saveFiles(
          ticket._id,
          FILE_RESOURCE.RI,
          attachment,
        );
      }
      await this.ticketDetailRepository.create(items);
      const ticketResult = await this.ticketRepository.create(ticket);
      ticket.id = ticket._id;

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate('message.transferTicket.createSuccess'),
        )
        .withData(ticketResult)
        .build();
    } catch (error) {
      this.logger.error(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'));
    }
  }

  async update(id: string, request: TicketTransferWarehouseUpsertRequest) {
    const { attachment, templateId, attributes, items } = request;

    if (!isEmpty(attachment)) {
      const resultValidateAttachments = await this.validateAttachments(
        attachment,
      );

      if (resultValidateAttachments.statusCode !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttachments;
      }
    }

    if (!isEmpty(attributes)) {
      const resultValidateAttributes = await this.validateAttributes(
        templateId,
        attributes,
      );

      if (resultValidateAttributes.statusCode !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttributes;
      }
    }

    const ticket = await this.ticketRepository.findOneById(id);
    ticket.id = ticket._id;
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    // Check ticket status
    if (
      ticket.status !== TICKET_TRANSFER_STATUS.PENDING &&
      ticket.status !== TICKET_TRANSFER_STATUS.REJECTED
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }

    this.ticketDetailRepository.deleteManyByCondition({ ticketId: ticket._id });

    forEach(items, (item) => {
      item.ticketId = ticket._id;
    });

    if (!isEmpty(attachment)) {
      await this.fileService.saveFiles(
        ticket._id,
        FILE_RESOURCE.RI,
        attachment,
      );
    }

    try {
      await this.ticketDetailRepository.create(items);
      const response = await this.ticketRepository.findByIdAndUpdate(id, {
        ...request,
        status: TICKET_TRANSFER_STATUS.PENDING,
      });
      response.id = response._id;

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate('message.transferTicket.updateSuccess'),
        )
        .withData(response)
        .build();
    } catch (error) {
      this.logger.error(error.message);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async validateAttachments(attachment: any): Promise<any> {
    for (let i = 0; i < attachment?.length; i++) {
      const file = attachment[i];
      if (Object.values(ALLOW_MIME_TYPE_ENUM).indexOf(file?.mimetype) === -1) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.FILE_WRONG_TYPE'))
          .build();
      }

      if (file?.data.byteLength > MAX_FILE_SIZE) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.FILE_SIZE_IS_TOO_BIG'))
          .build();
      }
    }

    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async validateAttributes(templateId: any, attributes: any): Promise<any> {
    const template = await this.attributeService.getTemplateById(templateId);
    const attributeTemplates = template['attributes'];

    for (let i = 0; i < attributes.length; i++) {
      const attribute = find(attributeTemplates, ['_id', attributes[i]['id']]);
      const rule = attribute ? attribute['attributeRule'] : null;
      const min = rule?.min;
      const max = rule?.max;
      const dataType = attribute?.attribute?.dataType;
      const attributeName = attributes[i].name;
      const attributeValue = attributes[i].value;

      if (rule && rule?.isRequired === IS_OPTIONAL.NO) {
        if (
          attributeValue === undefined ||
          isEmpty(attributeValue?.toString())
        ) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(
              await this.i18n.translate('error.ATTRIBUTE_IS_EMPTY', {
                args: { attribute: attributeName },
              }),
            )
            .build();
        }
      }

      switch (dataType) {
        case DATA_TYPE_ENUM.NUMBER:
          if (!isEmpty(min?.toString()) && attributeValue < min) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_SMALLER_THAN_MIN',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          if (!isEmpty(max?.toString()) && attributeValue > max) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_BIGGER_THAN_MAX',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          break;
        case DATA_TYPE_ENUM.DATE:
          if (
            !isEmpty(min?.toString()) &&
            compareDate(new Date(attributeValue), new Date(min))
          ) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_SMALLER_THAN_MIN',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          if (
            !isEmpty(max?.toString()) &&
            compareDate(new Date(max), new Date(attributeValue))
          ) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_BIGGER_THAN_MAX',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          break;
        default:
          break;
      }
    }

    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async getTicketTransferByTicketId(
    request: GetTicketTransferByTicketIdRequestDto,
  ): Promise<any> {
    const ticket = await this.ticketRepository.findOneWithPopulate(
      {
        ticketId: request.ticketId,
      },
      'ticketDetails',
    );
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    return new ResponseBuilder(ticket)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  async getTicketTransferByRequestIds(
    request: GetTicketTransferByRequestIdsRequestDto,
  ): Promise<any> {
    const { requestIds } = request;
    const tickets = await this.ticketRepository.getTicketByRequestIds(
      requestIds,
    );
    if (isEmpty(tickets)) {
      return new ResponseBuilder([])
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    return new ResponseBuilder(tickets)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async createVirtualTicketExport(ticketTransferId: string) {
    const ticket = await this.ticketRepository.findOneByCondition({
      _id: ticketTransferId,
      deletedAt: null,
    });
    // Check ticket is existed
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.NOT_FOUND', {
            args: { code: ticket.code },
          }),
        )
        .build();
    }

    // Check ticket status
    if (ticket.status !== TICKET_TRANSFER_STATUS.CONFIRMED) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }

    // create virtual ticket export
    const { _id: oldId, ...virtualTicketDto } = ticket;
    virtualTicketDto.type = TICKET_TYPE_ENUM.EXPORT;
    virtualTicketDto.status = ExportReceiptStatusEnum.CONFIRMED;

    const virtualTicket = await this.ticketRepository.create(virtualTicketDto);

    const ticketTransferDetails =
      await this.ticketDetailRepository.findAllByCondition({
        ticketId: ticket.id,
      });

    const virtualTicketDetailsDto = ticketTransferDetails.map(
      (i: TicketDetail) => {
        const { _id, ...virtualTicketDetailDto } = i;
        virtualTicketDetailDto.ticketId = virtualTicket.id;
        return virtualTicketDetailDto;
      },
    );
    await this.ticketDetailRepository.createMany(virtualTicketDetailsDto);
  }

  async pickUpItems(id: string) {
    const ticket = await this.ticketRepository.findOneByCondition({
      _id: id,
      deletedAt: null,
    });
    // Check ticket is existed
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.NOT_FOUND', {
            args: { code: ticket.code },
          }),
        )
        .build();
    }

    // Check ticket status
    if (ticket.status !== TICKET_TRANSFER_STATUS.CONFIRMED) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }

    // create virtual ticket export
    const { _id: oldId, ...virtualTicketDto } = ticket;
    virtualTicketDto.type = TICKET_TYPE_ENUM.EXPORT;
    virtualTicketDto.status = ExportReceiptStatusEnum.CONFIRMED;

    const virtualTicket = await this.ticketRepository.create(virtualTicketDto);

    const ticketTransferDetails =
      await this.ticketDetailRepository.findAllByCondition({
        ticketId: ticket.id,
      });

    const virtualTicketDetailsDto = ticketTransferDetails.map(
      (i: TicketDetail) => {
        const { _id, ...virtualTicketDetailDto } = i;
        virtualTicketDetailDto.ticketId = virtualTicket.id;
        return virtualTicketDetailDto;
      },
    );

    try {
      await this.ticketDetailRepository.createMany(virtualTicketDetailsDto);
      // end create  virtual ticket export

      await this.exportReceiptService.pickUpMultipleReceiptItems({
        pickUpReceiptItems: [
          {
            ticketId: virtualTicket.id,
            items: ticketTransferDetails.map((i) => {
              return {
                itemId: i.itemId,
                warehouseId:
                  ticket.attributes[ATTRIBUTE_CODE.WAREHOUSE_EXPORT_CODE],
                lotNumber: i.attributes[ATTRIBUTE_CODE.LOT_NUMBER],
                quantity: i.quantity,
                locatorId: i.attributes[ATTRIBUTE_CODE.LOCATOR_EXPORT],
                mfg: i.attributes[ATTRIBUTE_CODE.MANUFACTURE_DATE],
                importDate: i.attributes[ATTRIBUTE_CODE.IMPORT_DATE],
              };
            }),
          },
        ],
      } as any);

      const confirmExportParams = { id: virtualTicket.id } as any;
      await this.exportReceiptService.confirmExport(confirmExportParams);

      const result = await this.ticketRepository.findByIdAndUpdate(id, {
        status: TICKET_TRANSFER_STATUS.WAITING_PICKUP,
      });

      const response = plainToInstance(TicketResponseDto, result, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withData(response)
        .build();
    } catch (e) {
      this.logger.error(e.message);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
}
