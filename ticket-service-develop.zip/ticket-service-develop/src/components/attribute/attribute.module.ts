import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AttributeService } from './attribute.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    {
      provide: 'AttributeServiceInterface',
      useClass: AttributeService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'AttributeServiceInterface',
      useClass: AttributeService,
    },
  ],
})
export class AttributeModule {}
