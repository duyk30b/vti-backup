import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { AttributeServiceInterface } from './interface/attribute.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NATS_ATTRIBUTE } from '@config/nats.config';

@Injectable()
export class AttributeService implements AttributeServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getTemplateByCode(code: string): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ATTRIBUTE}.get_templates_by_code`,
      { code },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }
    return response.data;
  }
  async getTemplateById(id: any): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_ATTRIBUTE}.get_template_by_id`,
        {
          id,
        },
      );
      return response?.data || {};
    } catch (err) {
      return {};
    }
  }

  async getTemplatesByIds(ids: any[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ATTRIBUTE}.get_templates_by_ids`,
      { ids },
    );

    return response.data || [];
  }
}
