export interface AttributeServiceInterface {
  getTemplateById(id: any): Promise<any>;
  getTemplateByCode(code: string): Promise<any>;
  getTemplatesByIds(ids: any[]): Promise<any>;
}
