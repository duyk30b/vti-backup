import { generateTicketCode } from 'src/helper/code.helper';
import { InventoryServiceInterface } from './interfaces/inventory.service.interface';
import { Inject, Injectable } from '@nestjs/common';
import { CreateInventoryRequestDto } from './dto/request/create-inventory.request.dto';
import { TicketRepositoryInterface } from '@utils/interface/ticket.repository.interface';
import { Ticket } from 'src/models/ticket/ticket.schema';
import {
  CAN_UPDATE_DELETE_INVENTORY,
  InventoryStatusEnum,
  InventoryTypeEnum,
  INVENTORY_CODE_PREFIX,
  INVENTORY_FIELD_CODE,
} from './inventory.constants';
import * as moment from 'moment';
import { compact, first, flatMap, isEmpty, keyBy, map, uniq } from 'lodash';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { ReceiptTypeEnum } from '@components/export-receipt/export-receipt.constant';
import { plainToInstance } from 'class-transformer';
import { TicketResponseDto } from '@utils/dto/response/ticket.response.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { GetDetailTicketRequestDto } from '@utils/dto/request/get-detail-ticket.request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { GetListTicketRequestDto } from '@utils/dto/request/get-list-ticket.request.dto';
import { TICKET_TYPE_ENUM } from '@constant/common';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { InventoryResponseDto } from './dto/response/inventory.response.dto';
import { AttributeServiceInterface } from '@components/attribute/interface/attribute.service.interface';
import { beautifyRequestOrder, makeResponse } from '@utils/common';
import {
  CAN_UPDATE_TICKET,
  statusObject,
} from '@components/receipt/receipt.constant';
import { TemplateResponse } from '@utils/dto/response/template.response.dto';
import { UpdateInventoryRequestDto } from './dto/request/update-inventory.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';

@Injectable()
export class InventoryService implements InventoryServiceInterface {
  constructor(
    @Inject('TicketRepositoryInterface')
    private readonly ticketRepository: TicketRepositoryInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    private readonly i18n: I18nRequestScopeService,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('AttributeServiceInterface')
    protected readonly attributeService: AttributeServiceInterface,
  ) {}
  async create(body: CreateInventoryRequestDto): Promise<any> {
    const {
      name,
      inventoryType,
      warehouses,
      impersonators,
      executeExpectFrom,
      executeExpectTo,
      inventoryPeriodDate,
      blockTicket,
      attributes,
    } = body;
    const warehouseIds = map(warehouses, 'id');
    const impersonatorIds = map(impersonators, 'id');
    let users = [];
    let warehouseList = [];
    if (!isEmpty(impersonatorIds)) {
      users = await this.userService.getUserByIds(impersonatorIds);
    }
    if (!isEmpty(warehouseIds)) {
      warehouseList = await this.warehouseService.getListByIDs(warehouseIds);
    }
    if (!warehouseList || warehouseIds.length !== warehouseList.length) {
      return new ResponseBuilder(warehouseList)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.REQUEST_WAREHOUSES_NOT_FOUND'),
        )
        .build();
    }
    if (!users || impersonatorIds.length !== users.length) {
      return new ResponseBuilder(users)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_USERS_NOT_FOUND'))
        .build();
    }

    attributes.push(statusObject as any);
    const currentDate = moment().utcOffset(7).format('DDMMYYYY');
    const invetoryDto = this.ticketRepository.createEntityInventory({
      ...body,
      type: ReceiptTypeEnum.INVENTORY,
    });
    const latestTicket = await this.ticketRepository.getTicketCode(
      `${INVENTORY_CODE_PREFIX}${currentDate}`,
    );
    const lastCode = !isEmpty(latestTicket) ? latestTicket.code : '';
    invetoryDto.code = generateTicketCode(
      INVENTORY_CODE_PREFIX,
      lastCode,
      currentDate,
    );
    let validateInventory;
    switch (inventoryType) {
      case InventoryTypeEnum.PERIODIC:
        validateInventory = await this.validateInventoryWithTypePeriod(
          body,
          InventoryTypeEnum.PERIODIC,
        );
        break;
      case InventoryTypeEnum.SURPRISE:
        break;

      default:
        break;
    }
    if (!validateInventory.success) {
      return new ResponseBuilder()
        .withData(validateInventory.data)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate(validateInventory.message))
        .build();
    }

    return await this.save(invetoryDto, body);
  }

  async update(request: UpdateInventoryRequestDto): Promise<any> {
    const { id } = request;

    const ticket = await this.ticketRepository.findOneById(id);
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_UPDATE_TICKET.includes(ticket.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
        .build();
    }
    const statusAttribute = ticket.attributes.find(
      (attributeValue) => attributeValue.code === INVENTORY_FIELD_CODE.STATUS,
    );
    const status = statusAttribute ? +statusAttribute.value : null;
    if (status === InventoryStatusEnum.REJECT) {
      ticket.attributes.find(
        (attributeValue) => attributeValue.code === INVENTORY_FIELD_CODE.STATUS,
      ).value = InventoryStatusEnum.PENDING;
    }
    const inventoryDoc = this.ticketRepository.updateEntityInventory(
      ticket,
      request,
    );
    return await this.save(inventoryDoc, request, true);
  }

  async save(
    ticketEntity: Ticket,
    payload: CreateInventoryRequestDto,
    isUpdate = false,
  ): Promise<any> {
    try {
      let result;
      if (isUpdate) {
        result = await this.ticketRepository.findByIdAndUpdate(
          ticketEntity._id,
          ticketEntity,
        );
      } else {
        result = await this.ticketRepository.create(ticketEntity);
      }
      const response = plainToInstance(TicketResponseDto, ticketEntity, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            isUpdate
              ? 'message.inventory.updateInventorySuccess'
              : 'message.inventory.createInventorySuccess',
          ),
        )
        .withData(response)
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async validateInventoryWithTypePeriod(
    request: any,
    type?: number,
  ): Promise<any> {
    const { inventoryPeriodDate, executeExpectFrom, executeExpectTo } = request;
    let isValidInventoryPeriodDate = true;
    let flagPeriodDate = true;
    const futureDate = moment().add(3, 'months');
    const pastDate = moment().subtract(3, 'months');

    if (
      moment(inventoryPeriodDate).isAfter(futureDate) ||
      moment(inventoryPeriodDate).isBefore(pastDate)
    ) {
      flagPeriodDate = true;
      isValidInventoryPeriodDate = false;
    }
    if (moment(inventoryPeriodDate) >= moment(executeExpectFrom)) {
      flagPeriodDate = false;
      isValidInventoryPeriodDate = false;
    }
    // Nhập ngày chốt kỳ > (ngày hiện tại + 3 tháng) hoặc nhập ngày chốt kỳ < (ngày hiện tại - 3 tháng)
    if (!isValidInventoryPeriodDate && flagPeriodDate) {
      return {
        success: false,
        message:
          'error.INVENTORY_PERIOD_DATE_NOT_EXCEED_THE_PREVIOUS_THREE_MONTH',
      };
    }
    //Nhập ngày chốt kỳ >= ngày start của ngày kiểm kê dự kiến:
    if (!isValidInventoryPeriodDate && !flagPeriodDate) {
      return {
        success: false,
        message: 'error.INVENTORY_PERIOD_DATE_MUST_BE_PRIOR_START_DATE_EXECUTE',
      };
    }

    //Validate executeFrom and executeTo

    if (moment(executeExpectFrom).isAfter(futureDate)) {
      //Nhập ngày start của ngày kiểm kê dự kiến > (ngày hiện tại + 3 tháng)
      return {
        success: false,
        message: 'error.EXECUTE_FROM_NOT_EXCEED_THREE_MONTH',
      };
    } else if (moment(executeExpectTo).isAfter(futureDate)) {
      //Nhập ngày end của ngày kiểm kê dự kiến > (ngày hiện tại + 3 tháng):
      return {
        success: false,
        message: 'error.EXECUTE_END_NOT_EXCEED_THREE_MONTH',
      };
    } else if (moment(executeExpectFrom).isAfter(executeExpectTo)) {
      //Nhập ngày start của ngày kiểm kê dự kiến > ngày end của ngày kiểm kê dự kiến
      return {
        success: false,
        message: 'error.EXECUTE_START_MUST_BE_LESS_THAN_EXECUTE_END',
      };
    } else if (moment(executeExpectFrom).isBefore(moment())) {
      //Nhập ngày start của ngày kiểm kê dự kiến < ngày hiện tại:
      return {
        success: false,
        message: 'error.EXECUTE_START_MUST_BE_GREATER_NOW_DATE',
      };
    }
    return {
      success: true,
    };
  }

  public async getList(request: GetListTicketRequestDto): Promise<any> {
    const { data, count } = await this.ticketRepository.getList(
      request,
      TICKET_TYPE_ENUM.INVENTORY,
    );
    if (count === 0) {
      return new ResponseBuilder<PaginationResponse>({
        items: [],
        meta: { total: 0, page: 1 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    const impersonatorIds = uniq(map(flatMap(data, 'impersonators'), 'id'));

    const warehouseIds = uniq(map(flatMap(data, 'warehouses'), 'id'));

    const [serilizeUser, serializeWarehouse] = await Promise.all([
      this.userService.getUserByIds(impersonatorIds, true),
      this.warehouseService.getListByIDs(warehouseIds, true),
    ]);
    const inventoryResponseFormated = data.map((inventory) => {
      return {
        ...inventory,
        warehouses: inventory.warehouses?.map((warehouse) => {
          return {
            id: serializeWarehouse[warehouse.id]?.id,
            name: serializeWarehouse[warehouse.id]?.name,
            code: serializeWarehouse[warehouse.id]?.code,
          };
        }),
      };
    });
    const dataReturn = plainToInstance(
      InventoryResponseDto,
      inventoryResponseFormated,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PaginationResponse>({
      items: dataReturn,
      meta: {
        total: count,
        page: request.page,
      },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getDetail(request: GetDetailTicketRequestDto): Promise<any> {
    const { id } = request;
    const inventory = await this.ticketRepository.findOneById(id);
    if (!inventory) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.TICKET_NOT_FOUND'))
        .build();
    }
    const templateInventory = await this.attributeService.getTemplateById(
      inventory?.templateId,
    );
    if (!templateInventory) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.TEMPLATE_NOT_FOUND'))
        .build();
    }
    const templateResponse = await this.attributeService.getTemplateByCode(
      templateInventory?.code,
    );
    let impersonatorIds = [];
    let warehouseIds = [];
    const userIds = [inventory?.createdBy] || [];

    inventory.attributes.forEach((attributeValue) => {
      const { code, value } = attributeValue;
      switch (code) {
        case INVENTORY_FIELD_CODE.INVENTORY_IMPERSONATOR:
          if (value) impersonatorIds = value;
          break;
        case INVENTORY_FIELD_CODE.INVENTORY_WAREHOUSE_CODE:
          if (value) warehouseIds = value;
        default:
          break;
      }
    });
    const [serializedimpersonator, serializedUser, serializedWarehouse] =
      await Promise.all([
        this.userService.getUserByIds(impersonatorIds, true),
        this.userService.getUserByIds(userIds, true),
        this.warehouseService.getListByIDs(warehouseIds, true),
      ]);

    let beautifiedData = first(beautifyRequestOrder([inventory]));

    beautifiedData = {
      ...beautifiedData,
      [INVENTORY_FIELD_CODE.STATUS]: {
        value: beautifiedData.status,
      },
      [INVENTORY_FIELD_CODE.INVENTORY_CODE]: {
        value: beautifiedData?.code,
      },
      [INVENTORY_FIELD_CODE.INVENTORY_NAME]: {
        value: beautifiedData?.name,
      },
      [INVENTORY_FIELD_CODE.INVENTORY_WAREHOUSE_CODE]: {
        value: beautifiedData[
          INVENTORY_FIELD_CODE.INVENTORY_WAREHOUSE_CODE
        ]?.value?.map((warehouse) => {
          return {
            id: serializedWarehouse[warehouse]?.id,
            name: serializedWarehouse[warehouse]?.name,
            code: serializedWarehouse[warehouse]?.code,
          };
        }),
      },
      [INVENTORY_FIELD_CODE.INVENTORY_IMPERSONATOR]: {
        value: beautifiedData[
          INVENTORY_FIELD_CODE.INVENTORY_IMPERSONATOR
        ]?.value?.map((user) => {
          return {
            id: serializedimpersonator[user]?.id,
            fullName: serializedimpersonator[user]?.fullName,
            username: serializedimpersonator[user]?.username,
            code: serializedimpersonator[user]?.code,
          };
        }),
      },
      [INVENTORY_FIELD_CODE.CREATED_AT]: {
        value: inventory?.createdAt,
      },
      [INVENTORY_FIELD_CODE.CREATED_BY]: {
        value: {
          id: serializedUser[inventory.createdBy]?.id,
          code: serializedUser[inventory.createdBy]?.code,
          username: serializedUser[inventory.createdBy]?.username,
          fullName: serializedUser[inventory.createdBy]?.fullName,
        },
      },
      [INVENTORY_FIELD_CODE.WMSX_APPROVER]: {
        value: {
          id: serializedUser[inventory.confirmedBy]?.id,
          code: serializedUser[inventory.confirmedBy]?.code,
          username: serializedUser[inventory.confirmedBy]?.username,
          fullName: serializedUser[inventory.confirmedBy]?.fullName,
        },
      },
      [INVENTORY_FIELD_CODE.WMSX_APPROVED_AT]: {
        value: inventory?.confirmedAt,
      },
      [INVENTORY_FIELD_CODE.WMSX_COMPLETER]: {
        value: {
          id: serializedUser[inventory.completedBy]?.id,
          code: serializedUser[inventory.completedBy]?.code,
          username: serializedUser[inventory.completedBy]?.username,
          fullName: serializedUser[inventory.completedBy]?.fullName,
        },
      },
      [INVENTORY_FIELD_CODE.WMSX_COMPLETED_AT]: {
        value: inventory?.completedAt,
      },
    };

    const data = makeResponse(templateResponse, beautifiedData);
    const dataFomart = plainToInstance(
      TemplateResponse,
      {
        ...data,
        inventory: {
          ...inventory,
          id: inventory.id,
          code: inventory.code,
          name: inventory.name,
          createdBy: {
            id: serializedUser[inventory.createdBy]?.id,
            code: serializedUser[inventory.createdBy]?.code,
            username: serializedUser[inventory.createdBy]?.username,
            fullName: serializedUser[inventory.createdBy]?.fullName,
          },
        },
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataFomart)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async confirm(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const ticket = await this.ticketRepository.findOneById(id);
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (ticket.status !== InventoryStatusEnum.PENDING) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
        .build();
    }
    try {
      ticket.attributes.find(
        (attributeValue) => attributeValue.code === INVENTORY_FIELD_CODE.STATUS,
      ).value = InventoryStatusEnum.CONFIRMED;

      ticket.status = InventoryStatusEnum.CONFIRMED;
      ticket.confirmedBy = request.userId;
      ticket.confirmedAt = new Date();
      await this.ticketRepository.findByIdAndUpdate(id, ticket);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
  async reject(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const ticket = await this.ticketRepository.findOneById(id);
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (ticket.status !== InventoryStatusEnum.PENDING) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INVALID_STATUS)
        .withMessage(await this.i18n.translate('error.TICKET_INVALID_STATUS'))
        .build();
    }
    try {
      ticket.attributes.find(
        (attributeValue) => attributeValue.code === INVENTORY_FIELD_CODE.STATUS,
      ).value = InventoryStatusEnum.REJECT;

      ticket.status = InventoryStatusEnum.REJECT;
      await this.ticketRepository.findByIdAndUpdate(id, ticket);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async delete(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const inventoryDoc = await this.ticketRepository.findOneById(id);
    if (!inventoryDoc) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }
    if (!CAN_UPDATE_DELETE_INVENTORY.includes(inventoryDoc.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
        .build();
    }
    await this.ticketRepository.deleteById(id);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
