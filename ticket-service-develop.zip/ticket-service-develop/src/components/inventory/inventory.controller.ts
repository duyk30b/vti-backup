import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { GetDetailTicketRequestDto } from '@utils/dto/request/get-detail-ticket.request.dto';
import { GetListTicketRequestDto } from '@utils/dto/request/get-list-ticket.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { TicketResponseDto } from '@utils/dto/response/ticket.response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateInventoryRequestDto } from './dto/request/create-inventory.request.dto';
import { UpdateInventoryBodyRequestDto } from './dto/request/update-inventory.request.dto';
import { InventoryResponseDto } from './dto/response/inventory.response.dto';
import { InventoryServiceInterface } from './interfaces/inventory.service.interface';

@Controller('inventories')
export class InventoryController {
  constructor(
    @Inject('InventoryServiceInterface')
    private readonly inventoryService: InventoryServiceInterface,
  ) {}

  /**
   * Create new Receip Ticket
   * @param payload
   * @returns
   */
  @Post()
  @ApiOperation({
    tags: ['Inventory'],
    summary: 'Create the inventory',
    description: 'Create the inventory',
  })
  @ApiResponse({
    status: 200,
    description: 'Create the inventory successfully',
    type: TicketResponseDto,
  })
  public async create(@Body() body: CreateInventoryRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryService.create(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['Inventory'],
    summary: 'Cập nhật Inventory',
    description: 'Cập nhật Inventory',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamMongoDto,
    @Body() payload: UpdateInventoryBodyRequestDto,
  ): Promise<any> {
    const { request: requestParam, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryService.update({
      id: requestParam.id,
      ...request,
    });
  }

  @Get('')
  @ApiOperation({
    tags: ['Inventory'],
    summary: 'Get List Inventory',
    description: 'Danh sách lệnh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    type: GetListTicketRequestDto,
  })
  public async getList(
    @Query() payload: GetListTicketRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.inventoryService.getList(request);
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Inventory'],
    summary: 'Detail Inventory',
    description: 'Chi tiết lệnh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail Successfully',
    type: InventoryResponseDto,
  })
  public async getDetail(
    @Param() param: GetDetailTicketRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.inventoryService.getDetail(request);
  }

  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Inventory'],
    summary: 'Confirm Inventory',
    description: 'Xác nhận lênh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm Successfully',
    type: TicketResponseDto,
  })
  public async confirm(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryService.confirm({
      ...request,
    });
  }

  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Receipt Inventory'],
    summary: 'Reject Receipt Inventory',
    description: 'Từ chối lệnh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject Successfully',
    type: TicketResponseDto,
  })
  public async reject(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryService.reject({
      ...request,
    });
  }
  @Delete('/:id')
  @ApiOperation({
    tags: ['Receipt Inventory'],
    summary: 'Reject Receipt Inventory',
    description: 'Từ chối lệnh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject Successfully',
    type: TicketResponseDto,
  })
  public async deletye(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryService.delete({
      ...request,
    });
  }
}
