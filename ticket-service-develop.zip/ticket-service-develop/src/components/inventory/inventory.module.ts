import { AttributeService } from '@components/attribute/attribute.service';
import { ItemService } from '@components/item/item.service';
import { UserService } from '@components/user/user.service';
import { WarehouseLayoutService } from '@components/warehouse-layout/warehouse-layout.service';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { TicketDetailSchema } from 'src/models/ticket/ticket-details.schema';
import { TicketSchema } from 'src/models/ticket/ticket.schema';
import { TicketDetailRepository } from 'src/repository/ticket/ticket-detail.repository';
import { TicketRepository } from 'src/repository/ticket/ticket.repository';
import { InventoryController } from './inventory.controller';
import { InventoryService } from './inventory.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: 'Ticket',
        schema: TicketSchema,
      },
      {
        name: 'TicketDetail',
        schema: TicketDetailSchema,
      },
    ]),
  ],
  controllers: [InventoryController],
  providers: [
    {
      provide: 'InventoryServiceInterface',
      useClass: InventoryService,
    },
    {
      provide: 'TicketRepositoryInterface',
      useClass: TicketRepository,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'WarehouseLayoutServiceInterface',
      useClass: WarehouseLayoutService,
    },
    {
      provide: 'AttributeServiceInterface',
      useClass: AttributeService,
    },
    {
      provide: 'TicketDetailRepositoryInterface',
      useClass: TicketDetailRepository,
    },
  ],
})
export class InventoryModule {}
