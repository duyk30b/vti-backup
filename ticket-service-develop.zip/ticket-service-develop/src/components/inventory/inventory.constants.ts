export const InventoryFrefix = 'INVENTORY';
export enum InventoryTypeEnum {
  PERIODIC = 1, //Định kỳ
  SURPRISE = 2, //Đột xuất
}
export enum InventoryFormEnum {
  FORM_QUANTITY = 1,
  FORM_QUANTITY_LOT_MFG = 2,
  FORM_LOT = 3,
  FORM_MFG = 4,
}

export enum InventoryStatusEnum {
  PENDING = 0,
  CONFIRMED = 1,
  REJECT = 2,
  IN_PROGRESS = 3,
  APPROVE = 4,
  COMPLETE = 5,
}
export const INVENTORY_CODE_PREFIX = 'K';

export const INVENTORY_FIELD_CODE = {
  STATUS: 'wmsxStatus',
  INVENTORY_CODE: 'wmsxInvenCode',
  INVENTORY_NAME: 'wmsxInvenName',
  INVENTORY_TYPE: 'wmsxInvenType',
  INVENTORY_DATE_PERIOD: 'wmsxInvenDate',
  INVENTORY_WAREHOUSE_CODE: 'wmsxInvenWarehouse',
  INVENTORY_EXECUTE_FROM: 'wmsxInvenDateExpected',
  INVENTORY_EXECUTE_TO: 'wmsxInvenDateExpectedTo',
  INVENTORY_IMPERSONATOR: 'wmsxInvenUser',
  INVENTORY_BLOCK_TICKET: 'wmsxInvenBlockTIcket',
  WMSX_APPROVER: 'wmsxApprover', //Người xác nhận lệnh,
  WMSX_APPROVED_AT: 'wmsxApprovedAt', //Ngày xác nhận lệnh
  WMSX_COMPLETER: 'wmsxCompleter', //Nguoi hoan thanh lenh
  WMSX_COMPLETED_AT: 'wmsxCompletedAt', //Ngay hoan thanh lenh
  //end lenh kiem ke
  CREATED_AT: 'wmsxCreatedAt',
  CREATED_BY: 'wmsxCreatedBy',
  TEMPLATE_NAME: 'wmsxTemplateName',
  DEPARTMENT_SETTING: 'departmentCode',
  DESCRIPTION: 'wmsxGeneralDescription',
  WAREHOUSE_IMPORT_CODE: 'warehouseImportCode',
  WAREHOUSE_EXPORT_CODE: 'warehouseExportCode',
  ITEM_CODE: 'wmsxItemCode',
  ITEM_NAME: 'wmsxItemName',
  ITEM_UNIT_NAME: 'wmsxItemUnitName',
  ACTUAL_QUANTITY: 'wmsxQuantityActual',
  REQUEST_QUANTITY: 'wmsxQuantityRequest',
  REQUEST_USER_NOTE: 'wmsxUserNote',
  RECEIPT_DATE: 'wmsxCreateReceiptDate',
  REASON: 'wmsxReason',
  MFG_DATE: 'wmsxManufactureDate',
  PLANNING_QUANTITY: 'wmsxCustomerImport',
  GEN_PRICE: 'wmsxGeneralPrice',
  GEN_AMOUNT: 'wmsxGeneralAmount',
  LOT_NUMBER: 'wmsxLotNumber',
  REMAINING_QUANTITY: 'wmsxRemainingQuantity',
  LOCATOR: 'wmsxLocator',
  STORED_QUANTITY: 'wmsxStoredQuantity',
  ENTRY_QUANTITY: 'wmsxEntryQuantity',
  PO_CODE: 'wmsxPoCode',
  FILE: 'wmsxFile',
  REQUEST_PRICE: 'wmsxPrice',
};
export const CAN_UPDATE_DELETE_INVENTORY = [
  InventoryStatusEnum.REJECT,
  InventoryStatusEnum.PENDING,
];
