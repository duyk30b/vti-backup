import { GetDetailTicketRequestDto } from '@utils/dto/request/get-detail-ticket.request.dto';
import { GetListTicketRequestDto } from '@utils/dto/request/get-list-ticket.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { TicketServiceInterface } from '@utils/interface/ticket.service.interface';
import { CreateInventoryRequestDto } from '../dto/request/create-inventory.request.dto';
import { UpdateInventoryRequestDto } from '../dto/request/update-inventory.request.dto';

export interface InventoryServiceInterface {
  create(request: CreateInventoryRequestDto): Promise<any>;
  getList(request: GetListTicketRequestDto): Promise<any>;
  getDetail(request: GetDetailTicketRequestDto): Promise<any>;
  update(request: UpdateInventoryRequestDto): Promise<any>;
  confirm(request: IdParamMongoDto): Promise<any>;
  reject(request: IdParamMongoDto): Promise<any>;
  delete(request: IdParamMongoDto): Promise<any>;
}
