import { BaseUserResponseDto } from '@components/user/dto/response/base.user.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose, Type } from 'class-transformer';
class WarehouseResponse {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;
}

class Impersonator {
  @Expose()
  id: number;

  @Expose()
  username: string;

  @Expose()
  fullName: string;

  @Expose()
  code: string;
}
export class InventoryResponseDto extends BaseResponseDto {
  @Expose()
  id: string;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  inventoryType: string;

  @Expose()
  @Type(() => WarehouseResponse)
  warehouses: WarehouseResponse[];

  @Expose()
  @Type(() => Impersonator)
  impersonators: Impersonator[];

  @Expose()
  inventoryPeriodDate: Date;

  @Expose()
  executeExpectFrom: Date;

  @Expose()
  executeExpectTo: Date;

  @Expose()
  status: number;

  @Expose()
  createdBy: BaseUserResponseDto;
}
