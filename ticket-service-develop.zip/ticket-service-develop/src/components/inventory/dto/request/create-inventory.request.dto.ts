import {
  InventoryFormEnum,
  InventoryTypeEnum,
} from '@components/inventory/inventory.constants';
import { UNIT_CONST } from '@components/unit/unit.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsDateString,
  IsEnum,
  IsInt,
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { Types } from 'mongoose';
import { Attribute } from 'src/models/attribute/attribute.model';

class Impersonator {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}

class WarehouseRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
export class CreateInventoryRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsMongoId()
  templateId: Types.ObjectId;

  @ApiProperty()
  @IsOptional()
  @IsString()
  name: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  code: string;

  @ApiProperty()
  @IsOptional()
  type: number;

  @ApiProperty()
  @IsOptional()
  @IsEnum(InventoryTypeEnum)
  inventoryType: InventoryTypeEnum;

  @ApiProperty()
  @ValidateNested()
  @ArrayUnique((e: WarehouseRequest) => e.id)
  @IsArray()
  @ArrayNotEmpty()
  @Type(() => WarehouseRequest)
  warehouses: WarehouseRequest[];

  @ApiProperty()
  @IsOptional()
  @ValidateNested()
  @ArrayUnique((e: Impersonator) => e.id)
  @IsArray()
  @Type(() => Impersonator)
  impersonators: Impersonator[]; // Bỏ không dùng

  @ApiProperty()
  @IsDateString()
  inventoryPeriodDate: Date;

  //Ngày kiểm kê dự kiến
  @ApiProperty()
  @IsDateString()
  executeExpectFrom: Date;

  //Ngày kiểm kê dự kiến
  @ApiProperty()
  @IsDateString()
  executeExpectTo: Date;

  @ApiProperty()
  blockTicket: boolean;

  @ApiProperty()
  @IsEnum(InventoryFormEnum)
  inventoryForm: InventoryFormEnum;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @MaxLength(UNIT_CONST.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ApiProperty()
  @IsOptional()
  @Type(() => Attribute)
  attributes: Attribute[];
}
