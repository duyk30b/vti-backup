import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsMongoId } from 'class-validator';
import { CreateInventoryRequestDto } from './create-inventory.request.dto';

export class UpdateInventoryBodyRequestDto extends CreateInventoryRequestDto {}

export class UpdateInventoryRequestDto extends UpdateInventoryBodyRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
