import DatabaseConfigService from '@config/database.config';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { I18nJsonLoader, I18nModule } from 'nestjs-i18n';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { APP_GUARD, APP_PIPE } from '@nestjs/core';
import { ValidationPipe } from '@core/pipe/validator.pipe';
import { ScheduleModule } from '@nestjs/schedule';
import { QueryResolver } from './i18n/query-resolver';
import { BootModule } from '@nestcloud/boot';
import { BOOT, CONSUL } from '@nestcloud/common';
import { ConsulModule } from '@nestcloud/consul';
import { ServiceModule } from '@nestcloud/service';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { KongGatewayModule } from '@core/components/kong-gateway/kong-gateway.module';
import { AuthorizationGuard } from '@core/guards/authorization.guard';
import { BullModule } from '@nestjs/bull';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { UserModule } from '@components/user/user.module';
import { UnitModule } from '@components/unit/unit.module';
import { AuthModule } from '@components/auth/auth.module';
import * as path from 'path';
import { ManufacturingRequestModule } from '@components/manufacturing-request-order/manufacturing-request-order.module';
import { AttributeModule } from '@components/attribute/attribute.module';
import { ItemModule } from '@components/item/item.module';
import { ProduceModule } from '@components/produce/produce.module';
import { WarehouseRequestOrderModule } from '@components/warehouse-request-order/warehouse-request-order.module';
import { NatsClientModule } from '@core/transporter/nats-transporter/nats-client.module';
import { ItemStockPlanningModule } from '@components/item-stock-planning/item-stock-planning.module';
import { TicketModule } from '@components/ticket/ticket.module';
import { SaleModule } from '@components/sale-order/sale-order.module';
import { ManufacturingImportExportRequestModule } from '@components/manufacturing-import-export-request-order/manufacturing-import-export-request-order.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    I18nModule.forRoot({
      fallbackLanguage: 'vi',
      loader: I18nJsonLoader,
      loaderOptions: {
        path: path.join(__dirname, '/i18n/'),
        watch: true,
      },
      resolvers: [{ use: QueryResolver, options: ['lang', 'locale', 'l'] }],
    }),
    MongooseModule.forRootAsync({
      useClass: DatabaseConfigService,
    }),
    ScheduleModule.forRoot(),
    BootModule.forRoot({
      filePath: path.resolve(__dirname, '../config.yaml'),
    }),
    BullModule.forRoot({
      url: `redis://${process.env.REDIS_HOST}:${process.env.REDIS_PORT}`,
    }),
    EventEmitterModule.forRoot(),
    ConsulModule.forRootAsync({ inject: [BOOT] }),
    ServiceModule.forRootAsync({ inject: [BOOT, CONSUL] }),
    HttpClientModule,
    KongGatewayModule.forRootAsync(),
    AuthModule,
    UserModule,
    UnitModule,
    ItemModule,
    ProduceModule,
    AttributeModule,
    NatsClientModule,
    ItemStockPlanningModule,
    ManufacturingRequestModule,
    WarehouseRequestOrderModule,
    TicketModule,
    SaleModule,
    ManufacturingImportExportRequestModule,
  ],
  controllers: [AppController],
  providers: [
    {
      provide: APP_PIPE,
      useClass: ValidationPipe,
    },
    {
      provide: APP_GUARD,
      useClass: AuthorizationGuard,
    },
    AppService,
  ],
})
export class AppModule {}
