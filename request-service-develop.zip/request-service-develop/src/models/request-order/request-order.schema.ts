import { MANUFACTURING_REQUEST_ORDER_STATUS_ENUM } from '@components/manufacturing-request-order/manufacturing-request-order.constant';
import {
  REQUEST_ORDER_STATUS_ENUM,
  REQUEST_ORDER_TYPE_ENUM,
  REQUEST_ORDER_VALIDATE,
} from '@components/request-order/request-order.constant';
import { RESQUEST_EXPORT_IMPORT_STATUS } from '@components/warehouse-request-order/warehouse-request-order.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import * as mongoose from 'mongoose';

export const AttributeValueSchema = new mongoose.Schema({
  attributeId: {
    type: mongoose.Schema.Types.ObjectId,
  },
  code: {
    type: String,
  },
  value: {
    type: mongoose.Schema.Types.Mixed,
  },
});
export const RequestOrderSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      maxlength: REQUEST_ORDER_VALIDATE.CODE.MAX_LENGTH,
    },
    name: {
      type: String,
      maxlength: REQUEST_ORDER_VALIDATE.NAME.MAX_LENGTH,
    },
    templateId: {
      type: mongoose.Schema.Types.ObjectId,
    },
    description: {
      type: String,
    },
    createdBy: {
      type: Number,
    },
    type: {
      type: Number,
      enum: REQUEST_ORDER_TYPE_ENUM,
      required: true,
    },
    status: {
      type: Number,
      enum:
        MANUFACTURING_REQUEST_ORDER_STATUS_ENUM ||
        RESQUEST_EXPORT_IMPORT_STATUS,
      default: REQUEST_ORDER_STATUS_ENUM.PENDING,
    },
    attributeValues: {
      type: [AttributeValueSchema],
    },
    deletedAt: {
      type: Date,
      required: false,
      default: null,
    },
  },
  {
    collection: 'requestOrders',
    id: true,
    timestamps: true,
    collation: DEFAULT_COLLATION,
  },
);

RequestOrderSchema.virtual('requestOrderDetails', {
  ref: 'RequestOrderDetail',
  localField: '_id',
  foreignField: 'requestOrderId',
  justOne: false,
});
