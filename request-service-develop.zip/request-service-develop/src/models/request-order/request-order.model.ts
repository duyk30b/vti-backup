import { BaseModel } from '@core/model/base.model';

export interface AttributeValue {
  attributeId: string;
  code: string;
  value: any;
}

export interface RequestOrder extends BaseModel {
  name: string;
  code: string;
  templateId: string;
  type: number;
  description: string;
  createdBy: number;
  createdAt: Date;
  status: number;
  attributeValues: AttributeValue[];
  deletedAt: Date;
}
