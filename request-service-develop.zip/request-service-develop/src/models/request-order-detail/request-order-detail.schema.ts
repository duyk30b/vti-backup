import { REQUEST_ORDER_DETAIL_VALIDATE } from '@components/request-order/request-order.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import * as mongoose from 'mongoose';
import { AttributeValueSchema } from '../request-order/request-order.schema';

// const DetailAttributeValueSchema = new mongoose.Schema({
//   attributeId: {
//     type: mongoose.Schema.Types.ObjectId,
//   },
//   code: {
//     type: String,
//   },
//   value: {
//     type: mongoose.Schema.Types.Mixed,
//   },
// });
export const RequestOrderDetailSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      maxlength: REQUEST_ORDER_DETAIL_VALIDATE.CODE.MAX_LENGTH,
    },
    name: {
      type: String,
      maxlength: REQUEST_ORDER_DETAIL_VALIDATE.NAME.MAX_LENGTH,
    },
    templateId: {
      type: mongoose.Schema.Types.ObjectId,
    },
    requestOrderId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'RequestOrder',
    },
    description: {
      type: String,
    },
    createdBy: {
      type: Number,
    },
    executionDate: {
      type: Date,
    },
    groupId: {
      type: mongoose.Schema.Types.ObjectId,
    },
    attributeValues: {
      type: [AttributeValueSchema],
    },
  },
  {
    collection: 'requestOrderDetails',
    id: true,
    timestamps: true,
    collation: DEFAULT_COLLATION,
  },
);
