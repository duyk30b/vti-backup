import { BaseModel } from '@core/model/base.model';
import { AttributeValue } from '../request-order/request-order.model';

// interface DetailAttributeValue {
//   attributeId: string;
//   code: string;
//   value: string | number | boolean;
// }

export interface RequestOrderDetail extends BaseModel {
  itemId: number;
  quantity: number;
  actualQuantity: number;
  requestOrderId: string;
  groupId: string;
  attributeValues: AttributeValue[];
}
