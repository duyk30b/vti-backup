import { DEFAULT_COLLATION } from '@constant/common';
import * as mongoose from 'mongoose';

export const RequestOrderHoldedMaterialSChema = new mongoose.Schema(
  {
    itemId: {
      type: Number,
      required: true,
    },
    materialId: {
      type: Number,
      required: true,
    },
    requestOrderId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'HoldedItem',
    },
    holdedQuantity: {
      type: Number,
      default: null,
    },
  },
  {
    collection: 'requestOrderHoldedMaterials',
    id: true,
    timestamps: true,
    collation: DEFAULT_COLLATION,
  },
);

RequestOrderHoldedMaterialSChema.virtual('requestOrders', {
  ref: 'RequestOrderModel',
  localField: 'requestOrderId',
  foreignField: '_id',
  justOne: false,
});
