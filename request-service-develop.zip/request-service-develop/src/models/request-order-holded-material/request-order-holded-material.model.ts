import { BaseModel } from '@core/model/base.model';

export interface RequestOrderHoldedMaterialModel extends BaseModel {
  itemId: number;
  materialId: number;
  requestOrderId: string;
  holdedQuantity: number;
}
