export interface ItemStockPlanningServiceInterface {
  getHoldedItemList(ids: any): Promise<any>;
}
