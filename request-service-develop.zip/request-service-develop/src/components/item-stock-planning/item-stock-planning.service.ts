import { Inject, Injectable } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { firstValueFrom } from 'rxjs';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ItemStockPlanningServiceInterface } from './interface/item-stock-planning.service.interface';
import { NATS_ITEM_STOCK } from '@config/nats.config';

@Injectable()
export class ItemStockPlanningService
  implements ItemStockPlanningServiceInterface
{
  constructor(
    @Inject('ITEM_STOCK_PLANNING_SERVICE_CLIENT')
    private readonly itemStockPlanningServiceClient: ClientProxy,
  ) {}

  async getHoldedItemList(ids: any): Promise<any> {
    try {
      const response = await firstValueFrom(
        this.itemStockPlanningServiceClient.send(
          `${NATS_ITEM_STOCK}.get_holded_item_list`,
          {
            ids,
          },
        ),
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      return response.data;
    } catch (error) {
      return [];
    }
  }
}
