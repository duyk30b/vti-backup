import { Global, Module } from '@nestjs/common';
import { ConfigService } from '@config/config.service';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ItemStockPlanningService } from './item-stock-planning.service';

@Global()
@Module({
  imports: [HttpClientModule],
  exports: [
    'ITEM_STOCK_PLANNING_SERVICE_CLIENT',
    {
      provide: 'ItemStockPlanningServiceInterface',
      useClass: ItemStockPlanningService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'ITEM_STOCK_PLANNING_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const itemStockPlanningServiceOptions = configService.get(
          'itemStockPlanningService',
        );
        return ClientProxyFactory.create(itemStockPlanningServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'ItemStockPlanningServiceInterface',
      useClass: ItemStockPlanningService,
    },
  ],
  controllers: [],
})
export class ItemStockPlanningModule {}
