import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { isEmpty } from 'lodash';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateRequestOrderFormData } from '@components/request-order/dto/request/create-request-order.request.dto';
import { UpdateRequestOrderFormData } from '@components/request-order/dto/request/update-request-order.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { MessagePattern } from '@nestjs/microservices';
import { GetWarehouseOrderRequestListRequestDto } from './dto/request/get-warehouse-request-order-list.request.dto';
import { GetWarehouseRequestOrderDetailRequestDto } from './dto/request/get-warehouse-request-order-detail.request.dto';
import { WarehouseRequestOrderServiceInterface } from './interface/warehouse-request-order.service.interface';
import { SuccessResponse } from '@utils/success.response.dto';
import { RESQUEST_EXPORT_IMPORT_STATUS } from './warehouse-request-order.constant';
import { NATS_REQUEST } from '@config/nats.config';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';

@Controller('warehouse-request-orders')
export class WarehouseRequestOrderController {
  constructor(
    @Inject('WarehouseRequestOrderServiceInterface')
    private readonly warehouseRequestOrderService: WarehouseRequestOrderServiceInterface,
  ) {}

  @Post('')
  @ApiOperation({
    tags: ['Warehouse Request Order Import , export,transfer'],
    summary: 'Create Warehouse Request Order Import , export,transfer',
    description: 'Tạo yêu cầu nhập,xuât,chuyển',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  public async create(
    @Body() payload: CreateRequestOrderFormData,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseRequestOrderService.create(request);
  }

  @Put(':id')
  @ApiOperation({
    tags: ['Warehouse Request Order Import , export,transfer'],
    summary: 'Update Warehouse Request Order Import , export,transfer',
    description: 'Sửa yêu cầu nhập,xuât,chuyển',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async update(
    @Param() param: IdParamMongoDto,
    @Body() payload: UpdateRequestOrderFormData,
  ): Promise<any> {
    const { request: requestParam, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseRequestOrderService.update({
      ...request,
      data: {
        ...request.data,
        id: requestParam.id,
      },
    });
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Warehouse Request Order Import , export,transfer'],
    summary: 'Get Warehouse Request Order Import , export,transfer Detail',
    description: 'Chi tiết yêu cầu nhập,xuât,chuyển',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getDetailByTemplate(
    @Param() param: GetWarehouseRequestOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseRequestOrderService.getDetailByTemplate(request);
  }

  @Get('')
  @ApiOperation({
    tags: ['Warehouse Request Order Import , export,transfer'],
    summary: 'Get Warehouse Request Order Import , export,transfer List',
    description: 'Danh sách yêu cầu nhập,xuât,chuyển',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getList(
    @Query() query: GetWarehouseOrderRequestListRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseRequestOrderService.getList(request);
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['Warehouse Request Order Import , export,transfer'],
    summary: 'Delete Warehouse Request Order Import , export,transfer',
    description: 'Xóa yêu cầu nhập,xuât,chuyển',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
  })
  public async delete(@Param() Param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = Param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseRequestOrderService.delete(request);
  }

  @Put(':id/confirm')
  @ApiOperation({
    tags: ['Request', 'Warehouse Request Order Import , export,transfer'],
    summary: 'Confirm Warehouse Request Order Import , export,transfer',
    description: 'Xác nhận yêu cầu nhập,xuât,chuyển',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
  })
  public async confirm(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseRequestOrderService.confirm({
      ...request,
    });
  }

  @Put(':id/reject')
  @ApiOperation({
    tags: ['Request', 'Warehouse Request Order Import , export,transfer'],
    summary: 'Reject Warehouse Request Order Import , export,transfer',
    description: 'Từ chối yêu cầu nhập,xuât,chuyển',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
  })
  public async reject(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseRequestOrderService.reject({
      ...request,
    });
  }
  @Put('/:id/close')
  @ApiOperation({
    tags: ['Request'],
    summary: 'Cloese Request',
    description: 'Cloese Request',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async close(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseRequestOrderService.updateStatus({
      ...request,
      status: RESQUEST_EXPORT_IMPORT_STATUS.COMPLETED,
    });
  }

  @MessagePattern(`${NATS_REQUEST}.update_status_warehouse_request`)
  async updateStatusRequest(
    @Body() body: UpdateActiveStatusPayload,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseRequestOrderService.updateStatus({
      ...request,
      status: request.status,
    });
  }

  @MessagePattern(`${NATS_REQUEST}.get_warehouse_request_order_import`)
  @ApiOperation({
    tags: ['Item'],
    summary: 'Get list item detail',
    description: 'Danh sách chi tiết',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  @Post('test')
  public async getDetail(
    @Body() body: GetWarehouseRequestOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseRequestOrderService.getDetail(request);
  }

  @MessagePattern(`${NATS_REQUEST}.get_list_request_warehouse_order_by_ids`)
  public async getListRequestImport(
    @Body() query: GetWarehouseOrderRequestListRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseRequestOrderService.getList(request);
  }
}
