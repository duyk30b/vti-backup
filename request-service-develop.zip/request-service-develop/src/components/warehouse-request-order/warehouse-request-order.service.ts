import { Inject, Injectable } from '@nestjs/common';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import {
  AttributeValue,
  RequestOrder,
} from 'src/models/request-order/request-order.model';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { RequestOrderRepositoryInterface } from '@components/request-order/interface/request-order.repository.interface';
import { RequestOrderDetailRepositoryInterface } from '@components/request-order/interface/request-order-detail.repository.interface.ts';
import { CreateRequestOrderFormData } from '@components/request-order/dto/request/create-request-order.request.dto';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { AttributeServiceInterface } from '@components/attribute/interface/attribute.service.interface';
import { RequestOrderServiceAbstract } from '@components/request-order/request-order.service.abstract';
import { InjectConnection } from '@nestjs/mongoose';
import * as mongoose from 'mongoose';
import {
  WAREHOUSE_REQUEST_ORDER_DETAIL_TEMPLATE_CODE,
  WAREHOUSE_REQUEST_ORDER_FIELD_CODE,
  WAREHOUSE_REQUEST_STATUS_CAN_REJECT,
  RESQUEST_EXPORT_IMPORT_STATUS,
  WAREHOUSE_REQUEST_ORDER_CONST,
  CAN_UPDATE_REQUEST,
} from './warehouse-request-order.constant';
import {
  isEmpty,
  map,
  uniq,
  filter,
  isEqual,
  flatMap,
  keyBy,
  first,
  compact,
  fromPairs,
} from 'lodash';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { GetManufacturingRequestOrderDetailResponseDto } from './dto/response/get-warehouse-request-order-detail.response.dto';
import { ApiError } from '@utils/api.error';
import { GetManufacturingRequestOrderListResponseDto } from './dto/response/get-warehouse-request-order-list.response.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { GetWarehouseRequestOrderDetailRequestDto } from './dto/request/get-warehouse-request-order-detail.request.dto';
import { GetWarehouseOrderRequestListRequestDto } from './dto/request/get-warehouse-request-order-list.request.dto';
import { WarehouseRequestOrderServiceInterface } from './interface/warehouse-request-order.service.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import * as Moment from 'moment';
import { getRegexByValue, minus } from '@utils/common';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { REQUEST_ORDER_TYPE_ENUM } from '@components/request-order/request-order.constant';
import { TicketServiceInterface } from '@components/ticket/interface/ticket.service.interface';
import { GetRequestByIdsRequestDto } from './dto/request/get-request-by-ids.request.dto';
import { arrayToObject } from '@constant/common';
import { plus } from '@utils/helper';

@Injectable()
export class WarehouseRequestOrderService
  extends RequestOrderServiceAbstract
  implements WarehouseRequestOrderServiceInterface
{
  constructor(
    @Inject('RequestOrderRepositoryInterface')
    protected readonly requestOrderRepository: RequestOrderRepositoryInterface,

    @Inject('AttributeServiceInterface')
    protected readonly attributeService: AttributeServiceInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('TicketServiceInterface')
    protected readonly ticketService: TicketServiceInterface,

    @Inject('ProduceServiceInterface')
    protected readonly produceService: ProduceServiceInterface,

    @Inject('RequestOrderDetailRepositoryInterface')
    protected readonly requestOrderDetailRepository: RequestOrderDetailRepositoryInterface,

    protected readonly i18n: I18nRequestScopeService,

    @InjectConnection()
    protected readonly connection: mongoose.Connection,
  ) {
    super(
      userService,
      requestOrderRepository,
      requestOrderDetailRepository,
      attributeService,
      i18n,
      connection,
    );
  }
  private async generateCodeWarehouseRequestOrder(type?: number) {
    const currentDate = Moment().utcOffset(7).format('DDMMYYYY');
    const lastWarehouseRequestOrderInDay =
      await this.requestOrderRepository.getLastWarehouseRequestOrderByGenerateCode(
        currentDate,
        type,
      );
    let generateCode;
    let prefixCodeDefault;
    switch (type) {
      case REQUEST_ORDER_TYPE_ENUM.WMSX_YCN:
        prefixCodeDefault =
          WAREHOUSE_REQUEST_ORDER_CONST.CODE_YN.PREFIX_CODE_DEFAULT;
        break;
      case REQUEST_ORDER_TYPE_ENUM.WMSX_YCX:
        prefixCodeDefault =
          WAREHOUSE_REQUEST_ORDER_CONST.CODE_YX.PREFIX_CODE_DEFAULT;
        break;
      case REQUEST_ORDER_TYPE_ENUM.WMSX_YCC:
        prefixCodeDefault =
          WAREHOUSE_REQUEST_ORDER_CONST.CODE_YC.PREFIX_CODE_DEFAULT;
        break;
      default:
        break;
    }

    if (!isEmpty(lastWarehouseRequestOrderInDay)) {
      const lastIncreaseId = Number(
        lastWarehouseRequestOrderInDay.code.slice(-3),
      );
      const newIncreaseId = lastIncreaseId + 1;
      generateCode = `${prefixCodeDefault}${currentDate}${newIncreaseId
        .toString()
        .padStart(3, '0')}`;
    } else {
      return `${prefixCodeDefault}${currentDate}000`;
    }

    return generateCode;
  }
  async save(
    requestOrderEntity: RequestOrder,
    payload: CreateRequestOrderFormData,
    attributeRequests: any,
    isUpdate?: boolean,
  ): Promise<any> {
    const { data } = payload;
    const { attributeValues, requestOrderDetails } = data;
    const concatnatedAttributeValues = [
      ...attributeValues,
      ...flatMap(requestOrderDetails, (i) => i.attributeValues),
    ] as any[];

    const [
      departmentSettings,
      warehouseImportIds,
      warehouseExportIds,
      itemIds,
    ] = this.getValueOfAttributesByCode(concatnatedAttributeValues, [
      WAREHOUSE_REQUEST_ORDER_FIELD_CODE.DEPARTMENT_SETTING,
      WAREHOUSE_REQUEST_ORDER_FIELD_CODE.WAREHOUSE_IMPORT_CODE,
      WAREHOUSE_REQUEST_ORDER_FIELD_CODE.WAREHOUSE_EXPORT_CODE,
      WAREHOUSE_REQUEST_ORDER_FIELD_CODE.ITEM_CODE,
    ]);
    const warehouseIds = [...warehouseImportIds, ...warehouseExportIds];
    if (!isEmpty(compact(warehouseIds))) {
      const warehouseRes = await this.warehouseService.getListByIDs(
        warehouseIds,
      );
      if (isEmpty(warehouseRes)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
          .build();
      }
    }
    const checkedResult = await this.checkExistance({
      departmentSettings,
      itemIds,
    });
    if (checkedResult.statusCode !== ResponseCodeEnum.SUCCESS) {
      return checkedResult;
    }
    if (!isUpdate) {
      requestOrderEntity.code = await this.generateCodeWarehouseRequestOrder(
        data?.type,
      );
      requestOrderEntity.attributeValues.find(
        (attributeValue) =>
          attributeValue.code === WAREHOUSE_REQUEST_ORDER_FIELD_CODE.STATUS,
      ).value = RESQUEST_EXPORT_IMPORT_STATUS.PENDING;
    }
    if (isUpdate) {
      const statusAttribute = requestOrderEntity.attributeValues.find(
        (attributeValue) =>
          attributeValue.code === WAREHOUSE_REQUEST_ORDER_FIELD_CODE.STATUS,
      );
      const status = statusAttribute ? +statusAttribute.value : null;
      //Validate trạng thái
      if (!CAN_UPDATE_REQUEST.includes(status)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
          .build();
      }
      if (status === RESQUEST_EXPORT_IMPORT_STATUS.REJECTED) {
        requestOrderEntity.attributeValues.find(
          (attributeValue) =>
            attributeValue.code == WAREHOUSE_REQUEST_ORDER_FIELD_CODE.STATUS,
        ).value = RESQUEST_EXPORT_IMPORT_STATUS.PENDING;
      }
    }
    return super.save(requestOrderEntity, payload, attributeRequests, isUpdate);
  }

  async getDetail(
    request: GetWarehouseRequestOrderDetailRequestDto,
  ): Promise<any> {
    const { id } = request;
    const data = await this.requestOrderRepository.getDetail(id);
    if (!data) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const concatnatedAttributeValues = [
      ...data.attributeValues,
      ...flatMap(data.requestOrderDetails, (i) => {
        return i.attributeValues;
      }),
    ];
    const [userIds, itemIds] = this.getValueOfAttributesByCode(
      concatnatedAttributeValues,
      [WAREHOUSE_REQUEST_ORDER_FIELD_CODE.ITEM_CODE],
    );
    const [serializedUser, serializedItem] = await Promise.all([
      this.userService.getUsersByIds(userIds, true),
      this.itemService.getItemByIds(itemIds, true),
    ]);

    const beautifiedData = first(this.beautifyRequestOrder([data]));

    const resData = plainToInstance(
      GetManufacturingRequestOrderDetailResponseDto,
      { ...beautifiedData },
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(resData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDetailByTemplate(
    request: GetWarehouseRequestOrderDetailRequestDto,
  ): Promise<any> {
    const { id } = request;
    const data = await this.requestOrderRepository.getDetail(id);
    if (!data) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const templateResponse = await this.attributeService.getTemplateById(
      data.templateId,
    );
    const template = await this.attributeService.getTemplateByCode(
      templateResponse.code,
    );
    if (!template) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.TEMPLATE_NOT_FOUND'))
        .build();
    }
    const concatnatedAttributeValues = [
      ...data.attributeValues,
      ...flatMap(data.requestOrderDetails, (i) => {
        return i.attributeValues;
      }),
    ];
    const userIds = [data?.createdBy] || [];
    const requestIds = [data._id.toString()];
    const ticketRes = await this.ticketService.getTicketReceiptByCondition(
      requestIds,
    );
    const requestOrderDetailsAttributes = map(
      data.requestOrderDetails,
      'attributeValues',
    );
    const ticketReceiptDetail = map(flatMap(ticketRes, 'ticketDetails'));
    const ticketReceiptDetailAttributes = map(
      ticketReceiptDetail,
      'attributes',
    );
    // Use forEach to convert each array in the mainArray to an object
    const ticketDetailsFormat = [];
    const warehouseRequestAttributeFormat = [];
    ticketReceiptDetailAttributes.forEach((array) => {
      const obj = arrayToObject(array);
      ticketDetailsFormat.push(obj);
    });
    requestOrderDetailsAttributes.forEach((array) => {
      const obj = arrayToObject(array);
      warehouseRequestAttributeFormat.push(obj);
    });
    const warehouseRequestAttributeFormatKeyBy = keyBy(
      warehouseRequestAttributeFormat,
      (e) => e.wmsxItemCode,
    );
    const ticketDetailsFormatKeyBy = keyBy(
      ticketDetailsFormat,
      (e) => e.wmsxItemCode,
    );
    const sumByPlanningQuantityTicket = {};
    // Use forEach to iterate through the dataArray and calculate the sum
    ticketDetailsFormat.forEach((item) => {
      const itemId = item.wmsxItemCode;
      if (!isNaN(item.wmsxCustomerImport)) {
        if (sumByPlanningQuantityTicket[itemId]) {
          sumByPlanningQuantityTicket[itemId] = plus(
            item.wmsxCustomerImport,
            sumByPlanningQuantityTicket[itemId],
          );
        } else {
          sumByPlanningQuantityTicket[itemId] = item.wmsxCustomerImport;
        }
      }
    });
    const [
      itemIds,
      departmentSettingIds,
      warehouseImportIds,
      warehoouseExportIds,
    ] = this.getValueOfAttributesByCode(concatnatedAttributeValues, [
      WAREHOUSE_REQUEST_ORDER_FIELD_CODE.ITEM_CODE,
      WAREHOUSE_REQUEST_ORDER_FIELD_CODE.DEPARTMENT_SETTING,
      WAREHOUSE_REQUEST_ORDER_FIELD_CODE.WAREHOUSE_IMPORT_CODE,
      WAREHOUSE_REQUEST_ORDER_FIELD_CODE.WAREHOUSE_EXPORT_CODE,
    ]);
    const warehouseIds = [...warehoouseExportIds, ...warehouseImportIds];
    const [
      serializedUser,
      serializedItem,
      serializedDepartment,
      serilizedWarehouse,
    ] = await Promise.all([
      this.userService.getUsersByIds(userIds, true),
      this.itemService.getItemByIds(itemIds, true),
      this.userService.getDepartmentSettingByIds(departmentSettingIds, true),
      this.warehouseService.getListByIDs(warehouseIds, true),
    ]);
    let beautifiedData = first(this.beautifyRequestOrder([data]));
    beautifiedData = {
      ...beautifiedData,
      [WAREHOUSE_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.CODE]: {
        value: beautifiedData?.code,
      },
      [WAREHOUSE_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.TEMPLATE_CODE]: {
        value: {
          id: templateResponse._id,
          name: templateResponse.name,
          code: templateResponse.code,
        },
      },
      [WAREHOUSE_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.CREATED_AT]: {
        value: data?.createdAt,
      },
      [WAREHOUSE_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.CREATED_BY]: {
        value: serializedUser[data?.createdBy],
      },
      [WAREHOUSE_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.STATUS]: {
        value: beautifiedData.status,
      },
      [WAREHOUSE_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.WAREHOUSE_IMPORT_CODE]: {
        value:
          serilizedWarehouse[
            beautifiedData[
              WAREHOUSE_REQUEST_ORDER_FIELD_CODE.WAREHOUSE_IMPORT_CODE
            ]?.value
          ],
      },
      [WAREHOUSE_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.WAREHOUSE_EXPORT_CODE]: {
        value:
          serilizedWarehouse[
            beautifiedData[
              WAREHOUSE_REQUEST_ORDER_FIELD_CODE.WAREHOUSE_EXPORT_CODE
            ]?.value
          ],
      },
      [WAREHOUSE_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.DEPARTMENT_CODE]: {
        value:
          serializedDepartment[
            beautifiedData[
              WAREHOUSE_REQUEST_ORDER_FIELD_CODE.DEPARTMENT_SETTING
            ]?.value
          ],
      },
      requestOrderDetails: beautifiedData.requestOrderDetails?.map((i) => {
        const key = i?.wmsxItemCode?.value;
        return {
          ...i,
          [WAREHOUSE_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.DETAIL.ITEM_NAME]: {
            value:
              serializedItem[
                i[WAREHOUSE_REQUEST_ORDER_FIELD_CODE.ITEM_CODE]?.value
              ]?.name,
          },
          [WAREHOUSE_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.DETAIL.ITEM_CODE]: {
            value:
              serializedItem[
                i[WAREHOUSE_REQUEST_ORDER_FIELD_CODE.ITEM_CODE]?.value
              ],
          },
          [WAREHOUSE_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.DETAIL.ITEM_UNIT_NAME]:
            {
              value:
                serializedItem[
                  i[WAREHOUSE_REQUEST_ORDER_FIELD_CODE.ITEM_CODE]?.value
                ]?.itemUnit,
            },
          [WAREHOUSE_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.DETAIL
            .REMAINNING_QUANTITY_REQUEST]: {
            value:
              minus(
                +warehouseRequestAttributeFormatKeyBy[key]
                  ?.wmsxQuantityRequest || 0,
                +sumByPlanningQuantityTicket[key] || 0,
              ) > 0
                ? minus(
                    +warehouseRequestAttributeFormatKeyBy[key]
                      ?.wmsxQuantityRequest || 0,
                    +sumByPlanningQuantityTicket[key] || 0,
                  )
                : 0,
          },
        };
      }),
    };
    return this.makeResponse(template, beautifiedData);
  }

  async getList(request: GetWarehouseOrderRequestListRequestDto): Promise<any> {
    const { filter } = request;
    let filterObj = {};
    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: getRegexByValue(value),
            };
            break;
          case 'status':
            filterObj = {
              ...filterObj,
              status: {
                $in: item.text?.split(',')?.map((e) => +e),
              },
            };
            break;
          case 'templateId':
            filterObj = {
              ...filterObj,
              templateId: {
                $in: item.text
                  .split(',')
                  ?.map((e) => new mongoose.Types.ObjectId(e)),
              },
            };
            break;
          case 'requestIds':
            filterObj = {
              ...filterObj,
              _id: {
                $in: item.text
                  .split(',')
                  ?.map((e) => new mongoose.Types.ObjectId(e)),
              },
            };
            break;
          case 'createdBy':
            filterObj = {
              ...filterObj,
              createdBy: value,
            };
            break;
          default:
            break;
        }
      });
    }
    request.filterObj = filterObj;
    const { data, count } = await this.requestOrderRepository.getList(request);
    const userIds = map(data, 'createdBy');
    const requestIds = map(data, '_id');
    const [serializedUser, serializedTicket] = await Promise.all([
      this.userService.getUsersByIds(userIds, true),
      this.ticketService.getTicketsByRequestIds(requestIds, true),
    ]);
    const result = plainToInstance(
      GetManufacturingRequestOrderListResponseDto,
      data.map((item) => {
        return {
          ...item,
          createdBy: serializedUser[item.createdBy],
          requestSource: serializedTicket[item._id],
        };
      }),
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder({
      items: result,
      meta: count,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async delete(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const warehouseRequestOrder =
      await this.requestOrderRepository.findOneByCondition(id);
    if (!warehouseRequestOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }
    await this.requestOrderRepository.deleteById(id);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const warehouseRequestOrder = await this.requestOrderRepository.findOneById(
      id,
    );
    if (!warehouseRequestOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    const dataSave = await this.requestOrderRepository.findByIdAndUpdate(id, {
      $set: { status: status },
    });
    return new ResponseBuilder(dataSave)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  async confirm(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const warehouseRequestOrder = await this.requestOrderRepository.findOneById(
      id,
    );
    if (!warehouseRequestOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (
      !WAREHOUSE_REQUEST_STATUS_CAN_REJECT.includes(
        warehouseRequestOrder.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.WAREHOUSE_REQUEST_ORDER_STATUS_INVALID',
          ),
        )
        .build();
    }
    try {
      warehouseRequestOrder.attributeValues.find(
        (attributeValue) =>
          attributeValue.code === WAREHOUSE_REQUEST_ORDER_FIELD_CODE.STATUS,
      ).value = RESQUEST_EXPORT_IMPORT_STATUS.CONFIRM;

      warehouseRequestOrder.status = RESQUEST_EXPORT_IMPORT_STATUS.CONFIRM;
      await this.requestOrderRepository.findByIdAndUpdate(
        id,
        warehouseRequestOrder,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async reject(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const warehouseRequestOrder = await this.requestOrderRepository.findOneById(
      id,
    );
    if (!warehouseRequestOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (
      !WAREHOUSE_REQUEST_STATUS_CAN_REJECT.includes(
        warehouseRequestOrder.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.WAREHOUSE_REQUEST_ORDER_STATUS_INVALID',
          ),
        )
        .build();
    }

    try {
      warehouseRequestOrder.attributeValues.find(
        (attributeValue) =>
          attributeValue.code === WAREHOUSE_REQUEST_ORDER_FIELD_CODE.STATUS,
      ).value = RESQUEST_EXPORT_IMPORT_STATUS.REJECTED;

      warehouseRequestOrder.status = RESQUEST_EXPORT_IMPORT_STATUS.REJECTED;
      await this.requestOrderRepository.findByIdAndUpdate(
        id,
        warehouseRequestOrder,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  // assign value to attribute template
  private makeResponse(template: any, beautifiedData: any) {
    let { attributeHeaders, attributeGroups } = template;
    attributeHeaders = attributeHeaders.map((attributeHeader) => {
      return {
        ...attributeHeader,
        attribute: {
          ...attributeHeader.attribute,
          value: beautifiedData[attributeHeader.attribute?.code]?.value,
        },
      };
    });
    const requestOrderDetails = beautifiedData.requestOrderDetails;
    attributeGroups = attributeGroups.map((attributeGroup) => {
      return compact(
        requestOrderDetails.map((requestOrderDetail) => {
          if (
            isEqual(
              requestOrderDetail.groupId.toString(),
              attributeGroup.attributes[0].attributeGroup.id.toString(),
            )
          ) {
            const attributes = attributeGroup.attributes.map((attribute) => {
              return {
                ...attribute,
                attribute: {
                  ...attribute.attribute,
                  value: requestOrderDetail[attribute.attribute?.code]?.value,
                },
              };
            });
            return { ...attributeGroup, attributes };
          }
          return;
        }),
      );
    });
    const dataReturn = {
      ...template,
      attributeHeaders,
      attributeGroups: attributeGroups,
    };
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private beautifyRequestOrder(data: any[]): any[] {
    return data.map((requestOrder) => {
      const generalInfo = keyBy(
        requestOrder.attributeValues.map((attributeValue) => {
          return { key: attributeValue.code, value: attributeValue.value };
        }),
        'key',
      );

      let requestOrderDetails = requestOrder.requestOrderDetails;
      if (!isEmpty(requestOrderDetails)) {
        requestOrderDetails = requestOrderDetails.map((requestOrderDetail) => {
          const generalInfo = keyBy(
            requestOrderDetail.attributeValues.map((attributeValue) => {
              return { key: attributeValue.code, value: attributeValue.value };
            }),
            'key',
          );
          return { ...requestOrderDetail, ...generalInfo };
        });
      }
      return { ...requestOrder, ...generalInfo, requestOrderDetails };
    });
  }

  private getValueOfAttributesByCode(
    attributeValues: AttributeValue[],
    codes: string[],
    isNotNumber?: boolean,
  ): any[] {
    return codes.map((code) => {
      return uniq(
        map(
          filter(
            attributeValues,
            (attributeValue) => attributeValue.code === code,
          ),
          (i) => {
            if (isNotNumber) {
              return i.value;
            }
            return +i.value;
          },
        ),
      );
    });
  }

  private async checkExistance(data: any): Promise<ResponsePayload<any>> {
    const { id, departmentSettingIds, itemIds, userIds } = data;
    switch (true) {
      case id && isEmpty(await this.requestOrderRepository.findOneById(id)):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      case itemIds &&
        !isEqual(
          (await this.itemService.getItemByIds(itemIds)).length,
          itemIds.length,
        ):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.ITEM_NOT_FOUND'))
          .build();
      case departmentSettingIds &&
        !isEqual(
          (
            await this.userService.getDepartmentSettingByIds(
              departmentSettingIds,
            )
          ).length,
          departmentSettingIds.length,
        ):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.DEPARTMENT_SETTING_NOT_FOUND'),
          )
          .build();
      case userIds &&
        !isEqual(
          (await this.userService.getUsersByIds(userIds)).length,
          userIds.length,
        ):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.USER_NOT_FOUND'))
          .build();
      default:
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
    }
  }
}
