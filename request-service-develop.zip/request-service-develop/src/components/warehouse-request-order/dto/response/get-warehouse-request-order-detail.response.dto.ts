import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class ItemResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => BaseResponseDto)
  itemUnit: BaseResponseDto;
}

class UserResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  fullName: string;
}

class ManufacturingRequestOrderDetailResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => BaseResponseDto)
  bomVersion: BaseResponseDto;

  @Expose()
  quantity: number;

  @Expose()
  actualQuantity: number;
}

export class GetManufacturingRequestOrderDetailResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  requestDate: Date;

  @ApiProperty()
  @Expose()
  deadline: Date;

  @ApiProperty()
  @Expose()
  @Type(() => UserResponseDto)
  requester: UserResponseDto;

  @ApiProperty()
  @Expose()
  note: string;

  @ApiProperty()
  @Type(() => ManufacturingRequestOrderDetailResponseDto)
  @Expose()
  requestOrderDetails: ManufacturingRequestOrderDetailResponseDto[];
}
