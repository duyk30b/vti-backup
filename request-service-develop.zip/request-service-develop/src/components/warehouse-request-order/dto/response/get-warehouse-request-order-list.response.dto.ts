import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class UserResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  fullName: string;

  @ApiProperty()
  @Expose()
  username: string;
}
class TicketResponseDto extends BaseResponseDto {}

export class GetManufacturingRequestOrderListResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  requestDate: Date;

  @ApiProperty()
  @Expose()
  @Type(() => UserResponseDto)
  requester: UserResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => TicketResponseDto)
  requestSource: TicketResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => UserResponseDto)
  createdBy: UserResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => UserResponseDto)
  approver: UserResponseDto;

  @ApiProperty()
  @Expose()
  note: string;
}
