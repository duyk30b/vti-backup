import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray } from 'class-validator';

export class GetRequestByIdsRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsArray()
  requestIds: string[];
}
