import { GetRequestOrderListRequestDto } from '@components/request-order/dto/request/get-request-order-list.request.dto';

export class GetWarehouseOrderRequestListRequestDto extends GetRequestOrderListRequestDto {}
