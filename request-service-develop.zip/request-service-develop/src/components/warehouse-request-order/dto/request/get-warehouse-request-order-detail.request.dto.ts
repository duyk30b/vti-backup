import { GetRequestOrderDetailRequestDto } from '@components/request-order/dto/request/get-request-order-detail.request.dto';

export class GetWarehouseRequestOrderDetailRequestDto extends GetRequestOrderDetailRequestDto {}
