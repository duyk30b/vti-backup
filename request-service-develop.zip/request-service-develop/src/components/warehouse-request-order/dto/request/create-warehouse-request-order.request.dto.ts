import { CreateRequestOrderFormData } from '@components/request-order/dto/request/create-request-order.request.dto';

export class CreateWarehouseRequestOrdertDto extends CreateRequestOrderFormData {}
