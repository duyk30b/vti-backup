import { CreateRequestOrderFormData } from '@components/request-order/dto/request/create-request-order.request.dto';
import { UpdateRequestOrderFormData } from '@components/request-order/dto/request/update-request-order.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { GetWarehouseRequestOrderDetailRequestDto } from '../dto/request/get-warehouse-request-order-detail.request.dto';
import { GetWarehouseOrderRequestListRequestDto } from '../dto/request/get-warehouse-request-order-list.request.dto';

export interface WarehouseRequestOrderServiceInterface {
  create(request: CreateRequestOrderFormData): Promise<any>;
  update(request: UpdateRequestOrderFormData): Promise<any>;
  getDetailByTemplate(
    request: GetWarehouseRequestOrderDetailRequestDto,
  ): Promise<any>;
  getDetail(request: GetWarehouseRequestOrderDetailRequestDto): Promise<any>;
  getList(request: GetWarehouseOrderRequestListRequestDto): Promise<any>;
  delete(request: any): Promise<any>;
  confirm(request: IdParamMongoDto): Promise<any>;
  reject(request: IdParamMongoDto): Promise<any>;
  updateStatus(request: UpdateActiveStatusPayload): Promise<any>;
}
