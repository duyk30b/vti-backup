import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { RequestOrderSchema } from 'src/models/request-order/request-order.schema';
import { RequestOrderDetailSchema } from 'src/models/request-order-detail/request-order-detail.schema';
import { RequestOrderRepository } from 'src/repository/request-order/request-order.repository';
import { AttributeService } from '@components/attribute/attribute.service';
import { ItemService } from '@components/item/item.service';
import { UserService } from '@components/user/user.service';
import { ProduceService } from '@components/produce/produce.service';
import { RequestOrderDetailRepository } from 'src/repository/request-order-detail/request-order-detail.repository';
import { WarehouseRequestOrderController } from './warehouse-request-order.controller';
import { WarehouseRequestOrderService } from './warehouse-request-order.service';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { TicketService } from '@components/ticket/ticket.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'RequestOrder', schema: RequestOrderSchema },
      { name: 'RequestOrderDetail', schema: RequestOrderDetailSchema },
    ]),
    WarehouseModule,
  ],
  controllers: [WarehouseRequestOrderController],
  providers: [
    {
      provide: 'WarehouseRequestOrderServiceInterface',
      useClass: WarehouseRequestOrderService,
    },
    {
      provide: 'RequestOrderRepositoryInterface',
      useClass: RequestOrderRepository,
    },
    {
      provide: 'AttributeServiceInterface',
      useClass: AttributeService,
    },
    {
      provide: 'RequestOrderDetailRepositoryInterface',
      useClass: RequestOrderDetailRepository,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'TicketServiceInterface',
      useClass: TicketService,
    },
    {
      provide: 'ProduceServiceInterface',
      useClass: ProduceService,
    },
  ],
  exports: [],
})
export class WarehouseRequestOrderModule {}
