import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsBoolean,
  IsDateString,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Length,
  Min,
  ValidateNested,
} from 'class-validator';

class PrODraftItemRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  warehouseId?: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  quantity: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsBoolean()
  qcCheck: boolean;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  qcCriteriaId?: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  lotNumber?: string;
}

export class CreateProductionOrderDraftRequestDto {
  @ApiProperty()
  @ArrayUnique<PrODraftItemRequest>()
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => PrODraftItemRequest)
  items: PrODraftItemRequest[];

  @ApiPropertyOptional()
  @IsInt()
  @IsOptional()
  manufacturingOrderId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  createdByUserId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @Length(1, 255)
  name: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @Length(0, 255)
  description: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  type: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @Length(1, 9)
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  deadline: Date;
}
