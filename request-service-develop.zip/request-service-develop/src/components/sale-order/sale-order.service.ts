import { ResponseCodeEnum } from '../../constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { SaleServiceInterface } from '@components/sale-order/interface/sale.service.interface';
import { ClientProxy } from '@nestjs/microservices';
import { flatMap, isEmpty, map, uniq } from 'lodash';
import { escapeCharForSearch } from '@utils/common';
import { CreateProductionOrderDraftRequestDto } from './dto/request/create-production-order-draft-request.dto';
import { CreatePurchaseOrderDraftRequestDto } from './dto/request/create-purchase-order-draft-request.dto';
import { REQUEST } from '@nestjs/core';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { NATS_SALE } from '@config/nats.config';

@Injectable()
export class SaleService implements SaleServiceInterface {
  constructor(
    private readonly natsClientService: NatsClientService,

    @Inject(REQUEST) private readonly req: any,
  ) {}
  async getPurchaseOrderByMOId(MoId: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_purchased_order_by_mo_id`,
      { manufacturingOrderId: MoId },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async getPurchaseOrderByIds(ids: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_purchased_order_by_ids`,
      { ids: ids },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async createProductionOrderDraft(
    payload: CreateProductionOrderDraftRequestDto,
  ): Promise<any> {
    const userId = await this.req['user']?.id;
    const request = {
      ...payload,
      userId: userId,
    };
    const response = await this.natsClientService.send(
      `${NATS_SALE}.create_production_order_draft`,
      request,
    );
    return response;
  }

  async createPurchaseOrderDraft(
    payload: CreatePurchaseOrderDraftRequestDto,
  ): Promise<any> {
    const userId = await this.req['user']?.id;
    const request = {
      ...payload,
      userId: userId,
    };
    const response = await this.natsClientService.send(
      `${NATS_SALE}.create_purchased_order`,
      request,
    );
    return response;
  }

  async getSaleOrdersByNameKeyword(
    filterByName,
    onlyId?: boolean,
  ): Promise<any> {
    if (isEmpty(filterByName)) {
      return [];
    }

    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_sale_orders_by_name_keyword`,
      {
        nameKeyword: filterByName.text,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (!isEmpty(response.data) && onlyId === true) {
      return uniq(map(flatMap(response.data), 'id'));
    }

    return response.data;
  }

  async getSaleOrdersByIds(
    payload: { ids: number[]; withDetail: boolean },
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_sale_order_by_ids`,
      payload,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    const serilizeSaleOrders = [];
    if (serilize) {
      response.data.forEach((item) => {
        serilizeSaleOrders[item.id] = item;
      });

      return serilizeSaleOrders;
    }
    return response.data;
  }

  async getSaleOrdersByRelation(relation: any): Promise<any[]> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_sale_order_by_relation`,
      {
        relation: relation,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async getSaleOrdersByName(name: string): Promise<any[]> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_sale_order_by_relation`,
      {
        relation: {
          where:
            'LOWER(unaccent(name)) LIKE ' +
            `LOWER(unaccent('%${escapeCharForSearch(name)}%')) escape '\\'`,
        },
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async getSaleOrdersByCode(code: string, onlyId?: boolean): Promise<any[]> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_sale_order_by_relation`,
      {
        relation: {
          where:
            'LOWER(unaccent(code)) LIKE ' +
            `LOWER(unaccent('%${escapeCharForSearch(code)}%')) escape '\\'`,
        },
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    if (!isEmpty(response.data) && onlyId === true) {
      return map(response.data, 'id');
    }
    return response.data;
  }

  async getSaleOrdersByIdsSorted(ids: number[]): Promise<any[]> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_sale_order_by_relation`,
      {
        relation: {
          where: ids.map((i) => {
            return {
              id: i,
            };
          }),
          order: {
            name: 'ASC',
          },
        },
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async getProductionOrdersByCondition(
    request: any,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_production_order_by_condition`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    const serilizeProductionOrders = [];
    if (serilize) {
      response.data.forEach((productionOrder) => {
        serilizeProductionOrders[productionOrder.manufacturing_order_id] =
          productionOrder;
      });

      return serilizeProductionOrders;
    }
    return response.data;
  }

  async getTotalQuantityItemProductionOrdersByCondition(
    request: any,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_total_quantity_item_production_order_by_condition`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    if (response.data.length > 0) {
      const serilizeProductionOrders = [];
      if (serilize) {
        response.data.forEach((productionOrder) => {
          serilizeProductionOrders[productionOrder.itemId] = productionOrder;
        });

        return serilizeProductionOrders;
      }
    }

    return response.data;
  }

  async getTotalQuantityItemPurchasedOrdersByCondition(
    request: any,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_total_quantity_item_purchased_order_by_condition`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    if (response.data.length > 0) {
      const serilizePurchasedOrders = [];
      if (serilize) {
        response.data.forEach((purchasedOrder) => {
          serilizePurchasedOrders[purchasedOrder.itemId] = purchasedOrder;
        });

        return serilizePurchasedOrders;
      }
    }

    return response.data;
  }

  async getSaleOrdersByCodeKeyword(
    filterByCode,
    onlyId?: boolean,
  ): Promise<any> {
    if (isEmpty(filterByCode)) {
      return [];
    }

    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_sale_orders_by_code_keyword`,
      {
        codeKeyword: filterByCode.text,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (!isEmpty(response.data) && onlyId === true) {
      return uniq(map(flatMap(response.data), 'id'));
    }

    return response.data;
  }

  async getSaleOrders(request: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_sale_order_list`,
      {
        ...request,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data.items;
  }
}
