import { Injectable } from '@nestjs/common';
import { WarehouseServiceInterface } from './interface/warehouse.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { NATS_WAREHOUSE } from '@config/nats.config';
@Injectable()
export class WarehouseService implements WarehouseServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getListByIDs(
    ids: number[],
    serilize?: boolean,
    relation?: string[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE}.get_warehouses_by_ids`,
      {
        warehouseIds: ids,
        relation,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    const serilizeWarehouses = {};
    if (serilize) {
      response.data.forEach((warehouse) => {
        serilizeWarehouses[warehouse.id] = warehouse;
      });

      return serilizeWarehouses;
    }

    return response.data;
  }

  async getWarehouseById(id: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE}.detail_warehouse`,
      {
        id,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }
}
