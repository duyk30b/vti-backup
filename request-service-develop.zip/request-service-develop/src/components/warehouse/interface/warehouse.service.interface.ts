export interface WarehouseServiceInterface {
  getListByIDs(
    warehouseIds: number[],
    serilize?: boolean,
    relation?: string[],
  ): Promise<any>;

  getWarehouseById(id: number): Promise<any>;
}
