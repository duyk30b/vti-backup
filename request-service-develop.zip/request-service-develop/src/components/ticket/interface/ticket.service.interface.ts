export interface TicketServiceInterface {
  getTicketsByRequestIds(
    requestIds: string[],
    serialize?: boolean,
  ): Promise<any>;
  getTicketReceiptByCondition(
    requestIds: string[],
    serialize?: boolean,
  ): Promise<any>;
}
