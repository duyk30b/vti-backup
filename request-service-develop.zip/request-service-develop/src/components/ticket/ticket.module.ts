import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ConfigService } from '@config/config.service';
import { UserController } from '@components/user/user.controller';
import { TicketService } from './ticket.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    'TICKET_SERVICE_CLIENT',
    {
      provide: 'TicketServiceInterface',
      useClass: TicketService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'TICKET_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const ticketServiceOptions = configService.get('ticketService');
        return ClientProxyFactory.create(ticketServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'TicketServiceInterface',
      useClass: TicketService,
    },
  ],
  controllers: [UserController],
})
export class TicketModule {}
