import { NATS_TICKET } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Inject, Injectable } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { keyBy } from 'lodash';
import { TicketServiceInterface } from './interface/ticket.service.interface';

@Injectable()
export class TicketService implements TicketServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  public async getTicketsByRequestIds(
    requestIds: string[],
    serialize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_TICKET}.get_tickets_by_request_ids`,
      { requestIds },
    );

    if (response.statusCode != ResponseCodeEnum.SUCCESS) {
      return [];
    }
    if (serialize) {
      return keyBy(response?.data, 'requestId');
    }
    return response?.data;
  }

  public async getTicketReceiptByCondition(
    requestIds: string[],
    serialize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_TICKET}.get_tickets_by_condition`,
      { requestIds },
    );

    if (response.statusCode != ResponseCodeEnum.SUCCESS) {
      return [];
    }
    if (serialize) {
      return keyBy(response?.data, 'requestId');
    }
    return response?.data;
  }
}
