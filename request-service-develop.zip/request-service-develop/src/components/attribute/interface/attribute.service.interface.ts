export interface AttributeServiceInterface {
  getTemplateById(id: string, serialize?: boolean): Promise<any>;
  getTemplateByCode(code: string): Promise<any>;
  validateTemplateAttributes(payload): Promise<any>;
  getAttributeByIds(ids: string[], serialize?: boolean): Promise<any>;
  getAttributeByCodes(codes: string[], serialize?: boolean): Promise<any>;
}
