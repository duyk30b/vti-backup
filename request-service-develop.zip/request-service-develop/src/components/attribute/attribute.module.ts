import { Global, Module } from '@nestjs/common';
import { ConfigService } from '@config/config.service';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { AttributeService } from './attribute.service';
import { ClientProxyFactory } from '@nestjs/microservices';

@Global()
@Module({
  imports: [HttpClientModule],
  exports: [
    'ATTRIBUTE_SERVICE_CLIENT',
    {
      provide: 'AttributeServiceInterface',
      useClass: AttributeService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'ATTRIBUTE_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const attributeServiceOptions = configService.get('attributeService');
        return ClientProxyFactory.create(attributeServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'AttributeServiceInterface',
      useClass: AttributeService,
    },
  ],
  controllers: [],
})
export class AttributeModule {}
