import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { keyBy } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { GetListUnitQuery } from './dto/request/get-list-unit.query';
import { CreateUnitRequest } from './dto/request/create-unit.request';
import { UpdateUnitRequest } from './dto/request/update-unit.request';
import { DetailUnitResponse } from './dto/response/detail-unit.response';
import { UnitRepositoryInterface } from './interface/unit.repository.interface';
import { UnitServiceInterface } from './interface/unit.service.interface';
import { UNIT_CONST } from './unit.constant';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';

@Injectable()
export class UnitService implements UnitServiceInterface {
  constructor(
    @Inject('UnitRepositoryInterface')
    private readonly unitRepository: UnitRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateUnitRequest): Promise<ResponsePayload<any>> {
    try {
      const validate = await this.validateBeforeSave(request);
      if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validate;
      }
      request.code = await this.unitRepository.generateNextCode(
        UNIT_CONST.CODE.PREFIX,
      );
      const unitEntity = this.unitRepository.createEntity(request);
      const dataSave = await unitEntity.save();
      const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async update(request: UpdateUnitRequest): Promise<ResponsePayload<any>> {
    try {
      const validate = await this.validateBeforeSave(request, true);
      if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validate;
      }
      let unitEntity = await this.unitRepository.findOneById(request.id);

      if (!unitEntity) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
      unitEntity = await this.unitRepository.updateEntity(unitEntity, request);

      await this.unitRepository.findByIdAndUpdate(request.id, unitEntity);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.error(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async detail(request: IdParamMongoDto): Promise<ResponsePayload<any>> {
    try {
      const unitEntity = await this.unitRepository.findOneById(request.id);

      if (!unitEntity) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const dataReturn = plainToInstance(DetailUnitResponse, unitEntity, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async list(request: GetListUnitQuery): Promise<ResponsePayload<any>> {
    const { data, count } = await this.unitRepository.list(request);

    const dataReturn = plainToInstance(DetailUnitResponse, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      result: dataReturn,
      meta: { total: count, page: request.page, size: request.limit },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const unit = await this.unitRepository.findOneById(id);
    if (!unit) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    await this.unitRepository.findByIdAndUpdate(id, {
      $set: { active: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async validateBeforeSave(request: any, isUpdate = false) {
    const conditionValidateNameUnique = isUpdate
      ? {
          name: { $regex: new RegExp(`^${request.name}$`, 'i') },
          _id: { $ne: request.id },
        }
      : {
          name: { $regex: new RegExp(`^${request.name}$`, 'i') },
        };
    const existsData = await this.unitRepository.findOneByCondition(
      conditionValidateNameUnique,
    );
    if (existsData) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.UNIT_NAME_HAS_EXISTS'))
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
