import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Injectable } from '@nestjs/common';
import { ItemServiceInterface } from './interface/item.service.interface';
import { ItemResponseDto } from './dto/response/item.dto.response';
import { plainToInstance } from 'class-transformer';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { NATS_ITEM } from '@config/nats.config';

@Injectable()
export class ItemService implements ItemServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}
  async getItems(itemIds: any[]): Promise<ItemResponseDto[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_items_by_ids`,
      {
        itemIds,
        basicInfor: true,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const items = response.data.map((item) => ({
      ...item,
      itemUnit: item.itemUnitName,
    }));
    const dataReturn = plainToInstance(ItemResponseDto, <any[]>items, {
      excludeExtraneousValues: true,
    });

    return dataReturn;
  }
  async getItemByIds(itemIds: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_items_by_ids`,
      {
        itemIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    const serilizeItems = {};
    if (serilize) {
      response.data.forEach((item) => {
        serilizeItems[item.id] = item;
      });

      return serilizeItems;
    }
    return response.data;
  }
  async getItemStock(itemIds: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_warehouse_available_stocks`,
      {
        items: itemIds.map((id) => ({ itemId: id })),
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const serilizeItems = {};
    if (serilize) {
      response.data.forEach((item) => {
        serilizeItems[item.itemId] = item;
      });

      return serilizeItems;
    }
    return response.data;
  }

  async getItemByCodes(codes: string[]): Promise<any[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_by_codes`,
      {
        codes: codes,
      },
    );
    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    return response.data;
  }
  async getItemsByCode(itemCode: string): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_list`,
      {
        filter: [{ column: 'code', text: itemCode }],
      },
    );
    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.items.length === 0
    ) {
      return [];
    }

    return response.data.items;
  }

  async getItemUnitByIds(
    itemUnitIds: number[],
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_unit_setting_by_ids`,
      {
        unitIds: itemUnitIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    const serilizeItems = {};
    if (serilize) {
      response.data?.forEach((item) => {
        serilizeItems[item.id] = item;
      });
      return serilizeItems;
    }
    return response.data;
  }
}
