import { Controller, Inject } from '@nestjs/common';
import { ItemServiceInterface } from './interface/item.service.interface';

@Controller('')
export class ItemController {
  constructor(
    @Inject('ItemServiceInterface')
    private readonly userService: ItemServiceInterface,
  ) {}
}
