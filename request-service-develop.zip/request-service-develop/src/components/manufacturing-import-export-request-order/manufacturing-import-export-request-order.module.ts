import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ManufacturingImportExportRequestOrderController } from './manufacturing-import-export-request-order.controller';
import { RequestOrderSchema } from 'src/models/request-order/request-order.schema';
import { RequestOrderDetailSchema } from 'src/models/request-order-detail/request-order-detail.schema';
import { RequestOrderRepository } from 'src/repository/request-order/request-order.repository';
import { AttributeService } from '@components/attribute/attribute.service';
import { ItemService } from '@components/item/item.service';
import { UserService } from '@components/user/user.service';
import { ProduceService } from '@components/produce/produce.service';
import { RequestOrderDetailRepository } from 'src/repository/request-order-detail/request-order-detail.repository';
import { ManufacturingImportExportRequestOrderService } from './manufacturing-import-export-request-order.service';
import { WarehouseService } from '@components/warehouse/warehouse.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'RequestOrder', schema: RequestOrderSchema },
      { name: 'RequestOrderDetail', schema: RequestOrderDetailSchema },
    ]),
  ],
  controllers: [ManufacturingImportExportRequestOrderController],
  providers: [
    {
      provide: 'ManufacturingImportExportRequestOrderServiceInterface',
      useClass: ManufacturingImportExportRequestOrderService,
    },
    {
      provide: 'RequestOrderRepositoryInterface',
      useClass: RequestOrderRepository,
    },
    {
      provide: 'AttributeServiceInterface',
      useClass: AttributeService,
    },
    {
      provide: 'RequestOrderDetailRepositoryInterface',
      useClass: RequestOrderDetailRepository,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ProduceServiceInterface',
      useClass: ProduceService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
  ],
  exports: [],
})
export class ManufacturingImportExportRequestModule {}
