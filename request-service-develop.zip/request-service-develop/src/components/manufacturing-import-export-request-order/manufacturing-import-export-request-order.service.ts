import { RequestOrderServiceAbstract } from '@components/request-order/request-order.service.abstract';
import { Inject, Injectable } from '@nestjs/common';
import { isEmpty, keyBy } from 'lodash';
import { ManufacturingImportExportRequestOrderServiceInterface } from './interface/manufacturing-import-export-request-order.service.interface';
import { RequestOrderRepositoryInterface } from '@components/request-order/interface/request-order.repository.interface';
import { AttributeServiceInterface } from '@components/attribute/interface/attribute.service.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { RequestOrderDetailRepositoryInterface } from '@components/request-order/interface/request-order-detail.repository.interface.ts';
import { I18nRequestScopeService } from 'nestjs-i18n';
import * as mongoose from 'mongoose';
import { InjectConnection } from '@nestjs/mongoose';
import {
  MANUFACTURING_EXPORT_ORDER_CONST,
  MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE,
  MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_STATUS_ENUM,
  MANUFACTURING_IMPORT_ORDER_CONST,
  ManufacturingImportExportRequestOrderTemplateCodeEnum,
} from './manufacturing-import-export-request-order.constant';
import {
  CreateManufacturingExportRequestOrderRequestDto,
  CreateManufacturingImportRequestOrderRequestDto,
} from './dto/request/create-manufacturing-import-export-request-order.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { REQUEST_ORDER_TYPE_ENUM } from '@components/request-order/request-order.constant';
import { MANUFACTURING_REQUEST_ORDER_FIELD_CODE } from '@components/manufacturing-request-order/manufacturing-request-order.constant';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import * as moment from 'moment';

@Injectable()
export class ManufacturingImportExportRequestOrderService
  extends RequestOrderServiceAbstract
  implements ManufacturingImportExportRequestOrderServiceInterface
{
  constructor(
    @Inject('RequestOrderRepositoryInterface')
    protected readonly requestOrderRepository: RequestOrderRepositoryInterface,

    @Inject('AttributeServiceInterface')
    protected readonly attributeService: AttributeServiceInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('ProduceServiceInterface')
    protected readonly produceService: ProduceServiceInterface,

    @Inject('RequestOrderDetailRepositoryInterface')
    protected readonly requestOrderDetailRepository: RequestOrderDetailRepositoryInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    protected readonly i18n: I18nRequestScopeService,

    @InjectConnection()
    protected readonly connection: mongoose.Connection,
  ) {
    super(
      userService,
      requestOrderRepository,
      requestOrderDetailRepository,
      attributeService,
      i18n,
      connection,
    );
  }
  async createManufacturingImportRequestOrder(
    payload: CreateManufacturingImportRequestOrderRequestDto,
  ): Promise<any> {
    const {
      itemId,
      productionOrderId,
      productionOrderCode,
      warehouseId,
      requestQuantity,
      description,
      approverId,
      approvedAt,
    } = payload;
    const template = await this.attributeService.getTemplateByCode(
      ManufacturingImportExportRequestOrderTemplateCodeEnum.ManufacturingImportRequestOrder,
    );
    if (isEmpty(template)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.TEMPLATE_NOT_FOUND'))
        .build();
    }
    const { attributeHeaders, attributeGroups } = template;
    const attributeHeaderMap = keyBy(
      attributeHeaders,
      (attributeHeader) => attributeHeader.attribute.code,
    );

    const attributeGroupMap = keyBy(
      attributeGroups[0].attributes,
      (attributeGroup) => attributeGroup.attribute.code,
    );

    const [serializeUsers, items] = await Promise.all([
      this.userService.getUsersByIds([approverId], true),
      this.itemService.getItemByIds([itemId]),
    ]);
    const approver = serializeUsers[approverId];

    const item = items ? items[0] : null;
    try {
      const manufacturingImportOrder: any = {};
      manufacturingImportOrder.attributeValues = [
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.STATUS
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.STATUS,
          value:
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_STATUS_ENUM.CONFIRMED,
        },
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE
              .PRODUCTION_ORDER_IMPORT_ID
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.PRODUCTION_ORDER_IMPORT_ID,
          value: productionOrderId,
        },
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.DEPARTMENT_CODE
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.DEPARTMENT_CODE,
          value: approver?.departmentSettings[0]?.id || '',
        },
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.NOTE
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.NOTE,
          value: description,
        },
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE
              .WAREHOUSE_IMPORT_CODE
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.WAREHOUSE_IMPORT_CODE,
          value: warehouseId,
        },
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.CREATED_BY
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.CREATED_BY,
          value: approverId,
        },
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.CREATED_AT
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.CREATED_AT,
          value: approvedAt,
        },
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.CODE
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.CODE,
          value: productionOrderCode,
        },
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.TEMPLATE_CODE
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.TEMPLATE_CODE,
          value: template.code,
        },
      ];

      manufacturingImportOrder.templateId = template.id;
      manufacturingImportOrder.type =
        REQUEST_ORDER_TYPE_ENUM.MANUFACTURING_IMPORT_REQUEST_ORDER;
      manufacturingImportOrder.status =
        MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_STATUS_ENUM.CONFIRMED;
      manufacturingImportOrder.code = productionOrderCode;
      manufacturingImportOrder.createdBy = approverId;

      const manufacturingImportRequestOrderEntity =
        this.requestOrderRepository.createDocument(manufacturingImportOrder);
      await this.requestOrderRepository.create(
        manufacturingImportRequestOrderEntity,
      );

      const manufacturingImportOrderDetail = [
        {
          requestOrderId: manufacturingImportRequestOrderEntity._id,
          groupId: template.attributeGroups[0].id,
          attributeValues: [
            {
              attributeId:
                attributeGroupMap[
                  MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.ITEM_CODE
                ].attribute.id,
              code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.ITEM_CODE,
              value: itemId,
            },
            {
              attributeId:
                attributeGroupMap[
                  MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.ITEM_NAME
                ].attribute.id,
              code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.ITEM_NAME,
              value: item?.name,
            },
            {
              attributeId:
                attributeGroupMap[
                  MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE
                    .REMAINNING_QUANTITY_REQUEST
                ].attribute.id,
              code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.REMAINNING_QUANTITY_REQUEST,
              value: requestQuantity,
            },
            {
              attributeId:
                attributeGroupMap[
                  MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE
                    .ITEM_UNIT_NAME
                ].attribute.id,
              code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.ITEM_UNIT_NAME,
              value: item?.itemUnit?.name,
            },
            {
              attributeId:
                attributeGroupMap[
                  MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE
                    .REQUEST_QUANTITY
                ].attribute.id,
              code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.REQUEST_QUANTITY,
              value: requestQuantity,
            },
          ],
        },
      ];
      const manufacturingImportOrderDetailEntities =
        manufacturingImportOrderDetail.map(
          (manufacturingExportOrderDetailItem) =>
            this.requestOrderDetailRepository.createDocument(
              manufacturingExportOrderDetailItem,
            ),
        );
      await this.requestOrderDetailRepository.create(
        manufacturingImportOrderDetailEntities,
      );
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async createManufacturingExportRequestOrder(
    payload: CreateManufacturingExportRequestOrderRequestDto,
  ): Promise<any> {
    const {
      itemId,
      productionOrderId,
      productionOrderCode,
      approverId,
      approvedAt,
      description,
      materials,
    } = payload;
    const template = await this.attributeService.getTemplateByCode(
      ManufacturingImportExportRequestOrderTemplateCodeEnum.ManufacturingExportRequestOrder,
    );
    if (isEmpty(template)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.TEMPLATE_NOT_FOUND'))
        .build();
    }

    const { attributeHeaders, attributeGroups } = template;
    const attributeHeaderMap = keyBy(
      attributeHeaders,
      (attributeHeader) => attributeHeader.attribute.code,
    );
    const attributeGroupMap = keyBy(
      attributeGroups[0].attributes,
      (attributeGroup) => attributeGroup.attribute.code,
    );

    const serializeUsers = await this.userService.getUsersByIds(
      [approverId],
      true,
    );
    const approver = serializeUsers[approverId];

    const itemIds = [itemId, ...materials.map((material) => material.itemId)];
    const serializeItems = await this.itemService.getItemByIds(itemIds, true);

    try {
      const manufacturingExportOrder: any = {};
      manufacturingExportOrder.attributeValues = [
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.STATUS
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.STATUS,
          value:
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_STATUS_ENUM.CONFIRMED,
        },
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.DEPARTMENT_CODE
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.DEPARTMENT_CODE,
          value: approver?.departmentSettings[0]?.id || '',
        },
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.NOTE
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.NOTE,
          value: description,
        },
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE
              .PRODUCTION_ORDER_EXPORT_ID
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.PRODUCTION_ORDER_EXPORT_ID,
          value: productionOrderId,
        },
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE
              .WAREHOUSE_EXPORT_CODE
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.WAREHOUSE_EXPORT_CODE,
          value: '',
        },
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.CREATED_BY
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.CREATED_BY,
          value: approverId,
        },
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.CREATED_AT
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.CREATED_AT,
          value: approvedAt,
        },
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.CODE
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.CODE,
          value: productionOrderCode,
        },
        {
          id: attributeHeaderMap[
            MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.TEMPLATE_CODE
          ].attribute.id,
          code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.TEMPLATE_CODE,
          value: template.code,
        },
      ];
      manufacturingExportOrder.templateId = template.id;
      manufacturingExportOrder.type =
        REQUEST_ORDER_TYPE_ENUM.MANUFACTURING_EXPORT_REQUEST_ORDER;
      manufacturingExportOrder.status =
        MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_STATUS_ENUM.CONFIRMED;
      manufacturingExportOrder.code = productionOrderCode;
      manufacturingExportOrder.createdBy = approverId;

      const manufacturingExportRequestOrderEntity =
        this.requestOrderRepository.createDocument(manufacturingExportOrder);
      await this.requestOrderRepository.create(
        manufacturingExportRequestOrderEntity,
      );

      const manufacturingExportOrderDetail = materials.map((material) => {
        return {
          requestOrderId: manufacturingExportRequestOrderEntity._id,
          groupId: template.attributeGroups[0].id,
          attributeValues: [
            {
              attributeId:
                attributeGroupMap[
                  MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.ITEM_CODE
                ].attribute.id,
              code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.ITEM_CODE,
              value: material.itemId,
            },
            {
              attributeId:
                attributeGroupMap[
                  MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.ITEM_NAME
                ].attribute.id,
              code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.ITEM_NAME,
              value: serializeItems[material.itemId]?.name,
            },
            {
              attributeId:
                attributeGroupMap[
                  MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE
                    .REQUEST_QUANTITY
                ].attribute.id,
              code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.REQUEST_QUANTITY,
              value: material.quantity,
            },
            {
              attributeId:
                attributeGroupMap[
                  MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE
                    .ITEM_UNIT_NAME
                ].attribute.id,
              code: MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE.ITEM_UNIT_NAME,
              value: serializeItems[material.itemId]?.itemUnit?.name,
            },
          ],
        };
      });
      const manufacturingExportOrderDetailEntities =
        manufacturingExportOrderDetail.map(
          (manufacturingExportOrderDetailItem) =>
            this.requestOrderDetailRepository.createDocument(
              manufacturingExportOrderDetailItem,
            ),
        );
      await this.requestOrderDetailRepository.create(
        manufacturingExportOrderDetailEntities,
      );
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
