import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class BasicResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose({ name: 'code' })
  code: string;

  @ApiProperty()
  @Expose({ name: 'name' })
  name: string;
}
class RequestUserResponse extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  fullName: string;
}

class BomResponse extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  routing: BaseResponseDto;
}

class ItemResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose({ name: 'code' })
  code: string;

  @ApiProperty()
  @Expose({ name: 'name' })
  name: string;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  itemUnit: BasicResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => BomResponse)
  bom: BomResponse;
}

class RequestOrderDetailDto {
  @ApiProperty()
  @Expose()
  itemId: Number;

  @ApiProperty()
  @Expose()
  itemUnitId: Number;

  @ApiProperty()
  @Expose()
  bomVersionId: Number;

  @ApiProperty()
  @Expose()
  quantity: Number;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  bomVersion: BasicResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto[];
}

export class GetManufacturingRequestOrderByIdsResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  requestDate: Date;

  @ApiProperty()
  @Expose()
  requestUserId: Number;

  @ApiProperty()
  @Expose()
  approvedUserId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  unmanufacturedQuantity: number;

  @ApiProperty()
  @Expose()
  note: string;

  @ApiProperty()
  @Expose()
  @Type(() => RequestUserResponse)
  requestUser: RequestUserResponse;

  @ApiProperty()
  @Expose()
  @Type(() => RequestOrderDetailDto)
  requestOrderDetails: RequestOrderDetailDto[];
}
