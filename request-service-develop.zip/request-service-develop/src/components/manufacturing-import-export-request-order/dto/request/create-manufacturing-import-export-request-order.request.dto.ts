import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsDateString, IsMongoId, IsNotEmpty, IsNumber } from 'class-validator';
import {
  ArrayUnique,
  IsInt,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

export class MaterialRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  quantity: number;
}

export class CreateManufacturingImportExportRequestOrderRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  productionOrderId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  productionOrderCode: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  moId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  moCode: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  requesterId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  requestDate: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  bomVersionId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  approverId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  approvedAt: Date;

  @ApiProperty()
  @IsOptional()
  @IsString()
  description: string;
}

export class CreateManufacturingImportRequestOrderRequestDto extends CreateManufacturingImportExportRequestOrderRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  requestQuantity: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseId: number;
}

export class CreateManufacturingExportRequestOrderRequestDto extends CreateManufacturingImportExportRequestOrderRequestDto {
  @ApiProperty()
  @ArrayUnique<MaterialRequestDto>()
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => MaterialRequestDto)
  materials: MaterialRequestDto[];
}
