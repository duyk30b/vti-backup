import { MANUFACTURING_REQUEST_ORDER_FIELD_CODE } from '@components/manufacturing-request-order/manufacturing-request-order.constant';

const PREFIX_CODE = 'MES';
export const MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_FIELD_CODE = {
  ['APPROVED_ID']: 'mesxApprovedId',
  ['REQUEST_USER_ID']: 'mesxRequestUserId',
  ['BOM_VERSION_ID']: 'mesxBomVersionId',
  ['ITEM_ID']: 'mesxItemId',
  ['ITEM_UNIT_ID']: 'mesxItemUnitId',

  //common
  ['CODE']: 'requestCode',
  ['STATUS']: 'wmsxStatus',
  ['CREATED_AT']: 'wmsxCreatedAt',
  ['CREATED_BY']: 'wmsxCreatedBy',
  ['NOTE']: 'wmsxDescription',
  ['WAREHOUSE_IMPORT_CODE']: 'warehouseImportCode',
  ['TEMPLATE_CODE']: 'wmsxTemplateCode',
  ['WAREHOUSE_EXPORT_CODE']: 'warehouseExportCode',
  ['PRODUCTION_ORDER_IMPORT_ID']: 'mesxProductionOrderImportId',
  ['PRODUCTION_ORDER_EXPORT_ID']: 'mesxProductionOrderExportId',

  ['ITEM_CODE']: 'wmsxItemCode',
  ['ITEM_NAME']: 'wmsxItemName',
  ['ITEM_UNIT_NAME']: 'wmsxItemUnitName',
  ['REMAINNING_QUANTITY_REQUEST']: 'wmsxRemainningQuantityRequest',

  ['BOM_VERSION_CODE']: 'mesxBomVersionCode',
  ['QUANTITY']: 'mesxQuantity',
  ['ACTUAL_QUANTITY']: 'mesxActualQuantity',
  ['DEADLINE']: 'mesxDeadline',
  ['IS_HAS_PLAN']: 'mesxIsHasPlan',
  ['APPROVED_AT']: 'mesxApprovedAt',
  ['FILES']: 'mesxFiles',
  ['MO_ID']: 'mesxManufacturingOrderId',
  ['MO_CODE']: 'mesxManufacturingOrderCode',
  ['ITEM_TYPE_ID']: 'mesxItemTypeId',
  ['ITEM_TYPE_NAME']: 'mesxItemTypeName',
  ['DEPARTMENT_CODE']: 'departmentCode',
  ['REQUEST_QUANTITY']: 'wmsxQuantityRequest',
  ['APPROVER_NAME']: 'mesxApproverName',
  ['WAREHOUSE_IMPORT_NAME']: 'mesxWarehouseImportName',
};

export enum ManufacturingImportExportRequestOrderTemplateCodeEnum {
  ManufacturingImportRequestOrder = 'MESX_MANUFACTURING_IMPORT_REQUEST',
  ManufacturingExportRequestOrder = 'MESX_MANUFACTURING_EXPORT_REQUEST',
}

export enum MANUFACTURING_IMPORT_EXPORT_REQUEST_ORDER_STATUS_ENUM {
  PENDING = 0,
  CONFIRMED = 1,
  INPROGRESS = 2,
  APPROVED = 3,
  COMPLETED = 4,
  REJECT = 5,
  INRECEIVING = 6,
  RECEIVED = 7,
  DELIVERED = 8,
  INCOLLECTING = 9,
  COLLECTED = 10,
  EXPORTED = 11,
  REJECT_RECEIVED = 12,
  IN_PRODUCING = 13,
  PRODUCED = 14,
  IN_RETURNING = 15,
  RETURNED = 16,
  STORED = 17,
  PLANNED = 18,
}

export const MANUFACTURING_IMPORT_ORDER_CONST = {
  CODE: {
    PREFIX_CODE_DEFAULT: 'NTP',
    END_CODE_DEFAULT: 'YY',
    START_CODE_DEFAULT: '00001',
  },
};

export const MANUFACTURING_EXPORT_ORDER_CONST = {
  CODE: {
    PREFIX_CODE_DEFAULT: 'XNVL',
    END_CODE_DEFAULT: 'YY',
    START_CODE_DEFAULT: '00001',
  },
};
