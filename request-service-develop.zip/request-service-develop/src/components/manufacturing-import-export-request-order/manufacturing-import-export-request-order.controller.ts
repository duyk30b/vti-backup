import { Body, Controller, Inject, Post } from '@nestjs/common';
import { isEmpty } from 'lodash';
import { ManufacturingImportExportRequestOrderServiceInterface } from './interface/manufacturing-import-export-request-order.service.interface';
import {
  CreateManufacturingExportRequestOrderRequestDto,
  CreateManufacturingImportRequestOrderRequestDto,
} from './dto/request/create-manufacturing-import-export-request-order.request.dto';
import { NATS_REQUEST } from '@config/nats.config';
import { MessagePattern } from '@nestjs/microservices';

@Controller('manufacturing-import-export-request-orders')
export class ManufacturingImportExportRequestOrderController {
  constructor(
    @Inject('ManufacturingImportExportRequestOrderServiceInterface')
    private readonly manufacturingImportExportRequestOrderService: ManufacturingImportExportRequestOrderServiceInterface,
  ) {}

  @MessagePattern(`${NATS_REQUEST}.create_manufacturing_import_request_order`)
  // @Post('/create-import')
  public async createManufacturingImportRequestOrder(
    @Body() payload: CreateManufacturingImportRequestOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingImportExportRequestOrderService.createManufacturingImportRequestOrder(
      request,
    );
  }

  @MessagePattern(`${NATS_REQUEST}.create_manufacturing_export_request_order`)
  // @Post('/create-export')
  public async createManufacturingExportRequestOrder(
    @Body() payload: CreateManufacturingExportRequestOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingImportExportRequestOrderService.createManufacturingExportRequestOrder(
      request,
    );
  }
}
