import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ManufacturingRequestOrderController } from './manufacturing-request-order.controller';
import { ManufacturingOrderService } from './manufacturing-request-order.service';
import { RequestOrderSchema } from 'src/models/request-order/request-order.schema';
import { RequestOrderDetailSchema } from 'src/models/request-order-detail/request-order-detail.schema';
import { RequestOrderRepository } from 'src/repository/request-order/request-order.repository';
import { AttributeService } from '@components/attribute/attribute.service';
import { ItemService } from '@components/item/item.service';
import { UserService } from '@components/user/user.service';
import { ProduceService } from '@components/produce/produce.service';
import { RequestOrderDetailRepository } from 'src/repository/request-order-detail/request-order-detail.repository';
import { ItemStockPlanningService } from '@components/item-stock-planning/item-stock-planning.service';
import { RequestOrderHoldedMaterialSChema } from 'src/models/request-order-holded-material/request-order-holded-material.schema';
import { RequestOrderHoldedMaterialRepository } from 'src/repository/request-order-holded-material/request-order-holded-material.repository';
import { FileModule } from '@components/file/file.module';
import { FileService } from '@components/file/file.service';
import { SaleService } from '@components/sale-order/sale-order.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'RequestOrder', schema: RequestOrderSchema },
      { name: 'RequestOrderDetail', schema: RequestOrderDetailSchema },
      {
        name: 'RequestOrderHoldedMaterialModel',
        schema: RequestOrderHoldedMaterialSChema,
      },
    ]),
    FileModule,
  ],
  controllers: [ManufacturingRequestOrderController],
  providers: [
    {
      provide: 'ManufacturingOrderServiceInterface',
      useClass: ManufacturingOrderService,
    },
    {
      provide: 'RequestOrderRepositoryInterface',
      useClass: RequestOrderRepository,
    },
    {
      provide: 'AttributeServiceInterface',
      useClass: AttributeService,
    },
    {
      provide: 'RequestOrderDetailRepositoryInterface',
      useClass: RequestOrderDetailRepository,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ProduceServiceInterface',
      useClass: ProduceService,
    },
    {
      provide: 'ItemStockPlanningServiceInterface',
      useClass: ItemStockPlanningService,
    },
    {
      provide: 'RequestOrderHoldedMaterialRepositoryInterface',
      useClass: RequestOrderHoldedMaterialRepository,
    },
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
  ],
  exports: [],
})
export class ManufacturingRequestModule {}
