import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { isEmpty } from 'lodash';
import { ManufacturingOrderServiceInterface } from './interface/manufacturing-request-order.service.interface';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateRequestOrderFormData } from '@components/request-order/dto/request/create-request-order.request.dto';
import { UpdateRequestOrderFormData } from '@components/request-order/dto/request/update-request-order.request.dto';
import { GetManufacturingOrderRequestListRequestDto } from './dto/request/get-manufacturing-request-order-list.request.dto';
import { GetManufacturingRequestOrderDetailRequestDto } from './dto/request/get-manufacturing-request-order-detail.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { MessagePattern } from '@nestjs/microservices';
import { GetManufacturingRequestOrderByIdsRequestDto } from './dto/request/get-manufacturing-request-order-by-ids.request.dto';
import { UpdateSoIsHasPlanRequestDto } from './dto/request/update-so-is-has-plan.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { NATS_REQUEST } from '@config/nats.config';
import { AutoCreateManufacturingRequestOrderRequestDto } from './dto/request/auto-create-manufacturing-request-order.request.dto';
import { UpdateProducedQuantityRequestDto } from './dto/request/update-produced-quantity.request.dto';

@Controller('manufacturing-request-orders')
export class ManufacturingRequestOrderController {
  constructor(
    @Inject('ManufacturingOrderServiceInterface')
    private readonly manufacturingRequestOrderService: ManufacturingOrderServiceInterface,
  ) {}

  @Post('create')
  @ApiOperation({
    tags: ['Manufacturing Request Order'],
    summary: 'Create Manufacturing Request Order',
    description: 'Tạo yêu cầu sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  public async create(
    @Body() payload: CreateRequestOrderFormData,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingRequestOrderService.create(request);
  }

  @Put(':id')
  @ApiOperation({
    tags: ['Manufacturing Request Order'],
    summary: 'Update Manufacturing Request Order',
    description: 'Sửa yêu cầu sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async update(
    @Param('id') id,
    @Body() payload: UpdateRequestOrderFormData,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingRequestOrderService.update({
      ...request,
      data: {
        ...request.data,
        id: id,
      },
    });
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Manufacturing Request Order'],
    summary: 'Get Manufacturing Request Order Detail',
    description: 'Chi tiết yêu cầu sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getDetailByTemplate(
    @Param() param: GetManufacturingRequestOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingRequestOrderService.getDetailByTemplate(
      request,
    );
  }

  @Get('/list')
  @ApiOperation({
    tags: ['Manufacturing Request Order'],
    summary: 'Get Manufacturing Request Order List',
    description: 'Danh sách yêu cầu sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getList(
    @Query() query: GetManufacturingOrderRequestListRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingRequestOrderService.getList(request);
  }

  @Get('/holded-items')
  @ApiOperation({
    tags: ['Manufacturing Request Order'],
    summary: 'Get Manufacturing Request Order List',
    description: 'Danh sách yêu cầu sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getHoldedItemList(
    @Query() query: GetManufacturingOrderRequestListRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingRequestOrderService.GetRequestOrderHoldedMaterialList(
      request,
    );
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['Manufacturing Request Order'],
    summary: 'Delete Manufacturing Request Order',
    description: 'Xóa yêu cầu sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
  })
  public async delete(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingRequestOrderService.delete(request);
  }

  @Put(':id/confirm')
  @ApiOperation({
    tags: ['Request', 'Manufacturing Request Order'],
    summary: 'Confirm Manufacturing Request Order',
    description: 'Xác nhận yêu cầu sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
  })
  public async confirm(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingRequestOrderService.confirm({
      ...request,
    });
  }

  @Put(':id/reject')
  @ApiOperation({
    tags: ['Request', 'Manufacturing Request Order'],
    summary: 'Reject Manufacturing Request Order',
    description: 'Từ chối yêu cầu sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
  })
  public async reject(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingRequestOrderService.reject({
      ...request,
    });
  }

  @MessagePattern(`${NATS_REQUEST}.get_manufacturing_request_order_by_id`)
  @ApiOperation({
    tags: ['Item'],
    summary: 'Get detail',
    description: 'Danh sách chi tiết',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getDetail(
    @Body() body: GetManufacturingRequestOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingRequestOrderService.getDetail(request);
  }

  @MessagePattern(`${NATS_REQUEST}.get_manufacturing_request_orders`)
  @Post('test')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Get manufacturing request order list ',
    description: 'Danh sách',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getManufacturingRequestOrdersTcp(
    @Body() body: GetManufacturingRequestOrderByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingRequestOrderService.getManufacturingRequestOrdersTcp(
      request,
    );
  }

  @Get('list-by-ids')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Get manufacturing request order list ',
    description: 'Danh sách',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getManufacturingRequestOrderByIds(
    @Query() body: GetManufacturingRequestOrderByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingRequestOrderService.getManufacturingRequestOrdersTcp(
      request,
    );
  }

  @Get('/generate-code')
  @ApiOperation({
    tags: ['Manufacturing request order'],
    summary: 'Gen code manufacturing request order',
    description: 'Gen code yêu cầu sản xuất',
  })
  @ApiResponse({
    status: 200,
    type: null,
    description: 'Get successfully',
  })
  public async generateCode(): Promise<any> {
    return await this.manufacturingRequestOrderService.generateCode();
  }

  @MessagePattern(
    `${NATS_REQUEST}.update_manufacturing_request_order_is_has_plan`,
  )
  public async updateSoIsHasPlan(
    @Body() payload: UpdateSoIsHasPlanRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingRequestOrderService.updateManufacturingRequestOrderIsHasPlan(
      request,
    );
  }

  /**
   * Update manufacturing request order status to inprogress
   * @param request IdParamMongoDto
   * @returns
   */
  @MessagePattern(
    `${NATS_REQUEST}.update_manufacturing_request_order_status_to_inprogress`,
  )
  @ApiOperation({
    tags: ['requests', 'Manufacturing request order'],
    summary: 'Update manufacturing request order status to inprogress',
    description: 'Chuyển trạng thái yêu cầu sản xuất sang đang thực hiện',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  public async updateManufacturingRequestOrderStatusToInprogress(
    @Body() payload: IdParamMongoDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingRequestOrderService.updateManufacturingRequestOrderStatusToInprogress(
      request,
    );
  }

  /**
   * Update manufacturing request order status to completed
   * @param request CompleteManufacturingRequestOrderRequestDto
   * @returns
   */
  @Put(':id/complete')
  @ApiOperation({
    tags: ['requests', 'Manufacturing request order'],
    summary: 'Update manufacturing request order status to completed',
    description: 'Hoàn thành yêu cầu sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  public async complete(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingRequestOrderService.complete({ ...request });
  }

  // @Post('/auto-create')
  @ApiOperation({
    tags: ['requests', 'Manufacturing request order'],
    summary: 'Auto create manufacturing request order ',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  @MessagePattern(`${NATS_REQUEST}.auto_create`)
  public async autoCreate(
    @Body() payload: AutoCreateManufacturingRequestOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingRequestOrderService.autoCreate(request);
  }

  @MessagePattern(`${NATS_REQUEST}.update_produced_quantity`)
  public async updateProducedQuantity(
    @Body() payload: UpdateProducedQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingRequestOrderService.updateProducedQuantity(
      request,
    );
  }
}
