import { GetRequestOrderListRequestDto } from '@components/request-order/dto/request/get-request-order-list.request.dto';

export class GetManufacturingOrderRequestListRequestDto extends GetRequestOrderListRequestDto {}
