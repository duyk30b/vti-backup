import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNotEmpty } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';

export class UpdateSoIsHasPlanRequestDto extends BaseDto {
  @ApiProperty()
  @IsArray()
  @IsNotEmpty()
  ids: string[];
}
