import { GetRequestOrderDetailRequestDto } from '@components/request-order/dto/request/get-request-order-detail.request.dto';
import { ArrayNotEmpty } from 'class-validator';

export class GetManufacturingRequestOrderDetailRequestDto extends GetRequestOrderDetailRequestDto {}
