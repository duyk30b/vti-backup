import { BaseDto } from '@core/dto/base.dto';
import { Query } from '@nestjs/common';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { Transform } from 'class-transformer';
import { ArrayNotEmpty, IsArray, IsNotEmpty, IsString } from 'class-validator';
import { isJson } from 'src/helper/string.helper';

export class GetManufacturingRequestOrderByIdsRequestDto extends PaginationQuery {}
