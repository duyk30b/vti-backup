import { CreateRequestOrderFormData } from '@components/request-order/dto/request/create-request-order.request.dto';

export class CreateManufacturingOrderReqeustDto extends CreateRequestOrderFormData {}
