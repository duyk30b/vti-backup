import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class UserResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  fullName: string;
}

class SaleOrderDetail {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  bomVersionId: number;

  @ApiProperty()
  @Expose()
  deadline: any;
}

export class GetManufacturingRequestOrderListResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  requestDate: Date;

  @ApiProperty()
  @Expose()
  @Type(() => UserResponseDto)
  requester: UserResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => UserResponseDto)
  approver: UserResponseDto;

  @ApiProperty()
  @Expose()
  approvedAt: Date;

  @ApiProperty()
  @Expose()
  note: string;

  @ApiProperty()
  @Expose()
  @Type(() => SaleOrderDetail)
  saleOrderDetails: SaleOrderDetail[];
}
