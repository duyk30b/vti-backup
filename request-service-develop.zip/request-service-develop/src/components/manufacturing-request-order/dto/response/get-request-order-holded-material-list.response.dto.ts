import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';

class ItemTypeResponseDto extends BaseResponseDto {}
class ItemUnitResponseDto extends BaseResponseDto {}

class ItemResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => ItemTypeResponseDto)
  itemType: ItemTypeResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => ItemTypeResponseDto)
  itemUnit: ItemUnitResponseDto;
}

class ManufacturingRequestOrderReponseDto extends BaseResponseDto {}

export class GetRequestOrderHoldedMaterialListResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  @Transform(({ value }) => value || 0)
  stockQuantity: number;

  @ApiProperty()
  @Expose()
  @Transform(({ value }) => value || 0)
  holdedQuantity: number;

  @ApiProperty()
  @Expose()
  @Transform(({ value }) => value || 0)
  availableQuantity: number;

  @ApiProperty()
  @Expose()
  @Transform(({ value }) => value || 0)
  lackQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  material: ItemResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => ManufacturingRequestOrderReponseDto)
  requestOrder: ManufacturingRequestOrderReponseDto;
}
