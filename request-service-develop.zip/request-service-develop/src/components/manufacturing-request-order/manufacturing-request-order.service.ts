import { Inject, Injectable } from '@nestjs/common';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ManufacturingOrderServiceInterface } from './interface/manufacturing-request-order.service.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import {
  AttributeValue,
  RequestOrder,
} from 'src/models/request-order/request-order.model';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { RequestOrderRepositoryInterface } from '@components/request-order/interface/request-order.repository.interface';
import { RequestOrderDetailRepositoryInterface } from '@components/request-order/interface/request-order-detail.repository.interface.ts';
import {
  CreateRequestOrderBodyDto,
  CreateRequestOrderFormData,
} from '@components/request-order/dto/request/create-request-order.request.dto';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { AttributeServiceInterface } from '@components/attribute/interface/attribute.service.interface';
import { RequestOrderServiceAbstract } from '@components/request-order/request-order.service.abstract';
import { InjectConnection } from '@nestjs/mongoose';
import * as mongoose from 'mongoose';
import {
  manufacturingRequestOrderTemplateCodeEnum,
  MANUFACTURING_REQUEST_ORDER_DETAIL_TEMPLATE_CODE,
  MANUFACTURING_REQUEST_ORDER_FIELD_CODE,
  MANUFACTURING_REQUEST_STATUS_CAN_REJECT,
  MANUFACTURING_REQUEST_STATUS_CAN_CONFIRM,
  MANUFACTURING_ORDER_CONST,
  MANUFACTURING_REQUEST_ORDER_STATUS_ENUM,
  MANUFACTURING_REQUEST_STATUS_CAN_DELETE,
  CAN_UPDATE_STATUS_MANUFACTURING_REQUEST_ORDER_TO_IN_PROGRESS,
  MANUFACTURING_REQUEST_STATUS_CAN_COMPLETE,
  STATUS_TO_UPDATE_QUANTITY_PRODUCING_ORDER,
} from './manufacturing-request-order.constant';
import {
  isEmpty,
  map,
  uniq,
  filter,
  isEqual,
  flatMap,
  keyBy,
  first,
  find,
  compact,
} from 'lodash';
import { ResponsePayload } from '@utils/response-payload';
import { GetManufacturingOrderRequestListRequestDto } from './dto/request/get-manufacturing-request-order-list.request.dto';
import { GetManufacturingRequestOrderDetailRequestDto } from './dto/request/get-manufacturing-request-order-detail.request.dto';
import { plainToInstance } from 'class-transformer';
import { GetManufacturingRequestOrderDetailResponseDto } from './dto/response/get-manufacturing-request-order-detail.response.dto';
import { ApiError } from '@utils/api.error';
import { GetManufacturingRequestOrderListResponseDto } from './dto/response/get-manufacturing-request-order-list.response.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import * as moment from 'moment';
import { GetManufacturingRequestOrderByIdsResponseDto } from './dto/response/get-manufacturing-request-order-by-ids.response.dto';
import { GetManufacturingRequestOrderByIdsRequestDto } from './dto/request/get-manufacturing-request-order-by-ids.request.dto';
import { UpdateSoIsHasPlanRequestDto } from './dto/request/update-so-is-has-plan.request.dto';
import { REQUEST_ORDER_TYPE_ENUM } from '@components/request-order/request-order.constant';
import { ItemStockPlanningServiceInterface } from '@components/item-stock-planning/interface/item-stock-planning.service.interface';
import { minus, plus } from '@utils/helper';
import { getRegexByValue } from '@utils/common';
import { RequestOrderHoldedMaterialRepositoryInterface } from './interface/request-order-holded-material.repository.interface';
import { GetRequestOrderHoldedMaterialLiRequestDto } from './dto/request/get-request-order-holded-material-list.request.dto';
import { GetRequestOrderHoldedMaterialListResponseDto } from './dto/response/get-request-order-holded-material-list.response.dto';
import { FileServiceInterface } from '@components/file/interface/file.service.interface';
import { SaleServiceInterface } from '@components/sale-order/interface/sale.service.interface';
import { AutoCreateManufacturingRequestOrderRequestDto } from './dto/request/auto-create-manufacturing-request-order.request.dto';
import { UpdateProducedQuantityRequestDto } from './dto/request/update-produced-quantity.request.dto';

@Injectable()
export class ManufacturingOrderService
  extends RequestOrderServiceAbstract
  implements ManufacturingOrderServiceInterface
{
  constructor(
    @Inject('RequestOrderRepositoryInterface')
    protected readonly requestOrderRepository: RequestOrderRepositoryInterface,

    @Inject('AttributeServiceInterface')
    protected readonly attributeService: AttributeServiceInterface,

    @Inject('ItemStockPlanningServiceInterface')
    protected readonly itemStockPlanningService: ItemStockPlanningServiceInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('ProduceServiceInterface')
    protected readonly produceService: ProduceServiceInterface,

    @Inject('RequestOrderDetailRepositoryInterface')
    protected readonly requestOrderDetailRepository: RequestOrderDetailRepositoryInterface,

    @Inject('RequestOrderHoldedMaterialRepositoryInterface')
    protected readonly requestOrderHoldedMaterialRepository: RequestOrderHoldedMaterialRepositoryInterface,

    @Inject('FileServiceInterface')
    protected readonly fileService: FileServiceInterface,

    @Inject('SaleServiceInterface')
    protected readonly saleService: SaleServiceInterface,

    protected readonly i18n: I18nRequestScopeService,

    @InjectConnection()
    protected readonly connection: mongoose.Connection,
  ) {
    super(
      userService,
      requestOrderRepository,
      requestOrderDetailRepository,
      attributeService,
      i18n,
      connection,
    );
  }
  async save(
    requestOrderEntity: RequestOrder,
    payload: CreateRequestOrderFormData,
    attributeRequests: any,
    isUpdate?: boolean,
  ): Promise<any> {
    const { data, files } = payload;
    const { attributeValues, requestOrderDetails, id } = data;
    if (!isUpdate) {
      const codeExist = await this.requestOrderRepository.findOneByCondition({
        attributeValues: {
          $elemMatch: {
            code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.CODE,
            value: attributeValues.find(
              (attributeValue) =>
                attributeValue.code ===
                MANUFACTURING_REQUEST_ORDER_FIELD_CODE.CODE,
            ).value,
          },
        },
      });
      if (codeExist)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.CODE_EXIST'))
          .build();
      requestOrderEntity.attributeValues.find(
        (attributeValue) =>
          attributeValue.code === MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
      ).value = MANUFACTURING_REQUEST_ORDER_STATUS_ENUM.PENDING;
    }

    const concatnatedAttributeValues = [
      ...attributeValues,
      ...flatMap(requestOrderDetails, (i) => i.attributeValues),
    ] as any[];

    let [userIds, itemIds, bomVersionIds] = this.getValueOfAttributesByCode(
      concatnatedAttributeValues,
      [
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.REQUEST_USER_ID,
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ITEM_ID,
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.BOM_VERSION_ID,
      ],
    );
    bomVersionIds = bomVersionIds.filter(
      (bomVersionId) => bomVersionId != null,
    );
    const checkedResult = await this.checkExistance({
      id,
      itemIds,
      bomVersionIds,
      userIds,
    });
    if (checkedResult.statusCode !== ResponseCodeEnum.SUCCESS) {
      return checkedResult;
    }
    if (isUpdate) {
      const statusAttribute = requestOrderEntity.attributeValues.find(
        (attributeValue) =>
          attributeValue.code == MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
      );
      const status = statusAttribute ? +statusAttribute.value : null;
      if (status === MANUFACTURING_REQUEST_ORDER_STATUS_ENUM.REJECT) {
        requestOrderEntity.attributeValues.find(
          (attributeValue) =>
            attributeValue.code ==
            MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
        ).value = MANUFACTURING_REQUEST_ORDER_STATUS_ENUM.PENDING;
      }
    }

    const requestDateAttribute = requestOrderEntity.attributeValues.find(
      (attributeValue) =>
        attributeValue.code ==
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.REQUEST_DATE,
    );
    if (!isEmpty(requestDateAttribute)) {
      requestOrderEntity.attributeValues.find(
        (attributeValue) =>
          attributeValue.code ==
          MANUFACTURING_REQUEST_ORDER_FIELD_CODE.REQUEST_DATE,
      ).value = new Date(requestDateAttribute.value);
    }

    const currentEntity = isUpdate
      ? await this.requestOrderRepository.findOneById(requestOrderEntity._id)
      : null;
    const currentFilesAttribute = currentEntity?.attributeValues?.find(
      (attributeValue) =>
        attributeValue.code === MANUFACTURING_REQUEST_ORDER_FIELD_CODE.FILES,
    );
    const oldFilesAttribute = data.attributeValues.find(
      (attributeValue) =>
        attributeValue.code === MANUFACTURING_REQUEST_ORDER_FIELD_CODE.FILES,
    );
    const saveFileResponse = await this.fileService.handleSaveFiles(
      currentFilesAttribute?.value || [],
      oldFilesAttribute?.value?.filter((file) => !isEmpty(file)) || null,
      files,
    );
    if (saveFileResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
      return saveFileResponse;
    }
    requestOrderEntity.attributeValues.find(
      (attributeValue) =>
        attributeValue.code === MANUFACTURING_REQUEST_ORDER_FIELD_CODE.FILES,
    ).value = saveFileResponse.data;

    return await super.save(
      requestOrderEntity,
      payload,
      attributeRequests,
      isUpdate,
    );
  }

  async getDetail(
    request: GetManufacturingRequestOrderDetailRequestDto,
  ): Promise<any> {
    const { id } = request;
    const data = await this.requestOrderRepository.getDetail(id);
    if (isEmpty(data)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const beautifiedData = first(this.beautifyRequestOrder([data]));

    const resData = plainToInstance(
      GetManufacturingRequestOrderDetailResponseDto,
      {
        ...beautifiedData,
        requestOrderDetails:
          beautifiedData.requestOrderDetails?.map((requestOrderDetail) => {
            return {
              bomVersionId:
                +requestOrderDetail[
                  MANUFACTURING_REQUEST_ORDER_FIELD_CODE.BOM_VERSION_ID
                ]?.value,
              itemId:
                +requestOrderDetail[
                  MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ITEM_ID
                ]?.value,
              quantity:
                +requestOrderDetail[
                  MANUFACTURING_REQUEST_ORDER_FIELD_CODE.QUANTITY
                ]?.value,
              deadline:
                requestOrderDetail[
                  'mesxDeadline' ||
                    MANUFACTURING_REQUEST_ORDER_FIELD_CODE.DEADLINE
                ]?.value,
            };
          }) || [],
      },
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(resData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDetailByTemplate(
    request: GetManufacturingRequestOrderDetailRequestDto,
  ): Promise<any> {
    const { id } = request;

    const data = await this.requestOrderRepository.getDetail(id);
    if (isEmpty(data)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const template = await this.attributeService.getTemplateByCode(
      manufacturingRequestOrderTemplateCodeEnum.CREATE,
    );

    if (isEmpty(template)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.TEMPLATE_NOT_FOUND'))
        .build();
    }

    const concatnatedAttributeValues = [
      ...data.attributeValues,
      ...flatMap(data.requestOrderDetails, (i) => {
        return i.attributeValues;
      }),
    ];

    const [userIds, itemIds, bomVersionIds, fileIds] =
      this.getValueOfAttributesByCode(concatnatedAttributeValues, [
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.REQUEST_USER_ID,
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ITEM_ID,
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.BOM_VERSION_ID,
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.FILES,
      ]);

    let files = [];
    if (!isEmpty(fileIds[0])) {
      files = await this.fileService.getFilesByIds(fileIds[0]);
    }

    const [serializedUser, serializedItem, serializedBomVersion] =
      await Promise.all([
        this.userService.getUsersByIds(userIds, true),
        this.itemService.getItemByIds(itemIds, true),
        this.produceService.getListBomVersionByIds(bomVersionIds, true),
      ]);

    let beautifiedData = first(this.beautifyRequestOrder([data]));
    beautifiedData = {
      ...beautifiedData,
      [MANUFACTURING_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.REQUEST_USER_ID]: {
        value:
          serializedUser[
            beautifiedData[
              MANUFACTURING_REQUEST_ORDER_FIELD_CODE.REQUEST_USER_ID
            ]?.value
          ],
      },
      [MANUFACTURING_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.FILES]: {
        value: files,
      },
      requestOrderDetails: beautifiedData.requestOrderDetails.map((i) => {
        return {
          ...i,
          [MANUFACTURING_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.DETAIL.ITEM_NAME]: {
            value:
              serializedItem[
                i[MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ITEM_ID]?.value
              ]?.name,
          },
          [MANUFACTURING_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.DETAIL.ITEM_ID]: {
            value:
              serializedItem[
                i[MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ITEM_ID]?.value
              ],
          },
          [MANUFACTURING_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.DETAIL
            .ITEM_UNIT_ID]: {
            value:
              serializedItem[
                i[MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ITEM_ID]?.value
              ]?.itemConvertUnits?.find(
                (itemConvertUnit) =>
                  itemConvertUnit?.itemUnit?.id ===
                  i[MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ITEM_UNIT_ID]?.value,
              )?.itemUnit ||
              serializedItem[
                i[MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ITEM_ID]?.value
              ]?.itemUnit,
          },
          [MANUFACTURING_REQUEST_ORDER_DETAIL_TEMPLATE_CODE.DETAIL
            .BOM_VERSION_ID]: {
            value:
              serializedBomVersion[
                i[MANUFACTURING_REQUEST_ORDER_FIELD_CODE.BOM_VERSION_ID]?.value
              ],
          },
        };
      }),
    };

    return this.makeResponse(template, beautifiedData);
  }

  async getList(
    request: GetManufacturingOrderRequestListRequestDto,
  ): Promise<any> {
    const { filter, sort } = request;
    let filterObj = {};
    let sortObj = {};
    let attributeValuesFilter = [];
    let detailAttributeValuesFilter = [];

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'status':
            attributeValuesFilter.push({
              attributeValues: {
                $elemMatch: {
                  value: +value,
                  code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
                },
              },
            });
            break;
          case 'requestUserIds':
            attributeValuesFilter.push({
              attributeValues: {
                $elemMatch: {
                  value: {
                    $in: item.text?.split(',')?.map((e) => +e),
                  },
                  code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.REQUEST_USER_ID,
                },
              },
            });
            break;
          case 'approvedIds':
            attributeValuesFilter.push({
              attributeValues: {
                $elemMatch: {
                  value: { $in: item.text?.split(',')?.map((e) => +e) },
                  code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.APPROVED_ID,
                },
              },
            });
            break;
          case 'bomVersionIds':
            detailAttributeValuesFilter.push({
              'requestOrderDetails.attributeValues': {
                $elemMatch: {
                  value: { $in: item.text?.split(',')?.map((e) => +e) },
                  code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.BOM_VERSION_ID,
                },
              },
            });
            break;
          case 'approvedAt':
            attributeValuesFilter.push({
              attributeValues: {
                $elemMatch: {
                  value: {
                    $gte: moment(item.text.split('|')[0])
                      .startOf('day')
                      .toDate(),
                    $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
                  },
                  code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.APPROVED_AT,
                },
              },
            });
            break;
          case 'code':
            attributeValuesFilter.push({
              attributeValues: {
                $elemMatch: {
                  value: {
                    $regex: '.*' + value + '.*',
                    $options: 'i',
                  },
                  code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.CODE,
                },
              },
            });
            break;
          case 'requestDate':
            attributeValuesFilter.push({
              attributeValues: {
                $elemMatch: {
                  value: {
                    $gte: moment(item.text.split('|')[0])
                      .startOf('day')
                      .toDate(),
                    $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
                  },
                  code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.REQUEST_DATE,
                },
              },
            });
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        switch (item.column) {
          case 'status':
            sortObj = {
              [`attributeValues.${MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS}`]:
                item.order,
            };
            break;
          case 'approvedAt':
            sortObj = {
              [`attributeValues.${MANUFACTURING_REQUEST_ORDER_FIELD_CODE.APPROVED_AT}`]:
                item.order,
            };
            break;
          case 'code':
            sortObj = {
              [`attributeValues.${MANUFACTURING_REQUEST_ORDER_FIELD_CODE.CODE}`]:
                item.order,
            };
            break;
          case 'requestDate':
            sortObj = {
              [`attributeValues.${MANUFACTURING_REQUEST_ORDER_FIELD_CODE.REQUEST_DATE}`]:
                item.order,
            };
            break;
          default:
            break;
        }
      });
    }

    if (
      !isEmpty(attributeValuesFilter) ||
      !isEmpty(detailAttributeValuesFilter)
    )
      filterObj = {
        ...filterObj,
        $and: [...attributeValuesFilter, ...detailAttributeValuesFilter],
      };
    request.requestOrderType =
      REQUEST_ORDER_TYPE_ENUM.MANUFACTURING_REQUEST_ORDER;

    request.filterObj = filterObj;
    const { data, count } = await this.requestOrderRepository.getList(request);

    const concatnatedAttributeValues = [
      ...flatMap(data, (i) => {
        return i.attributeValues;
      }),
    ];

    const [userIds, approvedIds] = this.getValueOfAttributesByCode(
      concatnatedAttributeValues,
      [
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.REQUEST_USER_ID,
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.APPROVED_ID,
      ],
    );

    const [serializedUser] = await Promise.all([
      this.userService.getUsersByIds(uniq([...userIds, ...approvedIds]), true),
    ]);

    const beautifiedData = this.beautifyRequestOrder(data);

    const resData = plainToInstance(
      GetManufacturingRequestOrderListResponseDto,
      beautifiedData.map((i) => {
        return {
          ...i,
          code: i[MANUFACTURING_REQUEST_ORDER_FIELD_CODE.CODE]?.value,
          requestDate:
            i[MANUFACTURING_REQUEST_ORDER_FIELD_CODE.REQUEST_DATE]?.value,
          note: i[MANUFACTURING_REQUEST_ORDER_FIELD_CODE.NOTE]?.value,
          requester:
            serializedUser[
              i[MANUFACTURING_REQUEST_ORDER_FIELD_CODE.REQUEST_USER_ID]?.value
            ],
          approver:
            serializedUser[
              i[MANUFACTURING_REQUEST_ORDER_FIELD_CODE.APPROVED_ID]?.value
            ],
          approvedAt:
            i[MANUFACTURING_REQUEST_ORDER_FIELD_CODE.APPROVED_AT]?.value,
          status: i[MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS]?.value,
          saleOrderDetails:
            i.requestOrderDetails?.map((requestOrderDetail) => {
              return {
                bomVersionId:
                  +requestOrderDetail[
                    MANUFACTURING_REQUEST_ORDER_FIELD_CODE.BOM_VERSION_ID
                  ]?.value,
                itemId:
                  +requestOrderDetail[
                    MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ITEM_ID
                  ]?.value,
                deadline:
                  requestOrderDetail[
                    'mesxDeadline' ||
                      MANUFACTURING_REQUEST_ORDER_FIELD_CODE.DEADLINE
                  ]?.value,
              };
            }) || [],
        };
      }),
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder({
      items: resData,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async delete(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const manufacturingRequestOrder =
      await this.requestOrderRepository.findOneById(id);
    if (isEmpty(manufacturingRequestOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate(
            'error.MANUFACTURING_REQUEST_ORDER_NOT_FOUND',
          ),
        )
        .build();
    }

    const statusAttribute = manufacturingRequestOrder.attributeValues.find(
      (attributeValue) =>
        attributeValue.code === MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
    );
    const status = statusAttribute ? +statusAttribute.value : null;
    if (!MANUFACTURING_REQUEST_STATUS_CAN_DELETE.includes(status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.MANUFACTURING_REQUEST_ORDER_STATUS_INVALID',
          ),
        )
        .build();
    }
    await this.requestOrderRepository.softDelete(id);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.DELETE_SUCCESS'))
      .build();
  }

  async confirm(request: IdParamMongoDto): Promise<any> {
    const { id, userId } = request;
    const manufacturingRequestOrder =
      await this.requestOrderRepository.findOneWithPopulate(
        {
          _id: id,
        },
        'requestOrderDetails',
      );
    if (isEmpty(manufacturingRequestOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate(
            'error.MANUFACTURING_REQUEST_ORDER_NOT_FOUND',
          ),
        )
        .build();
    }
    const statusAttribute = manufacturingRequestOrder.attributeValues.find(
      (attributeValue) =>
        attributeValue.code === MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
    );
    const status = statusAttribute ? +statusAttribute.value : null;
    if (!MANUFACTURING_REQUEST_STATUS_CAN_CONFIRM.includes(status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.MANUFACTURING_REQUEST_ORDER_STATUS_INVALID',
          ),
        )
        .build();
    }
    const beautifiedData = this.beautifyRequestOrder([
      manufacturingRequestOrder,
    ])[0];
    const attributeValues = [];

    attributeValues.push(
      ...beautifiedData.attributeValues,
      ...flatMap(beautifiedData.requestOrderDetails, 'attributeValues'),
    );

    const [itemIds, bomVersionIds] = this.getValueOfAttributesByCode(
      attributeValues,
      [
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ITEM_ID,
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.BOM_VERSION_ID,
      ],
    );
    const items = await this.itemService.getItemByIds(itemIds);
    if (!items || itemIds.length !== items.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }
    if (bomVersionIds.includes(null)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.BOM_VERSION_MUST_REQUIRED'),
        )
        .build();
    }
    const bomVersions = await this.produceService.getListBomVersionByIds(
      bomVersionIds,
    );
    if (!bomVersions || bomVersionIds.length !== bomVersions.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.BOM_VERSION_NOT_FOUND'))
        .build();
    }

    try {
      const attributes = await this.attributeService.getAttributeByCodes([
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.APPROVED_ID,
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.APPROVED_AT,
      ]);
      manufacturingRequestOrder.attributeValues = [
        ...manufacturingRequestOrder.attributeValues,
        {
          attributeId: attributes.find(
            (attribute) =>
              attribute.code ===
              MANUFACTURING_REQUEST_ORDER_FIELD_CODE.APPROVED_ID,
          ).id,
          code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.APPROVED_ID,
          value: userId,
        },
        {
          attributeId: attributes.find(
            (attribute) =>
              attribute.code ===
              MANUFACTURING_REQUEST_ORDER_FIELD_CODE.APPROVED_AT,
          ).id,
          code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.APPROVED_AT,
          value: new Date(Date.now()),
        },
      ];
      manufacturingRequestOrder.attributeValues.find(
        (attributeValue) =>
          attributeValue.code === MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
      ).value = MANUFACTURING_REQUEST_ORDER_STATUS_ENUM.CONFIRMED;

      await this.requestOrderRepository.findByIdAndUpdate(
        id,
        manufacturingRequestOrder,
      );

      const result = await this.createRequestOrderHoldedMaterial(id);
      if (result.statusCode !== ResponseCodeEnum.SUCCESS) {
        return result;
      }

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'error.CONFIRM_MANUFACTURING_REQUEST_ORDER_SUCCESS',
          ),
        )
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async reject(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const manufacturingRequestOrder =
      await this.requestOrderRepository.findOneById(id);
    if (isEmpty(manufacturingRequestOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate(
            'error.MANUFACTURING_REQUEST_ORDER_NOT_FOUND',
          ),
        )
        .build();
    }

    const statusAttribute = manufacturingRequestOrder.attributeValues.find(
      (attributeValue) =>
        attributeValue.code === MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
    );
    const status = statusAttribute ? +statusAttribute.value : null;
    if (!MANUFACTURING_REQUEST_STATUS_CAN_REJECT.includes(status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.MANUFACTURING_REQUEST_ORDER_STATUS_INVALID',
          ),
        )
        .build();
    }

    try {
      manufacturingRequestOrder.attributeValues.find(
        (attributeValue) =>
          attributeValue.code === MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
      ).value = MANUFACTURING_REQUEST_ORDER_STATUS_ENUM.REJECT;
      await this.requestOrderRepository.findByIdAndUpdate(
        id,
        manufacturingRequestOrder,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'error.REJECT_MANUFACTURING_REQUEST_ORDER_SUCCESS',
          ),
        )
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getManufacturingRequestOrdersTcp(
    request: GetManufacturingRequestOrderByIdsRequestDto,
  ): Promise<any> {
    const { filter } = request;
    let filterObj = {};

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'ids':
            filterObj = {
              ...filterObj,
              _id: {
                $in: item.text?.split(','),
              },
            };
            break;
          case 'code':
            filterObj = {
              ...filterObj,
              attributeValues: {
                $elemMatch: {
                  value: getRegexByValue(item.text),
                  code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.CODE,
                },
              },
            };
            break;
        }
      });
    }
    const data = await this.requestOrderRepository.findAllWithPopulate(
      filterObj,
      ['requestOrderDetails'],
    );

    const beautifiedData = this.beautifyRequestOrder(data);
    const attributeValues = [];
    beautifiedData.forEach((itemData) => {
      attributeValues.push(
        ...itemData.attributeValues,
        ...flatMap(itemData.requestOrderDetails, 'attributeValues'),
      );
    });

    const [userIds, itemIds, bomVersionIds] = this.getValueOfAttributesByCode(
      attributeValues,
      [
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.REQUEST_USER_ID,
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ITEM_ID,
        MANUFACTURING_REQUEST_ORDER_FIELD_CODE.BOM_VERSION_ID,
      ],
    );
    const [serializedUser, serializedItem, serializedBomVersion] =
      await Promise.all([
        this.userService.getUsersByIds(userIds, true),
        this.itemService.getItemByIds(itemIds, true),
        this.produceService.getListBomVersionByIds(bomVersionIds, true),
      ]);
    const boms = await this.produceService.getBomByItemIds(itemIds);
    const bomsSerialize = keyBy(boms, 'itemId');
    const manufacturingOrders =
      await this.produceService.getAllManufacturingOrder(
        beautifiedData.map(
          (manufacturingRequestOrder) => manufacturingRequestOrder.id,
        ),
      );
    const moDetails = {};
    manufacturingOrders.forEach((mo) => {
      mo.manufacturingOrderDetails.forEach((mod) => {
        moDetails[mo.id + '_' + mod.itemId] = mod;
      });
    });

    const resData = plainToInstance(
      GetManufacturingRequestOrderByIdsResponseDto,
      beautifiedData.map((requestOrder) => {
        return {
          _id: requestOrder._id,
          code: requestOrder[MANUFACTURING_REQUEST_ORDER_FIELD_CODE.CODE].value,
          requestUserId:
            +requestOrder[
              MANUFACTURING_REQUEST_ORDER_FIELD_CODE.REQUEST_USER_ID
            ].value,

          requestUser:
            serializedUser[
              +requestOrder[
                MANUFACTURING_REQUEST_ORDER_FIELD_CODE.REQUEST_USER_ID
              ].value
            ],
          approvedId:
            +requestOrder[MANUFACTURING_REQUEST_ORDER_FIELD_CODE.APPROVED_ID]
              ?.value,
          requestOrderDetails:
            requestOrder.requestOrderDetails?.map((requestOrderDetail) => {
              const itemId =
                +requestOrderDetail[
                  MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ITEM_ID
                ]?.value;
              const bomVersionId =
                +requestOrderDetail[
                  MANUFACTURING_REQUEST_ORDER_FIELD_CODE.BOM_VERSION_ID
                ]?.value;
              const quantity =
                +requestOrderDetail[
                  MANUFACTURING_REQUEST_ORDER_FIELD_CODE.QUANTITY
                ]?.value;
              let unmanufacturedQuantity = quantity;
              manufacturingOrders.forEach((mo) => {
                mo?.manufacturingOrderDetails.forEach((mod) => {
                  if (itemId === mod.itemId) {
                    unmanufacturedQuantity -=
                      moDetails[mo.id + '_' + mod.itemId]?.quantity;
                  }
                });
              });

              return {
                bomVersionId: bomVersionId,
                bomVersion: serializedBomVersion[bomVersionId],
                itemId:
                  +requestOrderDetail[
                    MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ITEM_ID
                  ].value,
                item: {
                  ...serializedItem[itemId],
                  bom: bomsSerialize[itemId],
                },
                quantity,
                unmanufacturedQuantity,
              };
            }) || [],
        };
      }),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(resData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  // assign value to attribute template
  private async makeResponse(template: any, beautifiedData: any) {
    let { attributeHeaders, attributeGroups } = template;
    attributeHeaders = attributeHeaders.map((attributeHeader) => {
      return {
        ...attributeHeader,
        attribute: {
          ...attributeHeader.attribute,
          value: beautifiedData[attributeHeader.attribute.code]?.value,
        },
      };
    });

    const requestOrderDetails = beautifiedData.requestOrderDetails;
    attributeGroups = attributeGroups.map((attributeGroup) => {
      return requestOrderDetails.map((requestOrderDetail) => {
        if (
          isEqual(
            requestOrderDetail.groupId.toString(),
            attributeGroup.attributes[0].attributeGroup.id.toString(),
          )
        ) {
          const attributes = attributeGroup.attributes.map((attribute) => {
            return {
              ...attribute,
              attribute: {
                ...attribute.attribute,
                value: requestOrderDetail[attribute.attribute.code]?.value,
              },
            };
          });
          return { ...attributeGroup, attributes };
        }
        return attributeGroup;
      });
    });
    return new ResponseBuilder({
      ...template,
      attributeHeaders,
      attributeGroups,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private beautifyRequestOrder(data: any[]): any[] {
    return data.map((requestOrder) => {
      const generalInfo = keyBy(
        requestOrder.attributeValues.map((attributeValue) => {
          return { key: attributeValue.code, value: attributeValue.value };
        }),
        'key',
      );

      let requestOrderDetails = requestOrder.requestOrderDetails;
      if (!isEmpty(requestOrderDetails)) {
        requestOrderDetails = requestOrderDetails.map((requestOrderDetail) => {
          const generalInfo = keyBy(
            requestOrderDetail.attributeValues.map((attributeValue) => {
              return { key: attributeValue.code, value: attributeValue.value };
            }),
            'key',
          );
          return { ...requestOrderDetail, ...generalInfo };
        });
      }

      return { ...requestOrder, ...generalInfo, requestOrderDetails };
    });
  }

  private getValueOfAttributesByCode(
    attributeValues: AttributeValue[],
    codes: string[],
    isNotNumber?: boolean,
  ): any[] {
    return codes.map((code) => {
      return uniq(
        map(
          filter(
            attributeValues,
            (attributeValue) => attributeValue.code === code,
          ),
          (i) => {
            return i.value;
          },
        ),
      );
    });
  }

  private async checkExistance(data: any): Promise<ResponsePayload<any>> {
    const { id, itemIds, bomVersionIds, userIds } = data;

    switch (true) {
      case id && isEmpty(await this.requestOrderRepository.findOneById(id)):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
        break;
      case itemIds &&
        !isEqual(
          (await this.itemService.getItemByIds(itemIds)).length,
          itemIds.length,
        ):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.ITEM_NOT_FOUND'))
          .build();
        break;

      case bomVersionIds &&
        !isEqual(
          (await this.produceService.getListBomVersionByIds(bomVersionIds))
            .length,
          bomVersionIds.length,
        ):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.BOM_VERSION_NOT_FOUND'))
          .build();
        break;

      case userIds &&
        !isEqual(
          (await this.userService.getUsersByIds(userIds)).length,
          userIds.length,
        ):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.USER_NOT_FOUND'))
          .build();
        break;
      default:
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
    }
  }

  async generateCode(): Promise<any> {
    const prefixCodeDefault =
      MANUFACTURING_ORDER_CONST.CODE.PREFIX_CODE_DEFAULT;
    let startCodeDefault = MANUFACTURING_ORDER_CONST.CODE.START_CODE_DEFAULT;
    const middleCodeDefault =
      MANUFACTURING_ORDER_CONST.CODE.MIDDLE_CODE_DEFAULT;
    const validPattern = new RegExp(
      `^${prefixCodeDefault}\.\\d{${middleCodeDefault.length}}\.\\d{${startCodeDefault.length}}$`,
    );
    const currentDay = moment().utcOffset(7).format(middleCodeDefault);

    const lastRequestOrder =
      await this.requestOrderRepository.getLastRequestOrder(
        REQUEST_ORDER_TYPE_ENUM.MANUFACTURING_REQUEST_ORDER,
      );
    const code =
      lastRequestOrder?.attributeValues?.find(
        (attributeValue) =>
          attributeValue.code === MANUFACTURING_REQUEST_ORDER_FIELD_CODE.CODE,
      )?.value || null;

    const count = plus(await this.requestOrderRepository.count(), 1);

    let generatedCode;

    if (
      isEmpty(lastRequestOrder) ||
      (code && !validPattern.test(code)) ||
      code.split('.')[1] != currentDay
    ) {
      generatedCode = `${prefixCodeDefault}.${currentDay}.${startCodeDefault}`;
    } else {
      const stt = Number(code.split('.')[2]) + 1;

      const sttString = ('0'.repeat(startCodeDefault.length) + stt).slice(
        -startCodeDefault.length,
      );
      startCodeDefault = sttString;
      generatedCode = `${prefixCodeDefault}.${currentDay}.${startCodeDefault}`;
    }

    return new ResponseBuilder({
      code: generatedCode,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateManufacturingRequestOrderIsHasPlan(
    request: UpdateSoIsHasPlanRequestDto,
  ): Promise<any> {
    const { ids } = request;
    const manufacturingRequestOrderEntities: any[] = [];
    const manufacturingRequestOrders =
      await this.requestOrderRepository.findAllByCondition({
        _id: { $in: ids },
      });
    for (let i = 0; i < manufacturingRequestOrders.length; i++) {
      const manufacturingRequestOrder = manufacturingRequestOrders[i];
      const ishasPlanAttributeExist =
        manufacturingRequestOrder.attributeValues.find(
          (attributevalue) =>
            attributevalue.code ===
            MANUFACTURING_REQUEST_ORDER_FIELD_CODE.IS_HAS_PLAN,
        );
      if (!ishasPlanAttributeExist) {
        const attributeByCodes =
          await this.attributeService.getAttributeByCodes([
            MANUFACTURING_REQUEST_ORDER_FIELD_CODE.IS_HAS_PLAN,
          ]);
        const isHasPlanAttribute = attributeByCodes
          ? attributeByCodes[0]
          : null;
        if (isHasPlanAttribute) {
          manufacturingRequestOrder.attributeValues.push({
            attributeId: isHasPlanAttribute.id,
            code: isHasPlanAttribute.code,
            value: true,
          });
        }
      }
      let statusAttribute = manufacturingRequestOrder.attributeValues.find(
        (attributevalue) =>
          attributevalue.code === MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
      );
      if (statusAttribute) {
        manufacturingRequestOrder.attributeValues.find(
          (attributeValue) =>
            attributeValue.code ===
            MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
        ).value = MANUFACTURING_REQUEST_ORDER_STATUS_ENUM.PLANNED;
      }
      manufacturingRequestOrderEntities.push(manufacturingRequestOrder);
    }
    const bulkOps = manufacturingRequestOrderEntities.map(
      (manufacturingRequestOrderEntity) => ({
        updateOne: {
          filter: { _id: manufacturingRequestOrderEntity._id },
          update: {
            ...manufacturingRequestOrderEntity,
          },
          upsert: false,
        },
      }),
    );
    await this.requestOrderRepository.bulkWrite(bulkOps);
    try {
    } catch (error) {
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async createRequestOrderHoldedMaterial(
    requestOrderId: string,
  ): Promise<any> {
    const requestOrder = (
      await this.getDetail({
        id: requestOrderId,
      } as GetManufacturingRequestOrderDetailRequestDto)
    ).data;

    const payload = map(requestOrder.requestOrderDetails, (i) => {
      return {
        id: i.itemId,
        bomVersionId: i.bomVersionId,
        quantity: i.quantity,
      };
    });
    const materials = await this.produceService.previewMaterials(payload);
    const requestOrderHoldedMaterialDocuments = [];
    map(materials, (i) => {
      requestOrderHoldedMaterialDocuments.push(
        this.requestOrderHoldedMaterialRepository.createDocument({
          requestOrderId: requestOrder.id,
          itemId: i.item.id,
          materialId: i.material.id,
          holdedQuantity: i.material.planQuantity,
        }),
      );
    });

    const bulkOps = requestOrderHoldedMaterialDocuments.map(
      (requestOrderHoldedMaterial) => ({
        updateOne: {
          filter: { _id: requestOrderHoldedMaterial._id },
          update: {
            ...requestOrderHoldedMaterial['_doc'],
          },
          upsert: true,
        },
      }),
    );
    try {
      await this.requestOrderHoldedMaterialRepository.bulkWrite(bulkOps);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async GetRequestOrderHoldedMaterialList(
    request: GetRequestOrderHoldedMaterialLiRequestDto,
  ): Promise<any> {
    const { data, count } =
      await this.requestOrderHoldedMaterialRepository.getList(request);

    const [serializedItem] = await Promise.all([
      await this.itemService.getItemByIds(uniq(map(data, 'materialId')), true),
    ]);

    const holdedItems = await this.itemStockPlanningService.getHoldedItemList(
      [],
    );
    const serializedHoldedItem = holdedItems.reduce((prev, cur) => {
      if (prev[cur.itemId]) {
        return {
          ...prev,
          [cur.itemId]: {
            ...prev[cur.itemId],
            holdedQuantity: plus(
              cur.holdedQuantity,
              prev[cur.itemId].holdedQuantity,
            ),
            stockQuantity: plus(
              cur.stockQuantity,
              prev[cur.itemId].stockQuantity,
            ),
          },
        };
      } else {
        return {
          ...prev,
          [cur.itemId]: {
            itemId: cur.itemId,
            holdedQuantity: cur.holdedQuantity,
            stockQuantity: cur.stockQuantity,
          },
        };
      }
    }, {});

    const resData = plainToInstance(
      GetRequestOrderHoldedMaterialListResponseDto,
      map(data, (i) => {
        const stockQuantity =
          serializedHoldedItem[i.itemId]?.stockQuantity || 0;
        const holdedQuantity = i.holdedQuantity || 0;
        const availableQuantity =
          minus(stockQuantity, holdedQuantity) > 0
            ? minus(stockQuantity, holdedQuantity)
            : 0;
        const lackQuantity =
          minus(holdedQuantity, availableQuantity) > 0
            ? minus(holdedQuantity, availableQuantity)
            : 0;
        return {
          ...i,
          stockQuantity,
          holdedQuantity,
          availableQuantity,
          lackQuantity,
          material: serializedItem[i.materialId],
          requestOrder: {
            id: i._id,
            code: find(
              i.requestOrder.attributeValues,
              (i) => i.code === MANUFACTURING_REQUEST_ORDER_FIELD_CODE.CODE,
            ).value,
          },
        };
      }),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder({
      items: resData,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload UpdateManufacturingRequestOrderStatusToInprogress
   * @returns
   */
  public async updateManufacturingRequestOrderStatusToInprogress(
    payload: IdParamMongoDto,
  ): Promise<any> {
    const { id } = payload;
    const manufacturingRequestOrder =
      await this.requestOrderRepository.findOneById(id);

    if (!manufacturingRequestOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const statusAttribute = manufacturingRequestOrder.attributeValues?.find(
      (attributeValue) =>
        attributeValue.code === MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
    );
    try {
      if (!isEmpty(statusAttribute)) {
        if (
          !CAN_UPDATE_STATUS_MANUFACTURING_REQUEST_ORDER_TO_IN_PROGRESS.includes(
            statusAttribute?.value,
          )
        ) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.FORBIDDEN)
            .withMessage(
              await this.i18n.translate(
                'error.MANUFACTURING_REQUEST_ORDER_STATUS_INVALID',
              ),
            )
            .build();
        }
        manufacturingRequestOrder.attributeValues.find(
          (attributeValue) =>
            attributeValue.code ===
            MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
        ).value = MANUFACTURING_REQUEST_ORDER_STATUS_ENUM.INPROGRESS;
        await this.requestOrderRepository.findByIdAndUpdate(
          id,
          manufacturingRequestOrder,
        );
      }
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async complete(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const manufacturingRequestOrder =
      await this.requestOrderRepository.findOneById(id);
    if (isEmpty(manufacturingRequestOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate(
            'error.MANUFACTURING_REQUEST_ORDER_NOT_FOUND',
          ),
        )
        .build();
    }
    const statusAttribute = manufacturingRequestOrder.attributeValues.find(
      (attributeValue) =>
        attributeValue.code === MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
    );
    const status = statusAttribute ? +statusAttribute.value : null;
    if (!MANUFACTURING_REQUEST_STATUS_CAN_COMPLETE.includes(status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.MANUFACTURING_REQUEST_ORDER_STATUS_INVALID',
          ),
        )
        .build();
    }

    try {
      manufacturingRequestOrder.attributeValues.find(
        (attributeValue) =>
          attributeValue.code === MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
      ).value = MANUFACTURING_REQUEST_ORDER_STATUS_ENUM.COMPLETED;

      await this.requestOrderRepository.findByIdAndUpdate(
        id,
        manufacturingRequestOrder,
      );

      const response =
        await this.produceService.completeMoByCompletedManufacturingRequestOrderId(
          id,
        );
      if (response.statusCode != ResponseCodeEnum.SUCCESS) {
        return response;
      }

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'error.COMPLETE_MANUFACTURING_REQUEST_ORDER_SUCCESS',
          ),
        )
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async autoCreate(request: AutoCreateManufacturingRequestOrderRequestDto) {
    const { soId } = request;

    const saleOrder = first(
      await this.saleService.getSaleOrdersByIds({
        ids: [soId],
        withDetail: false,
      }),
    ) as any;

    //get latest bom-version by item ids
    const bomVersions = await this.produceService.getBomVersionByItemIds(
      compact(uniq(map(saleOrder.saleOrderDetails, 'itemId'))),
    );
    const serializedBomVersion = keyBy(bomVersions, 'itemId') as any;

    //make m-request-order
    const attributeValues = [
      {
        code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.FILES,
        value: [],
      },
      {
        code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
        value: '',
      },
      {
        code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.CODE,
        value: (await this.generateCode()).data.code,
      },
      {
        code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.REQUEST_DATE,
        value: null,
      },
      {
        code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.SALE_ORDER_ID,
        value: saleOrder.id,
      },
    ];
    const template = (await this.attributeService.getTemplateByCode(
      manufacturingRequestOrderTemplateCodeEnum.CREATE,
    )) as any;
    const groupId = (first(template.attributeGroups) as any).id;

    const requestOrderDetails = [];
    for (const i of saleOrder.saleOrderDetails) {
      const requestOrderDetail = {
        groupId: groupId,
        attributeValues: [
          {
            code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ITEM_ID,
            value: i.itemId,
          },
          {
            code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.BOM_VERSION_ID,
            value: serializedBomVersion[i.itemId]?.latestVersion.id,
          },
          {
            code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.QUANTITY,
            value: i.quantity,
          },
          {
            code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.DEADLINE,
            value: i.deadline,
          },
        ],
      };
      requestOrderDetails.push(requestOrderDetail);
    }

    const createRequestOrderFormData = new CreateRequestOrderFormData();
    createRequestOrderFormData.data = {
      type: REQUEST_ORDER_TYPE_ENUM.MANUFACTURING_REQUEST_ORDER,
      templateId: template.id,
      attributeValues,
      requestOrderDetails,
    } as CreateRequestOrderBodyDto;
    createRequestOrderFormData.files = [];

    return await this.create(createRequestOrderFormData);
  }

  async updateProducedQuantity(
    request: UpdateProducedQuantityRequestDto,
  ): Promise<any> {
    const { id, items } = request;
    const manufacturingRequestOrder =
      await this.requestOrderRepository.getDetail(id);
    if (isEmpty(manufacturingRequestOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const status = manufacturingRequestOrder.attributeValues.find(
      (attributeValue) =>
        attributeValue.code === MANUFACTURING_REQUEST_ORDER_FIELD_CODE.STATUS,
    )?.value;
    if (!STATUS_TO_UPDATE_QUANTITY_PRODUCING_ORDER.includes(status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    const itemBomVersions = map(
      items,
      (item) => `${item.itemId}_${item.bomVersionId}`,
    );
    if (
      !isEmpty(
        itemBomVersions.filter(
          (item) =>
            !map(
              manufacturingRequestOrder.requestOrderDetails,
              (requestOrderDetail) => {
                const itemId = +requestOrderDetail.attributeValues.find(
                  (attributeValue) =>
                    attributeValue.code ===
                    MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ITEM_ID,
                )?.value;
                const bomVersionId = +requestOrderDetail.attributeValues.find(
                  (attributeValue) =>
                    attributeValue.code ===
                    MANUFACTURING_REQUEST_ORDER_FIELD_CODE.BOM_VERSION_ID,
                )?.value;
                return `${itemId}_${bomVersionId}`;
              },
            ).includes(item),
        ),
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }

    const serializeItemRequest = keyBy(
      items,
      (item) => `${item.itemId}_${item.bomVersionId}`,
    );

    let invalidQuantity = true;
    for (
      let index = 0;
      index < manufacturingRequestOrder.requestOrderDetails.length;
      ++index
    ) {
      const requestOrderDetail =
        manufacturingRequestOrder.requestOrderDetails[index];
      const itemId = requestOrderDetail.attributeValues.find(
        (attributeValue) =>
          attributeValue.code ===
          MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ITEM_ID,
      )?.value;
      const bomVersionId = requestOrderDetail.attributeValues.find(
        (attributeValue) =>
          attributeValue.code ===
          MANUFACTURING_REQUEST_ORDER_FIELD_CODE.BOM_VERSION_ID,
      )?.value;
      const quantity = +requestOrderDetail.attributeValues.find(
        (attributeValue) =>
          attributeValue.code ===
          MANUFACTURING_REQUEST_ORDER_FIELD_CODE.QUANTITY,
      )?.value;

      if (itemBomVersions.includes(`${itemId}_${bomVersionId}`)) {
        const actualQuantityAttribute = requestOrderDetail.attributeValues.find(
          (attributeValue) =>
            attributeValue.code ===
            MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ACTUAL_QUANTITY,
        );

        if (actualQuantityAttribute) {
          manufacturingRequestOrder.requestOrderDetails[
            index
          ].attributeValues.find(
            (attributeValue) =>
              attributeValue.code ===
              MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ACTUAL_QUANTITY,
          ).value = plus(
            +actualQuantityAttribute.value,
            serializeItemRequest[`${itemId}_${bomVersionId}`].quantity,
          );

          if (
            plus(
              +actualQuantityAttribute.value,
              serializeItemRequest[`${itemId}_${bomVersionId}`].quantity,
            ) > quantity
          ) {
            invalidQuantity = true;
          }
        } else {
          const attributeByCodes =
            await this.attributeService.getAttributeByCodes([
              MANUFACTURING_REQUEST_ORDER_FIELD_CODE.ACTUAL_QUANTITY,
            ]);
          const actualQuantityAttribute = attributeByCodes
            ? attributeByCodes[0]
            : null;
          if (actualQuantityAttribute) {
            manufacturingRequestOrder.requestOrderDetails[
              index
            ].attributeValues = [
              ...manufacturingRequestOrder.requestOrderDetails[index]
                .attributeValues,
              {
                attributeId: actualQuantityAttribute.id,
                code: actualQuantityAttribute.code,
                value:
                  serializeItemRequest[`${itemId}_${bomVersionId}`].quantity,
              },
            ];
            if (
              serializeItemRequest[`${itemId}_${bomVersionId}`].quantity >
              quantity
            ) {
              invalidQuantity = true;
            }
          }
        }
      }
    }

    if (!isEmpty(invalidQuantity)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.QUANTITY_ITEM_GREATER_THAN_QUANTITY_PURCHASE_ORDER',
          ),
        )
        .build();
    }

    try {
      await this.requestOrderDetailRepository.bulkWrite(
        manufacturingRequestOrder.requestOrderDetails.map(
          (requestOrderDetail) => ({
            updateOne: {
              filter: {
                _id: requestOrderDetail._id,
              },
              update: {
                attributeValues: requestOrderDetail.attributeValues,
              },
            },
          }),
        ),
      );
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          error?.message
            ? error.message
            : await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
        )
        .build();
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
