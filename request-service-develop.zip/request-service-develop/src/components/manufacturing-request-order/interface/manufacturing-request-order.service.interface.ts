import { CreateRequestOrderFormData } from '@components/request-order/dto/request/create-request-order.request.dto';
import { UpdateRequestOrderFormData } from '@components/request-order/dto/request/update-request-order.request.dto';
import { GetManufacturingRequestOrderDetailRequestDto } from '../dto/request/get-manufacturing-request-order-detail.request.dto';
import { GetManufacturingOrderRequestListRequestDto } from '../dto/request/get-manufacturing-request-order-list.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { GetManufacturingRequestOrderByIdsRequestDto } from '../dto/request/get-manufacturing-request-order-by-ids.request.dto';
import { UpdateSoIsHasPlanRequestDto } from '../dto/request/update-so-is-has-plan.request.dto';
import { GetRequestOrderHoldedMaterialLiRequestDto } from '../dto/request/get-request-order-holded-material-list.request.dto';
import { UpdateProducedQuantityRequestDto } from '../dto/request/update-produced-quantity.request.dto';

export interface ManufacturingOrderServiceInterface {
  create(request: CreateRequestOrderFormData): Promise<any>;
  update(request: UpdateRequestOrderFormData): Promise<any>;
  getDetailByTemplate(
    request: GetManufacturingRequestOrderDetailRequestDto,
  ): Promise<any>;
  getDetail(
    request: GetManufacturingRequestOrderDetailRequestDto,
  ): Promise<any>;
  getList(request: GetManufacturingOrderRequestListRequestDto): Promise<any>;
  delete(request: IdParamMongoDto): Promise<any>;
  confirm(request: IdParamMongoDto): Promise<any>;
  reject(request: IdParamMongoDto): Promise<any>;
  generateCode(): Promise<any>;
  getManufacturingRequestOrdersTcp(
    request: GetManufacturingRequestOrderByIdsRequestDto,
  ): Promise<any>;
  updateManufacturingRequestOrderIsHasPlan(
    request: UpdateSoIsHasPlanRequestDto,
  ): Promise<any>;
  GetRequestOrderHoldedMaterialList(
    request: GetRequestOrderHoldedMaterialLiRequestDto,
  ): Promise<any>;
  updateManufacturingRequestOrderStatusToInprogress(
    payload: IdParamMongoDto,
  ): Promise<any>;
  complete(request: IdParamMongoDto): Promise<any>;
  autoCreate(request: any): Promise<any>;
  updateProducedQuantity(
    request: UpdateProducedQuantityRequestDto,
  ): Promise<any>;
}
