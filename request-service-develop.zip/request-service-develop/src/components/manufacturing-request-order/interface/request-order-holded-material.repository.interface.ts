import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { RequestOrderHoldedMaterialModel } from 'src/models/request-order-holded-material/request-order-holded-material.model';
import { GetRequestOrderHoldedMaterialLiRequestDto } from '../dto/request/get-request-order-holded-material-list.request.dto';

export interface RequestOrderHoldedMaterialRepositoryInterface
  extends BaseInterfaceRepository<RequestOrderHoldedMaterialModel> {
  createDocument(request: any, document?: any): RequestOrderHoldedMaterialModel;
  getList(request: GetRequestOrderHoldedMaterialLiRequestDto): Promise<any>;
}
