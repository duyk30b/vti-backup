import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { Inject } from '@nestjs/common';
import { RequestOrderRepositoryInterface } from './interface/request-order.repository.interface';
import { RequestOrderDetailRepositoryInterface } from './interface/request-order-detail.repository.interface.ts';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { RequestOrderServiceInterface } from './interface/request-order.service.interface';
import { RequestOrder } from 'src/models/request-order/request-order.model';
import { CreateRequestOrderFormData } from './dto/request/create-request-order.request.dto';
import { find, isEmpty } from 'lodash';
import { AttributeServiceInterface } from '@components/attribute/interface/attribute.service.interface';
import { UpdateRequestOrderFormData } from './dto/request/update-request-order.request.dto';
import { AREA_ENUM, REQUEST_ORDER_STATUS_ENUM } from './request-order.constant';
import * as mongoose from 'mongoose';
import { InjectConnection } from '@nestjs/mongoose';
import { DATA_TYPE_ENUM } from '@constant/common';
import { compareDate } from '@utils/helper';

export class RequestOrderServiceAbstract
  implements RequestOrderServiceInterface
{
  constructor(
    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('RequestOrderRepositoryInterface')
    protected readonly requestOrderRepository: RequestOrderRepositoryInterface,

    @Inject('RequestOrderDetailRepositotyInterface')
    protected readonly requestOrderDetailRepository: RequestOrderDetailRepositoryInterface,

    @Inject('AttributeServiceInterface')
    protected readonly attributeService: AttributeServiceInterface,

    protected readonly i18n: I18nRequestScopeService,

    @InjectConnection()
    protected readonly connection: mongoose.Connection,
  ) {}

  async create(payload: CreateRequestOrderFormData): Promise<any> {
    const { data } = payload;
    const { templateId, attributeValues, requestOrderDetails } = data;
    const template = await this.attributeService.getTemplateById(templateId);
    if (!template) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.TEMPLATE_NOT_FOUND'))
        .build();
    }

    const detailAttributeValues = [];
    requestOrderDetails.forEach((detailRequestOrder) => {
      detailAttributeValues.push(
        ...detailRequestOrder.attributeValues.map((attributeValue) => ({
          ...attributeValue,
          groupId: detailRequestOrder.groupId,
          area: AREA_ENUM.DETAIL,
        })),
      );
    });
    const attributeRequests = [
      ...attributeValues.map((attributeValue) => ({
        ...attributeValue,
        groupId: null,
        area: AREA_ENUM.COMMON,
      })),
      ...detailAttributeValues,
    ];

    /* TODO */
    const validationResult = await this.validateAttributes(
      templateId,
      attributeRequests,
    );
    if (validationResult.statusCode !== ResponseCodeEnum.SUCCESS) {
      return validationResult;
    }
    // const existedRequestOrder =
    //   await this.requestOrderRepository.findOneByCondition({
    //     type: REQUEST_ORDER_TYPE_ENUM[template.code],
    //   });

    // if (!isEmpty(existedRequestOrder)) {
    //   return new ResponseBuilder()
    //     .withCode(ResponseCodeEnum.SUCCESS)
    //     .withMessage(
    //       await this.i18n.translate(`error.REQUEST_ORDER_IS_ALREADY_EXIST`),
    //     )
    //     .build();
    // }
    const requestOrderEntity = this.requestOrderRepository.createDocument({
      ...data,
      createdBy: payload?.userId,
    });

    return await this.save(requestOrderEntity, payload, attributeRequests);
  }

  async update(payload: UpdateRequestOrderFormData): Promise<any> {
    const { data } = payload;
    const { templateId, attributeValues, requestOrderDetails, id } = data;
    const template = await this.attributeService.getTemplateById(templateId);
    if (isEmpty(template)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.TEMPLATE_NOT_FOUND'))
        .build();
    }
    const existedRequestOrder = await this.requestOrderRepository.findOneById(
      id,
    );
    if (!existedRequestOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.REQUEST_ORDER_NOT_FOUND'))
        .build();
    }
    const detailAttributeValues = [];
    requestOrderDetails.forEach((detailRequestOrder) => {
      detailAttributeValues.push(
        ...detailRequestOrder.attributeValues.map((attributeValue) => ({
          ...attributeValue,
          groupId: detailRequestOrder.groupId,
          area: AREA_ENUM.DETAIL,
        })),
      );
    });
    const attributeRequests = [
      ...attributeValues.map((attributeValue) => ({
        ...attributeValue,
        groupId: null,
        area: AREA_ENUM.COMMON,
      })),
      ...detailAttributeValues,
    ];
    existedRequestOrder.status = REQUEST_ORDER_STATUS_ENUM.PENDING;
    const requestOrderUpdateEntity = this.requestOrderRepository.updateDocument(
      existedRequestOrder,
      { ...data },
    );
    return await this.save(
      requestOrderUpdateEntity,
      payload,
      attributeRequests,
      true,
    );
  }

  async save(
    requestOrderEntity: RequestOrder,
    payload: CreateRequestOrderFormData | UpdateRequestOrderFormData,
    attributeRequests: any,
    isUpdate?: boolean,
  ): Promise<any> {
    const { data } = payload;
    const { requestOrderDetails } = data;

    try {
      let requestOrder;
      if (isUpdate) {
        requestOrder = await this.requestOrderRepository.findByIdAndUpdate(
          requestOrderEntity._id,
          requestOrderEntity,
        );

        await this.requestOrderDetailRepository.deleteManyByCondition({
          requestOrderId: requestOrderEntity._id,
        });
      } else {
        requestOrder = await this.requestOrderRepository.create(
          requestOrderEntity,
        );
      }

      await this.requestOrderDetailRepository.create(
        requestOrderDetails.map((detailRequestOrder) => {
          return this.requestOrderDetailRepository.createDocument({
            ...detailRequestOrder,
            requestOrderId: requestOrder._id,
          });
        }),
      );
      return new ResponseBuilder(requestOrderEntity)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            isUpdate ? 'error.UPDATE_SUCCESS' : 'error.CREATE_SUCCESS',
          ),
        )
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    } finally {
    }
  }

  async validateAttributes(
    templateId: any,
    attributes: { code: string; value: any }[],
  ): Promise<any> {
    const template = await this.attributeService.getTemplateById(templateId);
    const attributeTemplates = template.attributes;

    for (let i = 0; i < attributes.length; i++) {
      const attribute = attributeTemplates.find((at) => {
        if (!at?.attribute?.code || !attributes[i]?.code) return false;
        return at.attribute.code === attributes[i].code;
      });
      if (!attribute) {
        continue;
      }
      const rule = attribute.attributeRule || null;
      const min = rule?.min;
      const max = rule?.max;
      const dataType = attribute?.attribute?.dataType;
      const attributeName = attributes[i].code;
      const attributeValue = attributes[i].value;

      if (rule && rule?.isRequired === 1) {
        if (
          attributeValue === undefined ||
          isEmpty(attributeValue?.toString())
        ) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(
              await this.i18n.translate('error.ATTRIBUTE_IS_EMPTY', {
                args: { attribute: attributeName },
              }),
            )
            .build();
        }
      }

      switch (dataType) {
        case DATA_TYPE_ENUM.NUMBER:
          if (!isEmpty(min?.toString()) && attributeValue < min) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_SMALLER_THAN_MIN',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          if (!isEmpty(max?.toString()) && attributeValue > max) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_BIGGER_THAN_MAX',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          break;
        case DATA_TYPE_ENUM.DATE:
          if (
            !isEmpty(min?.toString()) &&
            compareDate(new Date(attributeValue), new Date(min))
          ) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_SMALLER_THAN_MIN',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          if (
            !isEmpty(max?.toString()) &&
            compareDate(new Date(max), new Date(attributeValue))
          ) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate(
                  'error.ATTRIBUTE_IS_BIGGER_THAN_MAX',
                  {
                    args: { attribute: attributeName },
                  },
                ),
              )
              .build();
          }
          break;
        default:
          break;
      }
    }

    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }
}
