import { MIMETYPE_FILE_UPLOAD } from '@components/file/constant/file-upload.constant';
import { REQUEST_ORDER_VALIDATE } from '@components/request-order/request-order.constant';
import { ErrorMessageEnum } from '@constant/error-message.enum';
import { BaseDto } from '@core/dto/base.dto';
import { File } from '@core/dto/file-upload.request.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type, plainToClass } from 'class-transformer';
import { IsIn, IsMongoId, IsNotEmpty } from 'class-validator';
import {
  ArrayUnique,
  IsInt,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';

class FileUpload extends File {
  @ApiProperty()
  @IsIn(MIMETYPE_FILE_UPLOAD, {
    message: ErrorMessageEnum.MIMETYPE_FILE,
  })
  mimetype: string;
}
export class AttributeValueRequestDto {
  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  id: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  code: string;

  @ApiProperty()
  value: any;
}

export class RequestOrderDetailRequestDto {
  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  groupId: string;

  @ApiProperty()
  @ArrayUnique<AttributeValueRequestDto>()
  @IsOptional()
  @ValidateNested()
  @Type(() => AttributeValueRequestDto)
  attributeValues: AttributeValueRequestDto[];
}

export class CreateRequestOrderBodyDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsMongoId()
  id?: string;

  @ApiProperty()
  // @IsString()
  @IsOptional()
  @MaxLength(REQUEST_ORDER_VALIDATE.CODE.MAX_LENGTH)
  code?: string;

  @ApiProperty()
  // @IsString()
  @IsOptional()
  @MaxLength(REQUEST_ORDER_VALIDATE.NAME.MAX_LENGTH)
  name?: string;

  @ApiProperty()
  @IsNotEmpty()
  type?: number;

  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  templateId?: string;

  @ApiProperty()
  @IsString()
  @IsOptional()
  @MaxLength(REQUEST_ORDER_VALIDATE.DESCRIPTION.MAX_LENGTH)
  description?: string;

  @ApiProperty()
  @ArrayUnique<AttributeValueRequestDto>()
  @IsOptional()
  @ValidateNested()
  @Type(() => AttributeValueRequestDto)
  attributeValues: AttributeValueRequestDto[]; //thuoc tinh chung custom

  @ApiProperty()
  @ArrayUnique<RequestOrderDetailRequestDto>()
  @IsOptional()
  @ValidateNested()
  @Type(() => RequestOrderDetailRequestDto)
  requestOrderDetails: RequestOrderDetailRequestDto[];
}

export class CreateRequestOrderFormData extends BaseDto {
  @ApiProperty()
  @Transform((v) =>
    plainToClass(CreateRequestOrderBodyDto, JSON.parse(v.value)),
  )
  @Type(() => CreateRequestOrderBodyDto)
  @ValidateNested()
  data: CreateRequestOrderBodyDto;

  @ApiPropertyOptional()
  @Type(() => FileUpload)
  files?: FileUpload[];
}
