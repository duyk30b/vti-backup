import { REQUEST_ORDER_TYPE_ENUM } from '@components/request-order/request-order.constant';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { Transform } from 'class-transformer';
import { IsEnum, IsOptional } from 'class-validator';

export class GetRequestOrderListRequestDto extends PaginationQuery {
  @IsEnum(REQUEST_ORDER_TYPE_ENUM)
  @IsOptional()
  @Transform(({ value }) => Number(value))
  requestOrderType: number;

  @IsOptional()
  filterObj: any;
}
