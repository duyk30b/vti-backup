import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { plainToInstance, Transform, Type } from 'class-transformer';
import { IsInt, IsMongoId, IsOptional, ValidateNested } from 'class-validator';
import { CreateRequestOrderBodyDto } from './create-request-order.request.dto';
import { File } from '@core/dto/file-upload.request.dto';

class FileUpload extends File {
  @ApiProperty()
  mimetype: string;
}

export class UpdateRequestOrderDto extends CreateRequestOrderBodyDto {
  @ApiProperty()
  @IsOptional()
  @IsMongoId()
  id: string;
}

export class UpdateRequestOrderFormData extends BaseDto {
  @ApiProperty()
  @ValidateNested({ each: true })
  @Transform((v) => {
    return plainToInstance(UpdateRequestOrderDto, JSON.parse(v.value));
  })
  @Type(() => UpdateRequestOrderDto)
  data: UpdateRequestOrderDto;

  @ApiProperty({ description: 'File' })
  @ValidateNested({ each: true })
  @Type(() => FileUpload)
  files: FileUpload[];
}
