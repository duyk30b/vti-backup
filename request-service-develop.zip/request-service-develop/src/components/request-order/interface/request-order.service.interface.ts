import { RequestOrder } from 'src/models/request-order/request-order.model';
import { CreateRequestOrderFormData } from '../dto/request/create-request-order.request.dto';
import { UpdateRequestOrderFormData } from '../dto/request/update-request-order.request.dto';

export interface RequestOrderServiceInterface {
  create(payload: CreateRequestOrderFormData): Promise<any>;
  update(payload: UpdateRequestOrderFormData): Promise<any>;
  save(
    requestOrderEntity: RequestOrder,
    payload: CreateRequestOrderFormData,
    attributeRequests: any,
    isUpdate?: boolean,
  ): Promise<any>;
}
