import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { RequestOrderDetail } from 'src/models/request-order-detail/request-order-detail.model';

export interface RequestOrderDetailRepositoryInterface
  extends BaseInterfaceRepository<RequestOrderDetail> {
  createDocument(request: any): RequestOrderDetail;
  getDetail(id: string): any;
}
