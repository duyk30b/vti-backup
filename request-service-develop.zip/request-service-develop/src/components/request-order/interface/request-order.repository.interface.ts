import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { RequestOrder } from 'src/models/request-order/request-order.model';

export interface RequestOrderRepositoryInterface
  extends BaseInterfaceRepository<RequestOrder> {
  createDocument(request: any): RequestOrder;
  updateDocument(document: RequestOrder, request: any): RequestOrder;
  getList(request: any): Promise<any>;
  getDetail(id: string): Promise<any>;
  getLastRequestOrder(requestOrderType?: number): Promise<any>;
  getLastWarehouseRequestOrderByGenerateCode(
    date?: string,
    type?: number,
  ): Promise<any>;
}
