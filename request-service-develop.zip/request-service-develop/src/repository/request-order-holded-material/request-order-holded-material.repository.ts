import { GetRequestOrderHoldedMaterialLiRequestDto } from '@components/manufacturing-request-order/dto/request/get-request-order-holded-material-list.request.dto';
import { RequestOrderHoldedMaterialRepositoryInterface } from '@components/manufacturing-request-order/interface/request-order-holded-material.repository.interface';
import { MANUFACTURING_REQUEST_ORDER_FIELD_CODE } from '@components/manufacturing-request-order/manufacturing-request-order.constant';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { Model, Types } from 'mongoose';
import { RequestOrderHoldedMaterialModel } from 'src/models/request-order-holded-material/request-order-holded-material.model';
@Injectable()
export class RequestOrderHoldedMaterialRepository
  extends BaseAbstractRepository<RequestOrderHoldedMaterialModel>
  implements RequestOrderHoldedMaterialRepositoryInterface
{
  constructor(
    @InjectModel('RequestOrderHoldedMaterialModel')
    private readonly requestOrderHoldedMaterialModel: Model<RequestOrderHoldedMaterialModel>,
  ) {
    super(requestOrderHoldedMaterialModel);
  }

  createDocument(
    request: any,
    document?: any,
  ): RequestOrderHoldedMaterialModel {
    let newDocument = new this.requestOrderHoldedMaterialModel();
    if (!isEmpty(document)) {
      newDocument = document;
    }

    if (request._id) newDocument._id = request._id;
    newDocument.requestOrderId = request.requestOrderId;
    newDocument.itemId = request.itemId;
    newDocument.materialId = request.materialId;
    newDocument.holdedQuantity = request.holdedQuantity;
    return newDocument;
  }

  async getList(
    request: GetRequestOrderHoldedMaterialLiRequestDto,
  ): Promise<any> {
    const { keyword, sort, filter, take, skip } = request;
    let sortObj = {};
    let filterObj = {};

    if (!isEmpty(keyword)) {
      filterObj = {
        ...filterObj,
        // $or: [
        //   { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
        //   { name: getRegexByValue(keyword) },
        // ],
      };
    }
    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'requestOrderId':
            filterObj = {
              ...filterObj,
              requestOrderId: new Types.ObjectId(item.text),
            };
            break;
          case 'materialId':
            filterObj = {
              ...filterObj,
              materialId: +item.text,
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'createdAt':
            sortObj = { createdAt: order };
            break;
          case 'updatedAt':
            sortObj = { updatedAt: order };
            break;
            break;
        }
      });
    } else {
      sortObj = { createdAt: -1 };
    }

    const result = await this.requestOrderHoldedMaterialModel
      .aggregate()
      .lookup({
        from: 'requestOrders',
        localField: 'requestOrderId',
        foreignField: '_id',
        as: 'requestOrder',
        pipeline: [
          {
            $match: {
              attributeValues: {
                $elemMatch: {
                  value: { $regex: '.*' + keyword + '.*', $options: 'i' },
                  code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.CODE,
                },
              },
            },
          },
        ],
      })
      .unwind({
        path: '$requestOrder',
      })
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();

    const total: number = await this.requestOrderHoldedMaterialModel
      .find({ ...filterObj, deletedAt: null })
      .countDocuments()
      .exec();

    return { data: result, count: total };
  }
}
