import { RequestOrderDetailRepositoryInterface } from '@components/request-order/interface/request-order-detail.repository.interface.ts';
import { RequestOrderRepositoryInterface } from '@components/request-order/interface/request-order.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { RequestOrderDetail } from 'src/models/request-order-detail/request-order-detail.model';
import { RequestOrder } from 'src/models/request-order/request-order.model';

@Injectable()
export class RequestOrderDetailRepository
  extends BaseAbstractRepository<RequestOrderDetail>
  implements RequestOrderDetailRepositoryInterface
{
  constructor(
    @InjectModel('RequestOrderDetail')
    private readonly requestOrderDetail: Model<RequestOrderDetail>,
  ) {
    super(requestOrderDetail);
  }

  createDocument(request: any): RequestOrderDetail {
    const document = new this.requestOrderDetail();
    document.requestOrderId = request.requestOrderId;
    document.groupId = request.groupId;
    document.attributeValues = request.attributeValues;

    return document;
  }

  async getDetail(id: string): Promise<any> {
    return (
      this.requestOrderDetail
        .findById(id)
        //.populate({ path: 'attributeValues' })
        .populate({
          path: 'requestOrderId',
          // populate: {
          //   path: 'detailAttributeValues._id',
          // },
        })
        .exec()
    );
  }
}
