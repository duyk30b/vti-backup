import { MANUFACTURING_REQUEST_ORDER_FIELD_CODE } from '@components/manufacturing-request-order/manufacturing-request-order.constant';
import { RequestOrderRepositoryInterface } from '@components/request-order/interface/request-order.repository.interface';
import {
  WAREHOUSE_REQUEST_ORDER_CODE_PREFIX,
  WAREHOUSE_REQUEST_ORDER_CONST,
} from '@components/warehouse-request-order/warehouse-request-order.constant';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { Model } from 'mongoose';
import { RequestOrder } from 'src/models/request-order/request-order.model';

@Injectable()
export class RequestOrderRepository
  extends BaseAbstractRepository<RequestOrder>
  implements RequestOrderRepositoryInterface
{
  constructor(
    @InjectModel('RequestOrder')
    private readonly requestOrder: Model<RequestOrder>,
  ) {
    super(requestOrder);
  }

  createDocument(request: any): RequestOrder {
    const document = new this.requestOrder();
    document.code = request.code;
    document.name = request.name;
    document.templateId = request.templateId;
    document.type = request.type;
    document.description = request.description;
    document.attributeValues = request.attributeValues.map((attrValue) => ({
      attributeId: attrValue.id,
      value: attrValue.value,
      code: attrValue.code,
    }));
    document.createdBy = request.createdBy;
    if (request.status) document.status = request.status;

    return document;
  }

  updateDocument(document: RequestOrder, request: any): RequestOrder {
    document._id = request.id;
    document.name = request.name;
    document.templateId = request.templateId;
    document.type = request.type;
    document.description = request.description;
    document.attributeValues = request.attributeValues.map((attrValue) => ({
      attributeId: attrValue.id,
      value: attrValue.value,
      code: attrValue.code,
    }));
    document.createdBy = request.createdBy;

    return document;
  }

  async getList(request: any): Promise<any> {
    const { keyword, sort, filter, take, skip, requestOrderType } = request;
    let sortObj = {};
    let filterObj = request.filterObj || {};
    let sortField = '';

    if (!isEmpty(keyword)) {
      filterObj = {
        ...filterObj,
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
          {
            attributeValues: {
              $elemMatch: {
                value: { $regex: '.*' + keyword + '.*', $options: 'i' },
                code: MANUFACTURING_REQUEST_ORDER_FIELD_CODE.CODE,
              },
            },
          },
        ],
      };
    }
    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'type':
            filterObj = {
              ...filterObj,
              type: {
                $in: item.text?.split(',')?.map((e) => +e),
              },
            };
            break;

          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'createdAt':
            sortObj = { createdAt: order };
            break;
          case 'updatedAt':
            sortObj = { updatedAt: order };
            break;
          default:
            sortObj = { customField: order };
            sortField = item.column;
            break;
        }
      });
    } else {
      sortObj = { createdAt: -1 };
    }
    if (requestOrderType) {
      filterObj = {
        deletedAt: null,
        ...filterObj,
        type: requestOrderType || 1,
      };
    }

    const result = await this.requestOrder
      .aggregate([
        {
          $addFields: {
            customField: {
              $first: {
                $filter: {
                  input: '$attributeValues',
                  as: 'attributeValue',
                  cond: {
                    $eq: ['$$attributeValue.code', sortField],
                  },
                },
              },
            },
          },
        },
      ])
      .lookup({
        from: 'requestOrderDetails',
        localField: '_id',
        foreignField: 'requestOrderId',
        as: 'requestOrderDetails',
      })
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();

    const total: number = await this.requestOrder
      .find({ ...filterObj, deletedAt: null })
      .countDocuments()
      .exec();

    return { data: result, count: total };
  }

  async getDetail(id: string): Promise<any> {
    return await this.requestOrder
      .findById(id)
      .lean()
      .populate({
        path: 'requestOrderDetails',
      })
      .exec();
  }

  async getLastRequestOrder(requestOrderType?: number): Promise<any> {
    let filterObj = {};
    if (requestOrderType) {
      filterObj = { type: requestOrderType };
    }
    return await this.requestOrder
      .findOne(filterObj)
      .sort({ createdAt: 'DESC' })
      .exec();
  }
  async getLastWarehouseRequestOrderByGenerateCode(
    date?: string,
    type?: number,
  ): Promise<any> {
    const condition = {
      $or: [
        {
          code: {
            $regex: `${WAREHOUSE_REQUEST_ORDER_CONST.CODE_YN.PREFIX_CODE_DEFAULT}${date}.*`,
            $options: 'i',
          },
        },
        {
          code: {
            $regex: `${WAREHOUSE_REQUEST_ORDER_CONST.CODE_YX.PREFIX_CODE_DEFAULT}${date}.*`,
            $options: 'i',
          },
        },
        {
          code: {
            $regex: `${WAREHOUSE_REQUEST_ORDER_CONST.CODE_YC.PREFIX_CODE_DEFAULT}${date}.*`,
            $options: 'i',
          },
        },
      ],
      type: type,
    };
    return await this.requestOrder
      .findOne(condition)
      .sort({ createdAt: 'DESC' })
      .exec();
  }
}
