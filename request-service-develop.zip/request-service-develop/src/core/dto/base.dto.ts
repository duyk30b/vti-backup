export class BaseDto {
  request: any;

  responseError: any;

  user?: any;

  userId?: any;

  lang?: string;
}
