import { DatasyncModule } from './components/datasync/datasync.module';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthModule } from './components/auth/auth.module';
import { CoreModule } from './core/core.module';
import { InventoryModule } from '@components/inventory/inventory.module';
import { WarehouseReportModule } from '@components/warehouse-report/warehouse-report.module';
import { WarehouseTypeSettingModule } from '@components/warehouse-type-setting/warehouse-type-setting.module';
import { WarehouseTransferModule } from '@components/warehouse-transfer/warehouse-transfer.module';
import { ScheduleModule } from '@nestjs/schedule';
import { I18nJsonLoader, I18nModule } from 'nestjs-i18n';
import * as path from 'path';
import { APP_PIPE, APP_GUARD } from '@nestjs/core';
import { ValidationPipe } from '@core/pipe/validation.pipe';
import { WarehouseSectorModule } from '@components/warehouse-sector/warehouse-sector.module';
import { AuthorizationGuard } from '@core/guards/authorization.guard';
import { UserModule } from '@components/user/user.module';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ConfigService } from '@config/config.service';
import { WarehouseShelfModule } from '@components/warehouse-shelf/warehouse-shelf.module';
import { WarehouseShelfFloorModule } from '@components/warehouse-shelf-floor/warehouse-shelf-floor.module';
import { StaticModule } from '@components/static/static.module';
import { TemplateSectorModule } from '@components/template-sector/template-sector.module';
import { TemplateShelfModule } from '@components/template-shelf/template-shelf.module';
import { TemplateShelfFloorModule } from '@components/template-shelf-floor/template-shelf-floor.module';
import { TemplateSectorTemplateShelfModule } from '@components/template-sector-template-shelf/template-sector-template-shelf.module';
import { TemplateShelfTemplateShelfFloorModule } from '@components/template-shelf-template-shelf-floor/template-shelf-template-shelf-floor.module';
import { WarehouseDoorModule } from '@components/warehouse-door/warehouse-door.module';
import { QueryResolver } from './i18n/query-resolver';
import { SuspendLocationModule } from '@components/suspend-location/suspend-location.module';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { SuggestItemLocationModule } from '@components/suggest-item-location/suggest-item-location.module';
import { QrCodeModule } from '@components/qr-code/qr-code.module';
import { BootModule } from '@nestcloud/boot';
import { ConsulModule } from '@nestcloud/consul';
import { BOOT, CONSUL } from '@nestcloud/common';
import { ServiceModule } from '@nestcloud/service';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { KongGatewayModule } from '@core/components/kong-gateway/kong-gateway.module';
import { resolve } from 'path';
import { SnakeNamingStrategy } from 'typeorm-naming-strategies';
import { BussinessTypeModule } from '@components/bussiness-types/bussiness-type.module';
import { LocationSegmentModule } from '@components/location-segment/location-segment.module';
import { LocationModule } from '@components/location/location.module';
import { LocatorModule } from '@components/locator/locator.module';
import { FileModule } from '@components/file/file.module';
import { WarehouseLayoutModule } from '@components/warehouse-layout/warehouse-layout.module';
import { ReportModule } from '@components/report/report.module';
import { SyncDataFromHqModule } from '@components/sync-from-hq/sync-data-from-hq.module';
import { InventoryTimeLimitModule } from '@components/inventory-time-limit/inventory-time-limit.module';
import { WarehouseExportProposalModule } from '@components/warehouse-export-proposal/warehouse-export-proposal.module';
import { BullModule } from '@nestjs/bull';
import { DashboardModule } from '@components/dashboard/dashboard.module';
import { InventoryAdjustmentModule } from '@components/inventory-adjustment/inventory-adjustment.module';
import { isDevMode } from '@utils/helper';
import { SettingModule } from '@components/setting/setting.module';
import { TicketModule } from '@components/ticket/ticket.module';
import { NatsClientModule } from '@core/transporter/nats-transporter/nats-client.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    I18nModule.forRoot({
      fallbackLanguage: 'vi',
      loader: I18nJsonLoader,
      loaderOptions: {
        path: path.join(__dirname, '/i18n/'),
        watch: true,
      },
      resolvers: [{ use: QueryResolver, options: ['lang', 'locale', 'l'] }],
    }),
    ScheduleModule.forRoot(),
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DATABASE_POSTGRES_HOST,
      port: parseInt(process.env.DATABASE_POSTGRES_PORT),
      username: process.env.DATABASE_POSTGRES_USERNAME,
      password: process.env.DATABASE_POSTGRES_PASSWORD,
      database: process.env.DATABASE_NAME,
      logging: isDevMode(),
      entities: [path.join(__dirname, '/entities/**/*.entity.{ts,js}')],
      migrations: [path.join(__dirname, '/database/migrations/*.{ts,js}')],
      subscribers: ['dist/observers/subscribers/*.subscriber.{ts,js}'],
      // We are using migrations, synchronize should be set to false.
      synchronize: false,
      // Run migrations automatically,
      // you can disable this if you prefer running migration manually.
      migrationsRun: !isDevMode(),
      extra: {
        max: parseInt(process.env.DATABASE_MAX_POOL) || 20,
      },
      namingStrategy: new SnakeNamingStrategy(),
    }),
    BootModule.forRoot({
      filePath: resolve(__dirname, '../config.yaml'),
    }),
    ConsulModule.forRootAsync({ inject: [BOOT] }),
    ServiceModule.forRootAsync({ inject: [BOOT, CONSUL] }),
    BullModule.forRoot({
      redis: {
        host: process.env.REDIS_HOST,
        port: Number(process.env.REDIS_PORT),
        password: process.env.REDIS_PASSWORD,
      },
    }),
    EventEmitterModule.forRoot(),
    HttpClientModule,
    KongGatewayModule.forRootAsync(),
    CoreModule,
    AuthModule,
    WarehouseModule,
    InventoryModule,
    WarehouseReportModule,
    WarehouseTypeSettingModule,
    WarehouseTransferModule,
    WarehouseSectorModule,
    UserModule,
    WarehouseShelfModule,
    WarehouseShelfFloorModule,
    StaticModule,
    TemplateSectorModule,
    TemplateShelfModule,
    TemplateShelfFloorModule,
    TemplateSectorTemplateShelfModule,
    TemplateShelfTemplateShelfFloorModule,
    WarehouseDoorModule,
    SuspendLocationModule,
    EventEmitterModule.forRoot(),
    SuggestItemLocationModule,
    QrCodeModule,
    BussinessTypeModule,
    LocationSegmentModule,
    LocationModule,
    LocatorModule,
    FileModule,
    WarehouseLayoutModule,
    ReportModule,
    InventoryTimeLimitModule,
    WarehouseExportProposalModule,
    SyncDataFromHqModule,
    DashboardModule,
    InventoryAdjustmentModule,
    DatasyncModule,
    SettingModule,
    TicketModule,
    NatsClientModule,
  ],
  controllers: [AppController],
  providers: [
    {
      provide: APP_PIPE,
      useClass: ValidationPipe,
    },
    {
      provide: APP_GUARD,
      useClass: AuthorizationGuard,
    },
    ConfigService,
    AppService,
  ],
})
export class AppModule {}
