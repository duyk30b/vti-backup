import { FONT_NAME, WORD_FILE_CONFIG } from '@utils/constant';
import { isEmpty } from 'lodash';
import { BorderStyle, convertInchesToTwip, HeightRule, WidthType } from 'docx';

export const wordFileStyle = {
  border_none: {
    top: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
    bottom: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
    left: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
    right: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
  },
  border_left_right_none: {
    left: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
    right: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
  },
  border_left_none: {
    left: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
  },
  border_right_none: {
    right: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
  },
  table_header_style: {
    bold: WORD_FILE_CONFIG.WORD_BOLD,
    font: FONT_NAME,
    size: WORD_FILE_CONFIG.WORD_FONT_SIZE_9,
  },
  table_header_bg_color: {
    fill: 'd6d6d6',
  },
  text_style_size_12_bold: {
    font: FONT_NAME,
    size: WORD_FILE_CONFIG.WORD_FONT_SIZE_12,
    bold: WORD_FILE_CONFIG.WORD_BOLD,
  },
  text_style_size_12_normal: {
    font: FONT_NAME,
    size: WORD_FILE_CONFIG.WORD_FONT_SIZE_12,
  },
  company_info_style: {
    bold: WORD_FILE_CONFIG.WORD_BOLD,
    size: WORD_FILE_CONFIG.WORD_FONT_SIZE_9,
    font: FONT_NAME,
    allCaps: true,
  },
  company_info_style_warehouse_transfer: {
    bold: WORD_FILE_CONFIG.WORD_BOLD,
    size: WORD_FILE_CONFIG.WORD_FONT_SIZE_10,
    font: FONT_NAME,
    allCaps: true,
  },
  address_company_info_style: {
    bold: WORD_FILE_CONFIG.WORD_BOLD,
    size: WORD_FILE_CONFIG.WORD_FONT_SIZE_10,
    font: FONT_NAME,
  },
  title_style: {
    bold: WORD_FILE_CONFIG.WORD_BOLD,
    size: WORD_FILE_CONFIG.WORD_FONT_SIZE_14,
    font: FONT_NAME,
    allCaps: true,
  },
  title_warehouse_transfer_style: {
    bold: WORD_FILE_CONFIG.WORD_BOLD,
    size: WORD_FILE_CONFIG.WORD_FONT_SIZE_14,
    font: FONT_NAME,
    allCaps: true,
  },
  taxcode_style: {
    font: FONT_NAME,
    size: WORD_FILE_CONFIG.WORD_FONT_SIZE_10,
  },
  text_style: {
    font: FONT_NAME,
    size: WORD_FILE_CONFIG.WORD_FONT_SIZE_9,
  },
  text_style_small: {
    font: FONT_NAME,
    size: WORD_FILE_CONFIG.WORD_FONT_SIZE_8,
  },
  text_style_bold: {
    font: FONT_NAME,
    size: WORD_FILE_CONFIG.WORD_FONT_SIZE_9,
    bold: WORD_FILE_CONFIG.WORD_BOLD,
  },
  text_style_signature_bold: {
    font: FONT_NAME,
    size: WORD_FILE_CONFIG.WORD_FONT_SIZE_12,
    bold: WORD_FILE_CONFIG.WORD_BOLD,
  },
  margin_left: {
    left: convertInchesToTwip(WORD_FILE_CONFIG.MARGIN_LEFT),
  },
  margin_right: {
    right: convertInchesToTwip(WORD_FILE_CONFIG.MARGIN_RIGHT),
  },
  margin_top: {
    top: convertInchesToTwip(WORD_FILE_CONFIG.MARGIN_TOP),
  },
  // set layout page landscape
  pagesize_a4: {
    width: convertInchesToTwip(WORD_FILE_CONFIG.PAGE_SIZE_A4_WIDTH),
    height: convertInchesToTwip(WORD_FILE_CONFIG.PAGE_SIZE_A4_HEIGHT),
  },
  pagesize_a35: {
    width: convertInchesToTwip(WORD_FILE_CONFIG.PAGE_SIZE_A35_WIDTH),
    height: convertInchesToTwip(WORD_FILE_CONFIG.PAGE_SIZE_A35_HEIGHT),
  },
  pagesize_a3: {
    width: convertInchesToTwip(WORD_FILE_CONFIG.PAGE_SIZE_A3_WIDTH),
    height: convertInchesToTwip(WORD_FILE_CONFIG.PAGE_SIZE_A3_HEIGHT),
  },
};

export function setWidth(inch: number) {
  return {
    size: convertInchesToTwip(inch),
    type: WidthType.DXA,
  };
}

export function setHeight(twip: number) {
  return {
    value: twip,
    rule: HeightRule.ATLEAST,
  };
}

const STRING_VN = ['vn', 'vietnam', 'việtnam'];
const STRING_PROVINCE = ['tinh', 'tỉnh'];

export function getProvince(address: string): string {
  if (isEmpty(address)) return '';
  const arr = address.split(",");
  let vn = arr[arr.length - 1].replace(/ /g, "").toLowerCase();
  let province = '';
  if (STRING_VN.includes(vn)) {
    province = arr[arr.length - 2].trim();
  } else {
    province = arr[arr.length - 1].trim();
  }
  if (province.includes(".")) return province.split('.')[1];
  const arrProvince = province.split(" ");
  if(STRING_PROVINCE.includes(arrProvince[0].toLowerCase())) {
    return province.split(arrProvince[0])[1].trim();
  }
  return province;
}

export function readMoney(num: string) {
  if (num == null || num == '') return '';
  num = num.split('.')[0];
  let temp = '';
  while (num.length < 18) {
    num = '0' + num;
  }
  const g1 = num.substring(0, 3);
  const g2 = num.substring(3, 6);
  const g3 = num.substring(6, 9);
  const g4 = num.substring(9, 12);
  const g5 = num.substring(12, 15);
  const g6 = num.substring(15, 18);
  if (g1 != '000') {
    temp = readGroup(g1);
    temp += ' Triệu';
  }
  if (g2 != '000') {
    temp += readGroup(g2);
    temp += ' Nghìn';
  }
  if (g3 != '000') {
    temp += readGroup(g3);
    temp += ' Tỷ';
  } else if ('' != temp) {
    temp += ' Tỷ';
  }
  if (g4 != '000') {
    temp += readGroup(g4);
    temp += ' Triệu';
  }
  if (g5 != '000') {
    temp += readGroup(g5);
    temp += ' Nghìn';
  }
  temp = temp + readGroup(g6);
  temp = temp.replace(/Một Mươi/g, 'Mười');
  temp = temp.trim();
  if (temp.indexOf('Không Trăm') === 0) {
    temp = temp.substring(10);
  };
  temp = temp.trim();
  temp = temp.replace(/Mười Không/g, 'Mười');
  temp = temp.trim();
  temp = temp.replace(/Mươi Không/g, 'Mươi');
  temp = temp.trim();
  if (temp.indexOf('Lẻ') == 0) temp = temp.substring(2);
  temp = temp.trim();
  temp = temp.replace(/Mươi Một/g, 'Mươi Mốt');
  temp = temp.trim();
  const result =
    temp.substring(0, 1).toUpperCase() + temp.substring(1).toLowerCase();
  return (result == '' ? 'Không' : result);
}

export function readDecimal(num: string) {  
  let decimal = '';
  const numTmp = parseFloat(num).toFixed(2);
  if(!isEmpty(num.split('.')[1])) decimal += numTmp.toString().split('.')[1] ?? '';  
  num = num.split('.')[0];
  const firstNumberText = readMoney(num);
  const decimalText = readMoney(decimal);
  let totalText = firstNumberText;
  if( decimalText === 'Không' || isEmpty(decimal)) {
    totalText += " đồng chẵn."
  } else {
    totalText += " phẩy " + decimalText.toLocaleLowerCase() + " đồng."
  }
  return totalText;
}

function readGroup(group) {
  const readDigit = [
    ' Không',
    ' Một',
    ' Hai',
    ' Ba',
    ' Bốn',
    ' Năm',
    ' Sáu',
    ' Bảy',
    ' Tám',
    ' Chín',
  ];
  let total = '';
  if (group == '000') return '';
  total = readDigit[parseInt(group.substring(0, 1))] + ' Trăm';
  if (group.substring(1, 2) == '0')
    if (group.substring(2, 3) == '0') return total;
    else {
      total += ' Lẻ' + readDigit[parseInt(group.substring(2, 3))];
      return total;
    }
  else total += readDigit[parseInt(group.substring(1, 2))] + ' Mươi';
  if (group.substring(2, 3) == '5') total += ' Lăm';
  else if (group.substring(2, 3) != '0')
    total += readDigit[parseInt(group.substring(2, 3))];
  return total;
}

export function formatNumber(number: any, isDecimal?: number) {
  number = number || 0;
  isDecimal = isDecimal || 0;
  const num = number.toString();
  const checkInt = num.includes('.');
  const x = 3;
  const n = 2;
  let numPri = parseFloat(num).toFixed(isDecimal);
  let count = isDecimal;
  if (!checkInt) {
    numPri = num + '.0';
    count--;
    while (count) {
      numPri += '0';
      count--;
    }
  } else if (!isDecimal) numPri += '.0';
  let re = '(\\d)(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\.' : '$') + ')';
  let numReturn =numPri.replace(new RegExp(re, 'g'), '$1 ');
  if (isDecimal) {
    return numReturn.split('.')[0] + ',' + numReturn.split('.')[1];
  }
  return numReturn.split('.')[0];
}
