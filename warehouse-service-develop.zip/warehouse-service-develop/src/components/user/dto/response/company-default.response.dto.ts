import { BasicResponseDto } from '@core/dto/basic-response.dto';
import { Expose } from 'class-transformer';

export class CompanyDefaultResponseDto extends BasicResponseDto {
  @Expose()
  address: string;
}
