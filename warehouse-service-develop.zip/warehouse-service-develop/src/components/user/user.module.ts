import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClientProxyFactory } from '@nestjs/microservices';
import { UserService } from './user.service';
import { ConfigService } from '@config/config.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
  ],
  controllers: [],
})
export class UserModule {}
