import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ReportService } from './report.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    {
      provide: 'ReportServiceInterface',
      useClass: ReportService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'ReportServiceInterface',
      useClass: ReportService,
    },
  ],
})
export class ReportModule {}
