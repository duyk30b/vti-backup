export interface ReportServiceInterface {
  getDailyWarehouseItemStocks(
    itemIds: number[],
    warehouseIds: number[],
    checkPointDate: Date,
  ): Promise<any>;
  getDailyItemLocatorStocks(
    itemIds: number[],
    warehouseIds: number[],
    checkPointDate: Date,
  ): Promise<any>
}
