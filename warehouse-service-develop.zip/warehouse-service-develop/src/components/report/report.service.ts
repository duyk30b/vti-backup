import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { ReportServiceInterface } from './interface/report.service.interface';

@Injectable()
export class ReportService implements ReportServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getDailyWarehouseItemStocks(
    itemIds: number[],
    warehouseIds: number[],
    checkPointDate: Date,
  ): Promise<any> {
    return [];
  }

  async getDailyItemLocatorStocks(
    itemIds: number[],
    warehouseIds: number[],
    checkPointDate: Date,
  ): Promise<any> {
    return [];
  }
}
