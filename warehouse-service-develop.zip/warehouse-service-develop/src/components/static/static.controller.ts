import { Body, Controller, Get, Param } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { getTemplate } from '@utils/common';
import { FileStaticRequest } from './dto/file-static.request';
import { FileStaticResponse } from './dto/file-static.response';
import { FILE_NAME_ENUM, FILE_NAME_MAP } from '@constant/import.constant';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nRequestScopeService } from 'nestjs-i18n';
import * as fs from 'fs';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';

@Controller('')
export class StaticController {
  constructor(private readonly i18n: I18nRequestScopeService) {}

  @Get('imports/templates/:fileName')
  @ApiOperation({
    tags: ['import', 'import'],
    summary: 'import ',
    description: 'lấy file mẫu import',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  // @MessagePattern('download_warehouse_import_template_file')
  public async downloadFile(@Param() payload: FileStaticRequest): Promise<any> {
    const { request } = payload;
    const fileStaticResponse = new FileStaticResponse();

    if (!FILE_NAME_ENUM[request.fileName]) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.FILE_NOT_EXIST'))
        .build();
    }
    const fileName = FILE_NAME_MAP[request.fileName];
    fileStaticResponse.data = await Buffer.from(
      fs.readFileSync(`${getTemplate(request.lang || 'vi')}${fileName}`, {}),
    );
    return fileStaticResponse;
  }

  // TO DO: remove after refactor done
  @MessagePattern('download_warehouse_import_template_file')
  public async downloadFileTcp(@Body() body: FileStaticRequest): Promise<any> {
    const { request } = body;
    const fileStaticResponse = new FileStaticResponse();

    if (!FILE_NAME_ENUM[request.fileName]) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.FILE_NOT_EXIST'))
        .build();
    }
    const fileName = FILE_NAME_MAP[request.fileName];
    fileStaticResponse.data = await Buffer.from(
      fs.readFileSync(`${getTemplate(request.lang)}${fileName}`, {}),
    );
    return fileStaticResponse;
  }
}
