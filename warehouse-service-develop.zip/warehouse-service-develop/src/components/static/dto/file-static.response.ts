import { SuccessResponse } from "@components/warehouse/dto/response/success.response.dto";

export class FileStaticResponse extends SuccessResponse {
  data: Buffer;
}