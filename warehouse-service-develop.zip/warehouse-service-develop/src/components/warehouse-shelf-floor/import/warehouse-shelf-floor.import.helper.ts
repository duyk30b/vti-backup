import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectDataSource } from '@nestjs/typeorm';
import { WarehouseSectorRepository } from '@repositories/warehouse-sector.repository';
import { ResponsePayload } from '@utils/response-payload';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { WarehouseShelfFloorRepository } from '@repositories/warehouse-shelf-floor.repository';
import { WarehouseShelfRepository } from '@repositories/warehouse-shelf.repository';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { UnitMeasuresRequest } from '@components/warehouse/dto/request/unit-measures.request.dto';
import { DistanceRequest } from '@components/warehouse/dto/request/unit-measures.request.dto';
import { UnitWeightRequest } from '@components/warehouse/dto/request/unit-measures.request.dto';
import { CreateWarehouseShelfFloorRequestDto } from '../dto/request/create-warehouse-shelf-floor.request.dto';
import { UpdateWarehouseShelfFloorRequestDto } from '../dto/request/update-warehouse-shelf-floor.request.dto';
import { calculateVolume, calculateActualVolume } from '@utils/common';
import { minus, plus } from '@utils/common';
import { WarehouseShelfEntity } from '@entities/warehouse-shelf/warehouse-shelf.entity';
import { WarehouseShelfFloorEntity } from '@entities/warehouse-shelf-floor/warehouse-shelf-floor.entity';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import {
  UnitMeasuresEnum,
  UnitWeightEnum,
} from '@components/warehouse/warehouse.contant';
import { keyBy, isEmpty } from 'lodash';
@Injectable()
export class WarehouseShelfFloorImport extends ImportDataAbstract {
  private readonly FIELD_TEMPLATE_CONST = {
    CODE: {
      DB_COL_NAME: 'warehouseShelfFloorCode',
      COL_NAME: ['Floor code', 'パレットコード', 'Mã tầng'],
      MAX_LENGTH: 50,
      ALLOW_NULL: false,
      REGEX: /^([a-zA-Z0-9]+)$/,
    },
    NAME: {
      DB_COL_NAME: 'warehouseShelfFloorName',
      COL_NAME: ['Floor name', 'パレット名', 'Tên tầng'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    WAREHOUSE_NAME: {
      DB_COL_NAME: 'warehouseName',
      COL_NAME: ['Warehouse name', '倉庫名', 'Tên kho'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    SECTOR_NAME: {
      DB_COL_NAME: 'warehouseSectorName',
      COL_NAME: ['Sector name', 'エリア名', 'Tên khu vực'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    SHELF_NAME: {
      DB_COL_NAME: 'warehouseShelfName',
      COL_NAME: ['Shelf name', '棚名', 'Tên kệ'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    LONG: {
      DB_COL_NAME: 'long',
      COL_NAME: ['Long', '長辺', 'Chiều dài'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
      IS_DECIMAL: true,
      IS_DECIMAL_ALLOW_ZERO: false,
    },
    WIDTH: {
      DB_COL_NAME: 'width',
      COL_NAME: ['Width', '短辺', 'Chiều rộng'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
      IS_DECIMAL: true,
      IS_DECIMAL_ALLOW_ZERO: false,
    },
    HEIGHT: {
      DB_COL_NAME: 'height',
      COL_NAME: ['Height', '厚さ', 'Chiều cao'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
      IS_DECIMAL: true,
      IS_DECIMAL_ALLOW_ZERO: false,
    },
    FRONT_MARGIN: {
      DB_COL_NAME: 'frontMargin',
      COL_NAME: ['Front', 'エリア説明', 'Trước'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
      IS_DECIMAL: false,
      IS_DECIMAL_ALLOW_ZERO: true,
    },
    BEHIND_MARGIN: {
      DB_COL_NAME: 'behindMargin',
      COL_NAME: ['Behind', '前', 'Sau'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
      IS_DECIMAL: false,
      IS_DECIMAL_ALLOW_ZERO: true,
    },
    LEFT_MARGIN: {
      DB_COL_NAME: 'leftMargin',
      COL_NAME: ['Left', '後', 'Trái'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
      IS_DECIMAL: false,
      IS_DECIMAL_ALLOW_ZERO: true,
    },
    RIGHT_MARGIN: {
      DB_COL_NAME: 'rightMargin',
      COL_NAME: ['Right', '左', 'Phải'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
      IS_DECIMAL: false,
      IS_DECIMAL_ALLOW_ZERO: true,
    },
    TOP_MARGIN: {
      DB_COL_NAME: 'topMargin',
      COL_NAME: ['Above', '右', 'Trên'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
      IS_DECIMAL: false,
      IS_DECIMAL_ALLOW_ZERO: true,
    },
    BOTTOM_MARGIN: {
      DB_COL_NAME: 'bottomMargin',
      COL_NAME: ['Under', '上', 'Dưới'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
      IS_DECIMAL: false,
      IS_DECIMAL_ALLOW_ZERO: true,
    },
    WEIGHT_LOAD: {
      DB_COL_NAME: 'weightLoad',
      COL_NAME: ['Weight load', '下', 'Chịu trọng lượng tối đa'],
      MAX_LENGTH: 255,
      IS_DECIMAL: true,
      IS_DECIMAL_ALLOW_ZERO: false,
    },
    DESCRIPTION: {
      DB_COL_NAME: 'description',
      COL_NAME: ['Floor description', 'パレット説明', 'Mô tả về tầng'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 17,
  };

  constructor(
    @Inject('WarehouseShelfRepositoryInterface')
    private readonly warehouseShelfRepository: WarehouseShelfRepository,
    @Inject('WarehouseSectorRepositoryInterface')
    private readonly warehouseSectorRepository: WarehouseSectorRepository,
    @Inject('WarehouseShelfFloorRepositoryInterface')
    private readonly warehouseShelfFloorRepository: WarehouseShelfFloorRepository,
    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    this.fieldsMap.groupSet(
      [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17],
      [
        this.FIELD_TEMPLATE_CONST.CODE,
        this.FIELD_TEMPLATE_CONST.NAME,
        this.FIELD_TEMPLATE_CONST.WAREHOUSE_NAME,
        this.FIELD_TEMPLATE_CONST.SECTOR_NAME,
        this.FIELD_TEMPLATE_CONST.SHELF_NAME,
        this.FIELD_TEMPLATE_CONST.LONG,
        this.FIELD_TEMPLATE_CONST.WIDTH,
        this.FIELD_TEMPLATE_CONST.HEIGHT,
        this.FIELD_TEMPLATE_CONST.FRONT_MARGIN,
        this.FIELD_TEMPLATE_CONST.BEHIND_MARGIN,
        this.FIELD_TEMPLATE_CONST.LEFT_MARGIN,
        this.FIELD_TEMPLATE_CONST.RIGHT_MARGIN,
        this.FIELD_TEMPLATE_CONST.TOP_MARGIN,
        this.FIELD_TEMPLATE_CONST.BOTTOM_MARGIN,
        this.FIELD_TEMPLATE_CONST.WEIGHT_LOAD,
        this.FIELD_TEMPLATE_CONST.DESCRIPTION,
      ],
    );
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
  ): Promise<ImportResponseDto> {
    const findByCode =
      await this.warehouseShelfFloorRepository.findWithRelations({
        where: {
          code: In(dataDto.map((i) => i.warehouseShelfFloorCode)),
        },
      });
    const findByName =
      await this.warehouseShelfFloorRepository.findWithRelations({
        where: {
          name: In(dataDto.map((i) => i.warehouseShelfFloorName)),
        },
      });

    findByCode.forEach((i) => Object.assign(i, { type: 'old' }));
    findByName.forEach((i) => Object.assign(i, { type: 'old' }));

    const findByCodeMap = keyBy(findByCode, 'code');
    const findByNameMap = keyBy(findByName, 'name');
    const entities = [];
    const valid = [];
    const {
      duplicateCodeOrNameMsg,
      codeNotExistMsg,
      successMsg,
      unsuccessMsg,
      addText,
      updateText,
      warehouseNotFound,
      warehouseSectorNotFound,
      warehouseShelfNotFound,
      totalShelfFloorVolumeExceedShelfVolume,
      totalShelfFloorWeightExceedShelfWeight,
    } = await this.getMessage();
    for (let index = 0; index < dataDto.length; index++) {
      const data = dataDto[index];
      const {
        i,
        action,
        warehouseShelfFloorCode,
        warehouseShelfFloorName,
        warehouseName,
        warehouseSectorName,
        warehouseShelfName,
        long,
        width,
        height,
        frontMargin,
        behindMargin,
        leftMargin,
        rightMargin,
        topMargin,
        bottomMargin,
        weightLoad,
        description,
        position,
      } = data;
      const logRow = {
        id: i,
        row: i,
        action: action,
      } as ImportResultDto;
      const msgLogs = [];

      const warehouse = await this.warehouseRepository.findOneByCondition({
        name: warehouseName,
      });
      if (!warehouse) {
        msgLogs.push(warehouseNotFound);
        logRow.log = msgLogs;
        logs.push(logRow);
        continue;
      }

      const warehouseSector =
        await this.warehouseSectorRepository.findOneByCondition({
          name: warehouseSectorName,
        });

      if (!warehouseSector) {
        msgLogs.push(warehouseSectorNotFound);
        logRow.log = msgLogs;
        logs.push(logRow);
        continue;
      }

      const warehouseShelf =
        await this.warehouseShelfRepository.findOneByCondition({
          name: warehouseShelfName,
        });

      if (!warehouseShelf) {
        msgLogs.push(warehouseShelfNotFound);
        logRow.log = msgLogs;
        logs.push(logRow);
        continue;
      }

      const longValue = new UnitMeasuresRequest();
      longValue.value = long;
      longValue.unit = warehouse.long.unit;
      const widthValue = new UnitMeasuresRequest();
      widthValue.value = width;
      widthValue.unit = warehouse.width.unit;
      const heightValue = new UnitMeasuresRequest();
      heightValue.value = height;
      heightValue.unit = warehouse.height.unit;
      const frontMarginValue = new DistanceRequest();
      frontMarginValue.value = frontMargin;
      frontMarginValue.unit = warehouse.long.unit;
      const behindMarginValue = new DistanceRequest();
      behindMarginValue.value = behindMargin;
      behindMarginValue.unit = warehouse.long.unit;
      const leftMarginValue = new DistanceRequest();
      leftMarginValue.value = leftMargin;
      leftMarginValue.unit = warehouse.width.unit;
      const rightMarginValue = new DistanceRequest();
      rightMarginValue.value = rightMargin;
      rightMarginValue.unit = warehouse.width.unit;
      const topMarginValue = new DistanceRequest();
      topMarginValue.value = topMargin;
      topMarginValue.unit = warehouse.height.unit;
      const bottomMarginValue = new DistanceRequest();
      bottomMarginValue.value = bottomMargin;
      bottomMarginValue.unit = warehouse.height.unit;
      const weightLoadValue = new UnitWeightRequest();
      weightLoadValue.value = weightLoad;
      weightLoadValue.unit = UnitWeightEnum.KG;

      let formatedData = null;
      if (action.toLowerCase() === addText) {
        formatedData = new CreateWarehouseShelfFloorRequestDto();
      } else if (action.toLowerCase() === updateText) {
        formatedData = new UpdateWarehouseShelfFloorRequestDto();
      }
      formatedData.name = warehouseShelfFloorName?.toString()?.trim();
      formatedData.code = warehouseShelfFloorCode?.toString()?.trim();
      formatedData.warehouseId = warehouse.id;
      formatedData.warehouseSectorId = warehouseSector.id;
      formatedData.warehouseShelfId = warehouseShelf.id;
      formatedData.description = description?.trim() || '';
      formatedData.long = longValue;
      formatedData.width = widthValue;
      formatedData.height = heightValue;
      formatedData.frontMargin = frontMarginValue;
      formatedData.behindMargin = behindMarginValue;
      formatedData.leftMargin = leftMarginValue;
      formatedData.rightMargin = rightMarginValue;
      formatedData.topMargin = topMarginValue;
      formatedData.bottomMargin = bottomMarginValue;
      formatedData.weightLoad = weightLoadValue;

      if (!position && action.toLowerCase() === addText) {
        formatedData.position =
          await this.warehouseShelfFloorRepository.getNextPosition(
            warehouseSector.id,
          );
      }
      const shelfVolume = calculateVolume(widthValue, heightValue, longValue);
      const volume = {
        unit: UnitMeasuresEnum.CM,
        value: shelfVolume,
      };
      const payload = {
        ...formatedData,
        volume: volume,
      };

      if (action.toLowerCase() === addText) {
        if (
          findByCodeMap[warehouseShelfFloorCode] ||
          findByNameMap[warehouseShelfFloorName]
        ) {
          msgLogs.push(duplicateCodeOrNameMsg);
        } else {
          const entity = await this.warehouseShelfFloorRepository.createEntity(
            payload,
          );

          const isValidShelfVolume = await this.validateShelfFloorVolume(
            warehouseShelf,
            entity,
          );
          if (isValidShelfVolume) {
            msgLogs.push(totalShelfFloorVolumeExceedShelfVolume);
            logRow.log = msgLogs;
            logs.push(logRow);
            continue;
          }

          const isValidShelfFloorWeight = await this.validateShelfFloorWeight(
            warehouseShelf,
            entity,
          );
          if (isValidShelfFloorWeight) {
            msgLogs.push(totalShelfFloorWeightExceedShelfWeight);
            logRow.log = msgLogs;
            logs.push(logRow);
            continue;
          }

          entities.push(entity);
          Object.assign(entity, { type: 'new' });
          findByCodeMap[warehouseShelfFloorCode] = entity;
          findByNameMap[warehouseShelfFloorName] = entity;
        }
      } else if (action.toLowerCase() === updateText) {
        if (
          findByCodeMap[warehouseShelfFloorCode] &&
          findByCodeMap[warehouseShelfFloorCode]?.['type'] === 'old'
        ) {
          if (
            findByNameMap[warehouseShelfFloorName] &&
            findByNameMap[warehouseShelfFloorName].id !=
              findByCodeMap[warehouseShelfFloorCode].id
          ) {
            msgLogs.push(duplicateCodeOrNameMsg);
          } else {
            payload.id = findByCodeMap[warehouseShelfFloorCode].id;
            const entity =
              await this.warehouseShelfFloorRepository.createEntity(
                payload,
                true,
              );
            const warehouseShelfFloor =
              await this.warehouseShelfFloorRepository.findOneById(payload.id);

            const isValidShelfVolume = await this.validateShelfFloorVolume(
              warehouseShelf,
              entity,
              warehouseShelfFloor,
            );
            if (isValidShelfVolume) {
              msgLogs.push(totalShelfFloorVolumeExceedShelfVolume);
              logRow.log = msgLogs;
              logs.push(logRow);
              continue;
            }

            const isValidShelfFloorWeight = await this.validateShelfFloorWeight(
              warehouseShelf,
              entity,
              warehouseShelfFloor,
            );
            if (isValidShelfFloorWeight) {
              msgLogs.push(totalShelfFloorWeightExceedShelfWeight);
              logRow.log = msgLogs;
              logs.push(logRow);
              continue;
            }

            entities.push(entity);
            Object.assign(entity, { type: 'new' });
            findByCodeMap[warehouseShelfFloorCode] = entity;
            findByNameMap[warehouseShelfFloorName] = entity;
          }
        } else {
          msgLogs.push(codeNotExistMsg);
        }
      }
      if (isEmpty(msgLogs)) {
        logRow.log = [successMsg];
        valid.push(logRow);
      } else {
        logRow.log = msgLogs;
        logs.push(logRow);
      }
    }
    const response = new ImportResponseDto();
    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(entities);
        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        await queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((l) => (l.log = [unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }
    response.result = logs;
    response.totalCount = logs.length;
    response.result;
    return response;
  }

  private async validateShelfFloorVolume(
    warehouseShelf: WarehouseShelfEntity,
    warehouseShelfFloorNew: WarehouseShelfFloorEntity,
    warehouseShelfFloorOld?: WarehouseShelfFloorEntity,
  ): Promise<boolean> {
    const warehouseShelfFloors =
      await this.warehouseShelfFloorRepository.findByCondition({
        warehouseShelfId: warehouseShelf.id,
      });

    const warehouseShelfFloorNewVolume = calculateActualVolume(
      warehouseShelfFloorNew.width,
      warehouseShelfFloorNew.height,
      warehouseShelfFloorNew.long,
      warehouseShelfFloorNew.topMargin,
      warehouseShelfFloorNew.bottomMargin,
      warehouseShelfFloorNew.rightMargin,
      warehouseShelfFloorNew.leftMargin,
      warehouseShelfFloorNew.frontMargin,
      warehouseShelfFloorNew.behindMargin,
    );

    let warehouseShelfFloorOldVolume = 0;
    if (warehouseShelfFloorOld) {
      warehouseShelfFloorOldVolume = calculateActualVolume(
        warehouseShelfFloorOld.width,
        warehouseShelfFloorOld.height,
        warehouseShelfFloorOld.long,
        warehouseShelfFloorOld.topMargin,
        warehouseShelfFloorOld.bottomMargin,
        warehouseShelfFloorOld.rightMargin,
        warehouseShelfFloorOld.leftMargin,
        warehouseShelfFloorOld.frontMargin,
        warehouseShelfFloorOld.behindMargin,
      );
    }

    let totalWarehouseShelfFloorVolume = minus(
      warehouseShelfFloorNewVolume,
      warehouseShelfFloorOldVolume,
    );

    if (!isEmpty(warehouseShelfFloors)) {
      warehouseShelfFloors.forEach((record) => {
        totalWarehouseShelfFloorVolume = plus(
          totalWarehouseShelfFloorVolume,
          calculateActualVolume(
            record.width,
            record.height,
            record.long,
            record.topMargin,
            record.bottomMargin,
            record.rightMargin,
            record.leftMargin,
            record.frontMargin,
            record.behindMargin,
          ),
        );
      });
    }

    return Number(warehouseShelf.volume.value) < totalWarehouseShelfFloorVolume;
  }

  private async validateShelfFloorWeight(
    warehouseShelf: WarehouseShelfEntity,
    warehouseShelfFloorNew: WarehouseShelfFloorEntity,
    warehouseShelfFloorOld?: WarehouseShelfFloorEntity,
  ): Promise<boolean> {
    const warehouseShelfFloors =
      await this.warehouseShelfFloorRepository.findByCondition({
        warehouseShelfId: warehouseShelf.id,
      });

    const warehouseShelfFloorNewWeight = Number(
      warehouseShelfFloorNew.weightLoad.value,
    );

    let warehouseShelfFloorOldWeight = 0;
    if (warehouseShelfFloorOld) {
      warehouseShelfFloorOldWeight = Number(
        warehouseShelfFloorOld.weightLoad.value,
      );
    }

    let totalWarehouseShelfFloorWeight = minus(
      warehouseShelfFloorNewWeight,
      warehouseShelfFloorOldWeight,
    );

    if (!isEmpty(warehouseShelfFloors)) {
      warehouseShelfFloors.forEach((record) => {
        totalWarehouseShelfFloorWeight = plus(
          totalWarehouseShelfFloorWeight,
          Number(record.weightLoad.value),
        );
      });
    }

    return (
      Number(warehouseShelf.weightLoad.value) < totalWarehouseShelfFloorWeight
    );
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto | any>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_CONST.REQUIRED_COL_NUM,
    );
  }
}
