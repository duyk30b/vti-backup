import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { WarehouseDataResponseDto } from '../../../warehouse/dto/response/warehouse-data.response.dto';
import { Approver } from '@utils/common.response';
import { AbstractWarehouseSpaceDataResponseDto } from '@components/warehouse/dto/response/abstract-warehouse-space-data.response.dto';
import { WarehouseShelfResponse } from '@components/warehouse-shelf/dto/response/warehouse-shelf.response.dto';
import { SectorResponseDto } from '@components/warehouse-sector/dto/response/sector.response.dto';

export class WarehouseShelfFloorResponse extends AbstractWarehouseSpaceDataResponseDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'Tầng A', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'SA', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  status: number;

  @ApiProperty({ example: 'SA', description: '' })
  @Expose()
  description: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  position: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  quantity: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  fullmentPercent: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  fullmentWeightPercent: number;

  @ApiProperty({ type: Approver })
  @Expose()
  @Type(() => Approver)
  approver: Approver;

  @ApiProperty({ type: WarehouseShelfResponse })
  @Expose()
  @Type(() => WarehouseShelfResponse)
  warehouseShelf: WarehouseShelfResponse;

  @ApiProperty({ type: SectorResponseDto })
  @Expose()
  @Type(() => SectorResponseDto)
  warehouseSector: SectorResponseDto;

  @ApiProperty({ type: WarehouseDataResponseDto })
  @Expose()
  @Type(() => WarehouseDataResponseDto)
  warehouse: WarehouseDataResponseDto;
}

export class WarehouseShelfFloorResponseDto extends SuccessResponse {
  @ApiProperty({ type: WarehouseShelfFloorResponse })
  @Expose()
  @Type(() => WarehouseShelfFloorResponse)
  data: WarehouseShelfFloorResponse;
}
