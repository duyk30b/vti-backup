import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { WarehouseShelfFloorResponse } from './warehouse-shelf-floor.response.dto';
import { Meta } from '@utils/common.response';

class WarehouseShelfFloorData {
  @ApiProperty({ type: WarehouseShelfFloorResponse, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => WarehouseShelfFloorResponse)
  items: WarehouseShelfFloorResponse[];

  @ApiProperty({ type: Meta })
  @Expose()
  @Type(() => Meta)
  meta: Meta;
}

export class GetListWarehouseShelfFloorResponseDto extends SuccessResponse {
  @ApiProperty({ type: WarehouseShelfFloorData })
  @Expose()
  @Type(() => WarehouseShelfFloorData)
  data: WarehouseShelfFloorData;
}
