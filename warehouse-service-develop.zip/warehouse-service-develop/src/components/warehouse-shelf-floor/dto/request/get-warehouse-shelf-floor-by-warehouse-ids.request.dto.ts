import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { ArrayNotEmpty, IsArray } from 'class-validator';

export class GetWarehouseShelfFloorByWarehouseIdsRequestDto extends BaseDto {
  @ApiProperty()
  @ArrayNotEmpty()
  @IsArray()
  warehouseIds: number[];
}
