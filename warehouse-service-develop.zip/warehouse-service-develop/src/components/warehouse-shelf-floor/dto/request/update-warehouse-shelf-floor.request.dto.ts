import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateWarehouseShelfFloorRequestDto } from './create-warehouse-shelf-floor.request.dto';

export class UpdateWarehouseShelfFloorParamDto extends CreateWarehouseShelfFloorRequestDto {}
export class UpdateWarehouseShelfFloorRequestDto extends UpdateWarehouseShelfFloorParamDto {
  @ApiProperty({ example: 1, description: 'warehouse shelf floor id' })
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
