import { IsNotEmpty, IsArray } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';

export class GetListWarehouseShelfFloorByIdsRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsArray()
  ids: number[];
}
