import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ApiError } from '@utils/api.error';
import { ResponsePayload } from '@utils/response-payload';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { plainToInstance } from 'class-transformer';
import { ResponseBuilder } from '@utils/response-builder';
import { DataSource, In, Not } from 'typeorm';
import { isEmpty } from 'lodash';
import { PagingResponse } from '@utils/paging.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { WarehouseShelfFloorServiceInterface } from './interface/warehouse-shelf-floor.service.interface';
import { WarehouseShelfFloorRepositoryInterface } from './interface/warehouse-shelf-floor.repository.interface';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { GetListWarehouseShelfFloorRequestDto } from './dto/request/get-list-warehouse-shelf-floor.request.dto';
import { GetListWarehouseShelfFloorResponseDto } from './dto/response/get-list-warehouse-shelf-floor.response.dto';
import {
  WarehouseShelfFloorResponse,
  WarehouseShelfFloorResponseDto,
} from './dto/response/warehouse-shelf-floor.response.dto';
import { CreateWarehouseShelfFloorRequestDto } from './dto/request/create-warehouse-shelf-floor.request.dto';
import { UpdateWarehouseShelfFloorRequestDto } from './dto/request/update-warehouse-shelf-floor.request.dto';
import { SetStatusRequestDto } from '@utils/common.request.dto';
import {
  calculateActualVolume,
  calculateFullmentPercentContainer,
  calculateVolume,
  formatUnitMeasures,
  formatUnitWeight,
  minus,
  plus,
} from '@utils/common';
import {
  CAN_CONFIRM_WAREHOUSE_SHELF_FLOOR_STATUS,
  CAN_DELETE_WAREHOUSE_SHELF_FLOOR_STATUS,
  CAN_REJECT_WAREHOUSE_SHELF_FLOOR_STATUS,
  CAN_UPDATE_WAREHOUSE_SHELF_FLOOR_STATUS,
  WarehouseShelfFloorStatusEnum,
} from './warehouse-shelf-floor.constant';
import { WarehouseShelfEntity } from '@entities/warehouse-shelf/warehouse-shelf.entity';
import {
  DATA_DEFAULT_MEASURES,
  UnitMeasuresEnum,
} from '@components/warehouse/warehouse.contant';
import { WarehouseShelfRepositoryInterface } from '@components/warehouse-shelf/interface/warehouse-shelf.repository.interface';
import { WarehouseShelfFloorEntity } from '@entities/warehouse-shelf-floor/warehouse-shelf-floor.entity';
import { CAN_CONFIRM_WAREHOUSE_SHELF_STATUS } from '@components/warehouse-shelf/warehouse-shelf.constant';
import { WarehouseShelfFloorImport } from './import/warehouse-shelf-floor.import.helper';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { GetListWarehouseShelfFloorByIdsRequestDto } from './dto/request/get-list-warehouse-shelf-floor-by-ids.request.dto';
import { stringFormat } from '@utils/object.util';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

@Injectable()
export class WarehouseShelfFloorService
  implements WarehouseShelfFloorServiceInterface
{
  constructor(
    @Inject('WarehouseShelfFloorRepositoryInterface')
    private readonly warehouseShelfFloorRepository: WarehouseShelfFloorRepositoryInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('WarehouseShelfRepositoryInterface')
    private readonly warehouseShelfRepository: WarehouseShelfRepositoryInterface,

    @Inject('WarehouseShelfFloorImport')
    private readonly warehouseShelfFloorImport: WarehouseShelfFloorImport,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  public async getListByIds(
    request: GetListWarehouseShelfFloorByIdsRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { ids } = request;
    const data = await this.warehouseShelfFloorRepository.findWithRelations({
      where: {
        id: In(ids),
      },
      relations: [
        'warehouseShelf',
        'warehouseShelf.warehouseSector',
        'warehouse',
      ],
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(data)
      .build();
  }

  async importShelfFloor(request: FileUploadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
    } as ImportRequestDto;
    return this.warehouseShelfFloorImport.importUtil(importRequestDto);
  }

  public async create(
    request: CreateWarehouseShelfFloorRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfFloorResponseDto | any>> {
    try {
      const {
        long,
        width,
        height,
        warehouseShelfId,
        name,
        warehouseId,
        code,
        position,
        bottomMargin,
      } = request;

      const warehouse = await this.warehouseRepository.findOneById(warehouseId);
      if (!warehouse) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
          .build();
      }

      const warehouseShelf = await this.warehouseShelfRepository.findOneById(
        warehouseShelfId,
      );
      if (!warehouseShelf) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.WAREHOUSE_SHELF_NOT_FOUND'),
          )
          .build();
      }

      const warehouseShelfFloorCodeExist =
        await this.warehouseShelfFloorRepository.findOneByCondition({
          code: code,
        });
      if (warehouseShelfFloorCodeExist) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.CODE_ALREADY_EXISTS'))
          .build();
      }

      const warehouseShelfFloorNameExist =
        await this.warehouseShelfFloorRepository.findOneByCondition({
          name: name,
        });
      if (warehouseShelfFloorNameExist) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.NAME_ALREADY_EXISTS'))
          .build();
      }

      if (!bottomMargin) {
        request.bottomMargin = DATA_DEFAULT_MEASURES;
      }

      const shelfFloorVolume = calculateVolume(width, height, long);
      const volume = {
        unit: UnitMeasuresEnum.CM,
        value: shelfFloorVolume,
      };

      if (!position) {
        request.position =
          await this.warehouseShelfFloorRepository.getNextPosition(
            warehouseShelfId,
          );
      }

      const payload = {
        ...request,
        volume: volume,
      };

      const warehouseShelfFloorEntity =
        await this.warehouseShelfFloorRepository.createEntity(payload);

      const isValidShelfFloorVolume = await this.validateShelfFloorVolume(
        warehouseShelf,
        warehouseShelfFloorEntity,
      );
      if (isValidShelfFloorVolume) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.TOTAL_SHELF_FLOOR_VOLUME_EXCEEDS_SHELF_VOLUME',
            ),
          )
          .build();
      }

      const isValidShelfFloorWeight = await this.validateShelfFloorWeight(
        warehouseShelf,
        warehouseShelfFloorEntity,
      );
      if (isValidShelfFloorWeight) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.TOTAL_SHELF_FLOOR_WEIGHT_EXCEEDS_SHELF_WEIGHT',
            ),
          )
          .build();
      }

      const result = await this.warehouseShelfFloorRepository.create(
        warehouseShelfFloorEntity,
      );
      const response = plainToInstance(WarehouseShelfFloorResponse, result, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(response)
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CREATE'))
        .build();
    }
  }
  public async update(
    request: UpdateWarehouseShelfFloorRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfFloorResponseDto | any>> {
    try {
      const {
        long,
        width,
        height,
        warehouseShelfId,
        name,
        warehouseId,
        id,
        code,
        bottomMargin,
      } = request;

      const warehouseShelfFloor =
        await this.warehouseShelfFloorRepository.findOneById(id);
      if (!warehouseShelfFloor) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.WAREHOUSE_SHELF_FLOOR_NOT_FOUND'),
          )
          .build();
      }

      if (
        !CAN_UPDATE_WAREHOUSE_SHELF_FLOOR_STATUS.includes(
          warehouseShelfFloor.status,
        )
      ) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.STATUS_INVALID'),
        ).toResponse();
      }

      const warehouse = await this.warehouseRepository.findOneById(warehouseId);
      if (!warehouse) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
          .build();
      }

      const warehouseShelf = await this.warehouseShelfRepository.findOneById(
        warehouseShelfId,
      );
      if (!warehouseShelf) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.WAREHOUSE_SHELF_NOT_FOUND'),
          )
          .build();
      }

      const warehouseShelfFloorCodeExist =
        await this.warehouseShelfFloorRepository.findOneByCondition({
          code: code,
          id: Not(id),
        });
      if (warehouseShelfFloorCodeExist) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.CODE_ALREADY_EXISTS'))
          .build();
      }

      const warehouseShelfFloorNameExist =
        await this.warehouseShelfFloorRepository.findOneByCondition({
          name: name,
          id: Not(id),
        });
      if (warehouseShelfFloorNameExist) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.NAME_ALREADY_EXISTS'))
          .build();
      }

      if (!bottomMargin) {
        request.bottomMargin = DATA_DEFAULT_MEASURES;
      }

      const shelfFloorVolume = calculateVolume(width, height, long);
      const volume = {
        unit: UnitMeasuresEnum.CM,
        value: shelfFloorVolume,
      };

      const payload = {
        ...request,
        volume: volume,
      };
      const warehouseShelfFloorEntity =
        await this.warehouseShelfFloorRepository.createEntity(payload, true);

      const isValidShelfFloorVolume = await this.validateShelfFloorVolume(
        warehouseShelf,
        warehouseShelfFloorEntity,
        warehouseShelfFloor,
      );
      if (isValidShelfFloorVolume) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.TOTAL_SHELF_FLOOR_VOLUME_EXCEEDS_SHELF_VOLUME',
            ),
          )
          .build();
      }

      const isValidShelfFloorWeight = await this.validateShelfFloorWeight(
        warehouseShelf,
        warehouseShelfFloorEntity,
        warehouseShelfFloor,
      );
      if (isValidShelfFloorWeight) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.TOTAL_SHELF_FLOOR_WEIGHT_EXCEEDS_SHELF_WEIGHT',
            ),
          )
          .build();
      }

      const result = await this.warehouseShelfFloorRepository.create(
        warehouseShelfFloorEntity,
      );
      const response = plainToInstance(WarehouseShelfFloorResponse, result, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(response)
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }
  }
  public async delete(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const warehouseShelfFloor =
      await this.warehouseShelfFloorRepository.findOneById(id);
    if (!warehouseShelfFloor) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WAREHOUSE_SHELF_FLOOR_NOT_FOUND'),
        )
        .build();
    }

    if (
      !CAN_DELETE_WAREHOUSE_SHELF_FLOOR_STATUS.includes(
        warehouseShelfFloor.status,
      )
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_INVALID'),
      ).toResponse();
    }
    await this.warehouseShelfFloorRepository.remove(id);
    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const warehouseShelfFloors =
      await this.warehouseShelfFloorRepository.findByCondition({
        id: In(ids),
      });

    const warehouseShelfFloorIds = warehouseShelfFloors.map(
      (warehouseShelfFloor) => warehouseShelfFloor.id,
    );
    if (warehouseShelfFloors.length !== ids.length) {
      ids.forEach((id) => {
        if (!warehouseShelfFloorIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < warehouseShelfFloors.length; i++) {
      const warehouseShelfFloor = warehouseShelfFloors[i];
      if (
        !CAN_DELETE_WAREHOUSE_SHELF_FLOOR_STATUS.includes(
          warehouseShelfFloor.status,
        )
      )
        failIdsList.push(warehouseShelfFloor.id);
    }

    const validIds = warehouseShelfFloors
      .filter(
        (warehouseShelfFloor) => !failIdsList.includes(warehouseShelfFloor.id),
      )
      .map((warehouseShelfFloor) => warehouseShelfFloor.id);

    const queryRunner = await this.connection.createQueryRunner();
    try {
      if (!isEmpty(validIds)) {
        await queryRunner.startTransaction();
        await queryRunner.manager.delete(WarehouseShelfFloorEntity, validIds);
        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    await queryRunner.release();
    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async detail(
    id: number,
  ): Promise<ResponsePayload<WarehouseShelfFloorResponseDto | any>> {
    const warehouseShelfFloor =
      await this.warehouseShelfFloorRepository.getDetail(id);
    if (!warehouseShelfFloor) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WAREHOUSE_SHELF_FLOOR_NOT_FOUND'),
        )
        .build();
    }
    const response = plainToInstance(
      WarehouseShelfFloorResponse,
      warehouseShelfFloor,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }
  public async getList(
    request: GetListWarehouseShelfFloorRequestDto,
  ): Promise<ResponsePayload<GetListWarehouseShelfFloorResponseDto | any>> {
    const { result, count } = await this.warehouseShelfFloorRepository.getList(
      request,
    );
    const response = plainToInstance(WarehouseShelfFloorResponse, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
  public async confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfFloorResponseDto | any>> {
    const { id, userId } = request;
    const warehouseShelfFloor =
      await this.warehouseShelfFloorRepository.findOneById(id);
    if (!warehouseShelfFloor) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WAREHOUSE_SHELF_FLOOR_NOT_FOUND'),
        )
        .build();
    }

    if (
      !CAN_CONFIRM_WAREHOUSE_SHELF_FLOOR_STATUS.includes(
        warehouseShelfFloor.status,
      )
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_INVALID'),
      ).toResponse();
    }

    const warehouseShelf = await this.warehouseShelfRepository.findOneById(
      warehouseShelfFloor.warehouseShelfId,
    );
    if (!warehouseShelf) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WAREHOUSE_SHELF_NOT_FOUND'),
        )
        .build();
    }

    if (CAN_CONFIRM_WAREHOUSE_SHELF_STATUS.includes(warehouseShelf.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.WAREHOUSE_SHELF_NEED_CONFIRM'),
      ).toResponse();
    }

    warehouseShelfFloor.status = WarehouseShelfFloorStatusEnum.CONFIRMED;
    warehouseShelfFloor.approverId = userId;
    warehouseShelfFloor.approvedAt = new Date(Date.now());

    const result = await this.warehouseShelfFloorRepository.create(
      warehouseShelfFloor,
    );

    const response = plainToInstance(WarehouseShelfFloorResponse, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }
  public async reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfFloorResponseDto | any>> {
    const { id, userId } = request;
    const warehouseShelfFloor =
      await this.warehouseShelfFloorRepository.findOneById(id);
    if (!warehouseShelfFloor) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WAREHOUSE_SHELF_FLOOR_NOT_FOUND'),
        )
        .build();
    }

    if (
      !CAN_REJECT_WAREHOUSE_SHELF_FLOOR_STATUS.includes(
        warehouseShelfFloor.status,
      )
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_INVALID'),
      ).toResponse();
    }

    warehouseShelfFloor.status = WarehouseShelfFloorStatusEnum.REJECT;
    warehouseShelfFloor.approverId = userId;
    warehouseShelfFloor.approvedAt = new Date(Date.now());

    const result = await this.warehouseShelfFloorRepository.create(
      warehouseShelfFloor,
    );

    const response = plainToInstance(WarehouseShelfFloorResponse, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  private async validateShelfFloorVolume(
    warehouseShelf: WarehouseShelfEntity,
    warehouseShelfFloorNew: WarehouseShelfFloorEntity,
    warehouseShelfFloorOld?: WarehouseShelfFloorEntity,
  ): Promise<boolean> {
    const warehouseShelfFloors =
      await this.warehouseShelfFloorRepository.findByCondition({
        warehouseShelfId: warehouseShelf.id,
      });

    const warehouseShelfFloorNewVolume = calculateActualVolume(
      warehouseShelfFloorNew.width,
      warehouseShelfFloorNew.height,
      warehouseShelfFloorNew.long,
      warehouseShelfFloorNew.topMargin,
      warehouseShelfFloorNew.bottomMargin,
      warehouseShelfFloorNew.rightMargin,
      warehouseShelfFloorNew.leftMargin,
      warehouseShelfFloorNew.frontMargin,
      warehouseShelfFloorNew.behindMargin,
    );

    let warehouseShelfFloorOldVolume = 0;
    if (warehouseShelfFloorOld) {
      warehouseShelfFloorOldVolume = calculateActualVolume(
        warehouseShelfFloorOld.width,
        warehouseShelfFloorOld.height,
        warehouseShelfFloorOld.long,
        warehouseShelfFloorOld.topMargin,
        warehouseShelfFloorOld.bottomMargin,
        warehouseShelfFloorOld.rightMargin,
        warehouseShelfFloorOld.leftMargin,
        warehouseShelfFloorOld.frontMargin,
        warehouseShelfFloorOld.behindMargin,
      );
    }

    let totalWarehouseShelfFloorVolume = minus(
      warehouseShelfFloorNewVolume,
      warehouseShelfFloorOldVolume,
    );

    if (!isEmpty(warehouseShelfFloors)) {
      warehouseShelfFloors.forEach((record) => {
        totalWarehouseShelfFloorVolume = plus(
          totalWarehouseShelfFloorVolume,
          calculateActualVolume(
            record.width,
            record.height,
            record.long,
            record.topMargin,
            record.bottomMargin,
            record.rightMargin,
            record.leftMargin,
            record.frontMargin,
            record.behindMargin,
          ),
        );
      });
    }

    return Number(warehouseShelf.volume.value) < totalWarehouseShelfFloorVolume;
  }

  private async validateShelfFloorWeight(
    warehouseShelf: WarehouseShelfEntity,
    warehouseShelfFloorNew: WarehouseShelfFloorEntity,
    warehouseShelfFloorOld?: WarehouseShelfFloorEntity,
  ): Promise<boolean> {
    const warehouseShelfFloors =
      await this.warehouseShelfFloorRepository.findByCondition({
        warehouseShelfId: warehouseShelf.id,
      });

    const warehouseShelfFloorNewWeight = Number(
      warehouseShelfFloorNew.weightLoad.value,
    );

    let warehouseShelfFloorOldWeight = 0;
    if (warehouseShelfFloorOld) {
      warehouseShelfFloorOldWeight = Number(
        warehouseShelfFloorOld.weightLoad.value,
      );
    }

    let totalWarehouseShelfFloorWeight = minus(
      warehouseShelfFloorNewWeight,
      warehouseShelfFloorOldWeight,
    );

    if (!isEmpty(warehouseShelfFloors)) {
      warehouseShelfFloors.forEach((record) => {
        totalWarehouseShelfFloorWeight = plus(
          totalWarehouseShelfFloorWeight,
          Number(record.weightLoad.value),
        );
      });
    }

    return (
      Number(warehouseShelf.weightLoad.value) < totalWarehouseShelfFloorWeight
    );
  }

  async updateFullmentPercent(
    floors: any,
    itemsSize: any,
    isImport = true,
  ): Promise<any> {
    if (isEmpty(floors)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    floors.map((floor) => {
      const { volume, weight } = itemsSize.find(
        (item) => item.floorId === floor.id,
      );
      const { value: volumeFloor, unit: unitVolumeFloor } = floor.volume;
      const { value: weightFloor, unit: unitWeightFloor } = floor.weightLoad;
      if (volume !== 0 && volumeFloor !== 0) {
        const volumeFloorFormat = formatUnitMeasures(
          volumeFloor,
          unitVolumeFloor,
        );
        const fullmentPercent = calculateFullmentPercentContainer(
          floor.fullmentPercent,
          volumeFloorFormat,
          volume,
          isImport,
        );
        floor.fullmentPercent =
          fullmentPercent <= 0 ? 0 : fullmentPercent.toFixed(2);
      }

      if (weight !== 0 && weightFloor !== 0) {
        const weightFloorFormat = formatUnitWeight(
          weightFloor,
          unitWeightFloor,
        );
        const fullmentWeightPercent = calculateFullmentPercentContainer(
          floor.fullmentWeightPercent,
          weightFloorFormat,
          weight,
          isImport,
        );
        floor.fullmentWeightPercent =
          fullmentWeightPercent <= 0 ? 0 : fullmentWeightPercent.toFixed(2);
      }
    });
    await this.warehouseShelfFloorRepository.create(floors);

    return new ResponseBuilder(floors)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getWarehouseShelfFloorsByNameKeyword(
    nameKeyword: string,
  ): Promise<any> {
    const warehouseShelfFloors =
      await this.warehouseShelfFloorRepository.findWarehouseShelfFloorsByNameKeyword(
        nameKeyword,
      );
    const response = plainToInstance(
      WarehouseShelfFloorResponse,
      warehouseShelfFloors,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async getWarehouseShelfFloorByWarehouseIds(
    warehouseIds: number[],
  ): Promise<any> {
    const warehouseShelfFloors =
      await this.warehouseShelfFloorRepository.findByCondition({
        warehouseId: In(warehouseIds),
      });
    const response = plainToInstance(
      WarehouseShelfFloorResponse,
      warehouseShelfFloors,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
}
