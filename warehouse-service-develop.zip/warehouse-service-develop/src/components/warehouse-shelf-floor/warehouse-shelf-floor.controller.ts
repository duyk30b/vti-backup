import {
  DeleteRequestDto,
  DetailRequestDto,
  SetStatusRequestDto,
} from '@utils/common.request.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { WarehouseShelfFloorServiceInterface } from './interface/warehouse-shelf-floor.service.interface';
import { WarehouseShelfFloorResponseDto } from './dto/response/warehouse-shelf-floor.response.dto';
import { GetListWarehouseShelfFloorResponseDto } from './dto/response/get-list-warehouse-shelf-floor.response.dto';
import { GetListWarehouseShelfFloorRequestDto } from './dto/request/get-list-warehouse-shelf-floor.request.dto';
import { CreateWarehouseShelfFloorRequestDto } from './dto/request/create-warehouse-shelf-floor.request.dto';
import { UpdateWarehouseShelfFloorParamDto } from './dto/request/update-warehouse-shelf-floor.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CONFIRM_WAREHOUSE_SHELF_FLOOR_PERMISSION,
  CREATE_WAREHOUSE_SHELF_FLOOR_PERMISSION,
  UPDATE_WAREHOUSE_SHELF_FLOOR_PERMISSION,
  DELETE_WAREHOUSE_SHELF_FLOOR_PERMISSION,
  DETAIL_WAREHOUSE_SHELF_FLOOR_PERMISSION,
  LIST_WAREHOUSE_SHELF_FLOOR_PERMISSION,
  REJECT_WAREHOUSE_SHELF_FLOOR_PERMISSION,
  IMPORT_WAREHOUSE_SHELF_FLOOR_PERMISSION,
} from '@utils/permissions/warehouse-shelf-floor';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { GetListWarehouseShelfFloorByIdsRequestDto } from './dto/request/get-list-warehouse-shelf-floor-by-ids.request.dto';
import { GetWarehouseShelfFloorByWarehouseIdsRequestDto } from './dto/request/get-warehouse-shelf-floor-by-warehouse-ids.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ApiOperation, ApiResponse, ApiConsumes } from '@nestjs/swagger';
import { NATS_WAREHOUSE } from '@config/nats.config';

@Controller('floors')
export class WarehouseShelfFloorController {
  constructor(
    @Inject('WarehouseShelfFloorServiceInterface')
    private readonly warehouseShelfFloorService: WarehouseShelfFloorServiceInterface,
  ) {}

  @PermissionCode(IMPORT_WAREHOUSE_SHELF_FLOOR_PERMISSION.code)
  // @MessagePattern(`${NATS_WAREHOUSE}.import_warehouse_shelf_floor`)
  @Post('/import')
  @ApiOperation({
    tags: ['Tang'],
    summary: 'Import tang',
    description: 'Nhập một loạt tang',
  })
  @ApiResponse({
    status: 200,
    description: 'Import successfully',
    type: ImportResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  public async importWarehouseShelfFloor(
    @Body() body: FileUploadRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseShelfFloorService.importShelfFloor(request);
  }

  @PermissionCode(DETAIL_WAREHOUSE_SHELF_FLOOR_PERMISSION.code)
  // @MessagePattern(`${NATS_WAREHOUSE}.detail_warehouse_floor`)
  @Get('/:id')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'Get Floor Detail',
    description: 'Chi tiết tầng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: null,
  })
  public async detail(
    @Param() param: DetailRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfFloorResponseDto | any>> {
    const { request, responseError } = param;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseShelfFloorService.detail(request.id);
  }

  @PermissionCode(LIST_WAREHOUSE_SHELF_FLOOR_PERMISSION.code)
  // @MessagePattern(`${NATS_WAREHOUSE}.list_warehouse_floor`)
  @Get('/list')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'List Floor',
    description: 'Danh sách tầng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: null,
  })
  public async getList(
    @Query() payload: GetListWarehouseShelfFloorRequestDto,
  ): Promise<ResponsePayload<GetListWarehouseShelfFloorResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseShelfFloorService.getList(request);
  }

  @MessagePattern(`${NATS_WAREHOUSE}.list_warehouse_floor_by_ids`)
  public async getListByIds(
    @Body() payload: GetListWarehouseShelfFloorByIdsRequestDto,
  ): Promise<ResponsePayload<GetListWarehouseShelfFloorResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseShelfFloorService.getListByIds(request);
  }

  //TODO
  @PermissionCode(CREATE_WAREHOUSE_SHELF_FLOOR_PERMISSION.code)
  // @MessagePattern(`${NATS_WAREHOUSE}.create_warehouse_floor`)
  @Post('/create')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'Create Floor',
    description: 'Tạo tầng',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async create(
    @Body() payload: CreateWarehouseShelfFloorRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfFloorResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseShelfFloorService.create(request);
  }

  @PermissionCode(UPDATE_WAREHOUSE_SHELF_FLOOR_PERMISSION.code)
  // @MessagePattern(`${NATS_WAREHOUSE}.update_warehouse_floor`)
  @Put('/:id')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'Update Floor',
    description: 'Cập nhật tầng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateWarehouseShelfFloorParamDto,
  ): Promise<ResponsePayload<WarehouseShelfFloorResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = Number(id);
    return await this.warehouseShelfFloorService.update(request);
  }

  @PermissionCode(CONFIRM_WAREHOUSE_SHELF_FLOOR_PERMISSION.code)
  // @MessagePattern(`${NATS_WAREHOUSE}.confirm_warehouse_floor`)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'Confirm Floor',
    description: 'xác nhận tầng',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: null,
  })
  public async confirm(
    @Param() param: SetStatusRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfFloorResponseDto | any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseShelfFloorService.confirm(request);
  }

  @PermissionCode(REJECT_WAREHOUSE_SHELF_FLOOR_PERMISSION.code)
  // @MessagePattern(`${NATS_WAREHOUSE}.reject_warehouse_floor`)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'Reject Floor',
    description: 'Từ chối xác nhận tầng',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: null,
  })
  public async reject(
    @Param() param: SetStatusRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfFloorResponseDto | any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseShelfFloorService.reject(request);
  }

  @PermissionCode(DELETE_WAREHOUSE_SHELF_FLOOR_PERMISSION.code)
  // @MessagePattern(`${NATS_WAREHOUSE}.delete_warehouse_floor`)
  @Delete('/floors/:id')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'Delete Floor',
    description: 'Xóa tầng',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async delete(
    @Param() param: DeleteRequestDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = param;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseShelfFloorService.delete(request.id);
  }

  @PermissionCode(DELETE_WAREHOUSE_SHELF_FLOOR_PERMISSION.code)
  @MessagePattern(`${NATS_WAREHOUSE}.delete_warehouse_floor_multiple`)
  public async deleteMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseShelfFloorService.deleteMultiple(request);
  }

  @MessagePattern(`${NATS_WAREHOUSE}.get_warehouse_shelf_floor_by_name_keyword`)
  public async getItemByConditions(@Body() payload: any): Promise<any> {
    return await this.warehouseShelfFloorService.getWarehouseShelfFloorsByNameKeyword(
      payload.nameKeyword,
    );
  }

  @MessagePattern(
    `${NATS_WAREHOUSE}.get_warehouse_shelf_floor_by_warehouse_ids`,
  )
  public async getWarehouseShelfFloorByWarehouseIds(
    @Body() payload: GetWarehouseShelfFloorByWarehouseIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseShelfFloorService.getWarehouseShelfFloorByWarehouseIds(
      request.warehouseIds,
    );
  }

  //TODO remove when refactor done
  @MessagePattern(`${NATS_WAREHOUSE}.get_warehouse_shelf_floor_by_name_keyword`)
  public async getItemByConditionsTcp(@Body() payload: any): Promise<any> {
    return await this.warehouseShelfFloorService.getWarehouseShelfFloorsByNameKeyword(
      payload.nameKeyword,
    );
  }

  @MessagePattern(
    `${NATS_WAREHOUSE}.get_warehouse_shelf_floor_by_warehouse_ids`,
  )
  public async getWarehouseShelfFloorByWarehouseIdsTcp(
    @Body() payload: GetWarehouseShelfFloorByWarehouseIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseShelfFloorService.getWarehouseShelfFloorByWarehouseIds(
      request.warehouseIds,
    );
  }

  @PermissionCode(DETAIL_WAREHOUSE_SHELF_FLOOR_PERMISSION.code)
  @MessagePattern(`${NATS_WAREHOUSE}.detail_warehouse_floor`)
  public async detailTcp(
    @Body() body: DetailRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfFloorResponseDto | any>> {
    const { request, responseError } = body;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseShelfFloorService.detail(request.id);
  }

  @PermissionCode(LIST_WAREHOUSE_SHELF_FLOOR_PERMISSION.code)
  @MessagePattern(`${NATS_WAREHOUSE}.list_warehouse_floor`)
  public async getListTcp(
    @Body() payload: GetListWarehouseShelfFloorRequestDto,
  ): Promise<ResponsePayload<GetListWarehouseShelfFloorResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseShelfFloorService.getList(request);
  }
}
