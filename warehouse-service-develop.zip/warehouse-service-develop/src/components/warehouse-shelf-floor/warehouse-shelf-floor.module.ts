import { UserModule } from '@components/user/user.module';
import { WarehouseSectorModule } from '@components/warehouse-sector/warehouse-sector.module';
import { UserService } from '@components/user/user.service';
import { WarehouseShelfFloorEntity } from '@entities/warehouse-shelf-floor/warehouse-shelf-floor.entity';
import { WarehouseShelfEntity } from '@entities/warehouse-shelf/warehouse-shelf.entity';
import { Warehouse } from '@entities/warehouse/warehouse.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WarehouseShelfFloorRepository } from '@repositories/warehouse-shelf-floor.repository';
import { WarehouseShelfRepository } from '@repositories/warehouse-shelf.repository';
import { WarehouseRepository } from '@repositories/warehouse.repository';
import { WarehouseShelfFloorController } from './warehouse-shelf-floor.controller';
import { WarehouseShelfFloorService } from './warehouse-shelf-floor.service';
import { WarehouseShelfFloorImport } from './import/warehouse-shelf-floor.import.helper';
@Module({
  imports: [
    TypeOrmModule.forFeature([
      WarehouseShelfEntity,
      WarehouseShelfFloorEntity,
      Warehouse,
    ]),
    UserModule,
    WarehouseSectorModule,
  ],
  providers: [
    {
      provide: 'WarehouseShelfFloorRepositoryInterface',
      useClass: WarehouseShelfFloorRepository,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'WarehouseShelfRepositoryInterface',
      useClass: WarehouseShelfRepository,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'WarehouseShelfFloorServiceInterface',
      useClass: WarehouseShelfFloorService,
    },
    {
      provide: 'WarehouseShelfFloorImport',
      useClass: WarehouseShelfFloorImport,
    },
  ],
  exports: [
    {
      provide: 'WarehouseShelfFloorRepositoryInterface',
      useClass: WarehouseShelfFloorRepository,
    },
    {
      provide: 'WarehouseShelfRepositoryInterface',
      useClass: WarehouseShelfRepository,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'WarehouseShelfFloorServiceInterface',
      useClass: WarehouseShelfFloorService,
    },
    {
      provide: 'WarehouseShelfFloorImport',
      useClass: WarehouseShelfFloorImport,
    },
  ],
  controllers: [WarehouseShelfFloorController],
})
export class WarehouseShelfFloorModule {}
