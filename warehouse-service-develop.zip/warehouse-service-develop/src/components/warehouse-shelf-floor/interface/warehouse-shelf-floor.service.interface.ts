import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { SetStatusRequestDto } from '@utils/common.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { CreateWarehouseShelfFloorRequestDto } from '../dto/request/create-warehouse-shelf-floor.request.dto';
import { GetListWarehouseShelfFloorRequestDto } from '../dto/request/get-list-warehouse-shelf-floor.request.dto';
import { UpdateWarehouseShelfFloorRequestDto } from '../dto/request/update-warehouse-shelf-floor.request.dto';
import { GetListWarehouseShelfFloorResponseDto } from '../dto/response/get-list-warehouse-shelf-floor.response.dto';
import { WarehouseShelfFloorResponseDto } from '../dto/response/warehouse-shelf-floor.response.dto';
import { GetListWarehouseShelfFloorByIdsRequestDto } from '../dto/request/get-list-warehouse-shelf-floor-by-ids.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

export interface WarehouseShelfFloorServiceInterface {
  importShelfFloor(request: FileUploadRequestDto): Promise<any>;
  create(
    request: CreateWarehouseShelfFloorRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfFloorResponseDto | any>>;
  update(
    request: UpdateWarehouseShelfFloorRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfFloorResponseDto | any>>;
  delete(id: number): Promise<ResponsePayload<SuccessResponse | any>>;
  deleteMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<SuccessResponse | any>>;
  detail(
    id: number,
  ): Promise<ResponsePayload<WarehouseShelfFloorResponseDto | any>>;
  getList(
    request: GetListWarehouseShelfFloorRequestDto,
  ): Promise<ResponsePayload<GetListWarehouseShelfFloorResponseDto | any>>;
  getListByIds(
    request: GetListWarehouseShelfFloorByIdsRequestDto,
  ): Promise<ResponsePayload<any>>;
  confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfFloorResponseDto | any>>;
  reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfFloorResponseDto | any>>;
  updateFullmentPercent(floors: any, itemsSize: any, isImport): Promise<any>;
  getWarehouseShelfFloorsByNameKeyword(nameKeyword: string): Promise<any>;
  getWarehouseShelfFloorByWarehouseIds(warehouseIds: number[]);
}
