import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { GetListWarehouseShelfFloorRequestDto } from '../dto/request/get-list-warehouse-shelf-floor.request.dto';
import { WarehouseShelfFloorEntity } from '@entities/warehouse-shelf-floor/warehouse-shelf-floor.entity';
import { WarehouseShelfFloorDesignRequestDto } from '@components/warehouse/dto/request/update-warehouse-design.request.dto';
import { GetWarehouseInventoryListRequestDto } from '@components/inventory/dto/request/get-warehouse-inventory-list.request.dto';

export interface WarehouseShelfFloorRepositoryInterface
  extends BaseInterfaceRepository<WarehouseShelfFloorEntity> {
  createEntity(
    payload: any,
    isUpdate?: boolean,
  ): Promise<WarehouseShelfFloorEntity>;
  getList(request: GetListWarehouseShelfFloorRequestDto): Promise<any>;
  getNextPosition(warehouseShelfId: number): Promise<number>;
  getDetail(id: number): Promise<any>;
  findWarehouseShelfFloorsByNameKeyword(nameKeyword: string): Promise<any>;
  getFloorSpaceByWarehouse(
    warehouseIds: number[],
    floorIds?: number[],
  ): Promise<any>;
  getFloorSpaceByWarehousesInventory(
    request: GetWarehouseInventoryListRequestDto,
  ): Promise<any>;
  createEntityDesign(
    warehouseId: number,
    code: string,
    request: WarehouseShelfFloorDesignRequestDto,
  ): WarehouseShelfFloorEntity;
  updateEntityDesign(
    entity: WarehouseShelfFloorEntity,
    request: WarehouseShelfFloorDesignRequestDto,
  ): WarehouseShelfFloorEntity;
  getWarehouseShelfFloorByIds(ids: number[]): Promise<any>;
  getWarehouseShelfFloorByWarehouseIds(warehouseIds: number[]): Promise<any>;
  checkSectorShelfFloorInWarehouse(
    list: any[],
    warehouseId?: number,
  ): Promise<any>;
}
