import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsInt,
} from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';

export class CreateTemplateShelfTemplateShelfFloorDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'Mã tầng' })
  @IsNotEmpty()
  @IsInt()
  templateShelfFloorId: number;

  @ApiProperty({ example: 1, description: 'Mã kệ' })
  @IsNotEmpty()
  @IsInt()
  templateShelfId: number;
}
