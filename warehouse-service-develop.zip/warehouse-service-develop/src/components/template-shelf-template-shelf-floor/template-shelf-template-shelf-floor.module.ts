import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TemplateShelfTemplateShelfFloorEntity } from '@entities/template-shelf-template-shelf-floor/template-shelf-template-shelf-floor.entity';
import { TemplateShelfEntity } from '@entities/template-shelf/template-shelf.entity';
import { TemplateShelfFloorEntity } from '@entities/template-shelf-floor/template-shelf-floor.entity';
import { TemplateShelfTemplateShelfFloorRepository } from '@repositories/template-shelf-template-shelf-floor.repository';
import { TemplateShelfTemplateShelfFloorController } from './template-shelf-template-shelf-floor.controller';
import { TemplateShelfTemplateShelfFloorService } from './template-shelf-template-shelf-floor.service';
import { TemplateShelfFloorRepository } from '@repositories/template-shelf-floor.repository';
import { TemplateShelfRepository } from '@repositories/template-shelf.repository';
import { TemplateShelfFloorModule } from '@components/template-shelf-floor/template-shelf-floor.module';
import { TemplateShelfModule } from '@components/template-shelf/template-shelf.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      TemplateShelfTemplateShelfFloorEntity,
      TemplateShelfFloorEntity,
      TemplateShelfEntity,
    ]),
    TemplateShelfFloorModule,
    TemplateShelfModule,
  ],
  providers: [
    {
      provide: 'TemplateShelfTemplateShelfFloorServiceInterface',
      useClass: TemplateShelfTemplateShelfFloorService,
    },
    {
      provide: 'TemplateShelfTemplateShelfFloorRepositoryInterface',
      useClass: TemplateShelfTemplateShelfFloorRepository,
    },
    {
      provide: 'TemplateShelfFloorRepositoryInterface',
      useClass: TemplateShelfFloorRepository
    },
    {
      provide: 'TemplateShelfRepositoryInterface',
      useClass: TemplateShelfRepository
    },
  ],
  exports: [
    {
      provide: 'TemplateShelfTemplateShelfFloorRepositoryInterface',
      useClass: TemplateShelfTemplateShelfFloorRepository,
    },
    {
      provide: 'TemplateShelfFloorRepositoryInterface',
      useClass: TemplateShelfFloorRepository
    },
    {
      provide: 'TemplateShelfRepositoryInterface',
      useClass: TemplateShelfRepository
    },
  ],
  controllers: [TemplateShelfTemplateShelfFloorController],
})

export class TemplateShelfTemplateShelfFloorModule {}
