import { Controller, Inject, Post } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { isEmpty } from 'lodash';
import { CreateTemplateShelfTemplateShelfFloorDto } from './dto/request/create-template-shelf-template-shelf-floor.request.dto';
import { TemplateShelfTemplateShelfFloorServiceInterface } from './interface/template-shelf-template-shelf-floor.service.interface';
import { CREATE_TEMPLATE_SHELF_FLOOR_PERMISSION } from '@utils/permissions/template-shelf-floor';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';

@Controller('template-shelf-template-shelf-floors')
export class TemplateShelfTemplateShelfFloorController {
  constructor(
    @Inject('TemplateShelfTemplateShelfFloorServiceInterface')
    private readonly templateShelfTemplateShelfFloorService: TemplateShelfTemplateShelfFloorServiceInterface,
  ) {}

  @PermissionCode(CREATE_TEMPLATE_SHELF_FLOOR_PERMISSION.code)
  // @MessagePattern('create_template_shelf_template_shelf_floor')
  public async createTemplateShelfTemplateShelfFloor(
    payload: CreateTemplateShelfTemplateShelfFloorDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateShelfTemplateShelfFloorService.create(request);
  }
}
