import { ResponseCodeEnum } from '@constant/response-code.enum';
import { TemplateShelfTemplateShelfFloorEntity } from '@entities/template-shelf-template-shelf-floor/template-shelf-template-shelf-floor.entity';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { CreateTemplateShelfTemplateShelfFloorDto } from './dto/request/create-template-shelf-template-shelf-floor.request.dto';
import { TemplateShelfTemplateShelfFloorRepositoryInterface } from './interface/template-shelf-template-shelf-floor.repository.interface';
import { TemplateShelfTemplateShelfFloorServiceInterface } from './interface/template-shelf-template-shelf-floor.service.interface';
import { TemplateShelfFloorRepositoryInterface } from '@components/template-shelf-floor/interface/template-shelf-floor.repository.interface';
import { TemplateShelfRepositoryInterface } from '@components/template-shelf/interface/template-shelf.repository.interface';

@Injectable()
export class TemplateShelfTemplateShelfFloorService implements TemplateShelfTemplateShelfFloorServiceInterface {
  constructor(
    @Inject('TemplateShelfTemplateShelfFloorRepositoryInterface')
    private readonly templateSectorTemplateShelfRepository: TemplateShelfTemplateShelfFloorRepositoryInterface,

    @Inject('TemplateShelfFloorRepositoryInterface')
    private readonly templateShelfFloorRepository: TemplateShelfFloorRepositoryInterface,

    @Inject('TemplateShelfRepositoryInterface')
    private readonly templateShelfRepository: TemplateShelfRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  public async create(request: CreateTemplateShelfTemplateShelfFloorDto): Promise<ResponsePayload<any>> {
    const newSectorEntity = await this.templateSectorTemplateShelfRepository.createEntity(
      request,
    );
    return await this.save(newSectorEntity, request);
  }

  private async save(
    sectorEntity: TemplateShelfTemplateShelfFloorEntity,
    request: CreateTemplateShelfTemplateShelfFloorDto,
  ): Promise<any> {
    try {
      const { templateShelfFloorId, templateShelfId } = request;

      const templateShelfFloor = await this.templateShelfFloorRepository.findOneById(templateShelfFloorId);
      if (!templateShelfFloor) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.TEMPLATE_SECTOR_FLOOR_NOT_EXIST'),
        ).toResponse();
      }

      const templateShelf = await this.templateShelfRepository.findOneById(templateShelfId);
      if (!templateShelf) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.TEMPLATE_SHELF_NOT_EXIST'),
        ).toResponse();
      }

      const saveSector = await this.templateSectorTemplateShelfRepository.update(
        sectorEntity,
      );

      return new ResponseBuilder(saveSector)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(err?.message || err)
        .build();
    }
  }
}
