import { ResponsePayload } from '@utils/response-payload';
import { CreateTemplateShelfTemplateShelfFloorDto } from '../dto/request/create-template-shelf-template-shelf-floor.request.dto';

export interface TemplateShelfTemplateShelfFloorServiceInterface {
  create(payload: CreateTemplateShelfTemplateShelfFloorDto): Promise<ResponsePayload<any>>;
}
