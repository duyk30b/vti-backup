import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { TemplateShelfTemplateShelfFloorEntity } from '@entities/template-shelf-template-shelf-floor/template-shelf-template-shelf-floor.entity';

export interface TemplateShelfTemplateShelfFloorRepositoryInterface
  extends BaseInterfaceRepository<TemplateShelfTemplateShelfFloorEntity> {
  createEntity(body: any): TemplateShelfTemplateShelfFloorEntity;
}
