import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { SetStatusRequestDto } from '@utils/common.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { CreateWarehouseShelfRequestDto } from '../dto/request/create-warehouse-shelf.request.dto';
import { GetListWarehouseShelfRequestDto } from '../dto/request/get-list-warehouse-shelf.request.dto';
import { UpdateWarehouseShelfRequestDto } from '../dto/request/update-warehouse-shelf.request.dto';
import { GetListWarehouseShelfResponseDto } from '../dto/response/get-list-warehouse-shelf.response.dto';
import { WarehouseShelfResponseDto } from '../dto/response/warehouse-shelf.response.dto';
import { WarehouseShelfEntity } from '@entities/warehouse-shelf/warehouse-shelf.entity';
import { WarehouseSectorEntity } from '@entities/warehouse-sector/warehouse-sector.entity';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

export interface WarehouseShelfServiceInterface {
  importShelf(request: FileUploadRequestDto): Promise<any>;
  create(
    request: CreateWarehouseShelfRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfResponseDto | any>>;
  update(
    request: UpdateWarehouseShelfRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfResponseDto | any>>;
  delete(id: number): Promise<ResponsePayload<SuccessResponse | any>>;
  deleteMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<SuccessResponse | any>>;
  detail(id: number): Promise<ResponsePayload<WarehouseShelfResponseDto | any>>;
  getList(
    request: GetListWarehouseShelfRequestDto,
  ): Promise<ResponsePayload<GetListWarehouseShelfResponseDto | any>>;
  confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfResponseDto | any>>;
  reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfResponseDto | any>>;
  getWarehouseShelfsByNameKeyword(nameKeyword: string): Promise<any>;
}
