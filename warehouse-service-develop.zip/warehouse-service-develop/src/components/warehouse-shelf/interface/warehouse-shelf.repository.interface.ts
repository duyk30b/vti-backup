import { WarehouseShelfEntity } from '@entities/warehouse-shelf/warehouse-shelf.entity';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { GetListWarehouseShelfRequestDto } from '../dto/request/get-list-warehouse-shelf.request.dto';
import { WarehouseShelfDesignRequestDto } from '@components/warehouse/dto/request/update-warehouse-design.request.dto';
import { WarehouseShelfFloorEntity } from '@entities/warehouse-shelf-floor/warehouse-shelf-floor.entity';

export interface WarehouseShelfRepositoryInterface
  extends BaseInterfaceRepository<WarehouseShelfEntity> {
  createEntity(payload: any, isUpdate?: boolean): Promise<WarehouseShelfEntity>;
  getList(request: GetListWarehouseShelfRequestDto): Promise<any>;
  getNextPosition(warehouseSectorId: number): Promise<number>;
  findWarehouseShelfsByNameKeyword(nameKeyword: string): Promise<any>;
  createEntityDesign(
    warehouseId: number,
    code: string,
    request: WarehouseShelfDesignRequestDto,
    floorEntites: WarehouseShelfFloorEntity[],
  ): WarehouseShelfEntity;
  updateEntityDesign(
    entity: WarehouseShelfEntity,
    request: WarehouseShelfDesignRequestDto,
    floorEntites: WarehouseShelfFloorEntity[],
  ): WarehouseShelfEntity;
}
