import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { WarehouseSectorEntity } from '@entities/warehouse-sector/warehouse-sector.entity';
import { WarehouseShelfEntity } from '@entities/warehouse-shelf/warehouse-shelf.entity';
import { Warehouse } from '@entities/warehouse/warehouse.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WarehouseSectorRepository } from '@repositories/warehouse-sector.repository';
import { WarehouseShelfRepository } from '@repositories/warehouse-shelf.repository';
import { WarehouseRepository } from '@repositories/warehouse.repository';
import { WarehouseShelfController } from './warehouse-shelf.controller';
import { WarehouseShelfService } from './warehouse-shelf.service';
import { WarehouseShelfImport } from './import/warehouse-shelf.import.helper';
@Module({
  imports: [
    TypeOrmModule.forFeature([
      WarehouseShelfEntity,
      WarehouseSectorEntity,
      Warehouse,
    ]),
    UserModule,
  ],
  providers: [
    {
      provide: 'WarehouseShelfRepositoryInterface',
      useClass: WarehouseShelfRepository,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'WarehouseSectorRepositoryInterface',
      useClass: WarehouseSectorRepository,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'WarehouseShelfServiceInterface',
      useClass: WarehouseShelfService,
    },
    {
      provide: 'WarehouseShelfImport',
      useClass: WarehouseShelfImport
    }
  ],
  exports: [
    {
      provide: 'WarehouseShelfRepositoryInterface',
      useClass: WarehouseShelfRepository,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'WarehouseSectorRepositoryInterface',
      useClass: WarehouseSectorRepository,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'WarehouseShelfServiceInterface',
      useClass: WarehouseShelfService,
    },
  ],
  controllers: [WarehouseShelfController],
})
export class WarehouseShelfModule {}
