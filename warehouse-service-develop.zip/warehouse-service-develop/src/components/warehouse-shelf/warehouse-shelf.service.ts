import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ApiError } from '@utils/api.error';
import { ResponsePayload } from '@utils/response-payload';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { plainToInstance } from 'class-transformer';
import { ResponseBuilder } from '@utils/response-builder';
import { DataSource, In, Not } from 'typeorm';
import { isEmpty } from 'lodash';
import { PagingResponse } from '@utils/paging.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { WarehouseShelfServiceInterface } from './interface/warehouse-shelf.service.interface';
import { WarehouseShelfRepositoryInterface } from './interface/warehouse-shelf.repository.interface';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { WarehouseSectorRepositoryInterface } from '@components/warehouse-sector/interface/warehouse-sector.repository.interface';
import { GetListWarehouseShelfRequestDto } from './dto/request/get-list-warehouse-shelf.request.dto';
import { GetListWarehouseShelfResponseDto } from './dto/response/get-list-warehouse-shelf.response.dto';
import {
  WarehouseShelfResponse,
  WarehouseShelfResponseDto,
} from './dto/response/warehouse-shelf.response.dto';
import { CreateWarehouseShelfRequestDto } from './dto/request/create-warehouse-shelf.request.dto';
import { UpdateWarehouseShelfRequestDto } from './dto/request/update-warehouse-shelf.request.dto';
import { SetStatusRequestDto } from '@utils/common.request.dto';
import { calculateActual, calculateVolume, minus, plus } from '@utils/common';
import { WarehouseSectorEntity } from '@entities/warehouse-sector/warehouse-sector.entity';
import {
  CAN_CONFIRM_WAREHOUSE_SHELF_STATUS,
  CAN_DELETE_WAREHOUSE_SHELF_STATUS,
  CAN_REJECT_WAREHOUSE_SHELF_STATUS,
  CAN_UPDATE_WAREHOUSE_SHELF_STATUS,
  WarehouseShelfStatusEnum,
} from './warehouse-shelf.constant';
import { CAN_CONFIRM_WAREHOUSE_SECTOR_STATUS } from '@components/warehouse-sector/warehouse-sector.constant';
import { WarehouseShelfEntity } from '@entities/warehouse-shelf/warehouse-shelf.entity';
import {
  DATA_DEFAULT_MEASURES,
  UnitMeasuresEnum,
} from '@components/warehouse/warehouse.contant';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { WarehouseShelfImport } from './import/warehouse-shelf.import.helper';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { stringFormat } from '@utils/object.util';

@Injectable()
export class WarehouseShelfService implements WarehouseShelfServiceInterface {
  constructor(
    @Inject('WarehouseShelfRepositoryInterface')
    private readonly warehouseShelfRepository: WarehouseShelfRepositoryInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('WarehouseSectorRepositoryInterface')
    private readonly warehouseSectorRepository: WarehouseSectorRepositoryInterface,

    @Inject('WarehouseShelfImport')
    private readonly warehouseShelfImport: WarehouseShelfImport,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async importShelf(request: FileUploadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
    } as ImportRequestDto;
    return this.warehouseShelfImport.importUtil(importRequestDto);
  }

  public async create(
    request: CreateWarehouseShelfRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfResponseDto | any>> {
    try {
      const {
        long,
        width,
        height,
        warehouseSectorId,
        name,
        warehouseId,
        code,
        position,
        bottomMargin,
      } = request;

      const warehouse = await this.warehouseRepository.findOneById(warehouseId);
      if (!warehouse) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
          .build();
      }

      const warehouseSector = await this.warehouseSectorRepository.findOneById(
        warehouseSectorId,
      );
      if (!warehouseSector) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.WAREHOUSE_SECTOR_NOT_FOUND'),
          )
          .build();
      }

      const warehouseShelfCodeExist =
        await this.warehouseShelfRepository.findOneByCondition({
          code: code,
        });
      if (warehouseShelfCodeExist) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.CODE_ALREADY_EXISTS'))
          .build();
      }

      const warehouseShelfNameExist =
        await this.warehouseShelfRepository.findOneByCondition({
          name: name,
        });
      if (warehouseShelfNameExist) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.NAME_ALREADY_EXISTS'))
          .build();
      }

      if (!position) {
        request.position = await this.warehouseShelfRepository.getNextPosition(
          warehouseSectorId,
        );
      }

      if (!bottomMargin) {
        request.bottomMargin = DATA_DEFAULT_MEASURES;
      }

      const shelfVolume = calculateVolume(width, height, long);
      const volume = {
        unit: UnitMeasuresEnum.CM,
        value: shelfVolume,
      };

      const payload = {
        ...request,
        volume: volume,
      };

      const warehouseShelfEntity =
        await this.warehouseShelfRepository.createEntity(payload);
      const isValidShelfVolume = await this.validateShelfVolume(
        warehouseSector,
        warehouseShelfEntity,
      );
      if (isValidShelfVolume) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.TOTAL_SHELF_VOLUME_EXCEEDS_SECTOR_VOLUME',
            ),
          )
          .build();
      }

      const result = await this.warehouseShelfRepository.create(
        warehouseShelfEntity,
      );
      const response = plainToInstance(WarehouseShelfResponse, result, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(response)
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CREATE'))
        .build();
    }
  }
  public async update(
    request: UpdateWarehouseShelfRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfResponseDto | any>> {
    try {
      const {
        long,
        width,
        height,
        warehouseSectorId,
        name,
        warehouseId,
        id,
        code,
        bottomMargin,
      } = request;

      const warehouseShelf = await this.warehouseShelfRepository.findOneById(
        id,
      );
      if (!warehouseShelf) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.WAREHOUSE_SHELF_NOT_FOUND'),
          )
          .build();
      }

      if (!CAN_UPDATE_WAREHOUSE_SHELF_STATUS.includes(warehouseShelf.status)) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.WAREHOUSE_SHELF_WAS_CONFIRMED'),
        ).toResponse();
      }

      const warehouse = await this.warehouseRepository.findOneById(warehouseId);
      if (!warehouse) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
          .build();
      }

      const warehouseSector = await this.warehouseSectorRepository.findOneById(
        warehouseSectorId,
      );
      if (!warehouseSector) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.WAREHOUSE_SECTOR_NOT_FOUND'),
          )
          .build();
      }

      const warehouseShelfCodeExist =
        await this.warehouseShelfRepository.findOneByCondition({
          code: code,
          id: Not(id),
        });
      if (warehouseShelfCodeExist) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.CODE_ALREADY_EXISTS'))
          .build();
      }

      const warehouseShelfNameExist =
        await this.warehouseShelfRepository.findOneByCondition({
          name: name,
          id: Not(id),
        });
      if (warehouseShelfNameExist) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.NAME_ALREADY_EXISTS'))
          .build();
      }

      if (!bottomMargin) {
        request.bottomMargin = DATA_DEFAULT_MEASURES;
      }

      const shelfVolume = calculateVolume(width, height, long);
      const volume = {
        unit: UnitMeasuresEnum.CM,
        value: shelfVolume,
      };

      const payload = {
        ...request,
        volume: volume,
      };
      const warehouseShelfEntity =
        await this.warehouseShelfRepository.createEntity(payload, true);

      const isValidShelfVolume = await this.validateShelfVolume(
        warehouseSector,
        warehouseShelfEntity,
        warehouseShelf,
      );
      if (isValidShelfVolume) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.TOTAL_SHELF_VOLUME_EXCEEDS_SECTOR_VOLUME',
            ),
          )
          .build();
      }

      const result = await this.warehouseShelfRepository.create(
        warehouseShelfEntity,
      );
      const response = plainToInstance(WarehouseShelfResponse, result, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(response)
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }
  }
  public async delete(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const warehouseShelf = await this.warehouseShelfRepository.findOneById(id);
    if (!warehouseShelf) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WAREHOUSE_SHELF_NOT_FOUND'),
        )
        .build();
    }

    if (!CAN_DELETE_WAREHOUSE_SHELF_STATUS.includes(warehouseShelf.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.WAREHOUSE_SHELF_WAS_CONFIRMED'),
      ).toResponse();
    }
    await this.warehouseShelfRepository.remove(id);
    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const warehouseShelfs = await this.warehouseShelfRepository.findByCondition(
      {
        id: In(ids),
      },
    );

    const warehouseShelfIds = warehouseShelfs.map(
      (warehouseShelf) => warehouseShelf.id,
    );
    if (warehouseShelfs.length !== ids.length) {
      ids.forEach((id) => {
        if (!warehouseShelfIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < warehouseShelfs.length; i++) {
      const warehouseShelf = warehouseShelfs[i];
      if (!CAN_DELETE_WAREHOUSE_SHELF_STATUS.includes(warehouseShelf.status))
        failIdsList.push(warehouseShelf.id);
    }

    const validIds = warehouseShelfs
      .filter((warehouseShelf) => !failIdsList.includes(warehouseShelf.id))
      .map((warehouseShelf) => warehouseShelf.id);

    const queryRunner = await this.connection.createQueryRunner();
    try {
      if (!isEmpty(validIds)) {
        await queryRunner.startTransaction();
        await queryRunner.manager.delete(WarehouseShelfEntity, validIds);
        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    await queryRunner.release();
    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async detail(
    id: number,
  ): Promise<ResponsePayload<WarehouseShelfResponseDto | any>> {
    const warehouseShelf =
      await this.warehouseShelfRepository.findOneWithRelations({
        where: { id: id },
        relations: ['warehouse', 'warehouseSector'],
      });
    if (!warehouseShelf) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WAREHOUSE_SHELF_NOT_FOUND'),
        )
        .build();
    }

    const response = plainToInstance(WarehouseShelfResponse, warehouseShelf, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }
  public async getList(
    request: GetListWarehouseShelfRequestDto,
  ): Promise<ResponsePayload<GetListWarehouseShelfResponseDto | any>> {
    const { result, count } = await this.warehouseShelfRepository.getList(
      request,
    );
    const response = plainToInstance(WarehouseShelfResponse, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
  public async confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfResponseDto | any>> {
    const { id, userId } = request;
    const warehouseShelf = await this.warehouseShelfRepository.findOneById(id);
    if (!warehouseShelf) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WAREHOUSE_SHELF_NOT_FOUND'),
        )
        .build();
    }

    if (!CAN_CONFIRM_WAREHOUSE_SHELF_STATUS.includes(warehouseShelf.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_INVALID'),
      ).toResponse();
    }

    const warehouseSector = await this.warehouseSectorRepository.findOneById(
      warehouseShelf.warehouseSectorId,
    );
    if (!warehouseSector) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WAREHOUSE_SECTOR_NOT_FOUND'),
        )
        .build();
    }

    if (CAN_CONFIRM_WAREHOUSE_SECTOR_STATUS.includes(warehouseSector.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.WAREHOUSE_SECTOR_NEED_CONFIRM'),
      ).toResponse();
    }

    warehouseShelf.status = WarehouseShelfStatusEnum.CONFIRMED;
    warehouseShelf.approverId = userId;
    warehouseShelf.approvedAt = new Date(Date.now());

    const result = await this.warehouseShelfRepository.create(warehouseShelf);

    const response = plainToInstance(WarehouseShelfResponse, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }
  public async reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfResponseDto | any>> {
    const { id, userId } = request;
    const warehouseShelf = await this.warehouseShelfRepository.findOneById(id);
    if (!warehouseShelf) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WAREHOUSE_SHELF_NOT_FOUND'),
        )
        .build();
    }

    if (!CAN_REJECT_WAREHOUSE_SHELF_STATUS.includes(warehouseShelf.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_INVALID'),
      ).toResponse();
    }

    warehouseShelf.status = WarehouseShelfStatusEnum.REJECT;
    warehouseShelf.approverId = userId;
    warehouseShelf.approvedAt = new Date(Date.now());

    const result = await this.warehouseShelfRepository.create(warehouseShelf);

    const response = plainToInstance(WarehouseShelfResponse, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  private async validateShelfVolume(
    warehouseSector: WarehouseSectorEntity,
    warehouseShelfNew: WarehouseShelfEntity,
    warehouseShelfOld?: WarehouseShelfEntity,
  ): Promise<boolean> {
    const warehouseShelfs = await this.warehouseShelfRepository.findByCondition(
      {
        warehouseSectorId: warehouseSector.id,
      },
    );

    const warehouseShelfNewVolume =
      this.calculateActualVolume(warehouseShelfNew);

    let warehouseShelfOldVolume = 0;
    if (warehouseShelfOld) {
      warehouseShelfOldVolume = this.calculateActualVolume(warehouseShelfOld);
    }

    let totalWarehouseShelfVolume = minus(
      warehouseShelfNewVolume,
      warehouseShelfOldVolume,
    );

    if (!isEmpty(warehouseShelfs)) {
      warehouseShelfs.forEach((record) => {
        totalWarehouseShelfVolume = plus(
          totalWarehouseShelfVolume,
          this.calculateActualVolume(record),
        );
      });
    }

    return Number(warehouseSector.volume.value) < totalWarehouseShelfVolume;
  }

  private calculateActualVolume(warehouseShelf: WarehouseShelfEntity): number {
    const actualLong = calculateActual(
      warehouseShelf.long,
      warehouseShelf.frontMargin,
      warehouseShelf.behindMargin,
    );

    const actualWidth = calculateActual(
      warehouseShelf.width,
      warehouseShelf.rightMargin,
      warehouseShelf.leftMargin,
    );

    const actualHeght = calculateActual(
      warehouseShelf.height,
      warehouseShelf.topMargin,
      warehouseShelf.bottomMargin,
    );

    const objLong = {
      value: actualLong,
      unit: UnitMeasuresEnum.CM,
    };

    const objWidth = {
      value: actualWidth,
      unit: UnitMeasuresEnum.CM,
    };

    const objHeght = {
      value: actualHeght,
      unit: UnitMeasuresEnum.CM,
    };

    return calculateVolume(objWidth, objHeght, objLong);
  }

  async getWarehouseShelfsByNameKeyword(nameKeyword: string): Promise<any> {
    const warehouseShelfs =
      await this.warehouseShelfRepository.findWarehouseShelfsByNameKeyword(
        nameKeyword,
      );
    const response = plainToInstance(WarehouseShelfResponse, warehouseShelfs, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
}
