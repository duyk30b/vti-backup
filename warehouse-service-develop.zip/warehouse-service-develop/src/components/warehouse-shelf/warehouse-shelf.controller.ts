import {
  DeleteRequestDto,
  DetailRequestDto,
  SetStatusRequestDto,
} from '@utils/common.request.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { WarehouseShelfServiceInterface } from './interface/warehouse-shelf.service.interface';
import { WarehouseShelfResponseDto } from './dto/response/warehouse-shelf.response.dto';
import { GetListWarehouseShelfResponseDto } from './dto/response/get-list-warehouse-shelf.response.dto';
import { GetListWarehouseShelfRequestDto } from './dto/request/get-list-warehouse-shelf.request.dto';
import { CreateWarehouseShelfRequestDto } from './dto/request/create-warehouse-shelf.request.dto';
import { UpdateWarehouseShelfParamDto } from './dto/request/update-warehouse-shelf.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CONFIRM_WAREHOUSE_SHELF_PERMISSION,
  CREATE_WAREHOUSE_SHELF_PERMISSION,
  UPDATE_WAREHOUSE_SHELF_PERMISSION,
  DELETE_WAREHOUSE_SHELF_PERMISSION,
  DETAIL_WAREHOUSE_SHELF_PERMISSION,
  LIST_WAREHOUSE_SHELF_PERMISSION,
  REJECT_WAREHOUSE_SHELF_PERMISSION,
  IMPORT_WAREHOUSE_SHELF_PERMISSION,
} from '@utils/permissions/warehouse-shelf';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { ShelfResponseDto } from '@components/template-shelf/dto/response/shelf.response.dto';

@Controller('shelfs')
export class WarehouseShelfController {
  constructor(
    @Inject('WarehouseShelfServiceInterface')
    private readonly warehouseShelfService: WarehouseShelfServiceInterface,
  ) {}

  @PermissionCode(IMPORT_WAREHOUSE_SHELF_PERMISSION.code)
  // @MessagePattern('import_warehouse_shelf')
  @Post('/import')
  @ApiOperation({
    tags: ['Khu Vuc'],
    summary: 'Import ke',
    description: 'Nhập một loạt ke',
  })
  @ApiResponse({
    status: 200,
    description: 'Import successfully',
    type: ImportResponseDto,
  })
  public async importWarehouseShelf(
    @Body() body: FileUploadRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseShelfService.importShelf(request);
  }

  @PermissionCode(DETAIL_WAREHOUSE_SHELF_PERMISSION.code)
  // @MessagePattern('detail_warehouse_shelf')
  @Get('/:id')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'Get Shelf Detail',
    description: 'Chi tiết kệ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: null,
  })
  public async detail(
    @Param() param: DetailRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfResponseDto | any>> {
    const { request, responseError } = param;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseShelfService.detail(request.id);
  }

  @PermissionCode(LIST_WAREHOUSE_SHELF_PERMISSION.code)
  // @MessagePattern('list_warehouse_shelf')
  @Get('/list')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'List Shelf',
    description: 'Danh sách kệ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: null,
  })
  public async getList(
    @Query() query: GetListWarehouseShelfRequestDto,
  ): Promise<ResponsePayload<GetListWarehouseShelfResponseDto | any>> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseShelfService.getList(request);
  }

  @PermissionCode(CREATE_WAREHOUSE_SHELF_PERMISSION.code)
  // @MessagePattern('create_warehouse_shelf')
  @Post('/create')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'Create Shelf',
    description: 'Tạo kệ',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async create(
    @Body() payload: CreateWarehouseShelfRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseShelfService.create(request);
  }

  @PermissionCode(UPDATE_WAREHOUSE_SHELF_PERMISSION.code)
  // @MessagePattern('update_warehouse_shelf')
  @Put('/:id')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'Update Shelf',
    description: 'Cập nhật kệ',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateWarehouseShelfParamDto,
  ): Promise<ResponsePayload<WarehouseShelfResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = Number(id);
    return await this.warehouseShelfService.update(request);
  }

  @PermissionCode(CONFIRM_WAREHOUSE_SHELF_PERMISSION.code)
  // @MessagePattern('confirm_warehouse_shelf')
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'Confirm Shelf',
    description: 'xác nhận kệ',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ShelfResponseDto,
  })
  public async confirm(
    @Param() param: SetStatusRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfResponseDto | any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseShelfService.confirm(request);
  }

  @PermissionCode(REJECT_WAREHOUSE_SHELF_PERMISSION.code)
  // @MessagePattern('reject_warehouse_shelf')
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'Reject Shelf',
    description: 'Từ chối xác nhận kệ',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: ShelfResponseDto,
  })
  public async reject(
    @Param() param: SetStatusRequestDto,
  ): Promise<ResponsePayload<WarehouseShelfResponseDto | any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseShelfService.reject(request);
  }

  @PermissionCode(DELETE_WAREHOUSE_SHELF_PERMISSION.code)
  // @MessagePattern('delete_warehouse_shelf')
  @Delete('/:id')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'Delete Shelf',
    description: 'Xóa kệ',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async delete(
    @Param() param: DeleteRequestDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = param;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseShelfService.delete(request.id);
  }

  @PermissionCode(DELETE_WAREHOUSE_SHELF_PERMISSION.code)
  // @MessagePattern('delete_warehouse_shelf_multiple')
  @Delete('/multiple')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'Delete multiple Shelf',
    description: 'Xóa nhiều kệ',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseShelfService.deleteMultiple(request);
  }

  @MessagePattern('get_warehouse_shelf_by_name_keyword')
  public async getItemByConditions(@Body() payload: any): Promise<any> {
    return await this.warehouseShelfService.getWarehouseShelfsByNameKeyword(
      payload.nameKeyword,
    );
  }
  //TODO

  @MessagePattern('get_warehouse_shelf_by_name_keyword')
  public async getItemByConditionsTcp(@Body() payload: any): Promise<any> {
    return await this.warehouseShelfService.getWarehouseShelfsByNameKeyword(
      payload.nameKeyword,
    );
  }
}
