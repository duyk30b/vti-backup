export enum WarehouseShelfStatusEnum {
  CREATED = 0,
  CONFIRMED = 1,
  REJECT = 2,
}

export const CAN_UPDATE_WAREHOUSE_SHELF_STATUS: number[] = [
  WarehouseShelfStatusEnum.CREATED,
  WarehouseShelfStatusEnum.REJECT,
];

export const CAN_DELETE_WAREHOUSE_SHELF_STATUS: number[] = [
  WarehouseShelfStatusEnum.CREATED,
  WarehouseShelfStatusEnum.REJECT,
];

export const CAN_CONFIRM_WAREHOUSE_SHELF_STATUS: number[] = [
  WarehouseShelfStatusEnum.CREATED,
  WarehouseShelfStatusEnum.REJECT,
];

export const CAN_REJECT_WAREHOUSE_SHELF_STATUS: number[] = [
  WarehouseShelfStatusEnum.CREATED,
];
