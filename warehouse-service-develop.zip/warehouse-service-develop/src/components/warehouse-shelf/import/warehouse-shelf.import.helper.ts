import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectDataSource } from '@nestjs/typeorm';
import { WarehouseShelfRepository } from '@repositories/warehouse-shelf.repository';
import { ResponsePayload } from '@utils/response-payload';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { keyBy, isEmpty } from 'lodash';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { WarehouseSectorRepositoryInterface } from '@components/warehouse-sector/interface/warehouse-sector.repository.interface';
import { calculateVolume, calculateActual } from '@utils/common';
import { minus, plus } from '@utils/common';
import { WarehouseShelfEntity } from '@entities/warehouse-shelf/warehouse-shelf.entity';
import { WarehouseSectorEntity } from '@entities/warehouse-sector/warehouse-sector.entity';
import {
  UnitMeasuresEnum,
  UnitWeightEnum,
} from '@components/warehouse/warehouse.contant';
import { CreateWarehouseShelfRequestDto } from '../dto/request/create-warehouse-shelf.request.dto';
import { UpdateWarehouseShelfRequestDto } from '../dto/request/update-warehouse-shelf.request.dto';
import { UnitMeasuresRequest } from '@components/warehouse/dto/request/unit-measures.request.dto';
import { DistanceRequest } from '@components/warehouse/dto/request/unit-measures.request.dto';
import { UnitWeightRequest } from '@components/warehouse/dto/request/unit-measures.request.dto';

@Injectable()
export class WarehouseShelfImport extends ImportDataAbstract {
  private readonly FIELD_TEMPLATE_CONST = {
    CODE: {
      DB_COL_NAME: 'warehouseShelfCode',
      COL_NAME: ['Shelft code', '棚コード', 'Mã kệ'],
      MAX_LENGTH: 50,
      ALLOW_NULL: false,
      REGEX: /^([a-zA-Z0-9]+)$/,
    },
    NAME: {
      DB_COL_NAME: 'warehouseShelfName',
      COL_NAME: ['Shelf name', '棚名', 'Tên kệ'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    WAREHOUSE_NAME: {
      DB_COL_NAME: 'warehouseName',
      COL_NAME: ['Warehouse name', '倉庫名', 'Tên kho'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    SECTOR_NAME: {
      DB_COL_NAME: 'warehouseSectorName',
      COL_NAME: ['Sector name', 'エリア名', 'Tên khu vực'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    LONG: {
      DB_COL_NAME: 'long',
      COL_NAME: ['Long', '長辺', 'Chiều dài'],
      MAX_LENGTH: 255,
      IS_DECIMAL: true,
      IS_DECIMAL_ALLOW_ZERO: false,
    },
    WIDTH: {
      DB_COL_NAME: 'width',
      COL_NAME: ['Width', '短辺', 'Chiều rộng'],
      MAX_LENGTH: 255,
      IS_DECIMAL: true,
      IS_DECIMAL_ALLOW_ZERO: false,
    },
    HEIGHT: {
      DB_COL_NAME: 'height',
      COL_NAME: ['Height', '厚さ', 'Chiều cao'],
      MAX_LENGTH: 255,
      IS_DECIMAL: true,
      IS_DECIMAL_ALLOW_ZERO: false,
    },
    FRONT_MARGIN: {
      DB_COL_NAME: 'frontMargin',
      COL_NAME: ['Front', '前', 'Trước'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
      IS_DECIMAL: false,
      IS_DECIMAL_ALLOW_ZERO: true,
    },
    BEHIND_MARGIN: {
      DB_COL_NAME: 'behindMargin',
      COL_NAME: ['Behind', '後', 'Sau'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
      IS_DECIMAL: false,
      IS_DECIMAL_ALLOW_ZERO: true,
    },
    LEFT_MARGIN: {
      DB_COL_NAME: 'leftMargin',
      COL_NAME: ['Left', '左', 'Trái'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
      IS_DECIMAL: false,
      IS_DECIMAL_ALLOW_ZERO: true,
    },
    RIGHT_MARGIN: {
      DB_COL_NAME: 'rightMargin',
      COL_NAME: ['Right', '右', 'Phải'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
      IS_DECIMAL: false,
      IS_DECIMAL_ALLOW_ZERO: true,
    },
    TOP_MARGIN: {
      DB_COL_NAME: 'topMargin',
      COL_NAME: ['Above', '上', 'Trên'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
      IS_DECIMAL: false,
      IS_DECIMAL_ALLOW_ZERO: true,
    },
    BOTTOM_MARGIN: {
      DB_COL_NAME: 'bottomMargin',
      COL_NAME: ['Under', '下', 'Dưới'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
      IS_DECIMAL: false,
      IS_DECIMAL_ALLOW_ZERO: true,
    },
    WEIGHT_LOAD: {
      DB_COL_NAME: 'weightLoad',
      COL_NAME: ['Weight load', '耐荷重', 'Chịu tải'],
      MAX_LENGTH: 255,
      IS_DECIMAL: true,
      IS_DECIMAL_ALLOW_ZERO: false,
    },
    DESCRIPTION: {
      DB_COL_NAME: 'description',
      COL_NAME: ['Shelf description', '棚説明', 'Mô tả về kệ'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 16,
  };

  constructor(
    @Inject('WarehouseShelfRepositoryInterface')
    private readonly warehouseShelfRepository: WarehouseShelfRepository,
    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,
    @Inject('WarehouseSectorRepositoryInterface')
    private readonly warehouseSectorRepository: WarehouseSectorRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    this.fieldsMap.groupSet(
      [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
      [
        this.FIELD_TEMPLATE_CONST.CODE,
        this.FIELD_TEMPLATE_CONST.NAME,
        this.FIELD_TEMPLATE_CONST.WAREHOUSE_NAME,
        this.FIELD_TEMPLATE_CONST.SECTOR_NAME,
        this.FIELD_TEMPLATE_CONST.LONG,
        this.FIELD_TEMPLATE_CONST.WIDTH,
        this.FIELD_TEMPLATE_CONST.HEIGHT,
        this.FIELD_TEMPLATE_CONST.FRONT_MARGIN,
        this.FIELD_TEMPLATE_CONST.BEHIND_MARGIN,
        this.FIELD_TEMPLATE_CONST.LEFT_MARGIN,
        this.FIELD_TEMPLATE_CONST.RIGHT_MARGIN,
        this.FIELD_TEMPLATE_CONST.TOP_MARGIN,
        this.FIELD_TEMPLATE_CONST.BOTTOM_MARGIN,
        this.FIELD_TEMPLATE_CONST.WEIGHT_LOAD,
        this.FIELD_TEMPLATE_CONST.DESCRIPTION,
      ],
    );
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
  ): Promise<ImportResponseDto> {
    const findByCode = await this.warehouseShelfRepository.findWithRelations({
      where: {
        code: In(dataDto.map((i) => i.warehouseShelfCode)),
      },
    });
    const findByName = await this.warehouseShelfRepository.findWithRelations({
      where: {
        name: In(dataDto.map((i) => i.warehouseShelfName)),
      },
    });

    findByCode.forEach((i) => Object.assign(i, { type: 'old' }));
    findByName.forEach((i) => Object.assign(i, { type: 'old' }));

    const findByCodeMap = keyBy(findByCode, 'code');
    const findByNameMap = keyBy(findByName, 'name');
    const entities = [];
    const valid = [];
    const {
      duplicateCodeOrNameMsg,
      codeNotExistMsg,
      successMsg,
      unsuccessMsg,
      addText,
      updateText,
      warehouseNotFound,
      warehouseSectorNotFound,
      totalShelfVolumeExceedSectorVolume,
    } = await this.getMessage();
    for (let index = 0; index < dataDto.length; index++) {
      const data = dataDto[index];
      const {
        i,
        action,
        warehouseShelfCode,
        warehouseShelfName,
        warehouseName,
        warehouseSectorName,
        long,
        width,
        height,
        frontMargin,
        behindMargin,
        leftMargin,
        rightMargin,
        topMargin,
        bottomMargin,
        weightLoad,
        description,
        position,
      } = data;
      const logRow = {
        id: i,
        row: i,
        action: action,
      } as ImportResultDto;
      const msgLogs = [];

      const warehouse = await this.warehouseRepository.findOneByCondition({
        name: warehouseName,
      });
      if (!warehouse) {
        msgLogs.push(warehouseNotFound);
        logRow.log = msgLogs;
        logs.push(logRow);
        continue;
      }

      const warehouseSector =
        await this.warehouseSectorRepository.findOneByCondition({
          name: warehouseSectorName,
        });

      if (!warehouseSector) {
        msgLogs.push(warehouseSectorNotFound);
        logRow.log = msgLogs;
        logs.push(logRow);
        continue;
      }

      const longValue = new UnitMeasuresRequest();
      longValue.value = long;
      longValue.unit = warehouse.long.unit;
      const widthValue = new UnitMeasuresRequest();
      widthValue.value = width;
      widthValue.unit = warehouse.width.unit;
      const heightValue = new UnitMeasuresRequest();
      heightValue.value = height;
      heightValue.unit = warehouse.height.unit;
      const frontMarginValue = new DistanceRequest();
      frontMarginValue.value = frontMargin;
      frontMarginValue.unit = warehouse.long.unit;
      const behindMarginValue = new DistanceRequest();
      behindMarginValue.value = behindMargin;
      behindMarginValue.unit = warehouse.long.unit;
      const leftMarginValue = new DistanceRequest();
      leftMarginValue.value = leftMargin;
      leftMarginValue.unit = warehouse.width.unit;
      const rightMarginValue = new DistanceRequest();
      rightMarginValue.value = rightMargin;
      rightMarginValue.unit = warehouse.width.unit;
      const topMarginValue = new DistanceRequest();
      topMarginValue.value = topMargin;
      topMarginValue.unit = warehouse.height.unit;
      const bottomMarginValue = new DistanceRequest();
      bottomMarginValue.value = bottomMargin;
      bottomMarginValue.unit = warehouse.height.unit;
      const weightLoadValue = new UnitWeightRequest();
      weightLoadValue.value = weightLoad;
      weightLoadValue.unit = UnitWeightEnum.KG;

      let formatedData = null;
      if (action.toLowerCase() === addText.toLowerCase()) {
        formatedData = new CreateWarehouseShelfRequestDto();
      } else if (action.toLowerCase() === updateText.toLowerCase()) {
        formatedData = new UpdateWarehouseShelfRequestDto();
      }
      formatedData.name = warehouseShelfName;
      formatedData.code = warehouseShelfCode?.trim();
      formatedData.warehouseId = warehouse.id;
      formatedData.warehouseSectorId = warehouseSector.id;
      formatedData.description = description?.trim() || '';
      formatedData.long = longValue;
      formatedData.width = widthValue;
      formatedData.height = heightValue;
      formatedData.frontMargin = frontMarginValue;
      formatedData.behindMargin = behindMarginValue;
      formatedData.leftMargin = leftMarginValue;
      formatedData.rightMargin = rightMarginValue;
      formatedData.topMargin = topMarginValue;
      formatedData.bottomMargin = bottomMarginValue;
      formatedData.weightLoad = weightLoadValue;

      if (!position && action.toLowerCase() === addText) {
        formatedData.position =
          await this.warehouseShelfRepository.getNextPosition(
            warehouseSector.id,
          );
      }
      const shelfVolume = calculateVolume(widthValue, heightValue, longValue);
      const volume = {
        unit: UnitMeasuresEnum.CM,
        value: shelfVolume,
      };
      const payload = {
        ...formatedData,
        volume: volume,
      };

      if (action.toLowerCase() === addText) {
        if (
          findByCodeMap[warehouseShelfCode] ||
          findByNameMap[warehouseShelfName]
        ) {
          msgLogs.push(duplicateCodeOrNameMsg);
        } else {
          const entity = await this.warehouseShelfRepository.createEntity(
            payload,
          );
          const isValidShelfVolume = await this.validateShelfVolume(
            warehouseSector,
            entity,
          );
          if (isValidShelfVolume) {
            msgLogs.push(totalShelfVolumeExceedSectorVolume);
            logRow.log = msgLogs;
            logs.push(logRow);
            continue;
          }
          entities.push(entity);
          Object.assign(entity, { type: 'new' });
          findByCodeMap[warehouseShelfCode] = entity;
          findByNameMap[warehouseShelfName] = entity;
        }
      } else if (action.toLowerCase() === updateText) {
        if (
          findByCodeMap[warehouseShelfCode] &&
          findByCodeMap[warehouseShelfCode]?.['type'] === 'old'
        ) {
          if (
            findByNameMap[warehouseShelfName] &&
            findByNameMap[warehouseShelfName].id !=
              findByCodeMap[warehouseShelfCode].id
          ) {
            msgLogs.push(duplicateCodeOrNameMsg);
          } else {
            payload.id = findByCodeMap[warehouseShelfCode].id;
            const entity = await this.warehouseShelfRepository.createEntity(
              payload,
              true,
            );
            const warehouseShelf =
              await this.warehouseShelfRepository.findOneById(payload.id);
            const isValidShelfVolume = await this.validateShelfVolume(
              warehouseSector,
              entity,
              warehouseShelf,
            );
            if (isValidShelfVolume) {
              msgLogs.push(totalShelfVolumeExceedSectorVolume);
              logRow.log = msgLogs;
              logs.push(logRow);
              continue;
            }
            entities.push(entity);
            Object.assign(entity, { type: 'new' });
            findByCodeMap[warehouseShelfCode] = entity;
            findByNameMap[warehouseShelfName] = entity;
          }
        } else {
          msgLogs.push(codeNotExistMsg);
        }
      }
      if (isEmpty(msgLogs)) {
        logRow.log = [successMsg];
        valid.push(logRow);
      } else {
        logRow.log = msgLogs;
        logs.push(logRow);
      }
    }
    const response = new ImportResponseDto();
    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(entities);
        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        await queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((l) => (l.log = [unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }
    response.result = logs;
    response.totalCount = logs.length;
    response.result;
    return response;
  }

  private async validateShelfVolume(
    warehouseSector: WarehouseSectorEntity,
    warehouseShelfNew: WarehouseShelfEntity,
    warehouseShelfOld?: WarehouseShelfEntity,
  ): Promise<boolean> {
    const warehouseShelfs = await this.warehouseShelfRepository.findByCondition(
      {
        warehouseSectorId: warehouseSector.id,
      },
    );

    const warehouseShelfNewVolume =
      this.calculateActualVolume(warehouseShelfNew);

    let warehouseShelfOldVolume = 0;
    if (warehouseShelfOld) {
      warehouseShelfOldVolume = this.calculateActualVolume(warehouseShelfOld);
    }

    let totalWarehouseShelfVolume = minus(
      warehouseShelfNewVolume,
      warehouseShelfOldVolume,
    );

    if (!isEmpty(warehouseShelfs)) {
      warehouseShelfs.forEach((record) => {
        totalWarehouseShelfVolume = plus(
          totalWarehouseShelfVolume,
          this.calculateActualVolume(record),
        );
      });
    }

    return Number(warehouseSector.volume.value) < totalWarehouseShelfVolume;
  }

  private calculateActualVolume(warehouseShelf: WarehouseShelfEntity): number {
    const actualLong = calculateActual(
      warehouseShelf.long,
      warehouseShelf.frontMargin,
      warehouseShelf.behindMargin,
    );

    const actualWidth = calculateActual(
      warehouseShelf.width,
      warehouseShelf.rightMargin,
      warehouseShelf.leftMargin,
    );

    const actualHeght = calculateActual(
      warehouseShelf.height,
      warehouseShelf.topMargin,
      warehouseShelf.bottomMargin,
    );

    const objLong = {
      value: actualLong,
      unit: UnitMeasuresEnum.CM,
    };

    const objWidth = {
      value: actualWidth,
      unit: UnitMeasuresEnum.CM,
    };

    const objHeght = {
      value: actualHeght,
      unit: UnitMeasuresEnum.CM,
    };

    return calculateVolume(objWidth, objHeght, objLong);
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto | any>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_CONST.REQUIRED_COL_NUM,
    );
  }
}
