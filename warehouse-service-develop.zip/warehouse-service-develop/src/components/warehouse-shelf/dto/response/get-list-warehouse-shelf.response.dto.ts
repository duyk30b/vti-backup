import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { WarehouseShelfResponse } from './warehouse-shelf.response.dto';
import { Meta } from '@utils/common.response';

class WarehouseShelfData {
  @ApiProperty({ type: WarehouseShelfResponse, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => WarehouseShelfResponse)
  items: WarehouseShelfResponse[];

  @ApiProperty({ type: Meta })
  @Expose()
  @Type(() => Meta)
  meta: Meta;
}

export class GetListWarehouseShelfResponseDto extends SuccessResponse {
  @ApiProperty({ type: WarehouseShelfData })
  @Expose()
  @Type(() => WarehouseShelfData)
  data: WarehouseShelfData;
}
