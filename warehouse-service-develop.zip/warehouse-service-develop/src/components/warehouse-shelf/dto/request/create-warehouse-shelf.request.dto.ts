import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import {
  DesignRequest,
  UnitMeasuresRequest,
  UnitWeightRequest,
  DistanceRequest
} from '../../../warehouse/dto/request/unit-measures.request.dto';

export class CreateWarehouseShelfRequestDto extends BaseDto {
  @MaxLength(255)
  @IsNotEmpty()
  @ApiProperty({
    example: 'Kệ A',
  })
  name: string;

  @ApiProperty({ example: 1, description: '' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(50)
  code: string;

  @ApiProperty({ example: 1, description: '' })
  @IsInt()
  @IsNotEmpty()
  warehouseId: number;

  @ApiProperty({ example: 1, description: '' })
  @IsInt()
  @IsNotEmpty()
  warehouseSectorId: number;

  @ApiPropertyOptional({
    example: 'Kệ A',
    description: '',
  })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;

  @ApiPropertyOptional({ example: 1, description: '' })
  @IsOptional()
  @IsInt()
  position: number;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: '',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  width: UnitMeasuresRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: '',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  height: UnitMeasuresRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: '',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  long: UnitMeasuresRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: '',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => DistanceRequest)
  frontMargin: DistanceRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: '',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => DistanceRequest)
  behindMargin: DistanceRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: '',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => DistanceRequest)
  leftMargin: DistanceRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: '',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => DistanceRequest)
  rightMargin: DistanceRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: '',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => DistanceRequest)
  topMargin: DistanceRequest;

  @ApiPropertyOptional({
    example: { value: 1, unit: 1 },
    description: '',
  })
  @IsOptional()
  @ValidateNested()
  @Type(() => DistanceRequest)
  bottomMargin: DistanceRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: '',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitWeightRequest)
  weightLoad: UnitWeightRequest;

  @ApiProperty({
    example: { x: 0, y: 0, rotate: 0 },
    description: '',
  })
  @IsOptional()
  @ValidateNested()
  @Type(() => DesignRequest)
  design: DesignRequest;
}
