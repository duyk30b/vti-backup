import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateWarehouseShelfRequestDto } from './create-warehouse-shelf.request.dto';

export class UpdateWarehouseShelfParamDto extends CreateWarehouseShelfRequestDto {}
export class UpdateWarehouseShelfRequestDto extends UpdateWarehouseShelfParamDto {
  @ApiProperty({ example: 1, description: 'warehouse shelf id' })
  @IsInt()
  @Transform((obj) => Number(obj.value))
  @IsNotEmpty()
  id: number;
}
