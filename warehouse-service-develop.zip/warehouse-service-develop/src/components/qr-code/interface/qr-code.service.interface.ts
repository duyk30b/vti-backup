import { ScanRequestDto } from '../dto/request/scan.request.dto';

export interface QrCodeServiceInterface {
  scan(request: ScanRequestDto): Promise<any>;
}
