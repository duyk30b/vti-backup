import { InventoryResponse } from '@components/inventory/dto/response/inventory.response.dto';
import { InventoryRepositoryInterface } from '@components/inventory/interface/inventory.repository.interface';
import { ItemService } from '@components/item/item.service';
import { UserService } from '@components/user/user.service';
import { WarehouseLayoutServiceInterface } from '@components/warehouse-layout/interface/warehouse-layout.service.interface';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { keyBy, uniq, isEmpty } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ScanRequestDto } from './dto/request/scan.request.dto';
import { QrCodeServiceInterface as QrCodeServiceInterface } from './interface/qr-code.service.interface';
import { ItemBarcodeTypeEnum } from './qr-code.constant';

@Injectable()
export class QrCodeService implements QrCodeServiceInterface {
  constructor(
    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('InventoryRepositoryInterface')
    private readonly inventoryRepository: InventoryRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserService,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemService,

    @Inject('WarehouseLayoutServiceInterface')
    private readonly warehouseLayoutService: WarehouseLayoutServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}
  async scan(request: ScanRequestDto): Promise<any> {
    const { type, code, isInventory, warehouseId, locatorId } = request;

    let response;
    switch (type) {
      case ItemBarcodeTypeEnum.FLOOR:
        response = await this.scanFloor(
          code,
          isInventory,
          ItemBarcodeTypeEnum.FLOOR,
          warehouseId,
        );
        break;
      case ItemBarcodeTypeEnum.LOCATOR:
        response = await this.scanLocator(
          code,
          isInventory,
          ItemBarcodeTypeEnum.LOCATOR,
          locatorId,
          warehouseId,
        );
        break;

      default:
        break;
    }

    return response;
  }

  async scanFloor(
    code: string,
    isInventory: number,
    type: number,
    warehouseId?: number,
  ) {
    const data = await this.warehouseRepository.scan(code, type, warehouseId);

    if (!data) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const dataFactories = await this.userService.getFactories({
      id: data.factoryId,
    });
    const dataCompanies = await this.userService.getCompanies({
      id: data.companyId,
    });
    data.factoryCode = dataFactories?.data?.length
      ? dataFactories.data[0].code
      : null;
    data.factoryName = dataFactories?.data?.length
      ? dataFactories.data[0].name
      : null;
    data.companyCode = dataCompanies?.data?.length
      ? dataCompanies.data[0].code
      : null;
    data.companyName = dataCompanies?.data?.length
      ? dataCompanies.data[0].name
      : null;

    if (isInventory) {
      const inventoryRealTimeByFloor =
        await this.itemService.getItemStockMovementInWarehouseFloorByWarehouseFloorIds(
          [data.id],
        );
      const itemIds = inventoryRealTimeByFloor.map((i) => i.itemId);
      const items = await this.itemService.getItems(itemIds);
      const itemMap = keyBy(items, 'itemId');

      for (let i = 0; i < inventoryRealTimeByFloor.length; i++) {
        inventoryRealTimeByFloor[i].itemCode =
          itemMap[inventoryRealTimeByFloor[i].itemId].code;
        inventoryRealTimeByFloor[i].itemName =
          itemMap[inventoryRealTimeByFloor[i].itemId].name;
      }
      data.itemStockMovements = inventoryRealTimeByFloor;
    }

    return new ResponseBuilder(data).withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async scanLocator(
    code: string,
    isInventory: number,
    type: number,
    locatorId?: number,
    warehouseId?: number,
  ) {
    const locator = await this.warehouseLayoutService.getLocatorByCode({
      code,
      warehouseId,
    });
    if (isEmpty(locator)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND_QR'),
      ).toResponse();
    }
    if (!isInventory) {
      return new ResponseBuilder(locator)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    const data = await this.inventoryRepository.scanLocator(
      type,
      locator.locatorId,
    );
    const responseInventory =
      await this.inventoryRepository.getWarehouseByLocatorId(
        data.id,
        data.locatorId,
      );
    if (!data) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const userIds = uniq(
      [
        responseInventory.createdByUserId,
        responseInventory.confirmerId,
        responseInventory.approverId,
      ].filter((i) => i),
    );
    const users = await this.userService.getUserByIds(userIds, true);
    const locatorIds = [data.locatorId];
    if (!isEmpty(locatorIds)) {
      const locators = await this.warehouseLayoutService.getLocatorByIds(
        locatorIds,
        true,
      );
      data.locator = locators[data.locatorId];
      if (responseInventory.approverId) {
        responseInventory.approver = users[responseInventory.approverId];
      }
      if (responseInventory.createdByUserId) {
        responseInventory.createdByUser =
          users[responseInventory.createdByUserId];
      }
      if (responseInventory.confirmerId) {
        responseInventory.confirmer = users[responseInventory.confirmerId];
      }
    }
    const dataReturn = plainToInstance(InventoryResponse, data, {});

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
}
