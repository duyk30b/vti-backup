import { Controller, Get, Inject, Query } from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { isEmpty } from 'lodash';
import { ScanRequestDto } from './dto/request/scan.request.dto';
import { QrCodeServiceInterface } from './interface/qr-code.service.interface';

@Controller('scan')
export class ScanController {
  constructor(
    @Inject('QrCodeServiceInterface')
    private readonly scanService: QrCodeServiceInterface,
  ) {}

  // @MessagePattern('scan_qr_code')
  @ApiOperation({
    tags: ['Warehouse', 'Warehouse Scan Qr Code'],
    summary: 'Warehouse Scan Qr Code',
    description: 'Scan',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully',
  })
  @Get('/qr-code')
  public async Scan(@Query() payload: ScanRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.scanService.scan(request);
  }
}
