export enum ItemBarcodeTypeEnum {
  FLOOR = 1,
  LOCATOR = 2,
}

export enum IsInventoryEnum {
  NO = 0,
  YES = 1,
}
