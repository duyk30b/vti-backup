import { InventoryModule } from '@components/inventory/inventory.module';
import { ItemService } from '@components/item/item.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { WarehouseLayoutModule } from '@components/warehouse-layout/warehouse-layout.module';
import { WarehouseLayoutService } from '@components/warehouse-layout/warehouse-layout.service';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { Inventory } from '@entities/inventory/inventory.entity';
import { Warehouse } from '@entities/warehouse/warehouse.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InventoryRepository } from '@repositories/inventory.repository';
import { WarehouseRepository } from '@repositories/warehouse.repository';
import { ScanController as QrCodeController } from './qr-code.controller';
import { QrCodeService } from './qr-code.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([Warehouse, Inventory]),
    WarehouseModule,
    UserModule,
    InventoryModule,
    WarehouseLayoutModule,
  ],
  providers: [
    {
      provide: 'QrCodeServiceInterface',
      useClass: QrCodeService,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'InventoryRepositoryInterface',
      useClass: InventoryRepository,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseLayoutServiceInterface',
      useClass: WarehouseLayoutService,
    },
  ],
  controllers: [QrCodeController],
  exports: [
    {
      provide: 'QrCodeServiceInterface',
      useClass: QrCodeService,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
  ],
})
export class QrCodeModule {}
