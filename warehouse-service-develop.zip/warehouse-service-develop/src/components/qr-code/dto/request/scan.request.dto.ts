import { IsInt } from 'class-validator';
import {
  IsInventoryEnum,
  ItemBarcodeTypeEnum,
} from '@components/qr-code/qr-code.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsEnum, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class ScanRequestDto extends BaseDto {
  @ApiProperty()
  @IsEnum(ItemBarcodeTypeEnum)
  @Transform((v) => +v.value)
  @IsNotEmpty()
  type: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  code: string;

  @ApiPropertyOptional()
  @IsEnum(IsInventoryEnum)
  @Transform((v) => +v.value)
  @IsOptional()
  isInventory: number;

  @ApiPropertyOptional()
  @Transform((v) => +v.value)
  @IsOptional()
  warehouseId: number;

  @ApiProperty()
  @Transform((v) => +v.value)
  @IsOptional()
  @IsInt()
  locatorId: number;
}
