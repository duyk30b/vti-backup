import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNumberString, IsOptional, IsString } from 'class-validator';

interface File {
  data: any;
  fieldname: string;
  originalname: string;
  encoding: string;
  mimetype: string;
  size?: number;
  destination?: string;
  filename?: string;
  path?: string;
  buffer?: Buffer;
  stream?: NodeJS.ReadableStream;
}

export class UploadFileRequestDto extends BaseDto {
  @ApiProperty()
  files: File[];

  @ApiProperty()
  @IsString()
  @IsOptional()
  allowMimetype?: string;

  @ApiProperty()
  @IsOptional()
  @IsNumberString()
  allowFileSize?: string;

  @ApiProperty()
  @IsString()
  service: string;

  @ApiProperty()
  @IsString()
  resource: string;
}
