export const FileResource = {
  WXP: 'WXP',
  INVENTORY_ADJUSTMENT: 'INVENTORY_ADJUSTMENT',
};

export const UPLOAD_FILE_ENPOINT = {
  MULTIPLE: 'files/multiple-files',
  SINGLE: 'files/single-file',
  GET_FILE: 'files/detail/:id',
  GET_FILES: 'files/info?ids=:ids',
};
