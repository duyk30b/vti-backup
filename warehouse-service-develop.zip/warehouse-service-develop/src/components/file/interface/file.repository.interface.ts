import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { FileEntity } from '@entities/file/file.entity';

export interface FileRepositoryInterface
  extends BaseInterfaceRepository<FileEntity> {
  createEntity(data: any): FileEntity;
}
