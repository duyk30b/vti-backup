import { UploadFileRequestDto } from '../dto/request/upload-file.request.dto';

export interface FileServiceInterface {
  uploadFiles(request: UploadFileRequestDto): Promise<any>;
  handleSaveFiles(
    resourceId: any,
    resource: any,
    oldFiles: any,
    files: any,
  ): Promise<any>;
  getFileByIds(ids: string): Promise<any[]>;
}
