import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TicketService } from './ticket.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    {
      provide: 'TickerServiceInterface',
      useClass: TicketService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'TickerServiceInterface',
      useClass: TicketService,
    },
  ],
  controllers: [],
})
export class TicketModule {}
