import { NATS_WAREHOUSE } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable, Logger } from '@nestjs/common';
import { I18nService } from 'nestjs-i18n';
import { TicketServiceInterface } from './interface/ticket.service.interface';

@Injectable()
export class TicketService implements TicketServiceInterface {
  private readonly logger = new Logger(TicketService.name);
  constructor(
    private readonly natsClientService: NatsClientService,
    private readonly i18n: I18nService,
  ) {}

  public async getTicketReceiptById(ticketId: number): Promise<any> {
    const responseTicket = await this.natsClientService.send(
      `${NATS_WAREHOUSE}.get_ticket_receipt_by_ticket_id`,
      { ticketId: ticketId },
    );

    if (responseTicket.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }

    return responseTicket?.data;
  }
}
