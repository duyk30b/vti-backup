export interface TicketServiceInterface {
  getTicketReceiptById(ticketId: number): Promise<any>;
}
