import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { isEmpty } from 'lodash';
import { ApiConsumes, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateInventoryAdjustmentRequestDto } from './dto/request/create-inventory-adjustment.request.dto';
import { InventoryAdjustmentServiceInterface } from './interface/inventory-adjustment.service.interface';
import { UpdateInventoryAdjustmentBodyDto } from './dto/request/update-inventory-adjustment.request.dto';
import { GetListInventoryAdjustmentRequestDto } from './dto/request/get-list-inventory-adjustment.request.dto';
import { GetDetailInventoryAdjustmentRequestDto } from './dto/request/get-detail-inventory-adjustment.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CONFIRM_INVENTORY_ADJUSTMENT_PERMISSION,
  CREATE_INVENTORY_ADJUSTMENT_PERMISSION,
  DELETE_INVENTORY_ADJUSTMENT_PERMISSION,
  DETAIL_INVENTORY_ADJUSTMENT_PERMISSION,
  LIST_INVENTORY_ADJUSTMENT_PERMISSION,
  REJECT_INVENTORY_ADJUSTMENT_PERMISSION,
  UPDATE_INVENTORY_ADJUSTMENT_PERMISSION,
} from '@utils/permissions/inventory-adjustment';
import { MessagePattern } from '@nestjs/microservices';
import { GetListOpenTransactionRequestDto } from './dto/request/get-list-open-transaction.request.dto';
import { NATS_WAREHOUSE } from '@config/nats.config';

@Controller('inventory-adjustments')
export class InventoryAdjustmentController {
  constructor(
    @Inject('InventoryAdjustmentServiceInterface')
    private readonly inventoryAdjustmentService: InventoryAdjustmentServiceInterface,
  ) {}

  @PermissionCode(CREATE_INVENTORY_ADJUSTMENT_PERMISSION.code)
  @Post('/create')
  @ApiConsumes('multipart/form-data')
  @ApiOperation({
    tags: ['InventoryAdjustment'],
    summary: 'Tạo phiếu điều chỉnh tồn kho',
    description: 'Tạo phiếu điều chỉnh tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async create(
    @Body() body: CreateInventoryAdjustmentRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryAdjustmentService.create(request);
  }

  @PermissionCode(UPDATE_INVENTORY_ADJUSTMENT_PERMISSION.code)
  @Put('/:id')
  @ApiConsumes('multipart/form-data')
  @ApiOperation({
    tags: ['InventoryAdjustment'],
    summary: 'Sửa phiếu điều chỉnh tồn kho',
    description: 'Sửa phiếu điều chỉnh tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  public async edit(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() body: UpdateInventoryAdjustmentBodyDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.inventoryAdjustmentService.edit(request);
  }

  @PermissionCode(LIST_INVENTORY_ADJUSTMENT_PERMISSION.code)
  @Get('/list')
  @ApiOperation({
    tags: ['InventoryAdjustment'],
    summary: 'Lấy danh sách phiếu điều chỉnh tồn kho',
    description: 'Lấy danh sách phiếu điều chỉnh tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  public async getList(
    @Query() query: GetListInventoryAdjustmentRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryAdjustmentService.getList(request);
  }

  @PermissionCode(DETAIL_INVENTORY_ADJUSTMENT_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['InventoryAdjustment'],
    summary: 'Chi tiết phiếu điều chỉnh tồn kho',
    description: 'Chi tiết phiếu điều chỉnh tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  public async detail(
    @Param() param: GetDetailInventoryAdjustmentRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryAdjustmentService.detail(request.id);
  }

  @PermissionCode(CONFIRM_INVENTORY_ADJUSTMENT_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['InventoryAdjustment'],
    summary: 'Xác nhận phiếu điều chỉnh tồn kho',
    description: 'Xác nhận phiếu điều chỉnh tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  public async confirm(
    @Param() param: GetDetailInventoryAdjustmentRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.createdByUserId = request.userId;
    return await this.inventoryAdjustmentService.confirm(request);
  }

  @PermissionCode(REJECT_INVENTORY_ADJUSTMENT_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['InventoryAdjustment'],
    summary: 'Từ chối phiếu điều chỉnh tồn kho',
    description: 'Từ chối phiếu điều chỉnh tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  public async reject(
    @Param() param: GetDetailInventoryAdjustmentRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryAdjustmentService.reject(request.id);
  }

  @PermissionCode(DELETE_INVENTORY_ADJUSTMENT_PERMISSION.code)
  @Delete('/:id/delete')
  @ApiOperation({
    tags: ['InventoryAdjustment'],
    summary: 'Xác nhận phiếu điều chỉnh tồn kho',
    description: 'Xác nhận phiếu điều chỉnh tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  public async delete(
    @Param() param: GetDetailInventoryAdjustmentRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryAdjustmentService.delete(request);
  }

  @MessagePattern(
    `${NATS_WAREHOUSE}.get_list_inventory_adjustment_open_transaction`,
  )
  public async getListOpenTransaction(
    @Body() body: GetListOpenTransactionRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryAdjustmentService.getListOpenTransaction(
      request,
    );
  }
}
