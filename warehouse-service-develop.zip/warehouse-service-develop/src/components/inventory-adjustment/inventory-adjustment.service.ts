import { ConfigService } from '@nestjs/config';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, ILike, Not } from 'typeorm';
import { isEmpty, groupBy, flatten, keyBy, map } from 'lodash';
import { InventoryAdjustmentServiceInterface } from './interface/inventory-adjustment.service.interface';
import { InventoryAdjustmentRepositoryInterface } from './interface/inventory-adjustment.repository.interface';
import { CreateInventoryAdjustmentRequestDto } from './dto/request/create-inventory-adjustment.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import {
  INVENTORY_ADJUSTMENT_STATUS,
  INVENTORY_ADJUSTMENT_STATUS_EDITABLE,
  INVENTORY_ADJUSTMENT_TYPE,
} from './inventory-adjustment.constant';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { GetItemStockAvailableRequestDto } from '@components/item/dto/request/get-item-stock-available.request.dto';
import { WarehouseLayoutServiceInterface } from '@components/warehouse-layout/interface/warehouse-layout.service.interface';
import { UpdateInventoryAdjustmentRequestDto } from './dto/request/update-inventory-adjustment.request.dto';
import { InventoryAdjustmentDetailRepositoryInterface } from './interface/inventory-adjustment-detail.repository.interface';
import { GetListInventoryAdjustmentRequestDto } from './dto/request/get-list-inventory-adjustment.request.dto';
import { plainToInstance } from 'class-transformer';
import { GetInventoryAdjustmentResponseDto } from './dto/response/get-inventory-adjustment.response.dto';
import { PagingResponse } from '@utils/paging.response';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { GetDetailInventoryAdjustmentRequestDto } from './dto/request/get-detail-inventory-adjustment.request.dto';
import { GetItemWarehouseStockRequestDto } from '@components/item/dto/request/get-item-stock.dto';
import { WarehouseStockMovementRepositoryInterface } from '@components/warehouse/interface/warehouse-stock-movement.repository.interface';
import {
  OrderTypeEnum,
  OrderWarehouseActionTypeEnum,
} from '@constant/order.constant';
import {
  WarehouseMovementStatusEnum,
  WarehouseMovementTypeEnum,
} from '@components/warehouse/warehouse.constant';
import { UpdateStockFromOrderRequest } from '@components/item/dto/request/update-stock-from-order-request.dto';
import {
  CreateItemStockMovementDto,
  CreateItemStockMovementShelfFloorDto,
} from '@components/item/dto/request/create-item-stock-movement.request.dto';
import { ItemStockMovementTypeEnum } from '@components/item/item.constant';
import { FileServiceInterface } from '@components/file/interface/file.service.interface';
import { FileResource } from '@components/file/file.constants';
import { FileRepositoryInterface } from '@components/file/interface/file.repository.interface';
import { GetListOpenTransactionRequestDto } from './dto/request/get-list-open-transaction.request.dto';

@Injectable()
export class InventoryAdjustmentService
  implements InventoryAdjustmentServiceInterface
{
  constructor(
    @InjectDataSource()
    private readonly connection: DataSource,

    @Inject('InventoryAdjustmentRepositoryInterface')
    private readonly inventoryAdjustmentRepository: InventoryAdjustmentRepositoryInterface,

    @Inject('InventoryAdjustmentDetailRepositoryInterface')
    private readonly inventoryAdjustmentDetailRepository: InventoryAdjustmentDetailRepositoryInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('WarehouseStockMovementRepositoryInterface')
    private readonly warehouseStockMovementRepository: WarehouseStockMovementRepositoryInterface,

    @Inject('FileRepositoryInterface')
    private readonly fileRepository: FileRepositoryInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @Inject('WarehouseLayoutServiceInterface')
    private readonly warehouseLayoutService: WarehouseLayoutServiceInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @Inject('SaleServiceInterface')
    private readonly saleService: SaleServiceInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('FileServiceInterface')
    private readonly fileService: FileServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  public async create(
    request: CreateInventoryAdjustmentRequestDto,
  ): Promise<any> {
    const { code, warehouseId, items, type } = request;

    const existedInventoryAdjustment =
      await this.inventoryAdjustmentRepository.findOneByCondition({
        code: ILike(code),
      });
    if (!isEmpty(existedInventoryAdjustment)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.INVENTORY_ADJUSTMENT_ALREADY_EXIST'),
        )
        .build();
    }

    const warehouseExist = await this.warehouseRepository.findOneById(
      warehouseId,
    );
    if (isEmpty(warehouseExist)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
        .build();
    }

    if (type === INVENTORY_ADJUSTMENT_TYPE.EXPORT) {
      const invalidItemStockAvaiable =
        await this.warehouseService.validateItemExport({
          order: null,
          items: items.map((itemLot) => ({
            itemId: itemLot.itemId,
            lotNumber: itemLot.lotNumber,
            warehouseId: warehouseId,
            locatorIds: [itemLot.locatorId],
            quantity: itemLot.quantity,
          })),
        });

      if (invalidItemStockAvaiable.statusCode !== ResponseCodeEnum.SUCCESS) {
        return invalidItemStockAvaiable;
      }
    }

    if (type === INVENTORY_ADJUSTMENT_TYPE.IMPORT) {
      const itemIds = map(items, 'itemId');
      const existedItems = await this.itemService.getItems(itemIds);
      if (existedItems?.length < itemIds?.length) {
        const existedItemIds = map(existedItems, 'id');
        const nonExistedItems = items?.filter(
          (item) => !existedItemIds.includes(item.itemId),
        );
        return new ResponseBuilder(nonExistedItems)
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.ITEM_NOT_FOUND'))
          .build();
      }

      const locatorIds = map(items, 'locatorId');
      const existedLocators =
        await this.warehouseLayoutService.getLocatorsByRootIds(
          [warehouseId],
          locatorIds,
        );
      if (existedLocators.length < locatorIds.length) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.LOCATOR_NOT_FOUND'))
          .build();
      }
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const inventoryAdjustmentEntity =
        this.inventoryAdjustmentRepository.createEntity(request);
      const inventoryAdjustment = await queryRunner.manager.save(
        inventoryAdjustmentEntity,
      );

      const inventoryAdjustmentDetailEntites = items.map((item) => {
        return this.inventoryAdjustmentDetailRepository.createEntity({
          ...item,
          inventoryAdjustmentId: inventoryAdjustment.id,
          userId: request.userId,
        });
      });
      await queryRunner.manager.save(inventoryAdjustmentDetailEntites);

      const file = await this.fileService.handleSaveFiles(
        inventoryAdjustment.id || null,
        FileResource.INVENTORY_ADJUSTMENT,
        request.files ? request.files.filter((file) => !isEmpty(file)) : null,
        request.attachments,
      );
      if (file.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(file.statusCode)
          .withMessage(file.message)
          .build();
      }

      await queryRunner.commitTransaction();

      return new ResponseBuilder({
        success: true,
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  public async edit(
    request: UpdateInventoryAdjustmentRequestDto,
  ): Promise<any> {
    const { id, code, warehouseId, items, type } = request;

    const inventoryAdjustment =
      await this.inventoryAdjustmentRepository.findOneWithRelations({
        where: {
          id,
        },
        relations: ['inventoryAdjustmentDetails'],
      });
    if (isEmpty(inventoryAdjustment)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (
      !INVENTORY_ADJUSTMENT_STATUS_EDITABLE.includes(inventoryAdjustment.status)
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }

    const existedInventoryAdjustment =
      await this.inventoryAdjustmentRepository.findOneByCondition({
        code,
        id: Not(id),
      });
    if (!isEmpty(existedInventoryAdjustment)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.INVENTORY_ADJUSTMENT_ALREADY_EXIST'),
        )
        .build();
    }

    const warehouseExist = await this.warehouseRepository.findOneById(
      warehouseId,
    );
    if (isEmpty(warehouseExist)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
        .build();
    }

    if (type === INVENTORY_ADJUSTMENT_TYPE.EXPORT) {
      const invalidItemStockAvaiable =
        await this.warehouseService.validateItemExport({
          order: null,
          items: items.map((itemLot) => ({
            itemId: itemLot.itemId,
            lotNumber: itemLot.lotNumber,
            warehouseId: warehouseId,
            locatorIds: [itemLot.locatorId],
            quantity: itemLot.quantity,
          })),
        });

      if (invalidItemStockAvaiable.statusCode !== ResponseCodeEnum.SUCCESS) {
        return invalidItemStockAvaiable;
      }
    }

    if (type === INVENTORY_ADJUSTMENT_TYPE.IMPORT) {
      const itemIds = map(items, 'itemId');
      const existedItems = await this.itemService.getItems(itemIds);
      if (existedItems?.length < itemIds?.length) {
        const existedItemIds = map(existedItems, 'id');
        const nonExistedItems = items?.filter(
          (item) => !existedItemIds.includes(item.itemId),
        );
        return new ResponseBuilder(nonExistedItems)
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.ITEM_NOT_FOUND'))
          .build();
      }

      const locatorIds = map(items, 'locatorId');
      const existedLocators =
        await this.warehouseLayoutService.getLocatorsByRootIds(
          [warehouseId],
          locatorIds,
        );
      if (existedLocators.length < locatorIds.length) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.LOCATOR_NOT_FOUND'))
          .build();
      }
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.remove(
        inventoryAdjustment.inventoryAdjustmentDetails,
      );

      const inventoryAdjustmentEntity =
        this.inventoryAdjustmentRepository.updateEntity(
          inventoryAdjustment,
          request,
        );
      await queryRunner.manager.save(inventoryAdjustmentEntity);

      const inventoryAdjustmentDetailEntites = items.map((item) => {
        return this.inventoryAdjustmentDetailRepository.createEntity({
          ...item,
          inventoryAdjustmentId: id,
          userId: request.userId,
        });
      });
      await queryRunner.manager.save(inventoryAdjustmentDetailEntites);

      const file = await this.fileService.handleSaveFiles(
        inventoryAdjustment.id || null,
        FileResource.INVENTORY_ADJUSTMENT,
        request.files ? request.files.filter((file) => !isEmpty(file)) : null,
        request.attachments,
      );
      if (file.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(file.statusCode)
          .withMessage(file.message)
          .build();
      }

      await queryRunner.commitTransaction();

      return new ResponseBuilder({
        success: true,
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  public async getList(
    request: GetListInventoryAdjustmentRequestDto,
  ): Promise<any> {
    const [data, count] = await this.inventoryAdjustmentRepository.getList(
      request,
    );

    const sourceIds = map(data, 'sourceId');
    const reasonIds = map(data, 'reasonId');
    const userIds = map(data, 'createdBy');
    const departmentReceiptIds = map(data, 'departmentReceiptId');
    const { sourceByIds, reasonByIds, userByIds, departmentReceiptByIds } =
      await this.getRelationData(
        sourceIds,
        reasonIds,
        userIds,
        departmentReceiptIds,
      );

    const dataReturn = plainToInstance(
      GetInventoryAdjustmentResponseDto,
      data?.map((item) => ({
        ...item,
        source: sourceByIds[item.sourceId],
        reason: reasonByIds[item.reasonId],
        departmentReceipt: departmentReceiptByIds[item.departmentReceiptId],
        createdBy: userByIds[item.createdBy],
      })),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async detail(id: number): Promise<any> {
    const inventoryAdjustment = await this.inventoryAdjustmentRepository.detail(
      id,
    );

    const itemIds = map(inventoryAdjustment.items, 'itemId');
    const locatorIds = map(inventoryAdjustment.items, 'locatorId');
    const {
      sourceByIds,
      reasonByIds,
      userByIds,
      departmentReceiptByIds,
      itemByIds,
      locatorByIds,
    } = await this.getRelationData(
      [inventoryAdjustment.sourceId],
      [inventoryAdjustment.reasonId],
      [inventoryAdjustment.createdBy, inventoryAdjustment.confirmedBy].filter(
        (user) => user != null,
      ),
      [inventoryAdjustment.departmentReceiptId],
      itemIds,
      locatorIds,
    );

    let availableItemLocatorByKeys = {};
    let itemAvailableLocatorsMap = {};
    if (inventoryAdjustment.type === INVENTORY_ADJUSTMENT_TYPE.EXPORT) {
      const itemLots = inventoryAdjustment.items?.map((item) => ({
        ...item,
        itemLot: `${item.itemId}-${item.lotNumber || ''}`,
      }));
      const itemLotByKeys = groupBy(itemLots, 'itemLot');
      const itemConditionRequest = Object.keys(itemLotByKeys)?.map((key) => ({
        itemId: Number(key.split('-')[0]),
        lotNumber: key.split('-')[1],
        warehouseId: inventoryAdjustment?.warehouse?.id,
        locatorIds: itemLotByKeys[key].map((itemLot) => itemLot.locatorId),
      }));
      const itemStockAvailables =
        await this.itemService.getItemStockAvailableByConditions({
          items: itemConditionRequest,
        } as GetItemStockAvailableRequestDto);
      const availableItemLocators = flatten(
        itemStockAvailables?.map((item) => item.itemAvailables),
      );
      availableItemLocatorByKeys = keyBy(
        availableItemLocators.map((item) => ({
          quantity: Number(item.quantity),
          key: `${item.itemId}-${item.lotNumber}-${item.locatorId}`,
        })),
        'key',
      );
      const data = await this.itemService.getItemWarehouseStock({
        warehouseId: inventoryAdjustment?.warehouse?.id,
      } as GetItemWarehouseStockRequestDto);

      const itemWarehouseStock = data?.items.map((item) => {
        return (item = {
          id: item.id,
          locations: item.locations,
        });
      });
      const itemAvailableLocators = [];
      itemWarehouseStock.map((iws) => {
        iws?.locations.map((l) => {
          l?.lots.map((lot) => {
            itemAvailableLocators.push({
              idItem: iws?.id,
              locatorId: l?.locator?.locatorId || l?.locator?.id,
              lotNumber: lot?.lotNumber,
              quantity: lot?.quantity,
            });
          });
        });
      });
      itemAvailableLocatorsMap = keyBy(
        itemAvailableLocators?.map((i) => ({
          quantity: i?.quantity,
          key: `${i.idItem}-${i.locatorId}-${i.lotNumber}`,
        })),
        'key',
      );
    }

    const files = await this.fileRepository.findByCondition({
      resourceId: id,
      resource: FileResource.INVENTORY_ADJUSTMENT,
    });
    let attachments = [];
    if (!isEmpty(files)) {
      attachments = await this.fileService.getFileByIds(
        files.map((e) => e.fileId).join(','),
      );
    }

    const dataReturn = plainToInstance(
      GetInventoryAdjustmentResponseDto,
      {
        ...inventoryAdjustment,
        attachments,
        source: sourceByIds[inventoryAdjustment.sourceId],
        reason: reasonByIds[inventoryAdjustment.reasonId],
        departmentReceipt:
          departmentReceiptByIds[inventoryAdjustment.departmentReceiptId],
        createdBy: userByIds[inventoryAdjustment.createdBy],
        confirmedBy: userByIds[inventoryAdjustment.confirmedBy],
        items: inventoryAdjustment.items?.map((item) => ({
          ...item,
          item: {
            id: item.itemId,
            ...itemByIds[item.itemId],
            unitName: itemByIds[item.itemId]?.itemUnit?.name,
          },
          locator: {
            id: item.locatorId,
            ...locatorByIds[item.locatorId],
          },
          exportQuantity:
            itemAvailableLocatorsMap[
              `${item.itemId}-${item.locatorId}-${item.lotNumber}`
            ]?.quantity,
          planQuantity:
            availableItemLocatorByKeys[
              `${item.itemId}-${item.lotNumber}-${item.locatorId}`
            ]?.quantity,
        })),
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async confirm(
    request: GetDetailInventoryAdjustmentRequestDto,
  ): Promise<any> {
    const { id, userId } = request;
    const inventoryAdjustment =
      await this.inventoryAdjustmentRepository.findOneWithRelations({
        where: {
          id,
        },
        relations: ['inventoryAdjustmentDetails'],
      });
    if (isEmpty(inventoryAdjustment)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (inventoryAdjustment.status !== INVENTORY_ADJUSTMENT_STATUS.PENDING) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }

    const warehouseMovementType =
      inventoryAdjustment.type === INVENTORY_ADJUSTMENT_TYPE.EXPORT
        ? WarehouseMovementTypeEnum.INVENTORY_ADJUSTMENT_EXPORT
        : WarehouseMovementTypeEnum.INVENTORY_ADJUSTMENT_IMPORT;
    const orderType =
      inventoryAdjustment.type === INVENTORY_ADJUSTMENT_TYPE.EXPORT
        ? OrderWarehouseActionTypeEnum.EXPORT
        : OrderWarehouseActionTypeEnum.IMPORT;

    const warehouseStockMovementEntity =
      this.warehouseStockMovementRepository.createEntity(
        id,
        inventoryAdjustment.code,
        OrderTypeEnum.INVENTORY_ADJUSTMENT,
        warehouseMovementType,
        inventoryAdjustment.warehouseId,
        '',
        request.createdByUserId,
      );

    warehouseStockMovementEntity.status = WarehouseMovementStatusEnum.APPROVED;
    warehouseStockMovementEntity.approverId = userId;
    warehouseStockMovementEntity.approvedAt = new Date();

    inventoryAdjustment.status = INVENTORY_ADJUSTMENT_STATUS.CONFIRM;
    inventoryAdjustment.confirmedAt = new Date();
    inventoryAdjustment.confirmedBy = userId;

    const queryRunner = this.connection.createQueryRunner();
    try {
      await queryRunner.startTransaction();
      await queryRunner.manager.save(inventoryAdjustment);
      const warehouseStockMovement = await queryRunner.manager.save(
        warehouseStockMovementEntity,
      );

      const itemStockMovementEntities =
        inventoryAdjustment.inventoryAdjustmentDetails.map((detail) => {
          return new CreateItemStockMovementDto(
            id,
            inventoryAdjustment.code,
            OrderTypeEnum.INVENTORY_ADJUSTMENT,
            warehouseStockMovement.id,
            detail.itemId,
            inventoryAdjustment.warehouseId,
            userId,
            detail.id,
            detail.id,
            +detail.quantity,
            ItemStockMovementTypeEnum.Export,
            [
              new CreateItemStockMovementShelfFloorDto({
                locatorId: detail.locatorId,
                quantity: +detail.quantity,
                warehouseId: inventoryAdjustment.warehouseId,
                lotNumber: detail?.lotNumber ?? null,
                itemId: detail.itemId,
              }),
            ],
          );
        });

      const createItemStockMovementsDestinationResponse =
        await this.itemService.createItemStockMovementAndItemWarehouseShelfFloor(
          {
            items: itemStockMovementEntities,
          },
        );

      if (
        createItemStockMovementsDestinationResponse.statusCode !=
        ResponseCodeEnum.SUCCESS
      ) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
      }
      await queryRunner.commitTransaction();

      await this.itemService.updateStockFromOrder(
        new UpdateStockFromOrderRequest(
          warehouseStockMovementEntity.id,
          orderType,
          id,
          OrderTypeEnum.INVENTORY_ADJUSTMENT,
        ),
      );
    } catch (error) {
      console.log({ error });
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }

    return new ResponseBuilder({
      success: true,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async reject(id: number): Promise<any> {
    const inventoryAdjustment =
      await this.inventoryAdjustmentRepository.findOneById(id);
    if (isEmpty(inventoryAdjustment)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (inventoryAdjustment.status !== INVENTORY_ADJUSTMENT_STATUS.PENDING) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }

    inventoryAdjustment.status = INVENTORY_ADJUSTMENT_STATUS.REJECTED;
    await this.inventoryAdjustmentRepository.update(inventoryAdjustment);
    return new ResponseBuilder({
      success: true,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async delete(
    request: GetDetailInventoryAdjustmentRequestDto,
  ): Promise<any> {
    const { id, userId } = request;
    const inventoryAdjustment =
      await this.inventoryAdjustmentRepository.findOneWithRelations({
        where: { id },
        relations: ['inventoryAdjustmentDetails'],
      });
    if (isEmpty(inventoryAdjustment)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (
      !INVENTORY_ADJUSTMENT_STATUS_EDITABLE.includes(inventoryAdjustment.status)
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      inventoryAdjustment.deletedAt = new Date();
      inventoryAdjustment.deletedBy = userId;
      await queryRunner.manager.save(inventoryAdjustment);

      const inventoryAdjustmentDetailEntites =
        inventoryAdjustment.inventoryAdjustmentDetails.map((item) => {
          item.deletedAt = new Date();
          item.deletedBy = userId;
          return item;
        });
      await queryRunner.manager.save(inventoryAdjustmentDetailEntites);

      await queryRunner.commitTransaction();

      return new ResponseBuilder({
        success: true,
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  private async getRelationData(
    sourceIds: number[],
    reasonIds: number[],
    userIds: number[],
    departmentReceiptIds: number[],
    itemIds?: number[],
    locatorIds?: number[],
  ): Promise<any> {
    const data = await Promise.all([
      !isEmpty(sourceIds)
        ? this.saleService.getSourceByIds(sourceIds, true)
        : {},
      !isEmpty(reasonIds)
        ? this.saleService.getReasonByIds(reasonIds, true)
        : {},
      !isEmpty(userIds) ? this.userService.getUserByIds(userIds, true) : {},
      !isEmpty(departmentReceiptIds)
        ? this.userService.getDepartmentReceiptByIds(departmentReceiptIds)
        : [],
      !isEmpty(itemIds) ? this.itemService.getItems(itemIds) : [],
      !isEmpty(locatorIds)
        ? this.warehouseLayoutService.getLocatorByIds(locatorIds, true)
        : {},
    ]);

    return {
      sourceByIds: data[0],
      reasonByIds: data[1],
      userByIds: data[2],
      departmentReceiptByIds: keyBy(data[3], 'id'),
      itemByIds: keyBy(data[4], 'itemId'),
      locatorByIds: data[5],
    };
  }

  async getListOpenTransaction(
    request: GetListOpenTransactionRequestDto,
  ): Promise<any> {
    const configService = new ConfigService();
    const defaultTimeZone = configService.get('defaultTimeZone');
    const data =
      await this.inventoryAdjustmentRepository.getListOpenTransaction(
        request,
        defaultTimeZone,
      );

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
