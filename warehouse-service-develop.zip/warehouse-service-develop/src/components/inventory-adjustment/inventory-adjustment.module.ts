import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserModule } from '@components/user/user.module';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { InventoryAdjustmentEntity } from '@entities/inventory-adjusment/inventory-adjustment.entity';
import { InventoryAdjustmentRepository } from '@repositories/inventory-adjustment.repository';
import { InventoryAdjustmentController } from './inventory-adjustment.controller';
import { InventoryAdjustmentService } from './inventory-adjustment.service';
import { Warehouse } from '@entities/warehouse/warehouse.entity';
import { WarehouseRepository } from '@repositories/warehouse.repository';
import { ItemService } from '@components/item/item.service';
import { WarehouseLayoutService } from '@components/warehouse-layout/warehouse-layout.service';
import { InventoryAdjustmentDetailEntity } from '@entities/inventory-adjusment/inventory-adjustment-detail.entity';
import { InventoryAdjustmentDetailRepository } from '@repositories/inventory-adjustment-detail.repository';
import { SaleService } from '@components/sale/sale.service';
import { UserService } from '@components/user/user.service';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { FileRepository } from '@repositories/file.repository';
import { FileEntity } from '@entities/file/file.entity';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([
      InventoryAdjustmentEntity,
      InventoryAdjustmentDetailEntity,
      Warehouse,
      FileEntity,
    ]),
    UserModule,
    WarehouseModule,
  ],
  exports: [],
  providers: [
    {
      provide: 'InventoryAdjustmentRepositoryInterface',
      useClass: InventoryAdjustmentRepository,
    },
    {
      provide: 'InventoryAdjustmentDetailRepositoryInterface',
      useClass: InventoryAdjustmentDetailRepository,
    },
    {
      provide: 'InventoryAdjustmentServiceInterface',
      useClass: InventoryAdjustmentService,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'FileRepositoryInterface',
      useClass: FileRepository,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseLayoutServiceInterface',
      useClass: WarehouseLayoutService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
  ],
  controllers: [InventoryAdjustmentController],
})
export class InventoryAdjustmentModule {}
