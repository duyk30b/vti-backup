import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class RelationDataResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

class WarehouseResponse extends RelationDataResponseDto {
  @ApiProperty()
  @Expose()
  manageByLot: number;
}

class UserResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  username: string;

  @ApiProperty()
  @Expose()
  fullName: string;
}

class ItemResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  unitName: string;
}

class InventoryAdjustmentDetailResponseDto {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty({ type: ItemResponseDto })
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty({ type: RelationDataResponseDto })
  @Expose()
  @Type(() => RelationDataResponseDto)
  locator: RelationDataResponseDto;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  exportQuantity: number;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty()
  @Expose()
  amount: number;

  @ApiProperty()
  @Expose()
  debitAccount: string;

  @ApiProperty()
  @Expose()
  creditAccount: string;
}

export class GetInventoryAdjustmentResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty({ type: WarehouseResponse })
  @Expose()
  @Type(() => WarehouseResponse)
  warehouse: WarehouseResponse;

  @ApiProperty({ type: RelationDataResponseDto })
  @Expose()
  @Type(() => RelationDataResponseDto)
  source: RelationDataResponseDto;

  @ApiProperty({ type: RelationDataResponseDto })
  @Expose()
  @Type(() => RelationDataResponseDto)
  reason: RelationDataResponseDto;

  @ApiProperty({ type: RelationDataResponseDto })
  @Expose()
  @Type(() => RelationDataResponseDto)
  departmentReceipt: RelationDataResponseDto;

  @ApiProperty({ type: RelationDataResponseDto })
  @Expose()
  @Type(() => RelationDataResponseDto)
  inventory: RelationDataResponseDto;

  @ApiProperty()
  @Expose()
  receiptDate: Date;

  @ApiProperty()
  @Expose()
  receiptNumber: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  explaination: string;

  @ApiProperty()
  @Expose()
  attachments: any[];

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdBy: UserResponseDto;

  @ApiProperty()
  @Expose()
  confirmedAt: Date;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  confirmedBy: UserResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => InventoryAdjustmentDetailResponseDto)
  items: InventoryAdjustmentDetailResponseDto[];
}
