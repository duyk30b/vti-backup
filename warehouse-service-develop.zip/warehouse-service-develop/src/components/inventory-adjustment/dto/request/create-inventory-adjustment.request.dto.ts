import {
  INVENTORY_ADJUSTMENT_TYPE,
  RULE_INVENTORY_ADJUSTMENT,
} from '@components/inventory-adjustment/inventory-adjustment.constant';
import { BaseDto } from '@core/dto/base.dto';
import { File } from '@core/dto/file-upload.request';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsEnum,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  ValidateIf,
} from 'class-validator';
import { isJson } from 'src/helper/string.helper';

export class OldFile {
  id: string;
  fileName: string;
  fileUrl: string;
}

class InventoryAdjustmentDetailRequestDto {
  @ApiProperty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  itemId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  locatorId: number;

  @ApiProperty()
  @IsNumber({ maxDecimalPlaces: 2 })
  @Transform(({ value }) => Number(value))
  quantity: number;

  @ApiProperty()
  @IsNumber({ maxDecimalPlaces: 2 })
  @Transform(({ value }) => Number(value))
  price: number;

  @ApiProperty()
  @IsNumber({ maxDecimalPlaces: 2 })
  @Transform(({ value }) => Number(value))
  amount: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  debitAccount: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  creditAccount: string;
}

export class CreateInventoryAdjustmentRequestDto extends BaseDto {
  @ApiProperty()
  @IsString()
  @MaxLength(RULE_INVENTORY_ADJUSTMENT.CODE.MAX_LENGTH)
  code: string;

  @ApiProperty()
  @IsString()
  @MaxLength(RULE_INVENTORY_ADJUSTMENT.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty()
  @IsEnum(INVENTORY_ADJUSTMENT_TYPE)
  @Transform(({ value }) => Number(value))
  type: number;

  @ApiProperty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  warehouseId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  @Transform(({ value }) => Number(value))
  departmentReceiptId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  @Transform(({ value }) => Number(value))
  inventoryId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @ValidateIf((val) => {
    return val.receiptDate !== '' && val.receiptDate !== 'null';
  })
  @Transform(({ value }) => {
    if (value === '' || value === 'null') {
      return null;
    }
    return value;
  })
  @IsDateString()
  receiptDate: Date;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  receiptNumber: string;

  @ApiProperty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  sourceId: number;

  @ApiProperty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  reasonId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(RULE_INVENTORY_ADJUSTMENT.EXPLAINATION.MAX_LENGTH)
  explaination: string;

  @ApiPropertyOptional()
  @Type(() => File)
  @IsOptional()
  attachments: File[];

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => {
    if (value instanceof Array) {
      return value;
    }

    if (value && value.includes('\\"')) value = value.replace(/\\/g, '');

    if (isJson(value) && JSON.parse(value) instanceof Array) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    } else {
      return value.split(',');
    }
  })
  @Type(() => OldFile)
  files: OldFile[];

  @ApiProperty({
    type: InventoryAdjustmentDetailRequestDto,
    isArray: true,
  })
  @IsArray()
  @Transform(({ value }) => JSON.parse(value))
  @Type(() => InventoryAdjustmentDetailRequestDto)
  items: InventoryAdjustmentDetailRequestDto[];
}

export class InventoryAdjustmentDetailPayload extends InventoryAdjustmentDetailRequestDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  inventoryAdjustmentId?: number;

  @ApiProperty()
  @IsInt()
  userId: number;
}
