import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';
import { CreateInventoryAdjustmentRequestDto } from './create-inventory-adjustment.request.dto';

export class UpdateInventoryAdjustmentBodyDto extends CreateInventoryAdjustmentRequestDto {}

export class UpdateInventoryAdjustmentRequestDto extends UpdateInventoryAdjustmentBodyDto {
  @ApiProperty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  id: number;
}
