import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { InventoryAdjustmentEntity } from '@entities/inventory-adjusment/inventory-adjustment.entity';
import { CreateInventoryAdjustmentRequestDto } from '../dto/request/create-inventory-adjustment.request.dto';
import { GetListInventoryAdjustmentRequestDto } from '../dto/request/get-list-inventory-adjustment.request.dto';
import { GetListOpenTransactionRequestDto } from '../dto/request/get-list-open-transaction.request.dto';
import { UpdateInventoryAdjustmentRequestDto } from '../dto/request/update-inventory-adjustment.request.dto';

export interface InventoryAdjustmentRepositoryInterface
  extends BaseInterfaceRepository<InventoryAdjustmentEntity> {
  createEntity(
    payload: CreateInventoryAdjustmentRequestDto,
  ): InventoryAdjustmentEntity;
  updateEntity(
    entity: InventoryAdjustmentEntity,
    payload: UpdateInventoryAdjustmentRequestDto,
  ): InventoryAdjustmentEntity;
  getList(request: GetListInventoryAdjustmentRequestDto): Promise<any>;
  detail(id: number): Promise<any>;
  getListOpenTransaction(
    request: GetListOpenTransactionRequestDto,
    defaultTimeZone: string,
  ): Promise<any>;
}
