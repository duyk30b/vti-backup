import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { InventoryAdjustmentDetailEntity } from '@entities/inventory-adjusment/inventory-adjustment-detail.entity';
import { InventoryAdjustmentDetailPayload } from '../dto/request/create-inventory-adjustment.request.dto';

export interface InventoryAdjustmentDetailRepositoryInterface
  extends BaseInterfaceRepository<InventoryAdjustmentDetailEntity> {
  createEntity(
    payload: InventoryAdjustmentDetailPayload,
  ): InventoryAdjustmentDetailEntity;
}
