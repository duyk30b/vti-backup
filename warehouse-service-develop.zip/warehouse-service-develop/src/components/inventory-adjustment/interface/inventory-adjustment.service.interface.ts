import { CreateInventoryAdjustmentRequestDto } from '../dto/request/create-inventory-adjustment.request.dto';
import { GetDetailInventoryAdjustmentRequestDto } from '../dto/request/get-detail-inventory-adjustment.request.dto';
import { GetListInventoryAdjustmentRequestDto } from '../dto/request/get-list-inventory-adjustment.request.dto';
import { GetListOpenTransactionRequestDto } from '../dto/request/get-list-open-transaction.request.dto';
import { UpdateInventoryAdjustmentRequestDto } from '../dto/request/update-inventory-adjustment.request.dto';

export interface InventoryAdjustmentServiceInterface {
  create(request: CreateInventoryAdjustmentRequestDto): Promise<any>;
  edit(request: UpdateInventoryAdjustmentRequestDto): Promise<any>;
  getList(request: GetListInventoryAdjustmentRequestDto): Promise<any>;
  detail(id: number): Promise<any>;
  confirm(request: GetDetailInventoryAdjustmentRequestDto): Promise<any>;
  reject(id: number): Promise<any>;
  delete(request: GetDetailInventoryAdjustmentRequestDto): Promise<any>;
  getListOpenTransaction(
    request: GetListOpenTransactionRequestDto,
  ): Promise<any>;
}
