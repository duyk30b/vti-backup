import { ApiProperty } from '@nestjs/swagger';
import { Meta } from '@utils/common.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { SuspendLocationResponse } from './suspend-location.response.dto';

export class SuspendLocationDataResponse {
  @ApiProperty({ type: SuspendLocationResponse, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => SuspendLocationResponse)
  items: SuspendLocationResponse[];

  @ApiProperty({ type: Meta })
  @Expose()
  @Type(() => Meta)
  meta: Meta;
}

export class GetListSuspendLocationResponseDto extends SuccessResponse {
  @ApiProperty({ type: SuspendLocationDataResponse })
  @Expose()
  @Type(() => SuspendLocationDataResponse)
  data: SuspendLocationDataResponse[];
}
