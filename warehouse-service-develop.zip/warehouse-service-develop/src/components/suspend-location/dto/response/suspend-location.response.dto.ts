import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';

class FactoryResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}
class WarehouseSectorResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class WarehouseShelfResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class WarehouseFloorResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class WarehouseResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

export class SuspendLocationResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  status: string;

  @ApiProperty()
  @Expose()
  factoryId: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  warehouseSectorId: number;

  @ApiProperty()
  @Expose()
  warehouseShelfId: number;

  @ApiProperty()
  @Expose()
  warehouseFloorId: number;

  @ApiProperty()
  @Type(() => FactoryResponseDto)
  @Expose()
  factory: FactoryResponseDto;

  @ApiProperty()
  @Type(() => WarehouseResponseDto)
  @Expose()
  warehouse: WarehouseResponseDto;

  @ApiProperty()
  @Type(() => WarehouseSectorResponseDto)
  @Expose()
  warehouseSector: WarehouseSectorResponseDto;

  @ApiProperty()
  @Type(() => WarehouseShelfResponseDto)
  @Expose()
  warehouseshelf: WarehouseShelfResponseDto;

  @ApiProperty()
  @Type(() => WarehouseFloorResponseDto)
  @Expose()
  warehouseFloor: WarehouseFloorResponseDto;

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty()
  @Expose()
  createdAt: string;
}

export class SuspendLocationResponseDto extends SuccessResponse {
  @ApiProperty()
  @Type(() => SuspendLocationResponse)
  @Expose()
  data: SuspendLocationResponse;
}
