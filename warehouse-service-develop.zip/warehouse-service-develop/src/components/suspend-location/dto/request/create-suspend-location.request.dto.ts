import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsInt,
  IsNotEmpty,
  IsOptional,
  MaxLength,
  ValidateNested,
} from 'class-validator';

export class SuspendLocationDetailDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  factoryId: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseSectorId: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseShelfId: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseFloorId: number;
}

export class CreateSuspendLocationRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  @MaxLength(255)
  description: string;

  @ApiProperty({
    type: SuspendLocationDetailDto,
    isArray: true,
  })
  @ArrayNotEmpty()
  @ValidateNested()
  @ArrayUnique()
  @Type(() => SuspendLocationDetailDto)
  locations: SuspendLocationDetailDto[];
}
