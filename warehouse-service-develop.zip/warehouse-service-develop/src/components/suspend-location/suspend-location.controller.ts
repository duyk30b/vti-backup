import { SuspendLocationServiceInterface } from './interface/suspend-location.service.interface';
import {
  Controller,
  Inject,
  Body,
  Post,
  Delete,
  Get,
  Put,
  Param,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { isEmpty } from 'lodash';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import {
  SuspendLocationResponse,
  SuspendLocationResponseDto,
} from './dto/response/suspend-location.response.dto';
import { CreateSuspendLocationRequestDto } from './dto/request/create-suspend-location.request.dto';
import {
  SetStatusRequestDto,
  DeleteRequestDto,
  DetailRequestDto,
} from '@utils/common.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { GetListSuspendLocationResponseDto } from './dto/response/get-list-suspend-location.response.dto';
import { GetListSuspendLocationRequestDto } from './dto/request/get-list-suspend-location.request.dto';
import {
  CHANGE_STATUS_SUSPEND_ITEM_LOCATION_PERMISSION,
  CREATE_SUSPEND_ITEM_LOCATION_PERMISSION,
  DELETE_SUSPEND_ITEM_LOCATION_PERMISSION,
  DETAIL_SUSPEND_ITEM_LOCATION_PERMISSION,
  LIST_SUSPEND_ITEM_LOCATION_PERMISSION,
} from '@utils/permissions/suspend-location';
import { NATS_WAREHOUSE } from '@config/nats.config';

@Controller('suspends')
export class SuspendLocationController {
  constructor(
    @Inject('SuspendLocationServiceInterface')
    private readonly suspendLocationService: SuspendLocationServiceInterface,
  ) {}

  @PermissionCode(CREATE_SUSPEND_ITEM_LOCATION_PERMISSION.code)
  @Post('/create')
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: SuspendLocationResponseDto,
  })
  @MessagePattern(`${NATS_WAREHOUSE}.create_suspend_location`)
  public async createSuspendLocation(
    @Body() body: CreateSuspendLocationRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suspendLocationService.createSuspendLocation(request);
  }

  @PermissionCode(DELETE_SUSPEND_ITEM_LOCATION_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'delete suspend location',
    description: 'xóa khóa vị trí',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  // @MessagePattern('delete_suspend_location')
  public async deleteSuspendLocation(
    @Param() param: DeleteRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suspendLocationService.deleteSuspendLocation(
      Number(request.id),
    );
  }

  @PermissionCode(DETAIL_SUSPEND_ITEM_LOCATION_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'suspend location detail',
    description: 'Chi tiết khóa vị trí',
  })
  @ApiResponse({
    status: 200,
    description: 'Detail successfully',
    type: SuspendLocationResponseDto,
  })
  // @MessagePattern('detail_suspend_location')
  public async getSuspendLocation(
    @Param() param: DetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suspendLocationService.getDetail(request.id);
  }

  @PermissionCode(LIST_SUSPEND_ITEM_LOCATION_PERMISSION.code)
  @Get('/list')
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: GetListSuspendLocationResponseDto,
  })
  // @MessagePattern('list_suspend_location')
  public async getSuspendLocations(
    @Query() query: GetListSuspendLocationRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suspendLocationService.getList(request);
  }

  @PermissionCode(CHANGE_STATUS_SUSPEND_ITEM_LOCATION_PERMISSION.code)
  @Put('/:id/open')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'open suspend location',
    description: 'mở khóa vị trí',
  })
  @ApiResponse({
    status: 200,
    description: 'Open successfully',
    type: SuspendLocationResponseDto,
  })
  // @MessagePattern('open_suspend_location')
  public async openSuspendLocation(
    @Param() param: SetStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suspendLocationService.openSuspendLocation(request.id);
  }

  @PermissionCode(CHANGE_STATUS_SUSPEND_ITEM_LOCATION_PERMISSION.code)
  @Put('/:id/close')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'close suspend location',
    description: 'khóa vị trí',
  })
  @ApiResponse({
    status: 200,
    description: 'Close successfully',
    type: SuspendLocationResponseDto,
  })
  // @MessagePattern('close_suspend_location')
  public async closeSuspendLocation(
    @Param() param: SetStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suspendLocationService.closeSuspendLocation(request.id);
  }
}
