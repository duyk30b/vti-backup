import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { CreateSuspendLocationRequestDto } from '../dto/request/create-suspend-location.request.dto';
import { GetListSuspendLocationRequestDto } from '../dto/request/get-list-suspend-location.request.dto';
import { GetListSuspendLocationResponseDto } from '../dto/response/get-list-suspend-location.response.dto';
import { SuspendLocationResponseDto } from '../dto/response/suspend-location.response.dto';

export interface SuspendLocationServiceInterface {
  createSuspendLocation(
    request: CreateSuspendLocationRequestDto,
  ): Promise<ResponsePayload<any | SuspendLocationResponseDto>>;
  getDetail(
    id: number,
  ): Promise<ResponsePayload<any | SuspendLocationResponseDto>>;
  getList(
    request: GetListSuspendLocationRequestDto,
  ): Promise<ResponsePayload<any | GetListSuspendLocationResponseDto>>;
  deleteSuspendLocation(
    id: number,
  ): Promise<ResponsePayload<any | SuccessResponse>>;
  openSuspendLocation(
    id: number,
  ): Promise<ResponsePayload<any | SuspendLocationResponseDto>>;
  closeSuspendLocation(
    id: number,
  ): Promise<ResponsePayload<any | SuspendLocationResponseDto>>;
}
