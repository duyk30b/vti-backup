import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { SuspendLocationEntity } from '@entities/suspend-location/suspend-location.entity';
import { CreateSuspendLocationRequestDto } from '../dto/request/create-suspend-location.request.dto';
import { GetListSuspendLocationRequestDto } from '../dto/request/get-list-suspend-location.request.dto';

export interface SuspendLocationRepositoryInterface
  extends BaseInterfaceRepository<SuspendLocationEntity> {
  createEntities(
    request: CreateSuspendLocationRequestDto,
  ): Promise<SuspendLocationEntity[]>;
  getSuspendLocation(id: number): Promise<any>;
  getSuspendLocations(
    request: GetListSuspendLocationRequestDto,
    factories?: any[],
  ): Promise<any>;
}
