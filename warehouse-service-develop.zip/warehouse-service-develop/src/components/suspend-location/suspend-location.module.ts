import { ItemModule } from '@components/item/item.module';
import { ItemService } from '@components/item/item.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { SuspendLocationEntity } from '@entities/suspend-location/suspend-location.entity';
import { Warehouse } from '@entities/warehouse/warehouse.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SuspendLocationRepository } from '@repositories/suspend-location.repository';
import { WarehouseRepository } from '@repositories/warehouse.repository';
import { SuspendLocationController } from './suspend-location.controller';
import { SuspendLocationService } from './suspend-location.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([SuspendLocationEntity, Warehouse]),
    UserModule,
    ItemModule,
  ],
  exports: [],
  providers: [
    {
      provide: 'SuspendLocationRepositoryInterface',
      useClass: SuspendLocationRepository,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'SuspendLocationServiceInterface',
      useClass: SuspendLocationService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
  ],
  controllers: [SuspendLocationController],
})
export class SuspendLocationModule {}
