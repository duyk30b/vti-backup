export enum SuspendLocationStatusEnum {
  Open = 0,
  Close = 1,
}
