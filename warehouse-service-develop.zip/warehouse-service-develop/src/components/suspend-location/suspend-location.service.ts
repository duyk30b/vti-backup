import { PagingResponse } from '../../utils/paging.response';
import { plainToInstance } from 'class-transformer';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Injectable, Inject } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { DataSource } from 'typeorm';
import { first, isEmpty, map, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { SuspendLocationServiceInterface } from './interface/suspend-location.service.interface';
import { SuspendLocationRepositoryInterface } from './interface/suspend-location.repository.interface';
import { CreateSuspendLocationRequestDto } from './dto/request/create-suspend-location.request.dto';
import { GetListSuspendLocationRequestDto } from './dto/request/get-list-suspend-location.request.dto';
import { GetListSuspendLocationResponseDto } from './dto/response/get-list-suspend-location.response.dto';
import {
  SuspendLocationResponse,
  SuspendLocationResponseDto,
} from './dto/response/suspend-location.response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { SuspendLocationStatusEnum } from './suspend-location.constant';
import { UserService } from '@components/user/user.service';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';

@Injectable()
export class SuspendLocationService implements SuspendLocationServiceInterface {
  constructor(
    @Inject('SuspendLocationRepositoryInterface')
    private readonly suspendLocationRepository: SuspendLocationRepositoryInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserService,

    private readonly i18n: I18nRequestScopeService,

    @InjectDataSource()
    private readonly connection: DataSource,
  ) {}

  async createSuspendLocation(
    request: CreateSuspendLocationRequestDto,
  ): Promise<ResponsePayload<any | SuspendLocationResponseDto>> {
    const { locations } = request;

    const queryCondition = locations.map((record) => ({
      factoryId: record.factoryId,
      warehouseId: record.warehouseId ? record.warehouseId : null,
      warehouseSectorId: record.warehouseSectorId
        ? record.warehouseSectorId
        : null,
      warehouseShelfId: record.warehouseShelfId
        ? record.warehouseShelfId
        : null,
      warehouseFloorId: record.warehouseFloorId
        ? record.warehouseFloorId
        : null,
    }));

    const suspendLocationExist =
      await this.suspendLocationRepository.findByCondition(queryCondition);

    if (!isEmpty(suspendLocationExist)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.SUSPEND_LOCATION_DUPLICATE'),
        )
        .build();
    }

    const factories = await this.userService.getFactories({});

    const dataLocations =
      await this.warehouseRepository.getWarehouseLocationsByDataLocation(
        queryCondition,
        factories.data,
      );

    if (dataLocations.length !== locations.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.LOCATION_NOT_FOUND'))
        .build();
    }

    const suspendItemEntities =
      await this.suspendLocationRepository.createEntities(request);
    try {
      const result = await this.suspendLocationRepository.create(
        suspendItemEntities,
      );
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async getDetail(
    id: number,
  ): Promise<ResponsePayload<any | SuspendLocationResponseDto>> {
    const suspendLocation =
      await this.suspendLocationRepository.getSuspendLocation(id);
    if (!suspendLocation) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.SUSPEND_LOCATION_NOT_FOUND'),
      ).toResponse();
    }

    const factories = await this.userService.getFactoriesByIds([
      suspendLocation.factoryId,
    ]);

    const data = {
      ...suspendLocation,
      factory: factories.data ? first(factories.data) : {},
    };

    const response = plainToInstance(SuspendLocationResponse, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(
    request: GetListSuspendLocationRequestDto,
  ): Promise<ResponsePayload<any | GetListSuspendLocationResponseDto>> {
    const { filter } = request;
    let factories = [];
    const filterFactoryName = filter?.filter(
      (record) => record.column === 'factoryName',
    );

    if (!isEmpty(filterFactoryName)) {
      factories = await this.userService.getFactoriesByNameKeyword(
        first(filterFactoryName),
      );

      if (isEmpty(factories)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    } else {
      const suspendLocations =
        await this.suspendLocationRepository.findWithRelations({
          select: ['factoryId'],
        });
      const factoryIds = uniq(map(suspendLocations, 'factoryId'));
      const dataFactories = await this.userService.getFactoriesByIds(
        factoryIds,
      );
      factories =
        dataFactories.statusCode === ResponseCodeEnum.SUCCESS
          ? dataFactories.data
          : [];
    }

    const { data, count } =
      await this.suspendLocationRepository.getSuspendLocations(
        request,
        factories,
      );

    const dataReturn = plainToInstance(SuspendLocationResponse, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async deleteSuspendLocation(
    id: number,
  ): Promise<ResponsePayload<any | SuccessResponse>> {
    try {
      await this.suspendLocationRepository.remove(id);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async openSuspendLocation(
    id: number,
  ): Promise<ResponsePayload<any | SuspendLocationResponseDto>> {
    const suspendLocation = await this.suspendLocationRepository.findOneById(
      id,
    );
    if (!suspendLocation) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.SUSPEND_LOCATION_NOT_FOUND'),
      ).toResponse();
    }
    suspendLocation.status = SuspendLocationStatusEnum.Open;

    try {
      const result = await this.suspendLocationRepository.create(
        suspendLocation,
      );
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async closeSuspendLocation(
    id: number,
  ): Promise<ResponsePayload<any | SuspendLocationResponseDto>> {
    const suspendLocation = await this.suspendLocationRepository.findOneById(
      id,
    );
    if (!suspendLocation) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.SUSPEND_LOCATION_NOT_FOUND'),
      ).toResponse();
    }
    suspendLocation.status = SuspendLocationStatusEnum.Close;

    try {
      const result = await this.suspendLocationRepository.create(
        suspendLocation,
      );
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }
}
