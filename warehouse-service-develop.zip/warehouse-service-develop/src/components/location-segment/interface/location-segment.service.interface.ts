import { CreateLocationSegmentRequestDto } from '../dto/request/create-location-segment.request.dto';
import { UpdateLocationSegmentRequestDto } from '../dto/request/update-location-segment.request.dto';

export interface LocationSegmentServiceInterface {
  getList(): Promise<any>;
  create(request: CreateLocationSegmentRequestDto): Promise<any>;
  update(request: UpdateLocationSegmentRequestDto): Promise<any>;
}
