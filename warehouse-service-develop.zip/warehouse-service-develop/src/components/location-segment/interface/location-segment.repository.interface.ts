import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { CreateLocationSegmentRequestDto } from '../dto/request/create-location-segment.request.dto';
import { LocationSegmentEntity } from '@entities/location-segment/location-segment.entity';
import { UpdateLocationSegmentRequestDto } from '../dto/request/update-location-segment.request.dto';

export interface LocationSegmentRepositoryInterface
  extends BaseInterfaceRepository<LocationSegmentEntity> {
  createEntities(
    request: CreateLocationSegmentRequestDto,
  ): LocationSegmentEntity[];
  updateEntities(
    request: UpdateLocationSegmentRequestDto,
    entities: LocationSegmentEntity[],
  ): LocationSegmentEntity[];
  getList(): Promise<any>;
}
