export const LOCATION_SEGMENT_RULES = {
  NAME: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 20,
  },
};
