import { Body, Controller, Get, Inject, Post, Put, Req } from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateLocationSegmentRequestDto } from './dto/request/create-location-segment.request.dto';
import { isEmpty } from 'lodash';
import { LocationSegmentServiceInterface } from './interface/location-segment.service.interface';
import { LocationSegmentResponseDto } from './dto/response/location-segment.response.dto';
import { GetLocationSegmentRequestDto } from './dto/request/get-location-segment.request.dto';
import { UpdateLocationSegmentRequestDto } from './dto/request/update-location-segment.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  LIST_LOCATION_SEGMENT_PERMISSION,
  CREATE_LOCATION_SEGMENT_PERMISSION,
  UPDATE_LOCATION_SEGMENT_PERMISSION,
} from '@utils/permissions/location-segment';

@Controller('location-segments')
export class LocationSegmentController {
  constructor(
    @Inject('LocationSegmentServiceInterface')
    private readonly locationSegmentService: LocationSegmentServiceInterface,
  ) {}

  @PermissionCode(CREATE_LOCATION_SEGMENT_PERMISSION.code)
  @Post()
  @ApiOperation({
    tags: ['LocationSegment'],
    summary: 'Create new warehouse structure',
    description: 'Tạo cấu trúc kho mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async create(
    @Body() body: CreateLocationSegmentRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locationSegmentService.create(request);
  }

  @PermissionCode(UPDATE_LOCATION_SEGMENT_PERMISSION.code)
  @Put()
  @ApiOperation({
    tags: ['LocationSegment'],
    summary: 'Update location segment',
    description: 'Sửa location segment',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async update(
    @Body() body: UpdateLocationSegmentRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locationSegmentService.update(request);
  }

  @PermissionCode(LIST_LOCATION_SEGMENT_PERMISSION.code)
  @Get('/list')
  @ApiOperation({
    tags: ['LocationSegment'],
    summary: 'Get locationsegment',
    description: ' locationsegment',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: LocationSegmentResponseDto,
  })
  public async getList(@Req() req: GetLocationSegmentRequestDto): Promise<any> {
    const { responseError } = req;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locationSegmentService.getList();
  }
}
