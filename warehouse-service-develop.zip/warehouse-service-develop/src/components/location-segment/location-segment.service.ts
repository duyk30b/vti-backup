import { ResponseCodeEnum } from '@constant/response-code.enum';
import { LocationSegmentEntity } from '@entities/location-segment/location-segment.entity';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In } from 'typeorm';
import { CreateLocationSegmentRequestDto } from './dto/request/create-location-segment.request.dto';
import { LocationSegmentServiceInterface } from './interface/location-segment.service.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { LocationSegmentRepositoryInterface } from './interface/location-segment.repository.interface';
import { UpdateLocationSegmentRequestDto } from './dto/request/update-location-segment.request.dto';
import { LocationSegmentResponseDto } from './dto/response/location-segment.response.dto';
import { plainToInstance } from 'class-transformer';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { uniq } from 'lodash';

@Injectable()
export class LocationSegmentService implements LocationSegmentServiceInterface {
  constructor(
    @InjectDataSource()
    private readonly connection: DataSource,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('LocationSegmentRepositoryInterface')
    private readonly locationSegmentRepository: LocationSegmentRepositoryInterface,
    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateLocationSegmentRequestDto): Promise<any> {
    request.locationSegments.sort((a, b) => {
      return a.level - b.level;
    });
    const validLevel = request.locationSegments.every((segment, index) => {
      return segment.level === index;
    });
    if (!validLevel) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }
    const existingSegments = await this.locationSegmentRepository.findAll();
    if (existingSegments?.length > 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.LOCATION_SEGMENT_EXIST'))
        .build();
    }
    const segments = this.locationSegmentRepository.createEntities(request);
    return this.save(segments, existingSegments);
  }

  async update(request: UpdateLocationSegmentRequestDto): Promise<any> {
    const existSegments = await this.locationSegmentRepository.findAll();
    const updateSegments = this.locationSegmentRepository.updateEntities(
      request,
      existSegments,
    );

    return this.save(updateSegments, existSegments);
  }

  async getList(): Promise<any> {
    const segments = await this.locationSegmentRepository.getList();
    const response = await this.generateResponseDto(segments);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  async save(
    locationSegmentEntities: LocationSegmentEntity[],
    existSegments: LocationSegmentEntity[],
  ): Promise<any> {
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (locationSegmentEntities.length < existSegments.length) {
        const entitiesLevels = locationSegmentEntities.map(
          (segment) => segment.level,
        );
        const deleteSegmentIds = existSegments
          .map((segment) => segment.id)
          .filter((id) => !entitiesLevels.includes(id));
        await queryRunner.manager.delete(LocationSegmentEntity, {
          id: In(deleteSegmentIds),
        });
      }
      const result = await queryRunner.manager.save(locationSegmentEntities);
      await queryRunner.commitTransaction();
      const response = await this.generateResponseDto(result);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(response)
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  private async generateResponseDto(
    segments: LocationSegmentEntity[],
  ): Promise<LocationSegmentResponseDto[]> {
    const creatorIds = segments.map((segment) => segment.createdBy);
    const updaterIds = segments.map((segment) => segment.updatedBy);
    const userIds = uniq([...creatorIds, ...updaterIds]);
    const users = await this.userService.getUserByIds(userIds, true);
    segments.forEach((segment) => {
      segment.createdBy = users[segment.createdBy];
      segment.updatedBy = users[segment.updatedBy];
    });
    const response = plainToInstance(LocationSegmentResponseDto, segments, {
      excludeExtraneousValues: true,
    });
    return response;
  }
}
