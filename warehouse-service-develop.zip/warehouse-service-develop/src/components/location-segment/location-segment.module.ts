import { LocationSegmentEntity } from '@entities/location-segment/location-segment.entity';
import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LocationSegmentController } from './location-segment.controller';
import { LocationSegmentRepository } from '@repositories/location-segment.repository';
import { LocationSegmentService } from './location-segment.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';

@Global()
@Module({
  imports: [TypeOrmModule.forFeature([LocationSegmentEntity]), UserModule],
  exports: [],
  providers: [
    {
      provide: 'LocationSegmentRepositoryInterface',
      useClass: LocationSegmentRepository,
    },
    {
      provide: 'LocationSegmentServiceInterface',
      useClass: LocationSegmentService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
  ],
  controllers: [LocationSegmentController],
})
export class LocationSegmentModule {}
