import { CreateLocationSegmentRequestDto } from './create-location-segment.request.dto';

export class UpdateLocationSegmentRequestDto extends CreateLocationSegmentRequestDto {}
