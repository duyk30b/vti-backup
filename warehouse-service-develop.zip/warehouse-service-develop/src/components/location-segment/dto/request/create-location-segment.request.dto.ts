import { LOCATION_SEGMENT_RULES } from '@components/location-segment/location-segment.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsInt, IsString, MaxLength } from 'class-validator';

export class LocationSegment {
  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(LOCATION_SEGMENT_RULES.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(LOCATION_SEGMENT_RULES.CODE.MAX_LENGTH)
  code: string;

  @ApiProperty({ example: '', description: '' })
  @IsInt()
  level: number;
}

export class CreateLocationSegmentRequestDto extends BaseDto {
  @ApiProperty({ example: '', description: '' })
  @IsArray()
  locationSegments: LocationSegment[];
}
