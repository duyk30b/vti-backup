import { BaseDto } from '@core/dto/base.dto';

export class GetLocationSegmentRequestDto extends BaseDto {}
