import { ApiProperty } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';
import { IsNotEmpty } from 'class-validator';
import { Transform } from 'class-transformer';

export class GetGetWarehouseDoorsByWarehouseIdsParamDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  id: number;
}
export class GetWarehouseDoorsByWarehouseIdsRequestDto extends GetGetWarehouseDoorsByWarehouseIdsParamDto {
  @ApiProperty()
  @IsNotEmpty()
  warehouseIds: number[];
}

export class GetGetWarehouseDoorsByWarehouseIdsTcpDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  warehouseIds: number[];
}
