import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { BaseDto } from '@core/dto/base.dto';
import {
  IsNotEmpty,
  ValidateNested,
} from 'class-validator';
import { DesignRequest } from '@components/warehouse/dto/request/unit-measures.request.dto';

export class CreateWarehouseDoorRequestDto extends BaseDto {
  @ApiProperty({
    example: { x: 0, y: 0 },
    description: '',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => DesignRequest)
  design: DesignRequest;
}
