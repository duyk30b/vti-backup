import { Body, Controller, Get, Inject, Param, Req } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { isEmpty } from 'lodash';
import { ResponsePayload } from '@utils/response-payload';
import { DeleteAndDetailRequestDto } from '@utils/delete-and-detail.request.dto';
import { WarehouseDoorServiceInterface } from './interface/warehouse-door.service.interface';
import {
  GetGetWarehouseDoorsByWarehouseIdsParamDto,
  GetGetWarehouseDoorsByWarehouseIdsTcpDto,
  GetWarehouseDoorsByWarehouseIdsRequestDto,
} from './dto/request/get-warehouse-doors-by-warehouse-ids.request.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { WarehouseDoorResponseDto } from './dto/response/warehouse-door.response.dto';
import { NATS_WAREHOUSE } from '@config/nats.config';

@Controller('warehouse-doors')
export class WarehouseDoorController {
  constructor(
    @Inject('WarehouseDoorServiceInterface')
    private readonly warehouseDoorService: WarehouseDoorServiceInterface,
  ) {}

  //todo remove when refactor done
  @MessagePattern(`${NATS_WAREHOUSE}.get_warehouse_door_by_id`)
  public async getWarehouseDoorByIdTcp(
    @Body() payload: DeleteAndDetailRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseDoorService.getWarehouseDoorById(request.id);
  }

  @Get('/:id')
  public async getWarehouseDoorById(
    @Param() param: DeleteAndDetailRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseDoorService.getWarehouseDoorById(request.id);
  }

  @Get('/:id/door/list')
  @ApiOperation({
    tags: ['App', 'Warehouse Doors'],
    summary: 'Env',
    description: 'Lấy dữ liệu cửa',
  })
  @ApiResponse({
    status: 200,
    type: WarehouseDoorResponseDto,
  })
  public async getWarehouseDoorsByWarehouseIds(
    @Param() payload: GetGetWarehouseDoorsByWarehouseIdsParamDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    const warehouseIds = [request.id];
    return await this.warehouseDoorService.getWarehouseDoorsByWarehouseIds(
      warehouseIds,
    );
  }

  @MessagePattern(`${NATS_WAREHOUSE}.get_warehouse_doors_by_warehouse_ids`)
  public async getWarehouseDoorsByWarehouseIdsTcp(
    @Body() payload: GetGetWarehouseDoorsByWarehouseIdsTcpDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseDoorService.getWarehouseDoorsByWarehouseIds(
      request.warehouseIds,
    );
  }
}
