import { Inject, Injectable } from '@nestjs/common';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { WarehouseDoorRepositoryInterface } from '@components/warehouse-door/interface/warehouse-door.repository.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { WarehouseDoorServiceInterface } from './interface/warehouse-door.service.interface';
import { In } from 'typeorm';
import { isEmpty } from 'lodash';
import { plainToInstance } from 'class-transformer';
import { WarehouseDoorResponseDto } from './dto/response/warehouse-door.response.dto';

@Injectable()
export class WarehouseDoorService implements WarehouseDoorServiceInterface {
  constructor(
    @Inject('WarehouseDoorRepositoryInterface')
    private readonly warehouseDoorRepository: WarehouseDoorRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  public async getWarehouseDoorById(id: number): Promise<any> {
    const result = await this.warehouseDoorRepository.findOneWithRelations({
      where: { id },
      relations: ['warehouse'],
    });

    if (!result) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.WAREHOUSE_DOOR_NOT_FOUND'),
        )
        .build();
    }

    const dataReturn = plainToInstance(
      WarehouseDoorResponseDto,
      {
        ...result,
        name: result.id,
        warehouseId: result.warehouseId,
        warehouseName: result.warehouse?.name,
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(dataReturn)
      .build();
  }

  public async getWarehouseDoorsByWarehouseIds(
    warehouseIds: number[],
  ): Promise<any> {
    const results = await this.warehouseDoorRepository.findWithRelations({
      where: {
        warehouseId: In(warehouseIds),
      },
      relations: ['warehouse'],
    });

    if (isEmpty(results)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.WAREHOUSE_DOOR_NOT_FOUND'),
        )
        .build();
    }

    const dataReturn = plainToInstance(
      WarehouseDoorResponseDto,
      results.map((door) => ({
        ...door,
        name: door.id,
        warehouseId: door.warehouseId,
        warehouseName: door.warehouse?.name,
      })),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
