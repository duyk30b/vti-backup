import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WarehouseDoorEntity } from '@entities/warehouse-door/warehouse-door.entity';
import { WarehouseDoorRepository } from '@repositories/warehouse-door.repository';
import { WarehouseDoorService } from './warehouse-door.service';
import { WarehouseDoorController } from './warehouse-door.controller';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      WarehouseDoorEntity,
    ]),
  ],
  providers: [
    {
      provide: 'WarehouseDoorRepositoryInterface',
      useClass: WarehouseDoorRepository,
    },
    {
      provide: 'WarehouseDoorServiceInterface',
      useClass: WarehouseDoorService,
    },
  ],
  exports: [
    {
      provide: 'WarehouseDoorRepositoryInterface',
      useClass: WarehouseDoorRepository,
    },
    {
      provide: 'WarehouseDoorServiceInterface',
      useClass: WarehouseDoorService,
    },
  ],
  controllers: [WarehouseDoorController],
})
export class WarehouseDoorModule {}
