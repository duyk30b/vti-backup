export interface WarehouseDoorServiceInterface {
  getWarehouseDoorById(id: number): Promise<any>;
  getWarehouseDoorsByWarehouseIds(warehouseIds: number[]): Promise<any>;
}
