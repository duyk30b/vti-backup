import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WarehouseDoorEntity } from '@entities/warehouse-door/warehouse-door.entity';
import { WarehouseDoorDesignRequestDto } from '@components/warehouse/dto/request/update-warehouse-design.request.dto';

export interface WarehouseDoorRepositoryInterface
  extends BaseInterfaceRepository<WarehouseDoorEntity> {
  createEntity(
    warehouseId: number,
    request: WarehouseDoorDesignRequestDto
  ): WarehouseDoorEntity;
}
