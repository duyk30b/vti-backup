export interface ProduceServiceInterface {
  getListWorkCenter(request: any): Promise<any>;
  getWorkCenterById(id: number, baseInfo?: boolean): Promise<any>;
}
