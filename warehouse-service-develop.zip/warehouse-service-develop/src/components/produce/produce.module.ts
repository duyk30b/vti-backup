import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ProduceService } from './produce.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    {
      provide: 'ProduceServiceInterface',
      useClass: ProduceService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'ProduceServiceInterface',
      useClass: ProduceService,
    },
  ],
  controllers: [],
})
export class ProduceModule {}
