import { NATS_PRODUCE } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { ProduceServiceInterface } from './interface/produce.service.interface';

@Injectable()
export class ProduceService implements ProduceServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}
  async getListWorkCenter(request: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.work_center_list`,
      request,
    );
    if (response.statusCode === ResponseCodeEnum.SUCCESS) {
      return response.data.items;
    } else return [];
  }

  async getWorkCenterById(id: number, baseInfo?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.work_center_detail`,
      {
        id,
        baseInfo,
      },
    );
    if (response.statusCode === ResponseCodeEnum.SUCCESS) {
      return response.data;
    } else return [];
  }
}
