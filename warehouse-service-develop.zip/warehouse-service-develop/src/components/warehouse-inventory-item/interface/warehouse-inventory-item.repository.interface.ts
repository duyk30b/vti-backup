import { CreateInventoryItemDto } from '@components/inventory/dto/request/create-inventory-item.request.dto';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WarehouseInventoryItem } from '@entities/warehouse-inventory-item/warehouse-inventory-item.entity';

export interface WarehouseInventoryItemRepositoryInterface
  extends BaseInterfaceRepository<WarehouseInventoryItem> {
  createEntity(
    request: CreateInventoryItemDto,
    newItem: any,
  ): WarehouseInventoryItem;
  getWarehouseInventoryItems(
    inventoryId: number,
    itemIds: number[],
  ): Promise<any>;
}
