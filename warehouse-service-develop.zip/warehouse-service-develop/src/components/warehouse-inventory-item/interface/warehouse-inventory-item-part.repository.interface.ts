import { ItemInventory } from '@components/inventory/dto/request/create-inventory.request.dto';
import { GetItemInventoryQuantityRequestDto } from '@components/inventory/dto/request/get-item-inventory-quantity.request.dto';
import { GetListItemInventoryRequestDto } from '@components/inventory/dto/request/get-list-item-inventory.request.dto';
import { GetLocatorsByInventoryIdRequestDto } from '@components/inventory/dto/request/get-locators-by-inventory-id.request.dto';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { Inventory } from '@entities/inventory/inventory.entity';
import { WarehouseInventoryItemPartEntity } from '@entities/warehouse-inventory-item/warehouse-inventory-item-part.entity';

export interface WarehouseInventoryItemPartRepositoryInterface
  extends BaseInterfaceRepository<WarehouseInventoryItemPartEntity> {
  createEntity(request: ItemInventory): WarehouseInventoryItemPartEntity;
  getWarehouseInventoryItemPartByItems(
    request: GetItemInventoryQuantityRequestDto,
  ): Promise<any>;
  getWarehouseInventoryItemParts(
    request: GetItemInventoryQuantityRequestDto,
  ): Promise<any>;
  getListItemInventory(
    request: GetListItemInventoryRequestDto,
    filterItemIds?: number[],
  ): Promise<any>;
  getWarehouseInventoryItemPartByIds(inventoryIds: number[]): Promise<any>;
}
