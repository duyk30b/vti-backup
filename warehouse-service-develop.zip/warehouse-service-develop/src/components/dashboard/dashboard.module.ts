import { WarehouseRepository } from './../../repositories/warehouse.repository';
import { Warehouse } from './../../entities/warehouse/warehouse.entity';
import { SaleService } from '@components/sale/sale.service';
import { WarehouseTransfer } from '@entities/warehouse-transfer/warehouse-transfer.entity';
import { WarehouseExportProposalEntity } from './../../entities/warehouse-export-proposal/warehouse-export-proposal.entity';
import { DashboardService } from './dashboard.service';
import { WarehouseExportProposalRepository } from './../../repositories/warehouse-export-proposal.repository';

import { Global, Module } from '@nestjs/common';
import { DashboardController } from './dashboard.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WarehouseTransferRepository } from '@repositories/warehouse-transfer.repository';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([
      WarehouseExportProposalEntity,
      WarehouseTransfer,
      Warehouse,
    ]),
  ],
  providers: [
    {
      provide: 'WarehouseExportProposalRepositoryInterface',
      useClass: WarehouseExportProposalRepository,
    },
    {
      provide: 'WarehouseTransferRepositoryInterface',
      useClass: WarehouseTransferRepository,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
    {
      provide: 'DashboardServiceInterface',
      useClass: DashboardService,
    },
  ],
  controllers: [DashboardController],
})
export class DashboardModule {}
