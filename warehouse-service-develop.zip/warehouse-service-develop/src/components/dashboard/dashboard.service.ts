import { PagingResponse } from './../../utils/paging.response';
import { WarehouseResponse } from './../warehouse/dto/response/warehouse.response.dto';
import { plainToInstance } from 'class-transformer';
import { isEmpty } from 'class-validator';
import { WarehouseRepositoryInterface } from './../warehouse/interface/warehouse.repository.interface';
import { GetListWarehouseRequestDto } from './../warehouse/dto/request/get-list-warehouse.request.dto';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { WarehouseTransferRepositoryInterface } from '@components/warehouse-transfer/interface/warehouse-transfer.repository.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { WarehouseExportProposalRepositoryInterface } from '@components/warehouse-export-proposal/interface/warehouse-export-proposal.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ReportTotalOrderRequestDto } from './dto/request/report-total-order.request.dto';
import { DashboardServiceInterface } from './interface/dashboard.service.interface';

@Injectable()
export class DashboardService implements DashboardServiceInterface {
  constructor(
    private readonly i18n: I18nRequestScopeService,

    @Inject('WarehouseExportProposalRepositoryInterface')
    private readonly warehouseExportProposalRepository: WarehouseExportProposalRepositoryInterface,

    @Inject('WarehouseTransferRepositoryInterface')
    private readonly warehouseTransferRepository: WarehouseTransferRepositoryInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('SaleServiceInterface')
    private readonly saleService: SaleServiceInterface,
  ) {}

  async reportTotalOrder(request: ReportTotalOrderRequestDto): Promise<any> {
    const [
      totalWarehouseExportProposal,
      totalWarehouseTransfer,
      totalOrderSale,
    ] = await Promise.all([
      this.warehouseExportProposalRepository.reportTotalOrder(request),
      this.warehouseTransferRepository.reportTotalOrder(request),
      this.saleService.reportTotalOrder(request),
    ]);
    const response = {
      totalWarehouseExportProposal,
      totalWarehouseTransfer,
      totalSaleOrderExport: totalOrderSale?.totalSaleOrderExport || 0,
      totalPurchasedOrderImport: totalOrderSale?.totalPurchasedOrderImport || 0,
    };
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getListWarehouse(request: GetListWarehouseRequestDto): Promise<any> {
    const { result, count } = await this.warehouseRepository.getList(request);
    result.forEach((r) => {
      r.warehouseTypeSetting = !isEmpty(r.warehouseTypeSettings)
        ? r.warehouseTypeSettings[0]
        : null;
    });
    const response = plainToInstance(WarehouseResponse, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
