import { GetListWarehouseRequestDto } from './../../warehouse/dto/request/get-list-warehouse.request.dto';
import { ReportTotalOrderRequestDto } from './../dto/request/report-total-order.request.dto';
export interface DashboardServiceInterface {
  reportTotalOrder(request: ReportTotalOrderRequestDto): Promise<any>;
  getListWarehouse(request: GetListWarehouseRequestDto): Promise<any>;
}
