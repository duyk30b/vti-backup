import { GetListWarehouseRequestDto } from './../warehouse/dto/request/get-list-warehouse.request.dto';
import { Controller, Get, Inject, Query } from '@nestjs/common';
import { ReportTotalOrderRequestDto } from './dto/request/report-total-order.request.dto';
import { DashboardServiceInterface } from './interface/dashboard.service.interface';
import { isEmpty } from 'lodash';
@Controller('dashboard')
export class DashboardController {
  constructor(
    @Inject('DashboardServiceInterface')
    private readonly dashboardService: DashboardServiceInterface,
  ) {}

  @Get('orders/total')
  public async reportTotalOrder(
    @Query() query: ReportTotalOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.dashboardService.reportTotalOrder(request);
  }

  @Get('warehouse/list')
  public async getListWarehouse(
    @Query() query: GetListWarehouseRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.dashboardService.getListWarehouse(request);
  }
}
