import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { TemplateShelfEntity } from '@entities/template-shelf/template-shelf.entity';
import { GetListShelfRequestDto } from '../dto/request/get-list-shelf.request.dto';

export interface TemplateShelfRepositoryInterface
  extends BaseInterfaceRepository<TemplateShelfEntity> {
  createEntity(body: any): TemplateShelfEntity;
  updateEntity(
    entity: TemplateShelfEntity,
    request: any,
  ): TemplateShelfEntity;
  getList(request: GetListShelfRequestDto): Promise<any>;
  detail(request: number): Promise<any>;
}
