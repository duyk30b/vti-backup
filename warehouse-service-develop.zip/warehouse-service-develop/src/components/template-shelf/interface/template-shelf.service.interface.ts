import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateShelfDto } from '../dto/request/create-shelf.request.dto';
import { DeleteShelfDto } from '../dto/request/delete-shelf.request.dto';
import { GetListShelfRequestDto } from '../dto/request/get-list-shelf.request.dto';
import { UpdateShelfDto } from '../dto/request/update-shelf.request.dto';

export interface TemplateShelfServiceInterface {
  create(payload: CreateShelfDto): Promise<ResponsePayload<any>>;
  update(payload: UpdateShelfDto): Promise<ResponsePayload<any>>;
  detail(id: number): Promise<ResponsePayload<any>>;
  delete(id: DeleteShelfDto): Promise<ResponsePayload<any>>;
  deleteMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  getList(payload: GetListShelfRequestDto): Promise<ResponsePayload<any>>;
}
