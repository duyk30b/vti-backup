import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { isEmpty } from 'lodash';
import { CreateShelfDto } from './dto/request/create-shelf.request.dto';
import { DeleteShelfDto } from './dto/request/delete-shelf.request.dto';
import { GetDetailShelfRequestDto } from './dto/request/get-detail-shelf.request.dto';
import { GetListShelfRequestDto } from './dto/request/get-list-shelf.request.dto';
import {
  UpdateShelfBodyDto,
  UpdateShelfDto,
} from './dto/request/update-shelf.request.dto';
import { TemplateShelfServiceInterface } from './interface/template-shelf.service.interface';
import {
  CREATE_TEMPLATE_SHELF_PERMISSION,
  UPDATE_TEMPLATE_SHELF_PERMISSION,
  DELETE_TEMPLATE_SHELF_PERMISSION,
  DETAIL_TEMPLATE_SHELF_PERMISSION,
  LIST_TEMPLATE_SHELF_PERMISSION,
} from '@utils/permissions/template-shelf';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';

@Controller('template-shelfs')
export class TemplateShelfController {
  constructor(
    @Inject('TemplateShelfServiceInterface')
    private readonly templateShelfService: TemplateShelfServiceInterface,
  ) {}

  @PermissionCode(CREATE_TEMPLATE_SHELF_PERMISSION.code)
  // @MessagePattern('create_template_shelf')
  @Post('/')
  @ApiOperation({
    tags: ['Warehouse', 'Template shelfs'],
    summary: 'Create new template shelf',
    description: 'Tạo mới kệ mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  public async createShelf(@Body() payload: CreateShelfDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateShelfService.create(request);
  }

  @PermissionCode(UPDATE_TEMPLATE_SHELF_PERMISSION.code)
  // @MessagePattern('update_template_shelf')
  @Put('/:id')
  @ApiOperation({
    tags: ['Warehouse', 'Template shelfs'],
    summary: 'Update Template shelf',
    description: 'Cập nhật kệ mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async updateItem(
    @Param('id', new ParseIntPipe()) id,
    @Body() body: UpdateShelfBodyDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = Number(id);
    return await this.templateShelfService.update(request);
  }

  @PermissionCode(LIST_TEMPLATE_SHELF_PERMISSION.code)
  // @MessagePattern('get_list_template_shelf')
  @Get('')
  @ApiOperation({
    tags: ['Warehouse', 'Template Shelfs'],
    summary: 'List Template Shelf',
    description: 'Danh sách Thông tin kệ mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: null,
  })
  public async getList(@Query() query: GetListShelfRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.templateShelfService.getList(request);
  }

  @PermissionCode(DETAIL_TEMPLATE_SHELF_PERMISSION.code)
  // @MessagePattern('detail_template_shelf')
  @Get('/:id')
  @ApiOperation({
    tags: ['Warehouse', 'Template shelfs'],
    summary: 'Detail Template Shelf',
    description: 'Thông tin kệ mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  public async detail(@Param() param: GetDetailShelfRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.templateShelfService.detail(request.id);
  }

  @PermissionCode(DELETE_TEMPLATE_SHELF_PERMISSION.code)
  // @MessagePattern('delete_template_shelf')
  @Delete('/:id')
  @ApiOperation({
    tags: ['Warehouse', 'Template Shelfs'],
    summary: 'Delete Template Shelf',
    description: 'Xóa Thông tin kệ mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
  })
  public async delete(@Param() param: DeleteShelfDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateShelfService.delete(request);
  }

  @PermissionCode(DELETE_TEMPLATE_SHELF_PERMISSION.code)
  // @MessagePattern('delete_template_shelf_multiple')
  @Delete('/multiple')
  @ApiOperation({
    tags: ['Warehouse', 'Template Shelfs'],
    summary: 'Delete multiple Template Shelf',
    description: 'Xóa nhiều thông tin kệ mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
  })
  public async deleteMultiple(@Query() query: DeleteMultipleDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.templateShelfService.deleteMultiple(request);
  }
}
