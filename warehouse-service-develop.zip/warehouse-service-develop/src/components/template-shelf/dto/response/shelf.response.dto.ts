import { AbstractWarehouseSpaceDataResponseDto } from "@components/warehouse/dto/response/abstract-warehouse-space-data.response.dto";
import { ApiProperty } from "@nestjs/swagger";
import { Expose, Type } from "class-transformer";

class TemplateShelfFloor extends AbstractWarehouseSpaceDataResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  templateShelfTemplateShelfFloorId: number;
}

export class ShelfResponseDto extends AbstractWarehouseSpaceDataResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  totalTemplateShelfFloors: number;

  @ApiProperty()
  @Expose()
  @Type(() => TemplateShelfFloor)
  templateShelfFloors: TemplateShelfFloor[];

  @ApiProperty()
  @Expose()
  createdAt: string;
}