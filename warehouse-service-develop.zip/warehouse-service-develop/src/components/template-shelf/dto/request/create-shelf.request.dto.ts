import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import {
  UnitMeasuresRequest,
  UnitWeightRequest,
} from '@components/warehouse/dto/request/unit-measures.request.dto';
import { BaseDto } from '@core/dto/base.dto';
import { CreateShelfFloorRequestDto } from '@components/template-shelf-floor/dto/request/create-shelf-floor.request.dto';

export class CreateShelfDto extends BaseDto {
  @ApiProperty({ example: 'Kệ A', description: 'Tên kệ' })
  @IsNotEmpty()
  @MaxLength(255)
  @IsString()
  name: string;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Chiều Dài' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  long: UnitMeasuresRequest;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Chiều rộng' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  width: UnitMeasuresRequest;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Chiều Cao' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  height: UnitMeasuresRequest;

  @ApiProperty({ example: { value: 100, unit: 1 }, description: 'Tải trọng' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitWeightRequest)
  weightLoad: UnitWeightRequest;

  @ApiProperty({ example: CreateShelfFloorRequestDto, description: 'Tầng' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => CreateShelfFloorRequestDto)
  floors: CreateShelfFloorRequestDto[]
}
