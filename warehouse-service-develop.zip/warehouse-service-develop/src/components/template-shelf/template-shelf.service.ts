import { ResponseCodeEnum } from '@constant/response-code.enum';
import { TemplateShelfEntity } from '@entities/template-shelf/template-shelf.entity';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { stringFormat } from '@utils/object.util';
import { plainToInstance } from 'class-transformer';
import { isEmpty } from 'class-validator';
import { isEmpty as isEmpty2 } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In, Not } from 'typeorm';
import { CreateShelfDto } from './dto/request/create-shelf.request.dto';
import { GetListShelfRequestDto } from './dto/request/get-list-shelf.request.dto';
import { UpdateShelfDto } from './dto/request/update-shelf.request.dto';
import { ShelfResponseDto } from './dto/response/shelf.response.dto';
import { TemplateShelfRepositoryInterface } from './interface/template-shelf.repository.interface';
import { TemplateShelfServiceInterface } from './interface/template-shelf.service.interface';
import { TemplateShelfFloorServiceInterface } from '@components/template-shelf-floor/interface/template-shelf-floor.service.interface';
import { TemplateShelfTemplateShelfFloorRepositoryInterface } from '@components/template-shelf-template-shelf-floor/interface/template-shelf-template-shelf-floor.repository.interface';
import { TemplateSectorTemplateShelfRepositoryInterface } from '@components/template-sector-template-shelf/interface/template-sector-template-shelf.repository.interface';
import { TemplateShelfFloorRepositoryInterface } from '@components/template-shelf-floor/interface/template-shelf-floor.repository.interface';
import { DeleteShelfDto } from './dto/request/delete-shelf.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

@Injectable()
export class TemplateShelfService implements TemplateShelfServiceInterface {
  constructor(
    @Inject('TemplateShelfRepositoryInterface')
    private readonly templateShelfRepository: TemplateShelfRepositoryInterface,

    @Inject('TemplateShelfTemplateShelfFloorRepositoryInterface')
    private readonly templateShelfTemplateShelfFloorRepository: TemplateShelfTemplateShelfFloorRepositoryInterface,

    @Inject('TemplateSectorTemplateShelfRepositoryInterface')
    private readonly templateSectorTemplateShelfRepository: TemplateSectorTemplateShelfRepositoryInterface,

    @Inject('TemplateShelfFloorRepositoryInterface')
    private readonly templateShelfFloorRepository: TemplateShelfFloorRepositoryInterface,

    @Inject('TemplateShelfFloorServiceInterface')
    private readonly templateShelfFloorService: TemplateShelfFloorServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  public async create(request: CreateShelfDto): Promise<ResponsePayload<any>> {
    const newShelfEntity = await this.templateShelfRepository.createEntity(
      request,
    );
    return await this.save(newShelfEntity, request);
  }

  public async update(request: UpdateShelfDto): Promise<ResponsePayload<any>> {
    const shelf = await this.templateShelfRepository.findOneById(request.id);
    if (!shelf) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    return await this.save(shelf, request);
  }

  public async getList(
    request: GetListShelfRequestDto,
  ): Promise<ResponsePayload<any> | any> {
    const { data, total } = await this.templateShelfRepository.getList(request);
    const dataReturn = plainToInstance(ShelfResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async detail(id: number): Promise<ResponsePayload<any>> {
    const shelf = await this.templateShelfRepository.detail(id);
    if (isEmpty(shelf)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const response = plainToInstance(ShelfResponseDto, shelf, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async delete(request: DeleteShelfDto): Promise<ResponsePayload<any>> {
    try {
      const shelf = await this.templateShelfRepository.findOneById(request.id);
      if (!shelf) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const [
        deletedTemplateSectorTemplateShelfs,
        deletedTemplateShelfTemplateShelfFloors,
      ] = await Promise.all([
        this.templateSectorTemplateShelfRepository.findByCondition({
          templateShelfId: request.id,
        }),
        this.templateShelfTemplateShelfFloorRepository.findByCondition({
          templateShelfId: request.id,
        }),
      ]);

      if (deletedTemplateSectorTemplateShelfs?.length) {
        const deletedTemplateSectorTemplateShelfIds =
          deletedTemplateSectorTemplateShelfs.map((item) => item.id);
        await this.templateSectorTemplateShelfRepository.removeMany(
          deletedTemplateSectorTemplateShelfIds,
        );
      }

      if (deletedTemplateShelfTemplateShelfFloors?.length) {
        const deletedTemplateShelfTemplateShelfFloorIds =
          deletedTemplateShelfTemplateShelfFloors.map((item) => item.id);
        await this.templateShelfTemplateShelfFloorRepository.removeMany(
          deletedTemplateShelfTemplateShelfFloorIds,
        );
      }

      await this.templateShelfRepository.remove(request.id);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const templateShelfs = await this.templateShelfRepository.findByCondition({
      id: In(ids),
    });

    const templateShelfIds = templateShelfs.map(
      (templateShelf) => templateShelf.id,
    );
    if (templateShelfs.length !== ids.length) {
      ids.forEach((id) => {
        if (!templateShelfIds.includes(id)) failIdsList.push(id);
      });
    }

    const validIds = templateShelfs
      .filter((templateShelf) => !failIdsList.includes(templateShelf.id))
      .map((templateShelf) => templateShelf.id);

    try {
      if (!isEmpty(validIds)) {
        const [
          deletedTemplateSectorTemplateShelfs,
          deletedTemplateShelfTemplateShelfFloors,
        ] = await Promise.all([
          this.templateSectorTemplateShelfRepository.findByCondition({
            templateShelfId: In(validIds),
          }),
          this.templateShelfTemplateShelfFloorRepository.findByCondition({
            templateShelfId: In(validIds),
          }),
        ]);

        if (deletedTemplateSectorTemplateShelfs?.length) {
          const deletedTemplateSectorTemplateShelfIds =
            deletedTemplateSectorTemplateShelfs.map((item) => item.id);
          await this.templateSectorTemplateShelfRepository.removeMany(
            deletedTemplateSectorTemplateShelfIds,
          );
        }

        if (deletedTemplateShelfTemplateShelfFloors?.length) {
          const deletedTemplateShelfTemplateShelfFloorIds =
            deletedTemplateShelfTemplateShelfFloors.map((item) => item.id);
          await this.templateShelfTemplateShelfFloorRepository.removeMany(
            deletedTemplateShelfTemplateShelfFloorIds,
          );
        }

        await this.templateShelfRepository.removeMany(validIds);
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    if (isEmpty2(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  private async save(
    shelfEntity: TemplateShelfEntity,
    request: CreateShelfDto | UpdateShelfDto | any,
  ): Promise<any> {
    let templateShelfFloorIdsInShelf = [];
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const { name } = request;
      const isUpdate = shelfEntity.id !== undefined;

      const shelfName = await this.templateShelfRepository.findByCondition({
        name,
      });
      if (!isUpdate && shelfName.length) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.NAME_EXIST'),
        ).toResponse();
      }

      if (
        isUpdate &&
        request.name !== shelfEntity.name &&
        shelfName.length > 0
      ) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.NAME_EXIST'),
        ).toResponse();
      }

      if (isUpdate) {
        const templateShelfTemplateShelfFloorByShelfId =
          await this.templateShelfTemplateShelfFloorRepository.findByCondition({
            templateShelfId: shelfEntity.id,
          });
        await queryRunner.manager.remove(
          templateShelfTemplateShelfFloorByShelfId,
        );

        if (templateShelfTemplateShelfFloorByShelfId) {
          templateShelfFloorIdsInShelf =
            templateShelfTemplateShelfFloorByShelfId?.map(
              (item) => item.templateShelfFloorId,
            );
          const templateShelfFloorByIds =
            await this.templateShelfFloorRepository.findByCondition({
              id: In(templateShelfFloorIdsInShelf),
            });
          await queryRunner.manager.remove(templateShelfFloorByIds);
        }

        shelfEntity = this.templateShelfRepository.updateEntity(
          shelfEntity,
          request,
        );
      }

      const saveShelf = await queryRunner.manager.save(shelfEntity);

      const shelfFloorNames = request.floors?.map(
        (shelfFloor) => shelfFloor.name,
      );
      const templateShelfFloorByNames =
        await this.templateShelfFloorRepository.findByCondition({
          name: In(shelfFloorNames),
          id: Not(In(templateShelfFloorIdsInShelf)),
        });
      if (templateShelfFloorByNames?.length) {
        const existedNames = templateShelfFloorByNames
          .map((floor) => floor.name)
          .join(', ');
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            stringFormat(
              await this.i18n.translate('error.SHELF_FLOOR_NAME_EXIST'),
              existedNames,
            ),
          )
          .build();
      }
      const templateShelfFloorEntities = request.floors?.map(
        (templateShelfFloor) =>
          this.templateShelfFloorRepository.createEntity(templateShelfFloor),
      );
      const savedShelfFloors = await queryRunner.manager.save(
        templateShelfFloorEntities,
      );

      if (savedShelfFloors?.length) {
        const templateShelfTemplateShelfFloorEntities = savedShelfFloors.map(
          (templateShelfFloor) =>
            this.templateShelfTemplateShelfFloorRepository.createEntity({
              templateShelfFloorId: templateShelfFloor.id,
              templateShelfId: saveShelf.id,
            }),
        );
        await queryRunner.manager.save(templateShelfTemplateShelfFloorEntities);
      }
      await queryRunner.commitTransaction();

      return new ResponseBuilder({
        ...saveShelf,
        floors: savedShelfFloors,
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(err?.message || err)
        .build();
    } finally {
      await queryRunner.release();
    }
  }
}
