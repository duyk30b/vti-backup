import { TemplateShelfEntity } from '@entities/template-shelf/template-shelf.entity';
import { TemplateShelfTemplateShelfFloorEntity } from '@entities/template-shelf-template-shelf-floor/template-shelf-template-shelf-floor.entity';
import { TemplateSectorTemplateShelfEntity } from '@entities/template-sector-template-shelf/template-sector-template-shelf.entity';
import { TemplateShelfFloorEntity } from '@entities/template-shelf-floor/template-shelf-floor.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TemplateShelfRepository } from '@repositories/template-shelf.repository';
import { TemplateShelfController } from './template-shelf.controller';
import { TemplateShelfService } from './template-shelf.service';
import { TemplateShelfFloorService } from '@components/template-shelf-floor/template-shelf-floor.service';
import { TemplateSectorTemplateShelfRepository } from '@repositories/template-sector-template-shelf.repository';
import { TemplateShelfTemplateShelfFloorRepository } from '@repositories/template-shelf-template-shelf-floor.repository';
import { TemplateShelfFloorRepository } from '@repositories/template-shelf-floor.repository';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      TemplateShelfEntity,
      TemplateShelfTemplateShelfFloorEntity,
      TemplateSectorTemplateShelfEntity,
      TemplateShelfFloorEntity,
    ]),
  ],
  providers: [
    {
      provide: 'TemplateShelfServiceInterface',
      useClass: TemplateShelfService,
    },
    {
      provide: 'TemplateShelfFloorServiceInterface',
      useClass: TemplateShelfFloorService,
    },
    {
      provide: 'TemplateShelfRepositoryInterface',
      useClass: TemplateShelfRepository,
    },
    {
      provide: 'TemplateSectorTemplateShelfRepositoryInterface',
      useClass: TemplateSectorTemplateShelfRepository
    },
    {
      provide: 'TemplateShelfTemplateShelfFloorRepositoryInterface',
      useClass: TemplateShelfTemplateShelfFloorRepository,
    },
    {
      provide: 'TemplateShelfFloorRepositoryInterface',
      useClass: TemplateShelfFloorRepository,
    }
  ],
  exports: [
    {
      provide: 'TemplateShelfRepositoryInterface',
      useClass: TemplateShelfRepository,
    },
    {
      provide: 'TemplateShelfFloorServiceInterface',
      useClass: TemplateShelfFloorService,
    },
    {
      provide: 'TemplateSectorTemplateShelfRepositoryInterface',
      useClass: TemplateSectorTemplateShelfRepository
    },
    {
      provide: 'TemplateShelfTemplateShelfFloorRepositoryInterface',
      useClass: TemplateShelfTemplateShelfFloorRepository,
    },
    {
      provide: 'TemplateShelfFloorRepositoryInterface',
      useClass: TemplateShelfFloorRepository,
    }
  ],
  controllers: [TemplateShelfController],
})

export class TemplateShelfModule {}
