import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Inventory } from '@entities/inventory/inventory.entity';
import { InventoryController } from '@components/inventory/inventory.controller';
import { InventoryRepository } from '@repositories/inventory.repository';
import { InventoryService } from '@components/inventory/inventory.service';
import { Warehouse } from '@entities/warehouse/warehouse.entity';
import { ItemService } from '@components/item/item.service';
import { ItemModule } from '@components/item/item.module';
import { InventoryItemRepository } from '@repositories/inventory-item.repository';
import { WarehouseInventoryItem } from '@entities/warehouse-inventory-item/warehouse-inventory-item.entity';
import { WarehouseRepository } from '@repositories/warehouse.repository';
import { WarehouseShelfFloorRepository } from '@repositories/warehouse-shelf-floor.repository';
import { WarehouseShelfFloorEntity } from '../../entities/warehouse-shelf-floor/warehouse-shelf-floor.entity';
import { ConfigService } from '@config/config.service';
import { ClientProxyFactory } from '@nestjs/microservices';
import { WarehouseInventoryItemRepository } from '@repositories/warehouse-inventory-items.repository';
import { WarehouseInventoryItemPartRepository } from '@repositories/warehouse-inventory-items-part.repository';
import { WarehouseInventoryItemPartEntity } from '@entities/warehouse-inventory-item/warehouse-inventory-item-part.entity';
import { WarehouseShelfRepository } from '@repositories/warehouse-shelf.repository';
import { WarehouseSectorRepository } from '@repositories/warehouse-sector.repository';
import { WarehouseShelfEntity } from '@entities/warehouse-shelf/warehouse-shelf.entity';
import { WarehouseSectorEntity } from '@entities/warehouse-sector/warehouse-sector.entity';
import { WarehouseLayoutModule } from '@components/warehouse-layout/warehouse-layout.module';
import { WarehouseLayoutService } from '@components/warehouse-layout/warehouse-layout.service';
import { CheckPointExternalDataImport } from './import/check-point-external-data.import.helper';
import { ItemSnapshotInTypePeriodicWithInternalData } from './item-snapshot/item-snapshot-in-type-periodic-with-internal-data.helper';
import { ItemSnapshotInTypePeriodicWithExternalData } from './item-snapshot/item-snapshot-in-type-periodic-with-external-data.helper';
import { ItemSnapshotInTypeSurpriseWithItems } from './item-snapshot/item-snapshot-in-type-surprise-with-items.helper';
import { ItemSnapshotInTypeSurpriseWithoutItems } from './item-snapshot/item-snapshot-in-type-surprise-without-items.helper';
import { ReportService } from '@components/report/report.service';
import { InventoryImpersonatorEntity } from '@entities/inventory/inventory-impersonator.entity';
import { InventoryImpersonatorRepository } from '@repositories/inventory-impersonator.repository';
import { WarehouseInventoryItemPartImport } from './import/warehouse-inventory-item-part.import.helper';
import { SnapshotDataPeriodicExternal } from './item-snapshot/snapshot-data-external.helper';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Inventory,
      Warehouse,
      WarehouseShelfEntity,
      WarehouseSectorEntity,
      WarehouseInventoryItem,
      WarehouseShelfFloorEntity,
      WarehouseInventoryItemPartEntity,
      InventoryImpersonatorEntity,
    ]),
    ItemModule,
    WarehouseLayoutModule,
  ],
  providers: [
    {
      provide: 'InventoryRepositoryInterface',
      useClass: InventoryRepository,
    },
    {
      provide: 'InventoryImpersonatorRepositoryInterface',
      useClass: InventoryImpersonatorRepository,
    },
    {
      provide: 'WarehouseShelfFloorRepositoryInterface',
      useClass: WarehouseShelfFloorRepository,
    },
    {
      provide: 'WarehouseShelfRepositoryInterface',
      useClass: WarehouseShelfRepository,
    },
    {
      provide: 'WarehouseSectorRepositoryInterface',
      useClass: WarehouseSectorRepository,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'InventoryItemRepositoryInterface',
      useClass: InventoryItemRepository,
    },
    {
      provide: 'WarehouseInventoryItemRepositoryInterface',
      useClass: WarehouseInventoryItemRepository,
    },
    {
      provide: 'WarehouseInventoryItemPartRepositoryInterface',
      useClass: WarehouseInventoryItemPartRepository,
    },
    {
      provide: 'InventoryServiceInterface',
      useClass: InventoryService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseLayoutServiceInterface',
      useClass: WarehouseLayoutService,
    },
    {
      provide: 'CheckPointExternalDataImport',
      useClass: CheckPointExternalDataImport,
    },
    {
      provide: 'SnapshotDataPeriodicExternal',
      useClass: SnapshotDataPeriodicExternal,
    },
    {
      provide: 'ItemSnapshotInTypePeriodicWithExternalData',
      useClass: ItemSnapshotInTypePeriodicWithExternalData,
    },
    {
      provide: 'ItemSnapshotInTypePeriodicWithInternalData',
      useClass: ItemSnapshotInTypePeriodicWithInternalData,
    },
    {
      provide: 'ItemSnapshotInTypeSurpriseWithItems',
      useClass: ItemSnapshotInTypeSurpriseWithItems,
    },
    {
      provide: 'ItemSnapshotInTypeSurpriseWithoutItems',
      useClass: ItemSnapshotInTypeSurpriseWithoutItems,
    },
    {
      provide: 'ReportServiceInterface',
      useClass: ReportService,
    },
    {
      provide: 'WarehouseInventoryItemPartImport',
      useClass: WarehouseInventoryItemPartImport,
    },
    ConfigService,
  ],
  controllers: [InventoryController],
})
export class InventoryModule {}
