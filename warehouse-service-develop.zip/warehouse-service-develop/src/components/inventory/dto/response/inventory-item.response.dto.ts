import { Expose, Transform } from 'class-transformer';

export class InventoryItemResponse {
  @Expose()
  inventoryId: number;

  @Expose()
  warehouseId: number;

  @Expose()
  locatorId: number;

  @Expose()
  lotNumber: string;

  @Expose()
  itemId: number;

  @Expose()
  @Transform((data) => Number(data.value))
  planQuantity: number;

  @Expose()
  @Transform((data) => Number(data.value))
  actualQuantity: number;
}
