import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';

class Warehouse {
  @ApiProperty({ description: 'ID của kho' })
  @Expose()
  id: number;

  @ApiProperty({ description: 'tên của kho' })
  @Expose()
  name: string;

  @ApiProperty({ description: 'code của kho' })
  @Expose()
  code: string;
}

export class InventoryHistoryResponseDto {
  @ApiProperty({ description: 'ID của lệnh kiểm kê' })
  @Expose()
  id: number;

  @ApiProperty({ description: 'tên của lệnh kiểm kê' })
  @Expose()
  name: string;

  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  executionDay: string;

  @ApiProperty({ description: 'code của lệnh kiểm kê' })
  @Expose()
  code: string;

  @ApiProperty({ description: 'type của lệnh kiểm kê' })
  @Expose()
  type: number;

  @ApiProperty({ description: 'kho kiểm kê', type: Warehouse })
  @Expose()
  @Type(() => Warehouse)
  warehouse: Warehouse;
}
