import { ApiProperty } from "@nestjs/swagger";
import { Expose, Type } from "class-transformer";

class UnitResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ItemResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  @Type(() => UnitResponseDto)
  itemUnit: UnitResponseDto;
}

class WarehouseResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;
}

export class GetItemInventoryPartsResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  @Type(() => ItemResponse)
  item: ItemResponse[];

  @ApiProperty()
  @Expose()
  @Type(() => WarehouseResponse)
  warehouse: WarehouseResponse;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  locatorId: number;

  @ApiProperty()
  @Expose()
  locatorCode: string;

  @ApiProperty()
  @Expose()
  planQuantity: number;
}