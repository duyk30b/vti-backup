import { InventoryStatusEnum } from '@components/inventory/inventory.contant';
import { ItemResponseDto } from '@components/item/dto/response/item.dto.response';
import { LocatorResponseDto } from '@components/warehouse-layout/dto/response/locator.response.dto';
import { WarehouseImportResponse } from '@components/warehouse/dto/response/warehouse-import.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';

class Lot {
  @Expose()
  lotNumber: string;

  @Expose()
  date: string;

  @Expose()
  planQuantity: number;

  @Expose()
  actualQuantity: number;

  @Expose()
  diffQuantity: number;
}

class Location {
  @Expose()
  @Type(() => Lot)
  lots: Lot[];
}

class ItemUnit {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;
}

class LotPartInventory {
  @Expose()
  lotNumber: string;

  @Expose()
  quantity: number;

  @Expose({ name: 'mfg' })
  date: string;
}

export class ItemDetail {
  @Expose()
  itemId: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  @Type(() => ItemUnit)
  itemUnit: ItemUnit;
}

class ItemPart {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  warehouseName: string;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  locatorId: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  @Type(() => ItemDetail)
  item: ItemDetail;

  @Expose()
  @Type(() => LotPartInventory)
  lots: LotPartInventory[];
}

class WarehousItemResponse extends ItemResponseDto {
  @ApiProperty()
  @Expose()
  warehouseName: string;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  location: string;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @Expose()
  locatorId: number;

  @ApiProperty({ type: LocatorResponseDto })
  @Expose()
  @Type(() => LocatorResponseDto)
  locators: LocatorResponseDto[];

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  date: string;
}
class Impersonator {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  username: string;

  @ApiProperty()
  @Expose()
  fullName: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class UserResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  username: string;

  @ApiProperty()
  @Expose()
  fullName: string;

  @ApiProperty()
  @Expose()
  code: string;
}

export class InventoryResponse {
  @Expose()
  id: number;

  @Expose()
  createdByUserId: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  description: string;

  @Expose()
  approverId: number;

  @Expose()
  executeFrom: string;

  @Expose()
  executeTo: string;

  @Expose()
  checkPointDate: string;

  @Expose()
  checkPointDataType: number;

  @Expose()
  isSelectedItems: boolean;

  @Expose()
  isSnapShot: boolean;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty()
  @Expose()
  confirmedAt: string;

  @ApiProperty()
  @Expose()
  approvedAt: string;

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  confirmer: UserResponseDto;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  approver: UserResponseDto;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdByUser: UserResponseDto;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  updatedBy: UserResponseDto;

  @ApiProperty({ type: Impersonator })
  @Expose()
  @Type(() => Impersonator)
  impersonators: Impersonator[];

  @Expose()
  @Transform(
    ({ value }) => {
      switch (value) {
        case InventoryStatusEnum.CREATED:
          return 1; // May be created
        case InventoryStatusEnum.CONFIRMED:
          return 2;
        case InventoryStatusEnum.REJECT:
          return 3;
        case InventoryStatusEnum.COMPLETE:
          return 4;
        case InventoryStatusEnum.IN_PROGRESS:
          return 5;
        default:
          return 0;
      }
    },
    { toClassOnly: true },
  )
  status: number;

  @Expose()
  type: number;

  @Expose()
  locatorId: number;

  @Expose()
  @Type(() => WarehouseImportResponse)
  warehouses: WarehouseImportResponse[];

  @Expose()
  @Type(() => WarehouseImportResponse)
  warehouse: WarehouseImportResponse;

  @Expose()
  @Type(() => WarehousItemResponse)
  warehouseItems: WarehousItemResponse[];

  @ApiProperty({ type: LocatorResponseDto })
  @Expose()
  @Type(() => LocatorResponseDto)
  locator: LocatorResponseDto;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @Expose()
  @Type(() => ItemPart)
  items: ItemPart[];
}
