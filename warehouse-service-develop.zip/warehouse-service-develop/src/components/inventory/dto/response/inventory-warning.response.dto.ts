import { Expose, Type } from 'class-transformer';

class WarehouseTypes {
  @Expose()
  id: number;

  @Expose()
  name: string;
}

export class WarningResponse {
  @Expose()
  id: number;

  @Expose()
  itemId: number;

  @Expose()
  itemName: string;

  @Expose()
  itemCode: string;

  @Expose()
  dayExpire: number;

  @Expose()
  quantityExpire: number;

  @Expose()
  itemTypeId: number;

  @Expose()
  itemTypeName: string;

  @Expose()
  itemGroupId: number;

  @Expose()
  itemGroupName: string;

  @Expose()
  itemUnitId: number;

  @Expose()
  itemUnitName: string;

  @Expose()
  warehouseId: number;

  @Expose()
  warehouseName: string;

  @Expose()
  warehouseSectorName: string;

  @Expose()
  warehouseShelfName: string;

  @Expose()
  warehouseShelfFloorId: number;

  @Expose()
  warehouseShelfFloorName: string;

  @Expose()
  warehouseCode: string;

  @Expose()
  createdAt: string;

  @Expose()
  quantity: number;

  @Expose()
  expireDate: string;

  @Expose()
  @Type(() => WarehouseTypes)
  warehouseTypes: WarehouseTypes[];
}
