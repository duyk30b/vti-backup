import { BaseDto } from '@core/dto/base.dto';
import { Expose, Type } from 'class-transformer';

class WarehouseDto {
  @Expose()
  id: number;
  @Expose()
  code: string;
  @Expose()
  name: string;
}

class LocatorDto {
  @Expose()
  id: number;
  @Expose()
  code: string;
  @Expose()
  name: string;
}

export class GetWaringListResponseDto extends BaseDto {
  @Expose()
  id: number;

  @Expose()
  itemId: number;

  @Expose()
  itemCode: string;

  @Expose()
  itemName: string;

  @Expose()
  itemUnitName: string;

  @Expose()
  @Type(() => WarehouseDto)
  warehouse: WarehouseDto;

  @Expose()
  @Type(() => LocatorDto)
  locator: LocatorDto;

  @Expose()
  lotNumber: string;

  @Expose()
  quantity: number;

  @Expose()
  storageDate: Date;

  @Expose()
  expireDate: Date;
}
