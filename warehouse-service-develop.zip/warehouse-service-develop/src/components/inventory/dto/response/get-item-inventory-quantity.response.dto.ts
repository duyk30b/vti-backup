import { ApiProperty } from "@nestjs/swagger";
import { Expose, Type } from "class-transformer";

class UnitResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ItemResponseDto {
  @ApiProperty()
  @Expose({ name: 'itemId' })
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  @Type(() => UnitResponseDto)
  itemUnit: UnitResponseDto;
}

class LotResponseDto {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  warehouseName: string;

  @ApiProperty()
  @Expose()
  warehouseCode: string;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  locatorId: number;

  @ApiProperty()
  @Expose()
  locatorCode: string;

  @ApiProperty()
  @Expose()
  executeDate: Date;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  importedQuantityFromCheckPointToExecuteDate: number;
  
  @ApiProperty()
  @Expose()
  exportedQuantityFromCheckPointToExecuteDate: number;
  
  @ApiProperty()
  @Expose()
  inventoryQuantityAtExecuteDate: number;
  
  @ApiProperty()
  @Expose()
  actualInventoryQuantity: number;
  
  @ApiProperty()
  @Expose()
  importedQuantityFromStartExecute: number;
  
  @ApiProperty()
  @Expose()
  exportedQuantityFromStartExecute: number;
  
  @ApiProperty()
  @Expose()
  remainingQuantityAtCheckPoint: number;
  
  @ApiProperty()
  @Expose()
  actualRemainingQuantityAtCheckPoint: number;
  
  @ApiProperty()
  @Expose()
  excessQuantity: number;
  
  @ApiProperty()
  @Expose()
  missingQuantity: number;
}

export class GetItemInventoryQuantityResponseDto {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  warehouseName: string;

  @ApiProperty()
  @Expose()
  warehouseCode: string;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  importedQuantityFromCheckPointToExecuteDate: number;
  
  @ApiProperty()
  @Expose()
  exportedQuantityFromCheckPointToExecuteDate: number;
  
  @ApiProperty()
  @Expose()
  inventoryQuantityAtExecuteDate: number;
  
  @ApiProperty()
  @Expose()
  actualInventoryQuantity: number;
  
  @ApiProperty()
  @Expose()
  importedQuantityFromStartExecute: number;
  
  @ApiProperty()
  @Expose()
  exportedQuantityFromStartExecute: number;
  
  @ApiProperty()
  @Expose()
  remainingQuantityAtCheckPoint: number;
  
  @ApiProperty()
  @Expose()
  actualRemainingQuantityAtCheckPoint: number;
  
  @ApiProperty()
  @Expose()
  excessQuantity: number;
  
  @ApiProperty()
  @Expose()
  missingQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => LotResponseDto)
  lots: LotResponseDto[];
}