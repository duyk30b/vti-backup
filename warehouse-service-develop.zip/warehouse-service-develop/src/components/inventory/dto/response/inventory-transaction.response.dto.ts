import { InventoryStatusEnum } from '@components/inventory/inventory.contant';
import { ItemResponseDto } from '@components/item/dto/response/item.dto.response';
import { UserResponseDto } from '@components/user/dto/response/user.response.dto';
import { WarehouseImportResponse } from '@components/warehouse/dto/response/warehouse-import.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';

class WarehousItemResponse extends ItemResponseDto {
  @ApiProperty()
  @Expose()
  warehouseName: string;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;
}
export class InventoryTransactionResponse {
  @Expose()
  id: number;

  @Expose()
  createdByUserId: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  description: string;

  @Expose()
  factoryId: number;

  @Expose()
  approverId: number;

  @Expose()
  executionDay: string;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty()
  @Expose()
  confirmedAt: string;

  @ApiProperty()
  @Expose()
  approvedAt: string;

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  confirmer: UserResponseDto;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  approver: UserResponseDto;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdByUser: UserResponseDto;

  @Expose()
  @Transform(
    ({ value }) => {
      switch (value) {
        case InventoryStatusEnum.CREATED:
          return 1; // May be created
        case InventoryStatusEnum.CONFIRMED:
          return 2;
        case InventoryStatusEnum.REJECT:
          return 3;
        case InventoryStatusEnum.COMPLETE:
          return 4;
        case InventoryStatusEnum.IN_PROGRESS:
          return 5;
        default:
          return 0;
      }
    },
    { toClassOnly: true },
  )
  status: number;

  @Expose()
  @Type(() => WarehouseImportResponse)
  warehouse: WarehouseImportResponse;

  @Expose()
  @Type(() => WarehousItemResponse)
  warehouseItems: WarehousItemResponse[];
}
