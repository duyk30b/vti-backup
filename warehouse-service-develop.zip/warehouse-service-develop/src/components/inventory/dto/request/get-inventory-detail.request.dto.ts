import { IsInt, IsNotEmpty, IsOptional } from 'class-validator';
import { Expose, Transform } from 'class-transformer';
import { BaseDto } from './../../../../core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
export class GetInventoryDetailQueryDto extends BaseDto {
  @IsInt()
  @Transform((v) => +v.value)
  @IsOptional()
  warehouseId: number;

  @IsInt()
  @Transform((v) => +v.value)
  @IsOptional()
  locatorId: number;
}

export class GetInventoryDetailRequestDto extends GetInventoryDetailQueryDto {
  @ApiProperty()
  @Transform((v) => +v.value)
  @IsInt()
  id: number;
}
