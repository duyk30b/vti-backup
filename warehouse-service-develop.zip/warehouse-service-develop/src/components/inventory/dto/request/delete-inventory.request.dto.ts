import { IsInt, IsNotEmpty } from 'class-validator';

export class DeleteInventoryDto {
  @IsNotEmpty()
  @IsInt()
  userId: number;

  @IsNotEmpty()
  @IsInt()
  inventoryId: number;
}

class WarehouseId {
  @IsNotEmpty()
  @IsInt()
  id: number;
}
