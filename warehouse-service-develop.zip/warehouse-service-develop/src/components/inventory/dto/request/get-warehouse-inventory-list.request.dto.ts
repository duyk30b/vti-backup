import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';

export class GetWarehouseInventoryListQueryDto extends PaginationQuery {}

export class GetWarehouseInventoryListRequestDto extends GetWarehouseInventoryListQueryDto {
  @ApiProperty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
