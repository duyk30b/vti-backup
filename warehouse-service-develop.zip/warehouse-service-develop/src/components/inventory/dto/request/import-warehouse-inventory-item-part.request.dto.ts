import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsArray, IsNotEmpty } from 'class-validator';
export class File {
  filename: string;
  data: ArrayBuffer;
  encoding: string;
  mimetype: string;
  limit: boolean;
}
export class ImportWarehouseInventoryItemPartRequestDto extends BaseDto {
  @IsNotEmpty()
  // @Transform(({ value }) => JSON.parse(value))
  @IsArray()
  file: File[];
}
