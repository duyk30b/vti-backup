import { BaseDto } from '@core/dto/base.dto';
import { IsInt, IsNotEmpty } from 'class-validator';

export class UpdateInventoryStatusRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  userId: number;

  @IsNotEmpty()
  @IsInt()
  id: number;
}
