import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';

export class ApproveInventoryItemDto extends BaseDto {
  @IsInt()
  @IsNotEmpty()
  userId: number;

  @IsInt()
  @Transform((data) => Number(data.value))
  @IsNotEmpty()
  id: number;
}
