import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';

export class CreateInventoryItemBodyDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional()
  @IsNotEmpty()
  @IsInt()
  locatorId: number;

  @ArrayNotEmpty()
  @Type(() => ItemInventory)
  @ValidateNested()
  items: ItemInventory[];
}

class ItemInventory {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ArrayNotEmpty()
  @Type(() => ItemLotInventory)
  lots: ItemLotInventory[];
}
class ItemLotInventory {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MaxLength(20)
  lotNumber: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  quantity: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  date: string;
}

export class CreateInventoryItemDto extends CreateInventoryItemBodyDto {
  @IsNotEmpty()
  @IsInt()
  inventoryId: number;
}
