import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsNotEmpty, IsInt, IsString, IsOptional } from 'class-validator';
export class GetLocatorsByInventoryIdQuery extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsString()
  keyword: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsInt()
  warehouseId: number;
}

export class GetLocatorsByInventoryIdRequestDto extends GetLocatorsByInventoryIdQuery {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  inventoryId: number;
}
