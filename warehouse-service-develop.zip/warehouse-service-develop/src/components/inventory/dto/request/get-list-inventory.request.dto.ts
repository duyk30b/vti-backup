import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { Transform } from 'class-transformer';
import { IsEnum, IsOptional, IsNotEmpty, IsInt } from 'class-validator';
export class GetListInventoryRequestDto extends PaginationQuery {
  @IsNotEmpty()
  user: any;

  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsInt()
  excuteByUserId: number;
}
