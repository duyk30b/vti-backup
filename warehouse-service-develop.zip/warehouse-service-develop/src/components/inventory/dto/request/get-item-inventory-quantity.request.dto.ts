import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';

export class GetItemInventoryQuantityRequestDto extends PaginationQuery {
  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  id: number;
}
