import {
  InventoryCheckPointDataType,
  InventoryTypeEnum,
} from '@components/inventory/inventory.contant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsString,
  MaxLength,
  IsOptional,
  IsEnum,
  ValidateNested,
  ArrayUnique,
  ArrayNotEmpty,
} from 'class-validator';
import { isJson } from 'src/helper/string.helper';
import { ItemInventory } from './create-inventory.request.dto';
class Impersonator {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
export class UpdateInventoryBodyRequestDto extends BaseDto {
  @ApiProperty()
  @IsString()
  code: string;

  @ApiProperty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  createdByUserId: number;

  @ApiProperty()
  @IsDateString()
  executeFrom: Date;

  @ApiProperty()
  @IsDateString()
  executeTo: Date;

  @ApiProperty()
  @IsDateString()
  checkPointDate: Date;

  @ApiProperty()
  @Transform(({ value }) => JSON.parse(value))
  @IsArray()
  warehouseIds: number[];

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsEnum(InventoryTypeEnum)
  type: number;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsOptional()
  @IsEnum(InventoryCheckPointDataType)
  checkPointDataType: number;

  @ApiPropertyOptional()
  @IsOptional()
  checkPointDataAttachment: any;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => JSON.parse(value))
  @IsArray()
  @ValidateNested()
  @ArrayUnique()
  @Type(() => ItemInventory)
  items: ItemInventory[];

  @ApiProperty()
  @ValidateNested()
  @ArrayUnique((e: Impersonator) => e.id)
  @Transform(({ value }) => {
    if (typeof value !== 'string') return value;

    if (value) value = value.replace(/\\/g, '');

    if (isJson(value)) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    }
  })
  @IsArray()
  @ArrayNotEmpty()
  @Type(() => Impersonator)
  impersonators: Impersonator[];
}

export class UpdateInventoryDto extends UpdateInventoryBodyRequestDto {
  @IsNotEmpty()
  @IsInt()
  id: number;
}
