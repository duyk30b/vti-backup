import {
  InventoryCheckPointDataType,
  InventoryTypeEnum,
} from '@components/inventory/inventory.contant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsInt,
  IsString,
  MaxLength,
  IsOptional,
  IsEnum,
  ValidateNested,
  ArrayUnique,
  ArrayNotEmpty,
  IsNotEmpty,
} from 'class-validator';
import { isJson } from 'src/helper/string.helper';
class Impersonator {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
export class ItemInventory {
  @ApiProperty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  id: number;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  locatorId?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  warehouseId?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  planQuantity?: number;
}

export class CreateInventoryDto extends BaseDto {
  @ApiProperty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  createdByUserId: number;

  @ApiProperty()
  @IsDateString()
  executeFrom: Date;

  @ApiProperty()
  @IsDateString()
  executeTo: Date;

  @ApiProperty()
  @IsDateString()
  checkPointDate: Date;

  @ApiProperty()
  @Transform(({ value }) => JSON.parse(value))
  @IsArray()
  warehouseIds: number[];

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsEnum(InventoryTypeEnum)
  type: number;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsEnum(InventoryCheckPointDataType)
  checkPointDataType: number;

  @ApiPropertyOptional()
  @IsOptional()
  checkPointDataAttachment: any;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => JSON.parse(value))
  @IsArray()
  @ValidateNested()
  @ArrayUnique()
  @Type(() => ItemInventory)
  items: ItemInventory[];

  @ApiProperty()
  @ValidateNested()
  @ArrayUnique((e: Impersonator) => e.id)
  @Transform(({ value }) => {
    if (typeof value !== 'string') return value;

    if (value) value = value.replace(/\\/g, '');

    if (isJson(value)) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    }
  })
  @IsArray()
  @ArrayNotEmpty()
  @Type(() => Impersonator)
  impersonators: Impersonator[];
}
