import { BaseDto } from './../../../../core/dto/base.dto';
import { IsNotEmpty, IsInt } from 'class-validator';
import { Transform } from 'class-transformer';

export class GetInventoryWarehouseHistoryRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  @Transform(obj => parseInt(obj.value))
  id: number;

  @IsNotEmpty()
  @IsInt()
  @Transform(obj => parseInt(obj.value))
  warehouseId: number;
}
