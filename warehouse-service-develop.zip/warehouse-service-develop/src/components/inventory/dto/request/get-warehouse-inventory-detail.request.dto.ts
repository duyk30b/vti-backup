import { IsOptional } from 'class-validator';
import { PaginationQuery } from '@utils/pagination.query';
import { Transform } from 'class-transformer';
import { IsNotEmpty, IsInt } from 'class-validator';
export class GetWarehouseInventoryDetailRequestDto extends PaginationQuery {
  @IsNotEmpty()
  @Transform((data) => Number(data.value))
  @IsInt()
  id: number;

  @IsOptional()
  @Transform((data) => Number(data.value))
  @IsInt()
  warehouseId: number;

  @IsOptional()
  @Transform((data) => Number(data.value))
  @IsInt()
  locatorId: number;
}
