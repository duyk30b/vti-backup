import { PaginationQuery } from '@utils/pagination.query';
import { IsDateString, IsOptional } from 'class-validator';

export class GetInventoryHistoryListRequestDto extends PaginationQuery {
  @IsOptional()
  @IsDateString()
  executionDay: string;
}
