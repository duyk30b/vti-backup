import { GetWarehouseInventoryListQueryDto } from './dto/request/get-warehouse-inventory-list.request.dto';
import { GetWarehouseInventoryDetailRequestDto } from './dto/request/get-warehouse-inventory-detail.request.dto';
import { GetListInventoryRequestDto } from './dto/request/get-list-inventory.request.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { InventoryServiceInterface } from '@components/inventory/interface/inventory.service.interface';
import { CreateInventoryDto } from './dto/request/create-inventory.request.dto';
import { isEmpty } from 'lodash';
import { CreateInventoryItemBodyDto } from './dto/request/create-inventory-item.request.dto';
import { ApproveInventoryItemDto } from './dto/request/approve-inventory-item.request.dto';
import {
  GetInventoryDetailQueryDto,
  GetInventoryDetailRequestDto,
} from './dto/request/get-inventory-detail.request.dto';
import { UpdateInventoryBodyRequestDto } from './dto/request/update-inventory.request.dto';
import { GetInventoryHistoryListRequestDto } from './dto/request/get-inventory-history-list.request.dto';
import { GetInventoryWarehouseHistoryRequestDto } from './dto/request/get-inventory-warehouse-history.request.dto';
import {
  CREATE_INVENTORY_PERMISSION,
  UPDATE_INVENTORY_PERMISSION,
  DELETE_INVENTORY_PERMISSION,
  DETAIL_INVENTORY_PERMISSION,
  LIST_INVENTORY_PERMISSION,
  CONFIRM_INVENTORY_PERMISSION,
  REJECT_INVENTORY_PERMISSION,
  APPROVE_INVENTORY_PERMISSION,
  EXCUTE_WAREHOUSE_INVENTORY_PERMISSION,
} from '@utils/permissions/inventory';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  DETAIL_INVENTORY_STATISTICS_PERMISSION,
  LIST_INVENTORY_STATISTICS_PERMISSION,
} from '@utils/permissions/inventory-statistics';
import { generatePermissionCodes } from '@utils/common';
import { PaginationQuery } from '@utils/pagination.query';
import { LIST_INVENTORY_WARNING_PERMISSION } from '@utils/permissions/inventory-warning';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { DeleteMultipleWithUserIdDto } from '@core/dto/multiple/delete-multiple-with-user-id.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { InventoryResponse } from './dto/response/inventory.response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { BaseDto } from '@core/dto/base.dto';
import { InventoryItemResponse } from './dto/response/inventory-item.response.dto';
import { InventoryTransactionResponse } from './dto/response/inventory-transaction.response.dto';
import { WarehouseDataResponseDto } from '@components/warehouse/dto/response/warehouse-data.response.dto';
import { InventoryHistoryResponseDto } from './dto/response/inventory-history.response.dto';
import { GetItemInventoryQuantityRequestDto } from './dto/request/get-item-inventory-quantity.request.dto';
import { GetLocatorsByInventoryIdQuery } from './dto/request/get-locators-by-inventory-id.request.dto';
import { MessagePattern } from '@nestjs/microservices';
import { GetListItemInventoryRequestDto } from './dto/request/get-list-item-inventory.request.dto';
import { NATS_WAREHOUSE } from '@config/nats.config';

const WAREHOUSE_INVENTORY_DETAIL_PERMISSION = generatePermissionCodes([
  DETAIL_INVENTORY_PERMISSION.code,
  DETAIL_INVENTORY_STATISTICS_PERMISSION.code,
]);

@Controller('')
export class InventoryController {
  constructor(
    @Inject('InventoryServiceInterface')
    private readonly inventoryService: InventoryServiceInterface,
  ) {}

  @PermissionCode(CREATE_INVENTORY_PERMISSION.code)
  @Post('/inventories/create')
  @ApiOperation({
    tags: ['Inventory', 'Warehouse'],
    summary: 'Create Inventory Order',
    description: 'Tạo lệnh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: InventoryResponse,
  })
  public async create(@Body() payload: CreateInventoryDto): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryService.create({
      ...request,
      createdByUserId: request?.userId,
    });
  }

  @PermissionCode(UPDATE_INVENTORY_PERMISSION.code)
  @Put('/inventories/:id')
  @ApiOperation({
    tags: ['Inventory', 'Warehouse'],
    summary: 'Update Inventory',
    description: 'Cập nhật lệnh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  public async update(
    @Body() payload: UpdateInventoryBodyRequestDto,
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;

    return await this.inventoryService.update(request);
  }

  @PermissionCode(DELETE_INVENTORY_PERMISSION.code)
  @Delete('/inventories/:id')
  @ApiOperation({
    tags: ['Inventory', 'Warehouse'],
    summary: 'Delete Inventory Order',
    description: 'Xóa lệnh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async delete(@Param() req): Promise<any> {
    return await this.inventoryService.delete({
      inventoryId: req.id,
      userId: req.userId,
    });
  }

  @PermissionCode(DELETE_INVENTORY_PERMISSION.code)
  @Delete('/inventories/multiple')
  @ApiOperation({
    tags: ['Inventory', 'Warehouse'],
    summary: 'Delete multiple Inventory Order',
    description: 'Xóa nhiều lệnh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryService.deleteMultiple(request);
  }

  @PermissionCode(WAREHOUSE_INVENTORY_DETAIL_PERMISSION)
  @Get('/inventories/:id')
  @ApiOperation({
    tags: ['Inventory', 'Warehouse', 'Item'],
    summary: 'Get Inventory Detail',
    description: 'Chi tiết lệnh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: InventoryResponse,
  })
  public async detail(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() payload: GetInventoryDetailQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    return await this.inventoryService.getDetail(request);
  }

  @PermissionCode(EXCUTE_WAREHOUSE_INVENTORY_PERMISSION.code)
  @Post('/inventories/:id/execute')
  @ApiOperation({
    tags: ['Inventory', 'Warehouse', 'Item'],
    summary: 'Excute Inventory Item',
    description: 'Thực hiện kiểm kê nguyên vật liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: InventoryItemResponse,
  })
  public async createWarehouseInventoryItem(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() payload: CreateInventoryItemBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.inventoryId = id;
    return await this.inventoryService.execute(request);
  }

  @PermissionCode(CONFIRM_INVENTORY_PERMISSION.code)
  @Post('/inventories/:id/confirm')
  @ApiOperation({
    tags: ['Inventory', 'Warehouse', 'Item'],
    summary: 'Confirm lệnh kiểm kê',
    description: 'Confirm lệnh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: SuccessResponse,
  })
  public async confirmWarehouseInventoryItem(
    @Param() payload: BaseDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryService.confirm({
      ...request,
      id: request.id,
      userId: request.userId,
    });
  }

  @PermissionCode(CONFIRM_INVENTORY_PERMISSION.code)
  @Put('/inventories/confirm/multiple')
  @ApiOperation({
    tags: ['Inventory', 'Warehouse', 'Item'],
    summary: 'Confirm nhiều lệnh kiểm kê',
    description: 'Confirm nhiều lệnh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: SuccessResponse,
  })
  public async confirmMultipleWarehouseInventoryItem(
    @Query() payload: DeleteMultipleWithUserIdDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryService.confirmMultiple(request);
  }

  @PermissionCode(REJECT_INVENTORY_PERMISSION.code)
  @Post('/inventories/:id/reject')
  @ApiOperation({
    tags: ['Inventory', 'Warehouse', 'Item'],
    summary: 'Reject lệnh kiểm kê',
    description: 'Reject lệnh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: SuccessResponse,
  })
  public async rejectWarehouseInventoryItem(
    @Param() payload: BaseDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryService.reject({
      ...request,
      id: Number(request.id),
    });
  }

  @PermissionCode(REJECT_INVENTORY_PERMISSION.code)
  @Put('/inventories/reject/multiple')
  @ApiOperation({
    tags: ['Inventory', 'Warehouse', 'Item'],
    summary: 'Reject nhiều lệnh kiểm kê',
    description: 'Reject nhiều lệnh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: SuccessResponse,
  })
  public async rejectMultipleWarehouseInventoryItem(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryService.rejectMultiple(request);
  }

  @PermissionCode(APPROVE_INVENTORY_PERMISSION.code)
  @Post('/inventories/:id/approve')
  @ApiOperation({
    tags: ['Inventory', 'Warehouse', 'Item'],
    summary: 'Approve inventory',
    description: 'Approve lệnh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Approve successfully',
    type: SuccessResponse,
  })
  public async approveInventoryItem(
    @Param() param: ApproveInventoryItemDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryService.approve(request);
  }

  @PermissionCode(WAREHOUSE_INVENTORY_DETAIL_PERMISSION)
  @Get('inventories/:id/items')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'List Item Inventory Quantity',
    description: 'Danh sách vật tư',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: WarehouseDataResponseDto,
  })
  public async getItemInventoryPartDetail(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() payload: PaginationQuery,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    return await this.inventoryService.getItemInventoryPartDetail(request);
  }

  @PermissionCode(WAREHOUSE_INVENTORY_DETAIL_PERMISSION)
  @Get('inventories/:id/item-inventory-quantity')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'List Item Inventory Quantity',
    description: 'Danh sách vật tư',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: WarehouseDataResponseDto,
  })
  public async getItemInventoryQuantity(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() payload: PaginationQuery,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    return await this.inventoryService.getItemInventoryQuantity(request);
  }

  @PermissionCode(WAREHOUSE_INVENTORY_DETAIL_PERMISSION)
  @Get('inventories/:id/list-item-part')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'List Item Inventory',
    description: 'Danh sách vật tư kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: WarehouseDataResponseDto,
  })
  public async getListItemInventory(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() payload: PaginationQuery,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.inventoryService.getListItemInventory(request);
  }

  @PermissionCode(LIST_INVENTORY_STATISTICS_PERMISSION.code)
  @Get('/inventories/warehouse-transactions/list')
  @ApiOperation({
    tags: ['Inventory', 'Warehouse', 'Transaction'],
    summary: 'List inventory transaction',
    description: 'Danh sách phiếu kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: InventoryTransactionResponse,
  })
  public async listInventoryTransaction(
    @Query() param: GetListInventoryRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryService.getListTransaction(request);
  }

  @Get('/inventories/:id/locators/:locatorId')
  @ApiOperation({
    tags: ['Inventory'],
    summary: 'Get detail with locatorId',
    description: 'Get chi tiết lệnh theo vị trí ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detai; successfully',
    type: InventoryResponse,
  })
  public async getWarhouseInventoryDetail(
    @Param() param: GetWarehouseInventoryDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryService.getLocatorInventoryDetail(request);
  }

  // @Get('/inventories/:id/warehouses/list')
  @Get('/inventories/:id/locators')
  @ApiOperation({
    tags: ['Inventory'],
    summary: 'List locator with inventory',
    description: 'Danh sách vị trí theo lệnh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
    type: WarehouseDataResponseDto,
  })
  public async getWarhouseInventoryList(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() param: GetLocatorsByInventoryIdQuery,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.inventoryId = id;
    return await this.inventoryService.getLocatorsByInventoryId(request);
  }

  @Get('/inventories/:id/histories/:warehouseId')
  @ApiOperation({
    tags: ['Inventory', 'Warehouse', 'History'],
    summary: 'Get Inventory Warehouse Histories',
    description: 'Lịch sự kho đã kiểm kê theo ngày',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: InventoryResponse,
  })
  public async getWarhouseInventoryHistory(
    @Param() param: GetInventoryWarehouseHistoryRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryService.getInventoryWarehouseHistory(request);
  }

  @Get('/inventories/histories')
  @ApiOperation({
    tags: ['Inventory', 'Warehouse', 'Histories'],
    summary: 'Get Inventory Histories',
    description: 'Danh sách lịch sự các kho đã kiểm kê theo ngày',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: InventoryHistoryResponseDto,
  })
  public async getInventoryHistoryList(
    @Query() param: GetInventoryHistoryListRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryService.getInventoryHistoryList(request);
  }

  @PermissionCode(LIST_INVENTORY_PERMISSION.code)
  @Get('/inventories/list')
  @ApiOperation({
    tags: ['Inventory', 'Warehouse', 'Item'],
    summary: 'List inventory',
    description: 'Danh sách lệnh kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: InventoryResponse,
  })
  public async listInventoryItem(
    @Query() param: GetListInventoryRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryService.getList(request);
  }

  @PermissionCode(LIST_INVENTORY_WARNING_PERMISSION.code)
  @Get('inventory-warnings/list')
  @ApiOperation({
    tags: ['Warehouse', 'Sectors'],
    summary: 'List Inventories Warning',
    description: 'Danh sách Cảnh báo quá hạn lưu kho',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: WarehouseDataResponseDto,
  })
  public async listInventoryWarning(
    @Query() param: PaginationQuery,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryService.getListWarning(request);
  }

  @MessagePattern(`${NATS_WAREHOUSE}.get_list_item_inventory`)
  public async getListItemInventoryTcp(
    @Body() payload: GetListItemInventoryRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryService.getListItemInventory(request);
  }

  @Get('/inventories/:id/check-items-not-executed')
  @ApiOperation({
    tags: ['Warehouse', 'Sectors'],
    summary: 'List Items Are Not Executed',
    description: 'Danh sách vật tư chưa kiểm kê',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: WarehouseDataResponseDto,
  })
  public async checkItemNotExecute(
    @Param() param: GetInventoryDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryService.checkItemNotExecute(request.id);
  }
}
