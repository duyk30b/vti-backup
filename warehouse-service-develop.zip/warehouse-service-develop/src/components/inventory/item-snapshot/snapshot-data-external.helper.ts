import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { WarehouseInventoryItemPartRepositoryInterface } from '@components/warehouse-inventory-item/interface/warehouse-inventory-item-part.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { Inject } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { WarehouseInventoryItemPartImport } from '../import/warehouse-inventory-item-part.import.helper';
import { BaseInventoryItemPartAbstract } from './base.mapping.helper';
import { isEmpty } from 'lodash';

export class SnapshotDataPeriodicExternal extends BaseInventoryItemPartAbstract {
  constructor(
    protected readonly i18n: I18nRequestScopeService,
    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,
    @Inject('WarehouseInventoryItemPartImport')
    private readonly warehouseInventoryItemPartImport: WarehouseInventoryItemPartImport,
    @Inject('WarehouseInventoryItemPartRepositoryInterface')
    protected readonly warehouseInventoryItemPartRepository: WarehouseInventoryItemPartRepositoryInterface,
  ) {
    super(i18n);
  }
  protected getItemSnapshotQuantity(
    checkPointDate: Date,
    warehouseIds: number[],
    items?: any[],
  ) {
    // eslint-disable-next-line @typescript-eslint/no-empty-function
  }
  public async generateSnapshot({
    checkPointDataAttachment,
  }): Promise<ResponsePayload<any>> {
    const file = checkPointDataAttachment[0];
    if (isEmpty(file)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.CHECK_POINT_DATA_ATTACHMENT_IS_REQUIRED',
          ),
        )
        .build();
    }
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
    } as ImportRequestDto;
    const importResults =
      await this.warehouseInventoryItemPartImport.importUtil(importRequestDto);
    if (importResults.statusCode !== ResponseCodeEnum.SUCCESS) {
      return importResults;
    }
    if (!isEmpty(importResults.data)) {
      if (importResults?.data?.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(importResults.data.message)
          .build();
      }
    }
    const itemSnapshot = importResults?.data?.data?.map((item) => {
      return this.warehouseInventoryItemPartRepository.createEntity(item);
    });
    return new ResponseBuilder()
      .withData(itemSnapshot)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
}
