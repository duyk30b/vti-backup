import { isEmpty } from "class-validator";
import { I18nRequestScopeService } from "nestjs-i18n";
import { isSameDate } from "src/helper/date.helper";
import { ItemInventory } from "../dto/request/create-inventory.request.dto";

export abstract class BaseInventoryItemPartAbstract {
  protected constructor(
    protected readonly i18n: I18nRequestScopeService,
  ) {}

  protected abstract getItemSnapshotQuantity(
    checkPointDate: Date,
    warehouseIds: number[],
    items?: any[]
  );

  protected abstract generateSnapshot(request: any);
}