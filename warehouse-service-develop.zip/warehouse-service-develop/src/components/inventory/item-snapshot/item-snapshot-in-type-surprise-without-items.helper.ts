import { ItemServiceInterface } from "@components/item/interface/item.service.interface";
import { ResponseCodeEnum } from "@constant/response-code.enum";
import { Inject } from "@nestjs/common";
import { ResponseBuilder } from "@utils/response-builder";
import { I18nRequestScopeService } from "nestjs-i18n";
import { isEmpty, keyBy } from "lodash";
import { BaseInventoryItemPartAbstract } from "./base.mapping.helper";
import { WarehouseInventoryItemPartRepositoryInterface } from "@components/warehouse-inventory-item/interface/warehouse-inventory-item-part.repository.interface";
import { ResponsePayload } from "@utils/response-payload";
import { isSameDate } from "src/helper/date.helper";
import { ReportServiceInterface } from "@components/report/interface/report.service.interface";
import { WarehouseLayoutServiceInterface } from "@components/warehouse-layout/interface/warehouse-layout.service.interface";

export class ItemSnapshotInTypeSurpriseWithoutItems extends BaseInventoryItemPartAbstract {
  constructor(
    protected readonly i18n: I18nRequestScopeService,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('WarehouseLayoutServiceInterface')
    private readonly warehouseLayoutService: WarehouseLayoutServiceInterface,

    @Inject('WarehouseInventoryItemPartRepositoryInterface')
    protected readonly warehouseInventoryItemPartRepository: WarehouseInventoryItemPartRepositoryInterface,

    @Inject('ReportServiceInterface')
    protected readonly reportService: ReportServiceInterface,
  ) {
    super(i18n);
  }

  protected async getItemSnapshotQuantity(
    checkPointDate: Date,
    warehouseIds: number[],
    items?: any[]
  ): Promise<any> {
    if (isSameDate(checkPointDate, new Date())) {
      return items.map(item => ({
        ...item,
        id: item.itemId,
        planQuantity: item.quantity,
      }));
    } else {
      const itemLocatorStocks = await this.reportService.getDailyItemLocatorStocks(
        warehouseIds,
        items.map(item => item.itemId),
        checkPointDate
      );
      return itemLocatorStocks.map(item => ({
        id: item.itemId,
        warehouseId: item.warehouseId,
        locatorId: item.locatorId,
        planQuantity: item.stockQuantity,
      }));
    }
  }

  public async generateSnapshot({
    checkPointDate,
    warehouseIds,
  }): Promise<ResponsePayload<any>> {
    const locators = await this.warehouseLayoutService.getLocatorsByRootIds(warehouseIds);
    const locatorIds = locators?.map(locator => locator.locatorId);
    const itemWarehouseLocations = await this.itemService.getPositionItems({
      locatorIds
    });
    if (isEmpty(itemWarehouseLocations)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_NOT_FOUND_IN_WAREHOUSE'))
        .build();
    }
    const itemSnapshotQuantity = await this.getItemSnapshotQuantity(
      checkPointDate,
      warehouseIds,
      itemWarehouseLocations
    )

    const itemSnapshot = itemSnapshotQuantity.map((item) => {
      return this.warehouseInventoryItemPartRepository.createEntity(
        item
      );
    });
    return new ResponseBuilder()
      .withData(itemSnapshot)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
}
