import { ItemServiceInterface } from "@components/item/interface/item.service.interface";
import { ResponseCodeEnum } from "@constant/response-code.enum";
import { Inject } from "@nestjs/common";
import { ResponseBuilder } from "@utils/response-builder";
import { I18nRequestScopeService } from "nestjs-i18n";
import { isEmpty, uniq, flatten, keyBy } from "lodash";
import { ItemInventory } from "../dto/request/create-inventory.request.dto";
import { BaseInventoryItemPartAbstract } from "./base.mapping.helper";
import { WarehouseInventoryItemPartRepositoryInterface } from "@components/warehouse-inventory-item/interface/warehouse-inventory-item-part.repository.interface";
import { ResponsePayload } from "@utils/response-payload";
import { isSameDate } from "src/helper/date.helper";
import { ReportServiceInterface } from "@components/report/interface/report.service.interface";
import { WarehouseLayoutServiceInterface } from "@components/warehouse-layout/interface/warehouse-layout.service.interface";

export class ItemSnapshotInTypeSurpriseWithItems extends BaseInventoryItemPartAbstract {
  constructor(
    protected readonly i18n: I18nRequestScopeService,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('WarehouseLayoutServiceInterface')
    private readonly warehouseLayoutService: WarehouseLayoutServiceInterface,

    @Inject('WarehouseInventoryItemPartRepositoryInterface')
    protected readonly warehouseInventoryItemPartRepository: WarehouseInventoryItemPartRepositoryInterface,

    @Inject('ReportServiceInterface')
    protected readonly reportService: ReportServiceInterface,
  ) {
    super(i18n);
  }

  protected async getItemSnapshotQuantity(
    checkPointDate: Date,
    warehouseIds: number[],
    items: any[]
  ): Promise<any> {
    if (isSameDate(checkPointDate, new Date())) {
      return items.map(item => ({
        ...item,
        id: item.itemId,
        planQuantity: item.quantity,
      }));
    } else {
      const itemLocatorStocks = await this.reportService.getDailyItemLocatorStocks(
        warehouseIds,
        items.map(item => item.itemId),
        checkPointDate
      );
      return itemLocatorStocks.map(item => ({
        id: item.itemId,
        warehouseId: item.warehouseId,
        locatorId: item.locatorId,
        planQuantity: item.stockQuantity,
      }));
    }
  }

  protected async validateItemPart(
    warehouseIds: number[],
    items: ItemInventory[]
  ): Promise<any> {
    if (!items || isEmpty(items)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const itemIds = items.map(item => item.id);
    const itemsExist = await this.itemService.getItems(itemIds);
    if (uniq(itemIds).length !== itemsExist.length) {
      const itemIdsExist = itemsExist.map(item => item.itemId);
      const invalidItems = items.filter(item => !itemIdsExist.includes(item.id));
      return new ResponseBuilder()
        .withData(invalidItems)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_NOT_FOUND'))
        .build();
    }

    const locators = await this.warehouseLayoutService.getLocatorsByRootIds(warehouseIds);
    const locatorIds = locators?.map(locator => locator.locatorId);
    const itemWarehouseLocationsExist = await this.itemService.getPositionItems({
      locatorIds,
      itemIds
    });

    if (isEmpty(itemWarehouseLocationsExist)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_NOT_FOUND_IN_WAREHOUSE'))
        .build();
    }

    return new ResponseBuilder()
      .withData(itemWarehouseLocationsExist)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async generateSnapshot({
    checkPointDate,
    warehouseIds,
    items
  }): Promise<ResponsePayload<any>> {
    const validateItemResult = await this.validateItemPart(warehouseIds, items);
    if (validateItemResult.statusCode !== ResponseCodeEnum.SUCCESS) {
      return validateItemResult;
    }
    const itemSnapShotsQuantity = await this.getItemSnapshotQuantity(
      checkPointDate,
      warehouseIds,
      validateItemResult?.data
    );

    const itemSnapshot = itemSnapShotsQuantity.map((item) => {
      return this.warehouseInventoryItemPartRepository.createEntity(
        item
      );
    });
    return new ResponseBuilder()
      .withData(itemSnapshot)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
}