import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WarehouseInventoryItem } from '@entities/warehouse-inventory-item/warehouse-inventory-item.entity';

export interface InventoryItemRepositoryInterface
  extends BaseInterfaceRepository<WarehouseInventoryItem> {
  createMany(data: WarehouseInventoryItem[]): Promise<WarehouseInventoryItem[]>;
}
