import { GetListInventoryRequestDto } from './../dto/request/get-list-inventory.request.dto';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { Inventory } from '@entities/inventory/inventory.entity';
import { GetInventoryHistoryListRequestDto } from '../dto/request/get-inventory-history-list.request.dto';
import { GetInventoryWarehouseHistoryRequestDto } from '../dto/request/get-inventory-warehouse-history.request.dto';
import { GetWarehouseInventoryListRequestDto } from '../dto/request/get-warehouse-inventory-list.request.dto';

export interface InventoryRepositoryInterface
  extends BaseInterfaceRepository<Inventory> {
  getInventoryByExecutionDay(
    executionDay: string,
    factoryId: number,
  ): Promise<Inventory>;
  getList(
    payload: GetListInventoryRequestDto,
    warehouseIds?: number[],
  ): Promise<any>;
  getWarehouseInventoryHistoryList(
    payload: GetInventoryHistoryListRequestDto,
  ): Promise<any>;
  getInventoryWarehouseHistory(
    payload: GetInventoryWarehouseHistoryRequestDto,
  ): Promise<any>;
  getListTransaction(
    payload: GetListInventoryRequestDto,
    filterByUserIds?: any,
  ): Promise<any>;
  getDetail(
    id: number,
    userWarehouseIds?: number[],
    warehouseId?: any,
    locatorId?: any,
  ): Promise<any>;
  getWarehouseDetail(id: number, warehouseId: number): Promise<any>;
  getWarehouseByLocator(id: number, locatorId: number): Promise<any>;
  getLocatorByInventoryId(
    payload: GetWarehouseInventoryListRequestDto,
  ): Promise<any>;
  getWarehouseByLocatorId(id: number, locatorId: number): Promise<any>;
  scanLocator(type: number, locatorId?: number): Promise<any>;
}
