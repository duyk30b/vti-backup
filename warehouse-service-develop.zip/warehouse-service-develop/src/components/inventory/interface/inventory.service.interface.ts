import { GetWarehouseInventoryListRequestDto } from './../dto/request/get-warehouse-inventory-list.request.dto';
import { GetWarehouseInventoryDetailRequestDto } from './../dto/request/get-warehouse-inventory-detail.request.dto';
import { GetListInventoryRequestDto } from './../dto/request/get-list-inventory.request.dto';
import { DeleteInventoryDto } from './../dto/request/delete-inventory.request.dto';
import { Inventory } from '@entities/inventory/inventory.entity';
import { CreateInventoryDto } from '@components/inventory/dto/request/create-inventory.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateInventoryItemDto } from '../dto/request/create-inventory-item.request.dto';
import { ApproveInventoryItemDto } from '../dto/request/approve-inventory-item.request.dto';
import { UpdateInventoryStatusRequestDto } from '../dto/request/update-inventory-status-request.dto';
import { GetInventoryDetailRequestDto } from '../dto/request/get-inventory-detail.request.dto';
import { UpdateInventoryDto } from '../dto/request/update-inventory.request.dto';
import { GetInventoryHistoryListRequestDto } from '../dto/request/get-inventory-history-list.request.dto';
import { GetInventoryWarehouseHistoryRequestDto } from '../dto/request/get-inventory-warehouse-history.request.dto';
import { PaginationQuery } from '@utils/pagination.query';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { DeleteMultipleWithUserIdDto } from '@core/dto/multiple/delete-multiple-with-user-id.dto';
import { GetItemInventoryQuantityRequestDto } from '../dto/request/get-item-inventory-quantity.request.dto';
import { GetListItemInventoryRequestDto } from '../dto/request/get-list-item-inventory.request.dto';
import { GetLocatorsByInventoryIdRequestDto } from '../dto/request/get-locators-by-inventory-id.request.dto';

export interface InventoryServiceInterface {
  create(
    inventoryDto: CreateInventoryDto,
  ): Promise<Inventory | ResponsePayload<any>>;
  getDetail(
    payload: GetInventoryDetailRequestDto,
  ): Promise<Inventory | ResponsePayload<any>>;

  delete(warehouseDto: DeleteInventoryDto): Promise<ResponsePayload<any>>;
  getList(payload: GetListInventoryRequestDto): Promise<ResponsePayload<any>>;
  getInventoryHistoryList(
    payload: GetInventoryHistoryListRequestDto,
  ): Promise<ResponsePayload<any>>;
  getListTransaction(
    payload: GetListInventoryRequestDto,
  ): Promise<ResponsePayload<any>>;
  getWarehouseInventoryDetail(
    payload: GetWarehouseInventoryDetailRequestDto,
  ): Promise<ResponsePayload<any>>;
  getInventoryWarehouseHistory(
    payload: GetInventoryWarehouseHistoryRequestDto,
  ): Promise<ResponsePayload<any>>;
  getWarehouseInventoryList(
    payload: GetWarehouseInventoryListRequestDto,
  ): Promise<ResponsePayload<any>>;
  confirm(
    payload: UpdateInventoryStatusRequestDto,
  ): Promise<ResponsePayload<any>>;
  reject(
    payload: UpdateInventoryStatusRequestDto,
  ): Promise<ResponsePayload<any>>;

  execute(
    inventoryItem: CreateInventoryItemDto,
  ): Promise<Inventory | ResponsePayload<any>>;

  approve(
    approveInventoryItemDto: ApproveInventoryItemDto,
  ): Promise<ResponsePayload<any>>;

  update(
    inventoryDto: UpdateInventoryDto,
  ): Promise<Inventory | ResponsePayload<any>>;
  getListWarning(request: PaginationQuery): Promise<any>;
  confirmMultiple(request: DeleteMultipleWithUserIdDto): Promise<any>;
  rejectMultiple(request: DeleteMultipleDto): Promise<any>;
  deleteMultiple(request: DeleteMultipleDto): Promise<any>;
  getLocatorInventoryList(
    payload: GetWarehouseInventoryListRequestDto,
  ): Promise<ResponsePayload<any>>;
  getLocatorInventoryDetail(
    payload: GetWarehouseInventoryDetailRequestDto,
  ): Promise<any>;
  confirmMultiple(request: DeleteMultipleWithUserIdDto): Promise<any>
  rejectMultiple(request: DeleteMultipleDto): Promise<any>
  deleteMultiple(request: DeleteMultipleDto): Promise<any>
  getItemInventoryQuantity(
    request: GetItemInventoryQuantityRequestDto
  ): Promise<any>;
  getItemInventoryPartDetail(
    request: GetItemInventoryQuantityRequestDto
  ): Promise<any>;
  getListItemInventory(
    request: GetListItemInventoryRequestDto
  ): Promise<any>
  getLocatorsByInventoryId(
    payload: GetLocatorsByInventoryIdRequestDto,
    filterLocatorIds?: number[],
  ): Promise<any>;
  checkItemNotExecute(id: number): Promise<any>;
}
