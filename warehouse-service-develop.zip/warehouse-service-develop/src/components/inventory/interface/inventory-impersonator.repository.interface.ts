import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { InventoryImpersonatorEntity } from '@entities/inventory/inventory-impersonator.entity';

export interface InventoryImpersonatorRepositoryInterface
  extends BaseAbstractRepository<InventoryImpersonatorEntity> {
  createInventoryImpersonator(data: any): InventoryImpersonatorEntity;
}
