import { GetWarehouseInventoryDetailRequestDto } from './dto/request/get-warehouse-inventory-detail.request.dto';
import { WarehouseRepository } from '@repositories/warehouse.repository';
import {
  InventoryStatusEnum,
  STATUS_TO_DELETE_INVENTORY,
  STATUS_TO_CONFIRM_INVENTORY,
  STATUS_TO_APPROVE_INVENTORY,
  STATUS_TO_UPDATE_INVENTORY,
  InventoryTypeEnum,
  DATE_FORMAT,
  INVENTORY_CODE_PREFIX,
  InventoryCheckPointDataType,
} from './inventory.contant';
import { DeleteInventoryDto } from './dto/request/delete-inventory.request.dto';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { Inventory } from '@entities/inventory/inventory.entity';
import { InventoryRepositoryInterface } from '@components/inventory/interface/inventory.repository.interface';
import { InventoryServiceInterface } from '@components/inventory/interface/inventory.service.interface';
import {
  CreateInventoryDto,
  ItemInventory,
} from '@components/inventory/dto/request/create-inventory.request.dto';
import { Between, DataSource, In, IsNull, Like, Not } from 'typeorm';
import {
  flatMap,
  map,
  orderBy,
  uniq,
  keyBy,
  isEmpty,
  has,
  values,
  groupBy,
  difference,
  flatten,
  compact,
  find,
} from 'lodash';
import { ApiError } from '@utils/api.error';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ResponsePayload } from '@utils/response-payload';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToClass, plainToInstance } from 'class-transformer';
import { InventoryResponse } from './dto/response/inventory.response.dto';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { CreateInventoryItemDto } from './dto/request/create-inventory-item.request.dto';
import { WarehouseInventoryItem } from '@entities/warehouse-inventory-item/warehouse-inventory-item.entity';
import { InventoryItemRepositoryInterface } from './interface/inventory-item.repository.interface';
import { InventoryItemResponse } from './dto/response/inventory-item.response.dto';
import { ApproveInventoryItemDto } from './dto/request/approve-inventory-item.request.dto';
import { UpdateInventoryStatusRequestDto } from './dto/request/update-inventory-status-request.dto';
import { GetListInventoryRequestDto } from './dto/request/get-list-inventory.request.dto';
import { PagingResponse } from '@utils/paging.response';
import { GetInventoryDetailRequestDto } from './dto/request/get-inventory-detail.request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { InventoryTransactionResponse } from './dto/response/inventory-transaction.response.dto';
import { first } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { UpdateInventoryDto } from './dto/request/update-inventory.request.dto';
import { InjectDataSource } from '@nestjs/typeorm';
import { GetWarehouseInventoryListRequestDto } from './dto/request/get-warehouse-inventory-list.request.dto';
import { WarehouseDataResponseDto } from '@components/warehouse/dto/response/warehouse-data.response.dto';
import { GetInventoryHistoryListRequestDto } from './dto/request/get-inventory-history-list.request.dto';
import { InventoryHistoryResponseDto } from './dto/response/inventory-history.response.dto';
import { GetInventoryWarehouseHistoryRequestDto } from './dto/request/get-inventory-warehouse-history.request.dto';
import { WarehouseShelfFloorRepositoryInterface } from '@components/warehouse-shelf-floor/interface/warehouse-shelf-floor.repository.interface';
import { PaginationQuery } from '@utils/pagination.query';
import { WarningResponse } from './dto/response/inventory-warning.response.dto';
import { ClientProxy } from '@nestjs/microservices';
import {
  formatUnitMeasures,
  formatUnitWeight,
  getInnerJoinElements,
  minus,
  mul,
  plus,
} from '@utils/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { stringFormat } from '@utils/object.util';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { DeleteMultipleWithUserIdDto } from '@core/dto/multiple/delete-multiple-with-user-id.dto';
import { ROLE } from '@constant/common';
import { PushNotificationRequestDto } from '@components/notification/dto/notification.request.dto';
import {
  ActionNotificationEnum,
  TypeNotificationEnum,
} from '@components/notification/notification.const';
import { WarehouseInventoryItemRepositoryInterface } from '@components/warehouse-inventory-item/interface/warehouse-inventory-item.repository.interface';
import { WarehouseInventoryItemPartRepositoryInterface } from '@components/warehouse-inventory-item/interface/warehouse-inventory-item-part.repository.interface';
import { WarehouseInventoryItemPartEntity } from '@entities/warehouse-inventory-item/warehouse-inventory-item-part.entity';
import { WarehouseShelfRepositoryInterface } from '@components/warehouse-shelf/interface/warehouse-shelf.repository.interface';
import { WarehouseSectorRepositoryInterface } from '@components/warehouse-sector/interface/warehouse-sector.repository.interface';
import * as moment from 'moment';
import { WarehouseLayoutServiceInterface } from '@components/warehouse-layout/interface/warehouse-layout.service.interface';
import { CheckPointExternalDataImport } from './import/check-point-external-data.import.helper';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { GetItemInventoryQuantityRequestDto } from './dto/request/get-item-inventory-quantity.request.dto';
import { ItemStockMovementTypeEnum } from '@components/item/item.constant';
import { GetItemStockQuantityRequestDto } from '@components/item/dto/request/get-item-stock-quantity.request.dto';
import { endOfDay, isSameDate, startOfDay } from 'src/helper/date.helper';
import { GetItemInventoryPartsResponseDto } from './dto/response/get-item-inventory-parts.response.dto';
import { GetItemInventoryQuantityResponseDto } from './dto/response/get-item-inventory-quantity.response.dto';
import { ItemSnapshotInTypePeriodicWithInternalData } from './item-snapshot/item-snapshot-in-type-periodic-with-internal-data.helper';
import { ItemSnapshotInTypePeriodicWithExternalData } from './item-snapshot/item-snapshot-in-type-periodic-with-external-data.helper';
import { ItemSnapshotInTypeSurpriseWithItems } from './item-snapshot/item-snapshot-in-type-surprise-with-items.helper';
import { ItemSnapshotInTypeSurpriseWithoutItems } from './item-snapshot/item-snapshot-in-type-surprise-without-items.helper';
import { GetListItemInventoryRequestDto } from './dto/request/get-list-item-inventory.request.dto';
import { GetLocatorsByInventoryIdRequestDto } from './dto/request/get-locators-by-inventory-id.request.dto';
import { GetListLocatorsByInventoryResponseDto } from './dto/response/list-locator-by-inventory.response.dto';
import { GetWaringListResponseDto } from './dto/response/get-waring-list.response.dto';
import { InventoryImpersonatorRepositoryInterface } from './interface/inventory-impersonator.repository.interface';
import { InventoryImpersonatorEntity } from '@entities/inventory/inventory-impersonator.entity';
import { WarehouseInventoryItemPartImport } from './import/warehouse-inventory-item-part.import.helper';
import { SnapshotDataPeriodicExternal } from './item-snapshot/snapshot-data-external.helper';

@Injectable()
export class InventoryService implements InventoryServiceInterface {
  private readonly logger = new Logger(InventoryService.name);

  constructor(
    @Inject('InventoryRepositoryInterface')
    private readonly inventoryRepository: InventoryRepositoryInterface,

    @Inject('InventoryImpersonatorRepositoryInterface')
    private readonly inventoryImpersonatorRepository: InventoryImpersonatorRepositoryInterface,

    @Inject('WarehouseShelfFloorRepositoryInterface')
    private readonly warehouseShelfFloorRepository: WarehouseShelfFloorRepositoryInterface,

    @Inject('WarehouseShelfRepositoryInterface')
    private readonly warehouseShelfRepository: WarehouseShelfRepositoryInterface,

    @Inject('WarehouseSectorRepositoryInterface')
    private readonly warehouseSectorRepository: WarehouseSectorRepositoryInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepository,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('InventoryItemRepositoryInterface')
    private readonly inventoryItemRepository: InventoryItemRepositoryInterface,

    @Inject('WarehouseInventoryItemRepositoryInterface')
    private readonly warehouseInventoryItemRepository: WarehouseInventoryItemRepositoryInterface,

    @Inject('WarehouseInventoryItemPartRepositoryInterface')
    private readonly warehouseInventoryItemPartRepository: WarehouseInventoryItemPartRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,

    @InjectDataSource()
    private readonly connection: DataSource,

    @Inject('WarehouseLayoutServiceInterface')
    private readonly warehouseLayoutService: WarehouseLayoutServiceInterface,

    @Inject('CheckPointExternalDataImport')
    private readonly checkPointExternalDataImport: CheckPointExternalDataImport,

    @Inject('ItemSnapshotInTypePeriodicWithExternalData')
    private readonly itemSnapshotInTypePeriodicWithExternalData: ItemSnapshotInTypePeriodicWithExternalData,

    @Inject('ItemSnapshotInTypePeriodicWithInternalData')
    private readonly itemSnapshotInTypePeriodicWithInternalData: ItemSnapshotInTypePeriodicWithInternalData,

    @Inject('ItemSnapshotInTypeSurpriseWithItems')
    private readonly itemSnapshotInTypeSurpriseWithItems: ItemSnapshotInTypeSurpriseWithItems,

    @Inject('ItemSnapshotInTypeSurpriseWithoutItems')
    private readonly itemSnapshotInTypeSurpriseWithoutItems: ItemSnapshotInTypeSurpriseWithoutItems,

    @Inject('WarehouseInventoryItemPartImport')
    private readonly warehouseInventoryItemPartImport: WarehouseInventoryItemPartImport,

    @Inject('SnapshotDataPeriodicExternal')
    private readonly snapshotDataPeriodicExternal: SnapshotDataPeriodicExternal,

    private eventEmitter: EventEmitter2,
  ) {}

  async getInventoryWarehouseHistory(
    payload: GetInventoryWarehouseHistoryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const inventory =
      await this.inventoryRepository.getInventoryWarehouseHistory(payload);

    if (!inventory) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    let approver = {};
    const itemIds = uniq(map(inventory.warehouseItems, 'itemId'));
    const userIds = uniq([inventory.createdByUserId].filter((i) => i));
    if (inventory.approverId) {
      approver = await this.userService.getUserById(inventory.approverId);
    }
    const { items, users } = await this.getInventoryExtraInfor(
      itemIds,
      userIds,
    );
    inventory.warehouseItems = inventory.warehouseItems.map(
      (warehouseItem) => ({
        ...warehouseItem,
        ...items[warehouseItem.itemId],
      }),
    );
    const itemsInventorySerialize = {};
    inventory.warehouseItems.forEach((warehouseItem) => {
      const keyItem = warehouseItem.itemId;
      if (!has(itemsInventorySerialize, keyItem)) {
        itemsInventorySerialize[keyItem] = {
          ...items[keyItem],
          locations: {},
        };
      }
      const keyLocation = warehouseItem.warehouseShelfFloorId;
      if (!has(itemsInventorySerialize[keyItem].locations, keyLocation)) {
        itemsInventorySerialize[keyItem].locations[keyLocation] = {
          warehouseSector: warehouseItem.warehouseSector,
          warehouseShelf: warehouseItem.warehouseShelf,
          warehouseShelfFloor: warehouseItem.warehouseShelfFloor,
          lots: [],
        };
      }
      itemsInventorySerialize[keyItem].locations[keyLocation].lots.push({
        lotNumber: warehouseItem.lotNumber,
        date: warehouseItem.date,
        planQuantity: warehouseItem.planQuantity,
        actualQuantity: warehouseItem.actualQuantity,
        diffQuantity: minus(
          warehouseItem.planQuantity,
          warehouseItem.actualQuantity,
        ),
      });
    });
    const itemsInventory = values(itemsInventorySerialize);
    inventory.itemsInventory = itemsInventory.map((itemInventory) => {
      itemInventory['locations'] = values(itemInventory['locations']);
      return itemInventory;
    });

    inventory.createdByUser = users[inventory.createdByUserId];
    inventory.warehouse = first(inventory.warehouses);
    inventory.approver = approver;

    const dataReturn = plainToInstance(InventoryResponse, inventory, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getInventoryHistoryList(
    payload: GetInventoryHistoryListRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { data, count } =
      await this.inventoryRepository.getWarehouseInventoryHistoryList(payload);

    const dataReturn = plainToInstance(InventoryHistoryResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getWarehouseInventoryList(
    payload: GetWarehouseInventoryListRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { user } = payload;

    const userWarehouses = await this.userService.getUserWarehousesById(
      user.id,
    );

    if (isEmpty(userWarehouses)) {
      return new ResponseBuilder<PagingResponse>({
        items: [],
        meta: { total: 0, page: payload.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    if (!payload.filter) {
      payload.filter = [];
    }
    payload.filter.push({
      column: 'warehouseId',
      text: map(userWarehouses, 'id').join(','),
    });
    const { data, count } =
      await this.warehouseRepository.getWarehouseInventoryList(payload);
    const floorIds = [];
    const mapFloorWithWarehouse = {};
    data?.forEach((warehouse) => {
      warehouse.warehouseShelfFloors?.forEach((floor) => {
        floorIds.push(floor.id);
        mapFloorWithWarehouse[floor.id] = warehouse.id;
      });
    });
    const positionItems =
      await this.itemService.getItemStockMovementInWarehouseFloorByWarehouseFloorIds(
        uniq(floorIds),
      );
    const groupItemsByWarehouse = groupBy(
      positionItems.filter((item) => item.quantity > 0),
      (positionItem) =>
        mapFloorWithWarehouse[positionItem.warehouseShelfFloorId],
    );
    const infoTotalFloor =
      await this.warehouseShelfFloorRepository.getFloorSpaceByWarehousesInventory(
        payload,
      );
    const factoryIds = uniq(map(data, 'factoryId'));
    const factories = await this.userService.getFactoriesByIds(
      factoryIds,
      true,
    );
    const dataReturn = plainToInstance(
      WarehouseDataResponseDto,
      data.map((warehouse) => {
        return {
          ...warehouse,
          hasItem:
            has(groupItemsByWarehouse, warehouse.id) &&
            !isEmpty(groupItemsByWarehouse[warehouse.id]),
          factory: factories[warehouse.factoryId] || {},
        };
      }),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: {
        total: count,
        page: payload.page,
        totalFloor: infoTotalFloor.totalFloor,
        totalFloorSpace: infoTotalFloor.totalFloorSpace,
      },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getLocatorInventoryList(
    payload: GetWarehouseInventoryListRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { data, count } =
      await this.inventoryRepository.getLocatorByInventoryId(payload);
    const locatorResIds = [];
    const mapLocator = {};
    data?.map((item) => {
      item.locators?.map((locator) => {
        locatorResIds.push(locator.locatorId);
        mapLocator[locator.locatorId] = item.locatorId;
      });
    });

    const factoryIds = uniq(map(data, 'factoryId'));
    const factories = await this.userService.getFactoriesByIds(
      factoryIds,
      true,
    );
    const locators = await this.warehouseLayoutService.getLocatorByIds(
      uniq(locatorResIds),
      true,
    );
    const dataReturn = plainToInstance(
      WarehouseDataResponseDto,
      data.map((warehouse) => {
        return {
          ...warehouse,
          factory: factories[warehouse.factoryId] || {},
          locators: warehouse?.locators.map(
            (item) => locators[item.locatorId] || [],
          ),
        };
      }),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: {
        total: count,
        page: payload.page,
      },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  async getLocatorsByInventoryId(
    payload: GetLocatorsByInventoryIdRequestDto,
  ): Promise<any> {
    const { keyword, inventoryId, warehouseId } = payload;
    let dataReturn;
    const inventory = await this.inventoryRepository.findOneWithRelations({
      where: {
        id: inventoryId,
      },
      relations: ['warehouses'],
    });
    if (!inventory) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    let warehouseIds = [];
    if (warehouseId) {
      warehouseIds = inventory.warehouses
        .map((warehouse) => warehouse.id)
        .filter((item) => item === warehouseId);
    } else {
      warehouseIds = inventory.warehouses.map((warehouse) => warehouse.id);
    }

    if (keyword) {
      const locators = await this.warehouseLayoutService.getLocatorByKeyword(
        keyword,
        warehouseIds,
      );
      dataReturn = plainToInstance(
        GetListLocatorsByInventoryResponseDto,
        locators,
        {
          excludeExtraneousValues: true,
        },
      );
    } else {
      const data =
        await this.warehouseInventoryItemPartRepository.findByCondition({
          inventoryId,
          locatorId: Not(IsNull()),
        });
      const locatorIds = map(data, 'locatorId');
      const locators = await this.warehouseLayoutService.getLocatorsByRootIds(
        warehouseIds,
        locatorIds,
      );
      dataReturn = plainToInstance(
        GetListLocatorsByInventoryResponseDto,
        locators,
        {
          excludeExtraneousValues: true,
        },
      );
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(dataReturn)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  /**
   * Get Inventory Detail
   * @param payload
   * @returns
   */
  async getDetail(
    payload: GetInventoryDetailRequestDto,
  ): Promise<Inventory | ResponsePayload<any>> {
    const { id, user, warehouseId, locatorId } = payload;
    const userWarehouses = await this.userService.getUserWarehousesById(
      user.id,
    );
    const userWarehouseIds = map(userWarehouses, 'id');
    const inventory = await this.inventoryRepository.getDetail(
      id,
      userWarehouseIds,
      warehouseId,
      locatorId,
    );
    if (!inventory) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const userIds = uniq(
      [
        inventory.createdByUserId,
        inventory.confirmerId,
        inventory.approverId,
        inventory.updatedBy,
      ].filter((i) => i),
    );
    const impersonatorIds = uniq(
      compact(map(inventory.impersonators, 'impersonatorId')),
    );
    const impersonators = await this.userService.getUserByIds(
      impersonatorIds,
      true,
    );

    const { users } = await this.getInventoryExtraInfor([], userIds);
    if (inventory.approverId) {
      inventory.approver = users[inventory.approverId];
    }
    if (inventory.createdByUserId) {
      inventory.createdByUser = users[inventory.createdByUserId];
    }
    if (inventory.confirmerId) {
      inventory.confirmer = users[inventory.confirmerId];
    }
    if (inventory.updatedBy) {
      inventory.updatedBy = users[inventory.updatedBy];
    }
    inventory.impersonators.forEach((item) => {
      item.id = impersonators[item.impersonatorId]?.id;
      item.username = impersonators[item.impersonatorId]?.username;
      item.fullName = impersonators[item.impersonatorId]?.fullName;
      item.code = impersonators[item.impersonatorId]?.code;
    });
    const dataReturn = plainToInstance(InventoryResponse, inventory, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  async getWarehouseInventoryDetail(
    payload: GetWarehouseInventoryDetailRequestDto,
  ): Promise<any> {
    const { id, warehouseId } = payload;
    const inventory = await this.inventoryRepository.getWarehouseDetail(
      id,
      warehouseId,
    );
    if (!inventory) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const userIds = uniq(
      [
        inventory.createdByUserId,
        inventory.confirmerId,
        inventory.approverId,
      ].filter((i) => i),
    );
    const itemIds = uniq(map(inventory.warehouseItems, 'itemId'));
    const warehouseShelfFloorIds = map(
      inventory.warehouseItems,
      'warehouseShelfFloorId',
    );

    const dataShelfFloor =
      await this.warehouseShelfFloorRepository.findWithRelations({
        where: { id: In(warehouseShelfFloorIds) },
        relations: ['warehouseShelf', 'warehouseShelf.warehouseSector'],
      });
    const warehouseShelfFloorsData = keyBy(dataShelfFloor, 'id');
    const { items, users } = await this.getInventoryExtraInfor(
      itemIds,
      userIds,
    );
    inventory.warehouse = first(inventory.warehouses);
    inventory.warehouseItems = inventory.warehouseItems.map((warehouseItem) => {
      const warehouseSector = warehouseItem.warehouseShelfFloorId
        ? warehouseShelfFloorsData[warehouseItem.warehouseShelfFloorId]
            ?.warehouseShelf?.warehouseSector
        : null;
      const warehouseShelf = warehouseItem.warehouseShelfFloorId
        ? warehouseShelfFloorsData[warehouseItem.warehouseShelfFloorId]
            ?.warehouseShelf
        : null;
      const warehouseShelfFloor = warehouseItem.warehouseShelfFloorId
        ? warehouseShelfFloorsData[warehouseItem.warehouseShelfFloorId]
        : null;

      return {
        ...warehouseItem,
        ...items[warehouseItem.itemId],
        warehouseSector,
        warehouseShelf,
        warehouseShelfFloor,
      };
    });
    if (inventory.approverId) {
      inventory.approver = users[inventory.approverId];
    }
    if (inventory.createdByUserId) {
      inventory.createdByUser = users[inventory.createdByUserId];
    }
    if (inventory.confirmerId) {
      inventory.confirmer = users[inventory.confirmerId];
    }
    const dataReturn = plainToInstance(InventoryResponse, inventory, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getLocatorInventoryDetail(
    payload: GetWarehouseInventoryDetailRequestDto,
  ): Promise<any> {
    const { id, locatorId } = payload;
    const inventory = await this.inventoryRepository.getWarehouseByLocatorId(
      id,
      locatorId,
    );
    if (!inventory) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const userIds = uniq(
      [
        inventory.createdByUserId,
        inventory.confirmerId,
        inventory.approverId,
      ].filter((i) => i),
    );
    const users = await this.userService.getUserByIds(userIds, true);
    const locatorIds = uniq(map(inventory.locatorItems, 'locatorId'));
    if (!isEmpty(locatorIds)) {
      const locators = await this.warehouseLayoutService.getLocatorByIds(
        locatorIds,
        true,
      );
      inventory.locatorItems?.map(
        (item) => (item.locators = locators[item.locatorId]),
      );
    }

    if (inventory.approverId) {
      inventory.approver = users[inventory.approverId];
    }
    if (inventory.createdByUserId) {
      inventory.createdByUser = users[inventory.createdByUserId];
    }
    if (inventory.confirmerId) {
      inventory.confirmer = users[inventory.confirmerId];
    }
    const dataReturn = plainToInstance(InventoryResponse, inventory, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(
    payload: GetListInventoryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { user } = payload;
    if (!payload.filter) payload.filter = [];
    const userWarehouses = await this.userService.getUserWarehousesById(
      user.id,
    );
    let warehouseIds = [];
    if (!isEmpty(userWarehouses)) {
      warehouseIds = map(userWarehouses, (userWarehouse) => +userWarehouse.id);
    }
    if (isEmpty(warehouseIds)) {
      return new ResponseBuilder<PagingResponse>({
        items: [],
        meta: { total: 0, page: payload.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    const { data, count } = await this.inventoryRepository.getList(
      payload,
      warehouseIds,
    );
    const dataReturn = plainToInstance(InventoryResponse, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getListTransaction(
    payload: GetListInventoryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const filterCreatedBy = payload.filter?.find(
      (item) => item.column === 'createdByUser',
    );

    let filterByUserIds = [];

    if (!isEmpty(filterCreatedBy)) {
      filterByUserIds = await this.userService.getUsersByUsernameOrFullName(
        filterCreatedBy,
        true,
      );

      if (isEmpty(filterByUserIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: payload.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    const { data, count } = await this.inventoryRepository.getListTransaction(
      payload,
      filterByUserIds,
    );
    const userIds = uniq(map(data, 'createdByUserId'));
    const users = await this.userService.getUserByIds(userIds, true);
    const transactions = data.map((d) => ({
      ...d,
      createdByUser: users[d.createdByUserId],
    }));
    const dataReturn = plainToInstance(
      InventoryTransactionResponse,
      transactions,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async confirm(
    payload: UpdateInventoryStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, userId } = payload;
    const inventory = await this.inventoryRepository.getDetail(id);
    if (!inventory) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const existedInventoryTypeSuprise =
      await this.inventoryRepository.findByCondition([
        {
          executeFrom: Between(
            startOfDay(inventory.executeFrom),
            endOfDay(inventory.executeTo),
          ),
          status: InventoryStatusEnum.CONFIRMED,
          type: InventoryTypeEnum.SURPRISE,
        },
        {
          executeTo: Between(
            startOfDay(inventory.executeFrom),
            endOfDay(inventory.executeTo),
          ),
          status: InventoryStatusEnum.CONFIRMED,
          type: InventoryTypeEnum.SURPRISE,
        },
      ]);
    const existedInventoryTypePeriodic =
      await this.inventoryRepository.findByCondition([
        {
          executeFrom: Between(
            startOfDay(inventory.executeFrom),
            endOfDay(inventory.executeTo),
          ),
          type: InventoryTypeEnum.PERIODIC,
          status: InventoryStatusEnum.CONFIRMED,
        },
        {
          executeTo: Between(
            startOfDay(inventory.executeFrom),
            endOfDay(inventory.executeTo),
          ),
          type: InventoryTypeEnum.PERIODIC,
          status: InventoryStatusEnum.CONFIRMED,
        },
      ]);
    const warehouseIds = map(inventory.warehouses, 'id');
    const inventoryIds = compact(map(existedInventoryTypeSuprise, 'id'));
    let listItemWrehouseInventoryPartExisted;
    const keyWarehouseItemRequest = [];
    const keyWarehouseInventoryItemPart = [];
    if (!isEmpty(inventoryIds)) {
      listItemWrehouseInventoryPartExisted =
        await this.warehouseInventoryItemPartRepository.getWarehouseInventoryItemPartByIds(
          inventoryIds,
        );
    }
    const listItemWrehouseInventoryPart =
      await this.warehouseInventoryItemPartRepository.findByCondition({
        inventoryId: inventory.id,
      });
    if (inventory.type === InventoryTypeEnum.SURPRISE) {
      warehouseIds?.forEach((w) =>
        listItemWrehouseInventoryPart?.forEach((i) =>
          keyWarehouseItemRequest.push(`${w}-${i.itemId}`),
        ),
      );
      compact(listItemWrehouseInventoryPartExisted)?.forEach((i) =>
        keyWarehouseInventoryItemPart.push(`${i.warehouseId}-${i.itemId}`),
      );
    }
    const isValidKey = keyWarehouseInventoryItemPart.filter((key) =>
      keyWarehouseItemRequest.includes(key),
    );
    if (
      !isEmpty(existedInventoryTypeSuprise) &&
      !isEmpty(isValidKey) &&
      inventory.type === InventoryTypeEnum.SURPRISE
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.UNABLE_CREATE_INVENTORY_IS_A_PAIR_SAME_KEY_WAREHOUSE_AND_ITEM',
        ),
      ).toResponse();
    }
    if (
      !isEmpty(existedInventoryTypePeriodic) &&
      inventory.type === InventoryTypeEnum.PERIODIC
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.ALREADY_HAVE_INVENTORY_IN_EXECUTION_TIME',
        ),
      ).toResponse();
    }

    if (!STATUS_TO_CONFIRM_INVENTORY.includes(inventory.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.BAD_REQUEST'),
      ).toResponse();
    }
    inventory.status = InventoryStatusEnum.CONFIRMED;
    inventory.confirmerId = userId;
    inventory.confirmedAt = new Date().toISOString();

    //Push notification
    const user = await this.userService.getUserById(userId);
    const notificationRequest = new PushNotificationRequestDto();
    notificationRequest.title = `${
      user.username +
      (await this.i18n.translate(
        'error.WAREHOUSE_INVENTORY_CONFIRMED_NOTIFICATION',
      )) +
      inventory.name
    }`;
    notificationRequest.type = TypeNotificationEnum.WEB;
    notificationRequest.action = ActionNotificationEnum.WAREHOUSE_YARD;
    notificationRequest.content = inventory.description;
    //TODO SnP waiting
    notificationRequest.templateId = '62675f887848315c26a23033';
    notificationRequest.executionDate = new Date().toISOString();
    notificationRequest.payload = {
      title: notificationRequest.title,
      content: inventory.description,
    };
    notificationRequest.userIds = [inventory.createdByUserId];
    const pushMail = Object.assign(notificationRequest, {
      type: TypeNotificationEnum.MAIL,
    });
    this.eventEmitter.emit('warehouse_transfer.confirm', pushMail);
    this.eventEmitter.emit('warehouse_transfer.confirm', notificationRequest);

    await this.inventoryRepository.update(inventory);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async confirmMultiple(
    request: DeleteMultipleWithUserIdDto,
  ): Promise<any> {
    const { userId } = request;
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const inventories = await this.inventoryRepository.findByCondition({
      id: In(ids),
    });

    const inventoryIds = inventories.map((inventory) => inventory.id);
    if (inventories.length !== ids.length) {
      ids.forEach((id) => {
        if (!inventoryIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < inventories.length; i++) {
      const inventory = inventories[i];
      if (!STATUS_TO_CONFIRM_INVENTORY.includes(inventory.status))
        failIdsList.push(inventory.id);
    }

    const validIds = inventories
      .filter((inventory) => !failIdsList.includes(inventory.id))
      .map((inventory) => inventory.id);

    const validInventoryOrders = inventories.filter((inventory) =>
      validIds.includes(inventory.id),
    );

    if (!isEmpty(validInventoryOrders)) {
      validInventoryOrders.forEach((inventory) => {
        inventory.status = InventoryStatusEnum.CONFIRMED;
        inventory.confirmerId = userId;
        inventory.confirmedAt = new Date().toISOString();
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(Inventory, validInventoryOrders);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.CONFIRM_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  async reject(
    payload: UpdateInventoryStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, userId } = payload;
    const inventory = await this.inventoryRepository.findOneById(id);
    if (!inventory) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (!STATUS_TO_CONFIRM_INVENTORY.includes(inventory.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.BAD_REQUEST'),
      ).toResponse();
    }

    inventory.status = InventoryStatusEnum.REJECT;

    await this.inventoryRepository.update(inventory);

    //Push notification
    const user = await this.userService.getUserById(userId);
    const notificationRequest = new PushNotificationRequestDto();
    notificationRequest.title = `${
      user.username +
      (await this.i18n.translate(
        'error.WAREHOUSE_INVENTORY_REJECT_NOTIFICATION',
      )) +
      inventory.name
    }`;
    notificationRequest.type = TypeNotificationEnum.WEB;
    notificationRequest.action = ActionNotificationEnum.WAREHOUSE_YARD;
    notificationRequest.content = inventory.description;
    //TODO SnP waiting
    notificationRequest.templateId = '62675f887848315c26a23033';
    notificationRequest.executionDate = new Date().toISOString();
    notificationRequest.payload = {
      title: notificationRequest.title,
      content: inventory.description,
    };
    notificationRequest.userIds = [inventory.createdByUserId];
    const pushMail = Object.assign(notificationRequest, {
      type: TypeNotificationEnum.MAIL,
    });
    this.eventEmitter.emit('warehouse_transfer.reject', pushMail);
    this.eventEmitter.emit('warehouse_transfer.reject', notificationRequest);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async rejectMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const inventories = await this.inventoryRepository.findByCondition({
      id: In(ids),
    });

    const inventoryIds = inventories.map((inventory) => inventory.id);
    if (inventories.length !== ids.length) {
      ids.forEach((id) => {
        if (!inventoryIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < inventories.length; i++) {
      const inventory = inventories[i];
      if (!STATUS_TO_CONFIRM_INVENTORY.includes(inventory.status))
        failIdsList.push(inventory.id);
    }

    const validIds = inventories
      .filter((inventory) => !failIdsList.includes(inventory.id))
      .map((inventory) => inventory.id);

    const validInventoryOrders = inventories.filter((inventory) =>
      validIds.includes(inventory.id),
    );

    if (!isEmpty(validInventoryOrders)) {
      validInventoryOrders.forEach((inventory) => {
        inventory.status = InventoryStatusEnum.REJECT;
      });
      const queryRunner = this.connection.createQueryRunner();
      try {
        await queryRunner.startTransaction();
        await queryRunner.manager.save(Inventory, validInventoryOrders);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.REJECT_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  private async generateInventoryCode() {
    const currentDate = moment().format('DDMMYYYY');
    const lastPoImportInDay =
      await this.inventoryRepository.findOneWithRelations({
        where: { code: Like(`${INVENTORY_CODE_PREFIX}${currentDate}%`) },
        withDeleted: true,
        order: { code: 'DESC' },
      });
    if (!isEmpty(lastPoImportInDay)) {
      const lastIncreaseId = Number(lastPoImportInDay.code.slice(-3));
      const newIncreaseId = lastIncreaseId + 1;
      return `${INVENTORY_CODE_PREFIX}${currentDate}${newIncreaseId
        .toString()
        .padStart(3, '0')}`;
    }
    return `${INVENTORY_CODE_PREFIX}${currentDate}000`;
  }

  public async create(
    request: CreateInventoryDto,
  ): Promise<Inventory | ResponsePayload<any>> {
    const {
      createdByUserId,
      executeFrom,
      executeTo,
      name,
      description,
      type,
      items,
      warehouseIds,
      checkPointDataType,
      checkPointDate,
      checkPointDataAttachment,
      impersonators,
    } = request;

    const code = await this.generateInventoryCode();
    const existedInventoryTypeSuprise =
      await this.inventoryRepository.findByCondition([
        {
          executeFrom: Between(startOfDay(executeFrom), endOfDay(executeTo)),
          status: InventoryStatusEnum.CONFIRMED,
          type: InventoryTypeEnum.SURPRISE,
        },
        {
          executeTo: Between(startOfDay(executeFrom), endOfDay(executeTo)),
          status: InventoryStatusEnum.CONFIRMED,
          type: InventoryTypeEnum.SURPRISE,
        },
      ]);
    const existedInventoryTypePeriodic =
      await this.inventoryRepository.findByCondition([
        {
          executeFrom: Between(startOfDay(executeFrom), endOfDay(executeTo)),
          type: InventoryTypeEnum.PERIODIC,
          status: InventoryStatusEnum.CONFIRMED,
        },
        {
          executeTo: Between(startOfDay(executeFrom), endOfDay(executeTo)),
          type: InventoryTypeEnum.PERIODIC,
          status: InventoryStatusEnum.CONFIRMED,
        },
      ]);

    const inventoryIds = compact(map(existedInventoryTypeSuprise, 'id'));
    let listItemWrehouseInventoryPart;
    const keyWarehouseItemRequest = [];
    const keyWarehouseInventoryItemPart = [];
    if (!isEmpty(inventoryIds)) {
      listItemWrehouseInventoryPart =
        await this.warehouseInventoryItemPartRepository.getWarehouseInventoryItemPartByIds(
          inventoryIds,
        );
    }
    if (type === InventoryTypeEnum.SURPRISE) {
      warehouseIds?.forEach((w) =>
        items?.forEach((i) => keyWarehouseItemRequest.push(`${w}-${i.id}`)),
      );
      compact(listItemWrehouseInventoryPart)?.forEach((i) =>
        keyWarehouseInventoryItemPart.push(`${i.warehouseId}-${i.itemId}`),
      );
    }
    const isValidKey = keyWarehouseInventoryItemPart.filter((key) =>
      keyWarehouseItemRequest.includes(key),
    );
    if (
      !isEmpty(existedInventoryTypeSuprise) &&
      !isEmpty(isValidKey) &&
      type === InventoryTypeEnum.SURPRISE
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.UNABLE_CREATE_INVENTORY_IS_A_PAIR_SAME_KEY_WAREHOUSE_AND_ITEM',
        ),
      ).toResponse();
    }
    if (
      !isEmpty(existedInventoryTypePeriodic) &&
      type === InventoryTypeEnum.PERIODIC
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.ALREADY_HAVE_INVENTORY_IN_EXECUTION_TIME',
        ),
      ).toResponse();
    }
    const warehouses = await this.warehouseRepository.findByCondition({
      id: In(warehouseIds),
    });
    if (isEmpty(warehouses) || warehouses.length < warehouseIds.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'),
      ).toResponse();
    }
    let users = [];
    const impersonatorIds = uniq(compact(impersonators.map((e) => e.id)));
    if (!isEmpty(impersonatorIds)) {
      users = await this.userService.getUserByIds(impersonatorIds);
    }

    if (!users || impersonatorIds.length !== users.length) {
      const userIdsFound = users ? users.map((e) => e.id) : [];
      return new ResponseBuilder({
        invalidUserIds: impersonatorIds.filter(
          (id) => !userIdsFound.includes(id),
        ),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_USERS_NOT_FOUND'))
        .build();
    }
    const inventory = new Inventory();
    inventory.createdByUserId = createdByUserId;
    inventory.executeFrom = executeFrom;
    inventory.executeTo = executeTo;
    inventory.checkPointDate = checkPointDate;
    inventory.checkPointDataType = checkPointDataType;
    inventory.name = name;
    inventory.description = description;
    inventory.code = code;
    inventory.warehouses = warehouses;
    inventory.type = type;
    let generateSnapshotResult: ResponsePayload<any>;
    if (type === InventoryTypeEnum.SURPRISE && !isEmpty(items)) {
      inventory.isSelectedItems = true;
      generateSnapshotResult =
        await this.itemSnapshotInTypeSurpriseWithItems.generateSnapshot({
          checkPointDate,
          warehouseIds,
          items,
        });
    } else if (type === InventoryTypeEnum.SURPRISE && isEmpty(items)) {
      generateSnapshotResult =
        await this.itemSnapshotInTypeSurpriseWithoutItems.generateSnapshot({
          checkPointDate,
          warehouseIds,
        });
    } else if (
      type === InventoryTypeEnum.PERIODIC &&
      checkPointDataType === InventoryCheckPointDataType.INTERNAL_SNAPSHOT
    ) {
      inventory.isSnapShot = true;
      generateSnapshotResult =
        await this.itemSnapshotInTypePeriodicWithInternalData.generateSnapshot({
          checkPointDate,
          warehouseIds,
        });
    } else if (
      type === InventoryTypeEnum.PERIODIC &&
      checkPointDataType === InventoryCheckPointDataType.EXTERNAL_SNAPSHOT
    ) {
      inventory.isSnapShot = true;
      generateSnapshotResult =
        await this.snapshotDataPeriodicExternal.generateSnapshot({
          checkPointDataAttachment,
        });
    }
    let validWarehouseSnapshot = [];
    if (!isEmpty(generateSnapshotResult.data)) {
      validWarehouseSnapshot = generateSnapshotResult.data.filter((item) => {
        return !warehouseIds.includes(item.warehouseId);
      });
    }
    if (!isEmpty(validWarehouseSnapshot)) {
      return new ResponseBuilder()
        .withData(validWarehouseSnapshot)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.THE_WAREHOUSE_SNAPSHOT_MUST_MATCH_WAREHOUSE_SELECT_THE_INVENTORY',
          ),
        )
        .build();
    }

    if (generateSnapshotResult.statusCode !== ResponseCodeEnum.SUCCESS) {
      return generateSnapshotResult;
    }
    inventory.warehouseInventoryItemParts = generateSnapshotResult.data;
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const inventoryEntity = await queryRunner.manager.save(inventory);
      const inventoryImpersonators = impersonators.map((impersonator) =>
        this.inventoryImpersonatorRepository.createInventoryImpersonator({
          inventoryId: inventoryEntity.id,
          impersonatorId: impersonator.id,
        }),
      );
      inventoryEntity.inventoryImpersonators = await queryRunner.manager.save(
        inventoryImpersonators,
      );
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }

    const response = plainToInstance(InventoryResponse, inventory, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * @param  {DeleteInventoryDto} request
   * @returns Promise
   */
  public async delete(
    request: DeleteInventoryDto,
  ): Promise<ResponsePayload<any>> {
    const { inventoryId, userId } = request;

    const inventory = await this.inventoryRepository.findOneByCondition({
      id: inventoryId,
    });

    if (!inventory) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (!STATUS_TO_DELETE_INVENTORY.includes(inventory.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_DELETE_INVENTORY'),
      ).toResponse();
    }

    const [inventoryItemParts, inventoryItems] = await Promise.all([
      this.warehouseInventoryItemPartRepository.findByCondition({
        inventoryId,
      }),
      this.warehouseInventoryItemRepository.findByCondition({
        inventoryId,
      }),
    ]);

    const queryRunner = await this.connection.createQueryRunner();
    try {
      await queryRunner.startTransaction();
      inventory.deletedAt = new Date();
      inventory.deletedBy = userId;
      await queryRunner.manager.save(inventory);

      const inventoryItemPartEntites = inventoryItemParts?.map((item) => {
        item.deletedAt = new Date();
        item.deletedBy = userId;
        return item;
      });
      await queryRunner.manager.save(inventoryItemPartEntites);

      const inventoryItemEntites = inventoryItems?.map((item) => {
        item.deletedAt = new Date();
        item.deletedBy = userId;
        return item;
      });
      await queryRunner.manager.save(inventoryItemEntites);

      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    await queryRunner.release();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const inventories = await this.inventoryRepository.findByCondition({
      id: In(ids),
    });

    const inventoryIds = inventories.map((inventory) => inventory.id);
    if (inventories.length !== ids.length) {
      ids.forEach((id) => {
        if (!inventoryIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < inventories.length; i++) {
      const inventory = inventories[i];
      if (!STATUS_TO_DELETE_INVENTORY.includes(inventory.status))
        failIdsList.push(inventory.id);
    }

    const validIds = inventories
      .filter((inventory) => !failIdsList.includes(inventory.id))
      .map((inventory) => inventory.id);

    const queryRunner = await this.connection.createQueryRunner();
    try {
      if (!isEmpty(validIds)) {
        await queryRunner.startTransaction();
        await queryRunner.manager.delete(Inventory, validIds);
        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    await queryRunner.release();
    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  /**
   * @param  {CreateInventoryItemDto} request
   * @returns Promise
   */
  public async execute(
    request: CreateInventoryItemDto,
  ): Promise<ResponsePayload<any>> {
    const { inventoryId, warehouseId, items, locatorId } = request;
    const inventory = await this.inventoryRepository.findOneById(inventoryId);

    if (!inventory) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const locatorResponse = await this.warehouseLayoutService.getLocatorById(
      locatorId,
    );
    if (isEmpty(locatorResponse)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.LOCATOR_NOT_FOUND'))
        .build();
    }

    const itemIds = uniq(items.map((item) => item.itemId));
    const itemRes = await this.itemService.getItems(itemIds);
    if (itemIds.length !== itemRes.length) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.ITEM_NOT_FOUND'),
      ).toResponse();
    }

    const data = await this.itemService.getItemWarehouse(items, warehouseId);
    const lotMap: any = keyBy(flatMap(data.map((i) => i.lots)), 'lotNumber');
    let isLotNumber = true;
    const newItems: any = flatMap(
      items.map((item) => {
        return item.lots.map((lot: any) => {
          if (
            !lotMap[lot.lotNumber] &&
            moment(lot.date).format(DATE_FORMAT['YYYY-MM-DD']) >
              moment().format(DATE_FORMAT['YYYY-MM-DD'])
          ) {
            isLotNumber = false;
          }
          return {
            itemId: item.itemId,
            actualQuantity: lot.quantity,
            planQuantity: lotMap[lot.lotNumber]?.quantity
              ? lotMap[lot.lotNumber]?.quantity
              : 0,
            lotNumber: lot.lotNumber,
            mfg: lotMap[lot.lotNumber]?.mfg
              ? lotMap[lot.lotNumber]?.mfg
              : lot.date,
          };
        });
      }),
    );

    if (!isLotNumber)
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.LOT_NUMBER_IS_INVALID'),
      ).toResponse();

    if (newItems.includes(undefined)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.MFG_ERROR'),
      ).toResponse();
    }

    const warehouseInventoryItems: WarehouseInventoryItem[] = [];

    if (newItems.length) {
      for (let i = 0; i < newItems.length; i++) {
        warehouseInventoryItems.push(
          this.warehouseInventoryItemRepository.createEntity(
            request,
            newItems[i],
          ),
        );
      }
    }

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const newInventoryItem = await queryRunner.manager.save(
        warehouseInventoryItems,
      );
      inventory.status = InventoryStatusEnum.IN_PROGRESS;
      await queryRunner.manager.save(inventory);

      await queryRunner.commitTransaction();

      const dataCls = plainToInstance(InventoryItemResponse, newInventoryItem, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataCls)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      console.log(error);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      this.logger.log('===Transaction Release');
      await queryRunner.release();
    }
  }

  public async approve(
    request: ApproveInventoryItemDto,
  ): Promise<ResponsePayload<any>> {
    try {
      const { id, userId } = request;
      const inventory = await this.inventoryRepository.findOneById(id);

      if (!inventory) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      if (!STATUS_TO_APPROVE_INVENTORY.includes(inventory.status)) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.BAD_REQUEST'),
        ).toResponse();
      }

      inventory.status = InventoryStatusEnum.COMPLETE;
      inventory.approvedAt = new Date().toISOString();
      inventory.approverId = userId;

      await this.inventoryRepository.update(inventory);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  /**
   *
   * @param itemIds
   * @param userIds
   * @returns
   */
  private async getInventoryExtraInfor(
    itemIds: number[],
    userIds: number[],
    locatorIds?: number[],
  ): Promise<any> {
    const data = await Promise.all([
      this.itemService.getItems(itemIds),
      this.userService.getUserByIds(userIds),
      !locatorIds || isEmpty(locatorIds)
        ? []
        : this.warehouseLayoutService.getLocatorByIds(locatorIds, true),
    ]);
    const items = {};
    const users = {};
    data[0].forEach((i) => {
      items[i.itemId] = i;
    });
    data[1].forEach((u) => {
      users[u.id] = u;
    });

    return {
      items: items,
      users: users,
      locators: data[2],
    };
  }

  async update(
    request: UpdateInventoryDto,
  ): Promise<Inventory | ResponsePayload<any>> {
    const {
      id,
      code,
      userId,
      executeFrom,
      executeTo,
      name,
      description,
      type,
      items,
      warehouseIds,
      checkPointDataType,
      checkPointDate,
      checkPointDataAttachment,
      impersonators,
    } = request;

    const inventory = await this.inventoryRepository.findOneWithRelations({
      where: {
        id,
      },
      relations: ['warehouseInventoryItemParts'],
    });

    if (!inventory) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const existedInventoryTypeSuprise =
      await this.inventoryRepository.findByCondition([
        {
          executeFrom: Between(startOfDay(executeFrom), endOfDay(executeTo)),
          status: InventoryStatusEnum.CONFIRMED,
          type: InventoryTypeEnum.SURPRISE,
        },
        {
          executeTo: Between(startOfDay(executeFrom), endOfDay(executeTo)),
          status: InventoryStatusEnum.CONFIRMED,
          type: InventoryTypeEnum.SURPRISE,
        },
      ]);
    const existedInventoryTypePeriodic =
      await this.inventoryRepository.findByCondition([
        {
          executeFrom: Between(startOfDay(executeFrom), endOfDay(executeTo)),
          type: InventoryTypeEnum.PERIODIC,
          status: InventoryStatusEnum.CONFIRMED,
        },
        {
          executeTo: Between(startOfDay(executeFrom), endOfDay(executeTo)),
          type: InventoryTypeEnum.PERIODIC,
          status: InventoryStatusEnum.CONFIRMED,
        },
      ]);

    const inventoryIds = compact(map(existedInventoryTypeSuprise, 'id'));
    let listItemWrehouseInventoryPart;
    const keyWarehouseItemRequest = [];
    const keyWarehouseInventoryItemPart = [];
    if (!isEmpty(inventoryIds)) {
      listItemWrehouseInventoryPart =
        await this.warehouseInventoryItemPartRepository.getWarehouseInventoryItemPartByIds(
          inventoryIds,
        );
    }
    if (type === InventoryTypeEnum.SURPRISE) {
      warehouseIds?.forEach((w) =>
        items?.forEach((i) => keyWarehouseItemRequest.push(`${w}-${i.id}`)),
      );
      compact(listItemWrehouseInventoryPart)?.forEach((i) =>
        keyWarehouseInventoryItemPart.push(`${i.warehouseId}-${i.itemId}`),
      );
    }
    const isValidKey = keyWarehouseInventoryItemPart.filter((key) =>
      keyWarehouseItemRequest.includes(key),
    );
    if (
      !isEmpty(existedInventoryTypeSuprise) &&
      !isEmpty(isValidKey) &&
      type === InventoryTypeEnum.SURPRISE
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.UNABLE_CREATE_INVENTORY_IS_A_PAIR_SAME_KEY_WAREHOUSE_AND_ITEM',
        ),
      ).toResponse();
    }
    if (
      !isEmpty(existedInventoryTypePeriodic) &&
      type === InventoryTypeEnum.PERIODIC
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.ALREADY_HAVE_INVENTORY_IN_EXECUTION_TIME',
        ),
      ).toResponse();
    }
    if (!STATUS_TO_UPDATE_INVENTORY.includes(inventory.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    }

    const warehouses = await this.warehouseRepository.findByCondition({
      id: In(warehouseIds),
    });
    if (isEmpty(warehouses)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'),
      ).toResponse();
    }
    let users = [];
    const impersonatorIds = uniq(compact(impersonators.map((e) => e.id)));
    if (!isEmpty(impersonatorIds)) {
      users = await this.userService.getUserByIds(impersonatorIds);
    }

    if (!users || impersonatorIds.length !== users.length) {
      const userIdsFound = users ? users.map((e) => e.id) : [];
      return new ResponseBuilder({
        invalidUserIds: impersonatorIds.filter(
          (id) => !userIdsFound.includes(id),
        ),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_USERS_NOT_FOUND'))
        .build();
    }

    inventory.updatedBy = userId;
    inventory.executeFrom = executeFrom;
    inventory.executeTo = executeTo;
    inventory.checkPointDate = checkPointDate;
    inventory.checkPointDataType = checkPointDataType;
    inventory.name = name;
    inventory.description = description;
    inventory.warehouses = warehouses;
    inventory.updatedBy = userId;
    if (inventory.status === InventoryStatusEnum.REJECT) {
      inventory.status = InventoryStatusEnum.CREATED;
    }
    let generateSnapshotResult: ResponsePayload<any>;
    let warehouseInventoryItemParts: WarehouseInventoryItemPartEntity[];
    if (
      type === InventoryTypeEnum.SURPRISE &&
      !isEmpty(items) &&
      (isSameDate(checkPointDate, inventory.checkPointDate) ||
        !isEmpty(
          difference(
            warehouseIds,
            inventory.warehouses.map((warehouse) => warehouse.id),
          ),
        ) ||
        type !== inventory.type)
    ) {
      inventory.isSelectedItems = true;
      generateSnapshotResult =
        await this.itemSnapshotInTypeSurpriseWithItems.generateSnapshot({
          checkPointDate,
          warehouseIds,
          items,
        });
    } else if (
      type === InventoryTypeEnum.SURPRISE &&
      isEmpty(items) &&
      (isSameDate(checkPointDate, inventory.checkPointDate) ||
        !isEmpty(
          difference(
            warehouseIds,
            inventory.warehouses.map((warehouse) => warehouse.id),
          ),
        ) ||
        type !== inventory.type)
    ) {
      generateSnapshotResult =
        await this.itemSnapshotInTypeSurpriseWithoutItems.generateSnapshot({
          checkPointDate,
          warehouseIds,
        });
    } else if (
      type === InventoryTypeEnum.PERIODIC &&
      checkPointDataType === InventoryCheckPointDataType.INTERNAL_SNAPSHOT &&
      (!isSameDate(checkPointDate, inventory.checkPointDate) ||
        !isEmpty(
          difference(
            warehouseIds,
            inventory.warehouses.map((warehouse) => warehouse.id),
          ),
        ) ||
        type !== inventory.type)
    ) {
      inventory.isSnapShot = true;
      generateSnapshotResult =
        await this.itemSnapshotInTypePeriodicWithInternalData.generateSnapshot({
          checkPointDate,
          warehouseIds,
        });
    } else if (
      type === InventoryTypeEnum.PERIODIC &&
      checkPointDataType === InventoryCheckPointDataType.EXTERNAL_SNAPSHOT
    ) {
      inventory.isSnapShot = true;
      generateSnapshotResult =
        await this.snapshotDataPeriodicExternal.generateSnapshot({
          checkPointDataAttachment,
        });
    }
    if (
      generateSnapshotResult &&
      generateSnapshotResult.statusCode !== ResponseCodeEnum.SUCCESS
    ) {
      return generateSnapshotResult;
    }
    let validWarehouseSnapshot = [];
    if (!isEmpty(generateSnapshotResult?.data)) {
      validWarehouseSnapshot = generateSnapshotResult?.data.filter((item) => {
        return !warehouseIds.includes(item.warehouseId);
      });
    }
    if (!isEmpty(validWarehouseSnapshot)) {
      return new ResponseBuilder()
        .withData(validWarehouseSnapshot)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.THE_WAREHOUSE_SNAPSHOT_MUST_MATCH_WAREHOUSE_SELECT_THE_INVENTORY',
          ),
        )
        .build();
    }
    warehouseInventoryItemParts = generateSnapshotResult?.data || [];
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (
        !isEmpty(inventory.warehouseInventoryItemParts) &&
        !isEmpty(warehouseInventoryItemParts)
      ) {
        await queryRunner.manager.delete(
          WarehouseInventoryItemPartEntity,
          inventory.warehouseInventoryItemParts,
        );
        inventory.warehouseInventoryItemParts = warehouseInventoryItemParts;
      }
      inventory.type = type;
      const inventoryEntity = await queryRunner.manager.save(inventory);

      const inventoryImpersonators = impersonators.map((impersonator) =>
        this.inventoryImpersonatorRepository.createInventoryImpersonator({
          inventoryId: inventoryEntity.id,
          impersonatorId: impersonator.id,
        }),
      );
      const isUpdate = inventoryEntity.id !== undefined;
      if (isUpdate) {
        await queryRunner.manager.delete(InventoryImpersonatorEntity, {
          inventoryId: inventoryEntity.id,
        });
      }
      inventoryEntity.inventoryImpersonators = await queryRunner.manager.save(
        inventoryImpersonators,
      );
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
    const response = plainToInstance(InventoryResponse, inventory, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getListWarning(request: PaginationQuery): Promise<any> {
    const { data } = await this.itemService.getWarning(request);
    let items = data?.items;
    if (items.length === 0) {
      return new ResponseBuilder([])
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    const warehouseIds = uniq(map(items, 'warehouseId'));
    const warehouses = await this.warehouseRepository.findByCondition({
      id: In(warehouseIds),
    });
    const warehousesKeyBy = keyBy(warehouses, 'id');

    const locatorIds = uniq(map(items, 'locatorId'));
    const locators = await this.warehouseLayoutService.getLocatorByIds(
      locatorIds,
      true,
    );
    const locatorsKeyBy = keyBy(locators, 'id');

    items = items.map((i) => {
      return {
        ...i,
        warehouse: warehousesKeyBy[i.warehouseId] || {},
        locator: locatorsKeyBy[i.locatorId] || {},
      };
    });
    const resData = plainToClass(GetWaringListResponseDto, items, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      items: resData,
      meta: data.meta,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private calculateQuantityInInventoryDetail({
    itemImportedFromCheckPointToExecuteDate,
    itemExportedFromCheckPointToExecuteDate,
    itemImportedFromStartExecute,
    itemExportedFromStartExecute,
    warehouseInventoryItem,
    itemPlanQuantity,
  }): any {
    const importedQuantityFromCheckPointToExecuteDate =
      Number(itemImportedFromCheckPointToExecuteDate?.quantity) || 0;
    const exportedQuantityFromCheckPointToExecuteDate =
      Number(itemExportedFromCheckPointToExecuteDate?.quantity) || 0;
    const importedQuantityFromStartExecute =
      Number(itemImportedFromStartExecute?.quantity) || 0;
    const exportedQuantityFromStartExecute =
      Number(itemExportedFromStartExecute?.quantity) || 0;
    const actualInventoryQuantity =
      Number(warehouseInventoryItem?.actualQuantity) || 0;
    const inventoryQuantityAtExecuteDate =
      Number(itemPlanQuantity) +
      importedQuantityFromCheckPointToExecuteDate -
      exportedQuantityFromCheckPointToExecuteDate;
    const actualRemainingQuantityAtCheckPoint =
      actualInventoryQuantity +
      importedQuantityFromStartExecute -
      exportedQuantityFromStartExecute;
    const remainingQuantityAtCheckPoint =
      inventoryQuantityAtExecuteDate +
      importedQuantityFromStartExecute -
      exportedQuantityFromStartExecute;
    const excessQuantity =
      actualRemainingQuantityAtCheckPoint > exportedQuantityFromStartExecute
        ? actualRemainingQuantityAtCheckPoint - exportedQuantityFromStartExecute
        : 0;
    const missingQuantity =
      importedQuantityFromStartExecute > actualRemainingQuantityAtCheckPoint
        ? importedQuantityFromStartExecute - actualRemainingQuantityAtCheckPoint
        : 0;

    return {
      importedQuantityFromCheckPointToExecuteDate,
      exportedQuantityFromCheckPointToExecuteDate,
      inventoryQuantityAtExecuteDate,
      actualInventoryQuantity,
      importedQuantityFromStartExecute,
      exportedQuantityFromStartExecute,
      remainingQuantityAtCheckPoint,
      actualRemainingQuantityAtCheckPoint,
      excessQuantity,
      missingQuantity,
    };
  }

  private convertArrayToObjectByMappingKey(array) {
    return keyBy(
      array.map((item) => ({
        ...item,
        mappingKey: `${item.itemId}-${item.warehouseId}`,
      })),
      'mappingKey',
    );
  }

  public async getItemInventoryQuantity(
    request: GetItemInventoryQuantityRequestDto,
  ): Promise<any> {
    const { id } = request;
    const inventory = await this.inventoryRepository.findOneWithRelations({
      where: { id },
      relations: ['warehouses'],
    });

    if (isEmpty(inventory)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const [data, count] =
      await this.warehouseInventoryItemPartRepository.getWarehouseInventoryItemPartByItems(
        request,
      );

    if (isEmpty(data)) {
      return new ResponseBuilder({
        items: [],
        meta: { total: count, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const itemIds = uniq(data.map((item) => item.itemId));
    const warehouseIds = inventory.warehouses?.map((warehouse) => warehouse.id);
    const locatorIds = uniq(
      flatten(
        data.map((item) => item.lots?.map((lot) => lot.locatorId)),
      ).filter((locator) => locator != null),
    );
    const [
      itemImportedFromCheckPointToExecuteDate,
      itemExportedFromCheckPointToExecuteDate,
      itemImportedFromStartExecute,
      itemExportedFromStartExecute,
      warehouseInventoryItems,
    ] = await Promise.all([
      this.itemService.getItemStockQuantity({
        from: startOfDay(inventory.checkPointDate),
        to: endOfDay(inventory.executeFrom),
        orderType: ItemStockMovementTypeEnum.Import,
        warehouseIds,
        itemIds,
      } as GetItemStockQuantityRequestDto),
      this.itemService.getItemStockQuantity({
        from: startOfDay(inventory.checkPointDate),
        to: endOfDay(inventory.executeFrom),
        orderType: ItemStockMovementTypeEnum.Export,
        warehouseIds,
        itemIds,
      } as GetItemStockQuantityRequestDto),
      this.itemService.getItemStockQuantity({
        from: startOfDay(inventory.executeFrom),
        to:
          moment().endOf('day') < moment(inventory.executeTo)
            ? moment().endOf('day')
            : endOfDay(inventory.executeTo),
        orderType: ItemStockMovementTypeEnum.Import,
        warehouseIds,
        itemIds,
      } as GetItemStockQuantityRequestDto),
      this.itemService.getItemStockQuantity({
        from: startOfDay(inventory.executeFrom),
        to:
          moment().endOf('day') < moment(inventory.executeTo)
            ? moment().endOf('day')
            : endOfDay(inventory.executeTo),
        orderType: ItemStockMovementTypeEnum.Export,
        warehouseIds,
        itemIds,
      } as GetItemStockQuantityRequestDto),
      this.warehouseInventoryItemRepository.getWarehouseInventoryItems(
        id,
        itemIds,
      ),
    ]);
    const { items, locators } = await this.getInventoryExtraInfor(
      itemIds,
      [],
      locatorIds,
    );

    const itemImportedFromCheckPointToExecuteDateByItemIds =
      this.convertArrayToObjectByMappingKey(
        itemImportedFromCheckPointToExecuteDate,
      );
    const itemExportedFromCheckPointToExecuteDateByItemIds =
      this.convertArrayToObjectByMappingKey(
        itemExportedFromCheckPointToExecuteDate,
      );
    const itemImportedFromStartExecuteByItemIds =
      this.convertArrayToObjectByMappingKey(itemImportedFromStartExecute);
    const itemExportedFromStartExecuteByItemIds =
      this.convertArrayToObjectByMappingKey(itemExportedFromStartExecute);
    const warehouseInventoryItemByItemIds =
      this.convertArrayToObjectByMappingKey(warehouseInventoryItems);

    const dataReturn = data.map((item) => {
      const quantities = this.calculateQuantityInInventoryDetail({
        itemImportedFromCheckPointToExecuteDate:
          itemImportedFromCheckPointToExecuteDateByItemIds[
            `${item.itemId}-${item.warehouseId}`
          ],
        itemExportedFromCheckPointToExecuteDate:
          itemExportedFromCheckPointToExecuteDateByItemIds[
            `${item.itemId}-${item.warehouseId}`
          ],
        itemImportedFromStartExecute:
          itemImportedFromStartExecuteByItemIds[
            `${item.itemId}-${item.warehouseId}`
          ],
        itemExportedFromStartExecute:
          itemExportedFromStartExecuteByItemIds[
            `${item.itemId}-${item.warehouseId}`
          ],
        warehouseInventoryItem:
          warehouseInventoryItemByItemIds[`${item.itemId}-${item.warehouseId}`],
        itemPlanQuantity: item.planQuantity,
      });

      return {
        ...item,
        ...quantities,
        item: items[item.itemId],
        lots: item.lots
          ?.filter((lot) => lot.lotNumber)
          ?.map((lot) => {
            const lotImportedFromCheckPointToExecuteDate =
              itemImportedFromCheckPointToExecuteDateByItemIds[
                `${item.itemId}-${item.warehouseId}`
              ]?.lots?.find((itemLot) => itemLot.lotNumber === lot.lotNumber);
            const lotExportedFromCheckPointToExecuteDate =
              itemExportedFromCheckPointToExecuteDateByItemIds[
                `${item.itemId}-${item.warehouseId}`
              ]?.lots?.find((itemLot) => itemLot.lotNumber === lot.lotNumber);
            const lotImportedFromStartExecute =
              itemImportedFromStartExecuteByItemIds[
                `${item.itemId}-${item.warehouseId}`
              ]?.lots?.find((itemLot) => itemLot.lotNumber === lot.lotNumber);
            const lotExportedFromStartExecute =
              itemExportedFromStartExecuteByItemIds[
                `${item.itemId}-${item.warehouseId}`
              ]?.lots?.find((itemLot) => itemLot.lotNumber === lot.lotNumber);
            const lotWarehouseInventoryItem = warehouseInventoryItemByItemIds[
              `${item.itemId}-${item.warehouseId}`
            ]?.lots?.find((itemLot) => itemLot.lotNumber === lot.lotNumber);

            const lotQuantities = this.calculateQuantityInInventoryDetail({
              itemImportedFromCheckPointToExecuteDate:
                lotImportedFromCheckPointToExecuteDate,
              itemExportedFromCheckPointToExecuteDate:
                lotExportedFromCheckPointToExecuteDate,
              itemImportedFromStartExecute: lotImportedFromStartExecute,
              itemExportedFromStartExecute: lotExportedFromStartExecute,
              warehouseInventoryItem: lotWarehouseInventoryItem,
              itemPlanQuantity: item.planQuantity,
            });
            return {
              ...lot,
              ...lotQuantities,
              locatorCode: locators[lot.locatorId]?.code,
              item: items[lot.itemId],
              executeDate: lotWarehouseInventoryItem?.executeDate,
            };
          }),
      };
    });
    const result = plainToInstance(
      GetItemInventoryQuantityResponseDto,
      dataReturn,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder({
      items: result,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getListItemInventory(
    request: GetListItemInventoryRequestDto,
    filterItemIds?: number[],
  ): Promise<any> {
    const { id, keyword } = request;
    const inventory = await this.inventoryRepository.findOneWithRelations({
      where: { id },
      relations: ['warehouses'],
    });

    if (isEmpty(inventory)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const scanItemCodeFilter = find(
      request.filter,
      (f) => f.column === 'itemCode',
    );
    if (!isEmpty(scanItemCodeFilter)) {
      const items = await this.itemService.getItemsByCode(
        scanItemCodeFilter,
        false,
      );
      if (isEmpty(items)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
      filterItemIds = map(items, 'id');
    }
    if (keyword) {
      const listItem = await this.itemService.getItemsByNameOrCode(
        keyword,
        true,
      );
      if (isEmpty(listItem)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
      filterItemIds = map(listItem, 'id');
    }
    const [data, count] =
      await this.warehouseInventoryItemPartRepository.getListItemInventory(
        request,
        filterItemIds,
      );
    if (isEmpty(data)) {
      return new ResponseBuilder({
        items: [],
        meta: { total: count, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const itemIds = uniq(data.map((item) => item.itemId));
    const warehouseIds = inventory.warehouses?.map((warehouse) => warehouse.id);
    const locatorIds = uniq(
      flatten(
        data.map((item) => item.lots?.map((lot) => lot.locatorId)),
      ).filter((locator) => locator != null),
    );
    const [warehouseInventoryItems] = await Promise.all([
      this.itemService.getItemStockQuantity({
        from: startOfDay(inventory.executeFrom),
        to:
          moment().endOf('day') < moment(inventory.executeTo)
            ? moment().endOf('day')
            : endOfDay(inventory.executeTo),
        orderType: ItemStockMovementTypeEnum.Export,
        warehouseIds,
        itemIds,
      } as GetItemStockQuantityRequestDto),
      this.warehouseInventoryItemRepository.getWarehouseInventoryItems(
        id,
        itemIds,
      ),
    ]);
    const { items, locators } = await this.getInventoryExtraInfor(
      itemIds,
      [],
      locatorIds,
    );
    const warehouseInventoryItemByItemIds =
      this.convertArrayToObjectByMappingKey(warehouseInventoryItems);
    const dataReturn = data.map((item) => {
      return {
        ...item,
        item: items[item.itemId],
        lots: item.lots
          ?.filter((lot) => lot.lotNumber)
          ?.map((lot) => {
            const lotWarehouseInventoryItem = warehouseInventoryItemByItemIds[
              `${item.itemId}-${item.warehouseId}`
            ]?.lots?.find((itemLot) => itemLot.lotNumber === lot.lotNumber);
            return {
              ...lot,
              locatorCode: locators[lot.locatorId]?.code,
              item: items[lot.itemId],
              executeDate: lotWarehouseInventoryItem?.executeDate,
            };
          }),
      };
    });
    const result = plainToInstance(
      GetItemInventoryQuantityResponseDto,
      dataReturn,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder({
      items: result,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getItemInventoryPartDetail(
    request: GetItemInventoryQuantityRequestDto,
  ): Promise<any> {
    const { id } = request;
    const inventory = await this.inventoryRepository.findOneById(id);

    if (isEmpty(inventory)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const [itemParts, count] =
      await this.warehouseInventoryItemPartRepository.getWarehouseInventoryItemParts(
        request,
      );
    const itemIds = itemParts?.map((item) => item.itemId);
    const locatorIds = itemParts?.map((item) => item.locatorId);
    const { items, locators } = await this.getInventoryExtraInfor(
      itemIds,
      [],
      locatorIds,
    );

    const dataReturn = plainToInstance(
      GetItemInventoryPartsResponseDto,
      itemParts?.map((item) => ({
        ...item,
        item: items[item.itemId],
        locatorCode: locators[item.locatorId]?.code,
      })),
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async checkItemNotExecute(id: number): Promise<any> {
    const inventory = await this.inventoryRepository.findOneById(id);
    if (!inventory) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const itemsInventory =
      await this.warehouseInventoryItemRepository.findByCondition({
        inventoryId: id,
      });
    if (isEmpty(itemsInventory)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEMS_ARE_NOT_EXECUTED'))
        .build();
    }

    const itemConditions = itemsInventory?.map((item) => ({
      inventoryId: id,
      itemId: Not(item.itemId),
      lotNumber: Not(item.lotNumber),
      locatorId: Not(item.locatorId),
    }));
    const itemsNotExecuted =
      await this.warehouseInventoryItemPartRepository.findByCondition([
        ...itemConditions,
      ]);

    if (isEmpty(itemsNotExecuted)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('message.SUCCESS'))
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(await this.i18n.translate('error.ITEMS_ARE_NOT_EXECUTED'))
      .build();
  }
}
