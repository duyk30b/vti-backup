export enum InventoryStatusEnum {
  CREATED = 1,
  CONFIRMED = 2,
  REJECT = 3,
  COMPLETE = 4,
  IN_PROGRESS = 5,
}

export const STATUS_TO_CONFIRM_INVENTORY = [InventoryStatusEnum.CREATED];
export const STATUS_TO_APPROVE_INVENTORY = [
  InventoryStatusEnum.CONFIRMED,
  InventoryStatusEnum.IN_PROGRESS,
];
export const STATUS_TO_DELETE_INVENTORY = [
  InventoryStatusEnum.CREATED,
  InventoryStatusEnum.REJECT,
];
export const STATUS_TO_UPDATE_INVENTORY = [
  InventoryStatusEnum.CREATED,
  InventoryStatusEnum.REJECT,
];

export enum InventoryTypeEnum {
  PERIODIC,
  SURPRISE,
  BLIND,
}

export enum InventoryCheckPointDataType {
  EXTERNAL_SNAPSHOT = 0,
  INTERNAL_SNAPSHOT = 1,
}

export const DATE_FORMAT = {
  YYYYMMDDHHmmss: 'YYYYMMDDHHmmss',
  'YYYY-MM-DD': 'YYYY-MM-DD',
};

export const INVENTORY_CODE_PREFIX = 'K';

export const MAX_LENGTH_LOT_NUMBER = 10;
