import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty, keyBy } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { In } from 'typeorm';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';

@Injectable()
export class CheckPointExternalDataImport extends ImportDataAbstract {
  private readonly FIELD_TEMPLATE_CONST = {
    CODE: {
      DB_COL_NAME: 'warehouseCode',
      COL_NAME: ['Warehouse code', '倉庫コード', 'Mã kho'],
      MAX_LENGTH: 4,
      ALLOW_NULL: false,
      REGEX: /^([a-zA-Z0-9]+)$/,
    },
    ITEM_CODE: {
      DB_COL_NAME: 'itemCode',
      COL_NAME: ['Item code', '倉庫名', 'Mã vật tư'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    ITEM_NAME: {
      DB_COL_NAME: 'itemName',
      COL_NAME: ['Item name', '倉庫名', 'Tên vật tư'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    LOT_NUMBER: {
      DB_COL_NAME: 'lotNumber',
      COL_NAME: ['Lot number', '倉庫種類', 'Số lô'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    QUANTITY: {
      DB_COL_NAME: 'quantity',
      COL_NAME: ['Quantity', '倉庫種類', 'Số lượng'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    REQUIRED_COL_NUM: 5,
  };

  constructor(
    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,
    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    this.fieldsMap.groupSet(
      [1, 2, 3, 4, 5],
      [
        this.FIELD_TEMPLATE_CONST.CODE,
        this.FIELD_TEMPLATE_CONST.ITEM_CODE,
        this.FIELD_TEMPLATE_CONST.ITEM_NAME,
        this.FIELD_TEMPLATE_CONST.LOT_NUMBER,
        this.FIELD_TEMPLATE_CONST.QUANTITY,
      ],
    );
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
  ): Promise<ImportResponseDto | any> {
    const { warehouseNotFound, itemNotExisted } = await this.getMessage();
    const entities = [];

    const warehouseCodes = dataDto.map((i) => i.warehouseCode);
    const existedWarehouses = await this.warehouseRepository.findByCondition({
      code: In(warehouseCodes),
    });
    const existedWarehouseByCodes = keyBy(existedWarehouses, 'code');

    const itemCodes = dataDto.map((i) => i.itemCode);
    const existedItems = await this.itemService.getItems(itemCodes);
    const existedItemByCodes = keyBy(existedItems, 'code');
    for (let index = 0; index <= dataDto.length; index++) {
      const data = dataDto[index];
      const { i, action, warehouseCode, itemCode } = data;
      const msgLogs = [];
      const logRow = {
        id: i,
        row: i,
        action: action,
      } as ImportResultDto;

      if (!existedWarehouseByCodes[warehouseCode]) {
        msgLogs.push(warehouseNotFound);
        logRow.log = msgLogs;
        logs.push(logRow);
        continue;
      }

      if (!existedItemByCodes[itemCode]) {
        msgLogs.push(itemNotExisted);
        logRow.log = msgLogs;
        logs.push(logRow);
        continue;
      }

      entities.push(data);
    }
    if (!isEmpty(entities)) {
      return entities;
    } else {
      const response = new ImportResponseDto();
      response.result = logs;
      response.totalCount = logs.length;
      response.result;
      return response;
    }
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto> | any> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_CONST.REQUIRED_COL_NUM,
    );
  }
}
