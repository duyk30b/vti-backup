import { ImportFileDataAbstract } from '@core/abstracts/import-file-data.abstract';
import { InjectDataSource } from '@nestjs/typeorm';
import { In, Not } from 'typeorm';
import { flatMap, has } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ConfigService } from '@nestjs/config';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { Inject } from '@nestjs/common';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { keyBy, uniq, isEmpty, map } from 'lodash';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { WarehouseByLotManagementEnum } from '@components/warehouse/warehouse.constant';
import { MAX_LENGTH_LOT_NUMBER } from '../inventory.contant';

export class WarehouseInventoryItemPartImport extends ImportFileDataAbstract {
  private readonly FIELD_TEMPLATE_ITEM_CONST = {
    WAREHOUSE_CODE: {
      DB_COL_NAME: 'warehouseCode',
      COL_NAME: 'Mã kho',
      MAX_LENGTH: 50,
      ALLOW_NULL: false,
    },
    ITEM_CODE: {
      DB_COL_NAME: 'itemCode',
      COL_NAME: 'Mã vật tư',
      MAX_LENGTH: 50,
      ALLOW_NULL: false,
    },
    ITEM_NAME: {
      DB_COL_NAME: 'itemName',
      COL_NAME: 'Tên vật tư',
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    ITEM_UNIT: {
      DB_COL_NAME: 'unitName',
      COL_NAME: 'Đơn vị tính',
      MAX_LENGTH: 50,
      ALLOW_NULL: true,
    },
    LOT_NUMBER: {
      DB_COL_NAME: 'lotNumber',
      COL_NAME: 'Lô',
      MAX_LENGTH: 10,
      ALLOW_NULL: true,
    },
    QUANTITY: {
      DB_COL_NAME: 'quantity',
      COL_NAME: 'Số lượng sổ sách',
      ALLOW_NULL: true,
      REGEX_QUANTITY: /^[^\-!@#$%^&*()?":{}|<>].*$/,
    },
    REQUIRED_COL_NUM: 6,
  };
  private readonly SHEET_NAME = '';
  FIELD_TEMPLATE_CONST: any;

  constructor(
    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
    this.SHEET_NAME = this.i18n.translate(
      'file-header.SHEET_NAME_FILE_IMPORT_WAREHOUSE_INVENTORY_ITEM_PART',
    );
  }

  private init() {
    this.fieldsMap.groupSet(
      [1, 2, 3, 4, 5, 6],
      [
        this.FIELD_TEMPLATE_ITEM_CONST.WAREHOUSE_CODE,
        this.FIELD_TEMPLATE_ITEM_CONST.ITEM_CODE,
        this.FIELD_TEMPLATE_ITEM_CONST.ITEM_NAME,
        this.FIELD_TEMPLATE_ITEM_CONST.ITEM_UNIT,
        this.FIELD_TEMPLATE_ITEM_CONST.LOT_NUMBER,
        this.FIELD_TEMPLATE_ITEM_CONST.QUANTITY,
      ],
    );
  }
  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
  ): Promise<ImportResponseDto | any> {
    const filteredData = [];
    const filteredDataMap = {};
    dataDto.forEach((item) => {
      const key = `${item.warehouseCode}-${item.itemCode}-${item.quantity};`;
      if (!has(filteredDataMap, key)) {
        filteredDataMap[key] = true;
        filteredData.push(item);
      }
    });
    const warehousesCode = uniq(dataDto.map((e) => e.warehouseCode));
    const itemsCode = uniq(dataDto.map((e) => e.itemCode));
    const unitNames = dataDto
      .filter((data) => !!data.unitName)
      .map((data) => data.unitName);
    const [warehousesData, itemsData, itemUnitSettings] = await Promise.all([
      this.warehouseRepository.findByCondition({
        code: In(warehousesCode),
      }),
      this.itemService.getItemByCodes(itemsCode),
      this.itemService.getItemUnitSettingByNames(unitNames, true),
    ]);
    const itemsDataCode = map(itemsData, 'code');
    const warehousesDataCode = map(warehousesData, 'code');
    if (
      !warehousesData ||
      warehousesCode.length !== warehousesDataCode.length
    ) {
      return new ResponseBuilder({
        invalidWarehouseCodes: warehousesCode.filter(
          (code) => !warehousesDataCode.includes(code),
        ),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
        .build();
    }
    if (!itemsData || itemsCode.length !== itemsDataCode.length) {
      return new ResponseBuilder({
        invalidItemCodes: itemsCode.filter(
          (code) => !itemsDataCode.includes(code),
        ),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }
    //Kiểm tra độ dài của lot khi kho là quản lí theo lô
    const warehouseDataMap = keyBy(dataDto, 'warehouseCode');
    let validLotNumber = false;
    warehousesData.forEach((warehouse) => {
      if (
        warehouse.manageByLot === WarehouseByLotManagementEnum.LOT &&
        has(warehouseDataMap, warehouse.code) &&
        warehouseDataMap[warehouse.code].lotNumber.length <
          MAX_LENGTH_LOT_NUMBER
      ) {
        validLotNumber = true;
      }
    });
    if (validLotNumber) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          'error.THE_LENGTH_OF_LOTNUMBER_CANNOT_EXCEED_10_CHARACTERS',
        )
        .build();
    }
    if (!isEmpty(logs)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(map(flatMap(logs, 'log')).join('-'))
        .build();
    }
    const warehousesByCode = keyBy(warehousesData, 'code');
    const itemsByCode = keyBy(itemsData, 'code');
    const items = filteredData.map((data) => ({
      warehouseId: warehousesByCode[data.warehouseCode]?.id,
      warehouseCode: warehousesByCode[data.warehouseCode]?.code,
      itemCode: itemsByCode[data.itemCode]?.code || data.itemCode,
      id: itemsByCode[data.itemCode]?.id,
      itemName: itemsByCode[data.itemCode]?.name || data?.itemName,
      unitName: itemUnitSettings[data.unitName]?.name || data?.unitName,
      lotNumber: data?.lotNumber,
      planQuantity: data.quantity,
    }));
    return new ResponseBuilder(items)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto> | any> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_ITEM_CONST.REQUIRED_COL_NUM,
      this.SHEET_NAME,
    );
  }
}
