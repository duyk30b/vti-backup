import { ReportTotalOrderRequestDto } from '@components/dashboard/dto/request/report-total-order.request.dto';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { WarehouseExportProposalDetailEntity } from '@entities/warehouse-export-proposal/warehouse-export-proposal-detail.entity';
import { WarehouseExportProposalEntity } from '@entities/warehouse-export-proposal/warehouse-export-proposal.entity';
import { CreateWarehouseExportProposalRequestDto } from '../dto/request/create-warehouse-export-proposal.request.dto';
import { GetListWarehouseExportProposalRequestDto } from '../dto/request/get-list-warehouse-export-proposal.request.dto';
import { UpdateWarehouseExportProposalRequestDto } from '../dto/request/update-warehouse-export-proposal.request.dto';
export interface WarehouseExportProposalRepositoryInterface
  extends BaseAbstractRepository<WarehouseExportProposalEntity> {
  createEntityWithRelation(
    request: CreateWarehouseExportProposalRequestDto,
    warehouseExportProposalDetaiEntity: WarehouseExportProposalDetailEntity[],
  ): WarehouseExportProposalEntity;
  getList(request: GetListWarehouseExportProposalRequestDto): Promise<any>;
  updateEntityBeforeConfirm(
    request: UpdateWarehouseExportProposalRequestDto,
    warehouseExportProposalDetaiEntities: WarehouseExportProposalDetailEntity[],
  ): WarehouseExportProposalEntity;
  updateEntity(
    warehouseExportProposalEntity: WarehouseExportProposalEntity,
    request: UpdateWarehouseExportProposalRequestDto,
  ): WarehouseExportProposalEntity;
  getDetail(id: number): Promise<any>;
  reportTotalOrder(request: ReportTotalOrderRequestDto): Promise<number>;
  getLastWarehouseExportProposalByGenerateCode(
    date: string,
    departmentCode: string,
  ): Promise<WarehouseExportProposalEntity>;
  checkIsCompleteQuantityWarehouseExport(id: number): Promise<any>;
}
