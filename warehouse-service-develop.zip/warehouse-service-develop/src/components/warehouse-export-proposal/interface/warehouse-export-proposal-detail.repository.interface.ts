import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { WarehouseExportProposalDetailEntity } from '@entities/warehouse-export-proposal/warehouse-export-proposal-detail.entity';

export interface WarehouseExportProposalDetailRepositoryInterface
  extends BaseAbstractRepository<WarehouseExportProposalDetailEntity> {
  createEntity(data: any): WarehouseExportProposalDetailEntity;
  updateImportedQuantity(
    warehouseExportProposalDetailEntity: WarehouseExportProposalDetailEntity,
    request: any,
  ): WarehouseExportProposalDetailEntity;
}
