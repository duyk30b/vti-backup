import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { WarehouseExportProposalDetailChildEntity } from '@entities/warehouse-export-proposal/warehouse-export-proposal-detail-child.entity';

export interface WarehouseExportProposalDetailChildRepositoryInterface
  extends BaseAbstractRepository<WarehouseExportProposalDetailChildEntity> {
  createEntity(data: any): WarehouseExportProposalDetailChildEntity;
}
