import { ChangeStatusWarehouseExportProposalRequestDto } from '../dto/request/change-status-warehouse-export-porposal.request.dto';
import { CreateWarehouseExportProposalRequestDto } from '../dto/request/create-warehouse-export-proposal.request.dto';
import { DeleteWarehouseExportProposalRequestDto } from '../dto/request/delete-warehouse-export-proposal.request.dto';
import { GetListWarehoseExportProposalByIdsRequestDto } from '../dto/request/get-list-warehouse-export-proposal-by-ids.request';
import { GetListWarehouseExportProposalRequestDto } from '../dto/request/get-list-warehouse-export-proposal.request.dto';
import { ImportWarehouseExportProposalRequestDto } from '../dto/request/import-warehouse-export-proposal.request.dto';
import { RequestItemCodeWarehouseExportPorposalRequestDto } from '../dto/request/request-item-code-proposal.request.dto';
import { UpdateItemExportedWarehouseExportProposalRequestDto } from '../dto/request/update-item-exported-warehouse-export-proposal.request.dto';
import { UpdateItemRemainingWarehouseExportProposalRequestDto } from '../dto/request/update-item-planning-warehouse-export-proposal.request.dto';
import { UpdateWarehouseExportProposalAfterConfirmRequestDto } from '../dto/request/update-warehouse-export-proposal-after-confirm.request.dto';
import { UpdateWarehouseExportProposalRequestDto } from '../dto/request/update-warehouse-export-proposal.request.dto';

export interface WarehouseExportProposalServiceInterface {
  create(request: CreateWarehouseExportProposalRequestDto): Promise<any>;
  requestItemCode(
    request: RequestItemCodeWarehouseExportPorposalRequestDto,
  ): Promise<any>;
  confirm(request: ChangeStatusWarehouseExportProposalRequestDto): Promise<any>;
  reject(request: ChangeStatusWarehouseExportProposalRequestDto): Promise<any>;
  getList(request: GetListWarehouseExportProposalRequestDto): Promise<any>;
  delete(request: DeleteWarehouseExportProposalRequestDto): Promise<any>;
  updateEntity(request: UpdateWarehouseExportProposalRequestDto): Promise<any>;
  updateEntityAfterConfirm(
    request: UpdateWarehouseExportProposalAfterConfirmRequestDto,
  ): Promise<any>;
  detail(id: number): Promise<any>;
  getWarehouseExportProposalItems(
    id: number,
    warehouseId: number,
  ): Promise<any>;
  exportSupplyExportProposal(id: number): Promise<any>;
  import(payload: ImportWarehouseExportProposalRequestDto): Promise<any>;
  updateItemRemainingWarehouseExportProposal(
    request: UpdateItemRemainingWarehouseExportProposalRequestDto,
  ): Promise<any>;
  rollbackItemRemainingWarehouseExportProposal(
    request: UpdateItemRemainingWarehouseExportProposalRequestDto,
  ): Promise<any>;
  updateItemExportedWarehouseExportProposal(
    request: UpdateItemExportedWarehouseExportProposalRequestDto,
  ): Promise<any>;
  getWarehouseExportProposalByIds(
    request: GetListWarehoseExportProposalByIdsRequestDto,
  ): Promise<any>;
  getWarehouseExportProposalByCodes(codes: string[]): Promise<any>;
}
