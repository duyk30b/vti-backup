import { TableColumn } from '@entities/report/report.model';
export const WAREHOUSE_EXORT_PROPOSAL = 'warehouse_export_proposal';

export enum StatusWarehouseExportProposalEnum {
  PENDING = 0,
  COMFIRMED = 1,
  REJECTED = 2,
  IN_PROGRESS = 3,
  COMPLETED = 4,
}

export enum StatusExportWarehouseEnum {
  NO_EXPORT = 0,
  IN_PROGRESS = 1,
  COMPLETED = 2,
}

export enum StatusRequestItemCodeEnum {
  WAITING = 0,
  COMPLETE = 1,
}
export const CONFIRMABLE_WAREHOUSE_EXPORT_PROPOSAL_STATUSES = [
  StatusWarehouseExportProposalEnum.REJECTED,
  StatusWarehouseExportProposalEnum.PENDING,
];
export const REJECTABLE_WAREHOUSE_EXPORT_PROPOSAL_STATUSES = [
  StatusWarehouseExportProposalEnum.PENDING,
];
export const STATUS_TO_UPDATE_WAREHOUSE_EXPORT_PROPOSAL = [
  StatusWarehouseExportProposalEnum.COMFIRMED,
];

export const STATUS_EXPORT_WAREHOUSE_EXPORT_PROPOSAL = [
  StatusWarehouseExportProposalEnum.PENDING,
  StatusWarehouseExportProposalEnum.REJECTED,
];
export const STATUS_WAREHOUSE_EXPORT_PROPOSAL_DASHBOARD = [
  StatusWarehouseExportProposalEnum.COMFIRMED,
];
export const WAREHOUSE_EXPORT_PROPOSAL_RULE = {
  GREETING_TITLE: {
    MAX_LENGTH: 50,
  },
  SUGGESTED_BY: {
    MAX_LENGTH: 50,
  },
  REASON: {
    MAX_LENGTH: 255,
  },
  ITEM_NAME: {
    MAX_LENGTH: 255,
  },
  ITEM_CODE: {
    MAX_LENGTH: 22,
  },
  NOTE: {
    MAX_LENGTH: 255,
  },
  RECEIVER_INFO: {
    MAX_LENGTH: 255,
  },
  ITEM_DETAIL: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 20,
  },
};

export const TABLE_WAREHOUSE_EXPORT_ITEMS: TableColumn[] = [
  {
    name: 'stt',
    width: 0.3,
  },
  {
    name: 'itemCode',
    width: 2,
  },
  {
    name: 'itemName',
    width: 3,
  },
  {
    name: 'itemUnit',
    width: 0.8,
  },
  {
    name: 'requestedQuantity',
    width: 0.8,
  },
  {
    name: 'note',
    width: 1.4,
  },
];
export const TABLE_WAREHOUSE_EXPORT_SIGNATURE: TableColumn[] = [
  {
    name: 'supplyProposal',
    width: 2,
  },
  {
    name: 'userInCharge',
    width: 2,
  },
  {
    name: 'requestUser',
    width: 2,
  },
  {
    name: 'approved',
    width: 2,
  },
];
export enum EventChangeStatusEnumWarehouseExport {
  update = 'event.checkQuantityWarehouseExport.update',
}
