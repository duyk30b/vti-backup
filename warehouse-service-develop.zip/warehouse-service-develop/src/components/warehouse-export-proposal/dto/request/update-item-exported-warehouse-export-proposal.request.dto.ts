import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsArray,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class ItemWarehouseExportProposal {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsNumber()
  @Transform(({ value }) => Number(value))
  quantity: number;

  @ApiProperty()
  @IsNumber()
  @Transform(({ value }) => Number(value))
  diffQuantity: number;
}

export class UpdateItemExportedWarehouseExportProposalRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ItemWarehouseExportProposal)
  items: ItemWarehouseExportProposal[];
}
