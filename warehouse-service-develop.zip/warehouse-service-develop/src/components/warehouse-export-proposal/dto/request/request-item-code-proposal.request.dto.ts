import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsArray,
  IsInt,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';
class WarehouseExportProposalItemRequest {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  itemName: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  itemCode: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  unitName: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  unitId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  objectCategoryId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  manufacturingCountryId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  itemQuanlityId: number;

  @ApiPropertyOptional()
  @IsInt()
  @IsOptional()
  itemTypeSettingId: number;

  @ApiProperty()
  @IsInt()
  detailId: number;
}

export class RequestItemCodeWarehouseExportProposalBodyDto extends BaseDto {
  @ApiProperty()
  @IsArray()
  @Type(() => WarehouseExportProposalItemRequest)
  @ValidateNested({ each: true })
  items: WarehouseExportProposalItemRequest[];
}
export class RequestItemCodeWarehouseExportPorposalRequestDto extends RequestItemCodeWarehouseExportProposalBodyDto {
  @ApiProperty({ example: '', description: '' })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
