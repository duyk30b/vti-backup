import { BaseDto } from '@core/dto/base.dto';
import { Expose, Transform } from 'class-transformer';
import { IsArray, IsNotEmpty } from 'class-validator';
import { isJson } from 'src/helper/string.helper';
export class GetListWarehoseExportProposalByIdsRequestDto extends BaseDto {
  @Expose()
  @IsNotEmpty()
  @Transform(({ value }) => {
    if (value instanceof Array) {
      return value;
    }

    if (value && value.includes('\\"')) value = value.replace(/\\/g, '');

    if (isJson(value) && JSON.parse(value) instanceof Array) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    } else {
      return value.split(',');
    }
  })
  @IsArray()
  ids: number[];
}
