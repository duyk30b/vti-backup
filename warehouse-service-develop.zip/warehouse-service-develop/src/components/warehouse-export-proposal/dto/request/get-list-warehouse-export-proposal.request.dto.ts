import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsArray, IsOptional } from 'class-validator';

export class GetListWarehouseExportProposalRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  filterDepartmentSettingIds: number[];
}
