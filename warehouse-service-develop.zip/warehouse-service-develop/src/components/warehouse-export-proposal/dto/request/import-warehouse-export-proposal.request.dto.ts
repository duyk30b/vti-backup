import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';

export class ImportWarehouseExportProposalRequestDto extends BaseDto {
  @ApiProperty()
  file: any;
}
