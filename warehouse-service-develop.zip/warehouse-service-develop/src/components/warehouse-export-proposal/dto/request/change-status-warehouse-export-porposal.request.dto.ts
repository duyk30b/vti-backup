import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';
import { IsInt, IsOptional } from 'class-validator';
import { File } from '@core/dto/file-upload.request';

export class ChangeStatusWarehouseExportProposalBody extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  attachment: File;
}
export class ChangeStatusWarehouseExportProposalRequestDto extends ChangeStatusWarehouseExportProposalBody {
  @ApiProperty({ example: '1' })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
