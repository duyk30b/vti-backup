import { IsOptional } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsInt,
  IsString,
  ValidateNested,
} from 'class-validator';
import { WarehouseExportProposalItemRequest } from './create-warehouse-export-proposal.request.dto';

export class UpdateWarehouseExportProposalAfterConfirmBodyDto extends BaseDto {
  @ApiProperty()
  @IsString()
  greetingTitle: string;

  @ApiProperty()
  @IsString()
  suggestedBy: string;

  @ApiProperty()
  @IsInt()
  @IsOptional()
  constructionId: number;

  @ApiProperty()
  @IsDateString()
  receiptDate: Date;

  @ApiProperty()
  @IsString()
  reason: string;

  @ApiProperty()
  @IsString()
  receiverInfo: string;

  @ApiProperty()
  @IsArray()
  @Type(() => WarehouseExportProposalItemRequest)
  @ValidateNested({ each: true })
  items: UpdateWarehouseExportProposalItemRequest[];
}
export class UpdateWarehouseExportProposalAfterConfirmRequestDto extends UpdateWarehouseExportProposalAfterConfirmBodyDto {
  @ApiProperty({ example: '', description: '' })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}

class UpdateWarehouseExportProposalItemRequest extends WarehouseExportProposalItemRequest {
  @ApiProperty({ example: '', description: '' })
  @IsInt()
  id: number;
}
