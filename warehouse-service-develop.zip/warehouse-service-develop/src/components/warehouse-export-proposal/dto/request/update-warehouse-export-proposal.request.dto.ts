import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';
import { CreateWarehouseExportProposalRequestDto } from './create-warehouse-export-proposal.request.dto';

export class UpdateWarehouseExportProposalBodyDto extends CreateWarehouseExportProposalRequestDto {}

export class UpdateWarehouseExportProposalRequestDto extends UpdateWarehouseExportProposalBodyDto {
  @ApiProperty({ example: '', description: '' })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
