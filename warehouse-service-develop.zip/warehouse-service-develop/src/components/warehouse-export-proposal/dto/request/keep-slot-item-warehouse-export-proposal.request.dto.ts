import { IsInt } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';

export class KeepSlotItemWarehouseExportProposalRequestDto extends BaseDto {
  @ApiProperty({ example: '', description: '' })
  @IsInt()
  quantity: number;

  @ApiProperty({ example: '', description: '' })
  @IsInt()
  warehouseId: number;

  @ApiProperty({ example: '', description: '' })
  @IsInt()
  itemId: number;

  @ApiProperty({ example: '', description: '' })
  @IsInt()
  lotNumber: number;
}
