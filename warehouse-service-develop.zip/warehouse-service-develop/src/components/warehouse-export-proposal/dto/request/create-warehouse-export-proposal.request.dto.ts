import { WAREHOUSE_EXPORT_PROPOSAL_RULE } from '@components/warehouse-export-proposal/warehouse-export-proposal.constants';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsInt,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
export class WarehouseExportProposalDetailChildrenRequest {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(WAREHOUSE_EXPORT_PROPOSAL_RULE.ITEM_NAME.MAX_LENGTH)
  itemName: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(WAREHOUSE_EXPORT_PROPOSAL_RULE.ITEM_CODE.MAX_LENGTH)
  itemCode: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  unitId: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  exportedActualQuantity: number;

  @ApiProperty()
  @IsOptional()
  exportedQuantity: number;

  @ApiPropertyOptional()
  @IsOptional()
  isKeepSlot: boolean;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseExportId: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  lotNumber: number;
}
export class WarehouseExportProposalItemRequest {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(WAREHOUSE_EXPORT_PROPOSAL_RULE.ITEM_NAME.MAX_LENGTH)
  itemName: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(WAREHOUSE_EXPORT_PROPOSAL_RULE.ITEM_CODE.MAX_LENGTH)
  itemCode: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  unitId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  itemDetail: string;

  @ApiProperty()
  @IsOptional()
  requestedQuantity: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(WAREHOUSE_EXPORT_PROPOSAL_RULE.NOTE.MAX_LENGTH)
  note: string;

  @ApiProperty()
  @IsOptional()
  importedQuantity: number;

  @ApiPropertyOptional({ example: '', description: '' })
  @IsOptional()
  isProvideCode: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => WarehouseExportProposalDetailChildrenRequest)
  @ValidateNested({ each: true })
  childrens: UpdateWarehouseExportProposalDetailChildrenRequest[];
}

class UpdateWarehouseExportProposalDetailChildrenRequest extends WarehouseExportProposalDetailChildrenRequest {
  @ApiProperty({ example: '', description: '' })
  @IsInt()
  id: number;
}

class UpdateWarehouseExportProposalItemRequest extends WarehouseExportProposalItemRequest {
  @ApiProperty({ example: '', description: '' })
  @IsOptional()
  @IsInt()
  id: number;
}

export class CreateWarehouseExportProposalRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsInt()
  factoryId?: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  departmentSettingId: number;

  @ApiProperty()
  @IsString()
  @MaxLength(WAREHOUSE_EXPORT_PROPOSAL_RULE.GREETING_TITLE.MAX_LENGTH)
  greetingTitle: string;

  @ApiProperty()
  @IsString()
  @MaxLength(WAREHOUSE_EXPORT_PROPOSAL_RULE.SUGGESTED_BY.MAX_LENGTH)
  suggestedBy: string;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  constructionId: number;

  @ApiProperty()
  @IsDateString()
  receiptDate: Date;

  @ApiProperty()
  @IsString()
  @MaxLength(WAREHOUSE_EXPORT_PROPOSAL_RULE.REASON.MAX_LENGTH)
  reason: string;

  @ApiProperty()
  @IsString()
  @MaxLength(WAREHOUSE_EXPORT_PROPOSAL_RULE.RECEIVER_INFO.MAX_LENGTH)
  receiverInfo: string;

  @ApiProperty()
  @IsArray()
  @Type(() => UpdateWarehouseExportProposalItemRequest)
  @ValidateNested({ each: true })
  items: UpdateWarehouseExportProposalItemRequest[];
}
