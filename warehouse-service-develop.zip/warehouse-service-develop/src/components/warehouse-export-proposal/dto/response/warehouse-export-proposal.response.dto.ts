import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
class ItemUnit {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}
class ItemResponse {
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  status: number;

  @Expose()
  @Type(() => ItemUnit)
  itemUnit: ItemUnit;
}
class UserResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  fullName: string;

  @ApiProperty()
  @Expose()
  username: string;
}
class ObjectCategory {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ManufacturingCountry {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}
class ItemQuanlity {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class WarehouseResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  manageByLot: number;
}
class ItemTypeSettingResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}
class WarehouseExportProposalDetailChildrenResponse {
  @Expose()
  id: number;

  @Expose()
  itemName: string;

  @Expose()
  itemId: number;

  @Expose()
  @Type(() => ItemResponse)
  itemResponse: ItemResponse;

  @Expose()
  exportableQuantity: number;

  @Expose()
  usedQuantity: number;

  @Expose()
  itemCode: string;

  @Expose()
  unitId: number;

  @Expose()
  warehouseExportId: number;

  @Expose()
  @Type(() => WarehouseResponse)
  warehouseExport: WarehouseResponse;

  @Expose()
  lotNumber: string;

  @Expose()
  exportedQuantity: number;

  @Expose()
  requestedQuantity: number;

  @Expose()
  exportedActualQuantity: number;

  @Expose()
  isKeepSlot: boolean;

  @ApiProperty({ type: UserResponse })
  @Expose()
  @Type(() => UserResponse)
  updatedByChild: UserResponse;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}
class WarehouseExportProposalItemResponse {
  @Expose()
  id: number;

  @Expose()
  itemName: string;

  @Expose()
  itemId: number;

  @Expose()
  itemCode: string;

  @Expose()
  itemDetail: string;

  @Expose()
  statusRequestCode: number;

  @Expose()
  @Type(() => ItemResponse)
  itemResponse: ItemResponse;

  @Expose()
  @Type(() => ItemUnit)
  itemUnit: ItemUnit;

  @Expose()
  unitId: number;

  @Expose()
  requestedQuantity: number;

  @Expose()
  exportedQuantity: number;

  @Expose()
  exportedActualQuantity: number;

  @Expose()
  exportAbleQuantity: number;

  @Expose()
  importedQuantity: number;

  @Expose()
  importedActualQuantity: number;

  @Expose()
  unitName: string;

  @Expose()
  note: string;

  @Expose()
  providedItemCodes: any[];

  @Expose()
  isProvideCode: boolean;

  @Expose()
  itemTypeSettingId: number;

  @Expose()
  @Type(() => ItemTypeSettingResponse)
  itemTypeSetting: ItemTypeSettingResponse;

  @Expose()
  @Type(() => ObjectCategory)
  objectCategory: ObjectCategory;

  @Expose()
  @Type(() => ManufacturingCountry)
  manufacturingCountry: ManufacturingCountry;

  @Expose()
  @Type(() => ItemQuanlity)
  itemQuanlity: ItemQuanlity;

  @ApiProperty({ type: UserResponse })
  @Expose()
  @Type(() => UserResponse)
  updatedBy: UserResponse;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @Expose()
  @Type(() => WarehouseExportProposalDetailChildrenResponse)
  childrens: WarehouseExportProposalDetailChildrenResponse[];
}
class Construction {
  @ApiProperty()
  @Expose()
  id: number;
  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}
class Factory {
  @ApiProperty()
  @Expose()
  id: number;
  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class DepartmentSetting {
  @ApiProperty()
  @Expose()
  id: number;
  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}
class Attachment {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  fileName: string;

  @ApiProperty()
  @Expose()
  fileUrl: string;
}
export class WarehouseExportProposalResponseDto {
  @Expose()
  id: number;

  @Expose()
  greetingTitle: string;

  @Expose()
  code: string;

  @Expose()
  receiptNumber: string;

  @Expose()
  suggestedBy: string;

  @Expose()
  departmentSettingId: number;

  @Expose()
  @Type(() => DepartmentSetting)
  departmentSetting: DepartmentSetting;

  @Expose()
  @Type(() => Factory)
  factory: Factory;

  @Expose()
  @Type(() => Construction)
  construction: Construction;

  @ApiProperty()
  @Expose()
  @Type(() => Attachment)
  attachment: Attachment;

  @Expose()
  receiptDate: Date;

  @Expose()
  reason: string;

  @Expose()
  status: number;

  @Expose()
  exportStatus: number;

  @Expose()
  receiverInfo: string;

  @Expose()
  @Type(() => WarehouseExportProposalItemResponse)
  items: WarehouseExportProposalItemResponse[];

  @ApiProperty({ type: UserResponse })
  @Expose()
  @Type(() => UserResponse)
  createdBy: UserResponse;

  @ApiProperty({ type: UserResponse })
  @Expose()
  @Type(() => UserResponse)
  updatedBy: UserResponse;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}
