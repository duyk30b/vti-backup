import { ApiProperty } from "@nestjs/swagger";
import { Expose, Type } from "class-transformer";

class UnitResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ItemWarehouseSource {
  @Expose()
  warehouseId: number;

  @Expose()
  sourceId: number;

  @Expose()
  sourceName: string;

  @Expose()
  sourceCode: string;

  @Expose()
  accountIdentifier: string;
}

class ItemResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  @Type(() => UnitResponseDto)
  itemUnit: UnitResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => ItemWarehouseSource)
  itemWarehouseSources: ItemWarehouseSource[];
}

class LotResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  isKeepSlot: boolean;

  @ApiProperty()
  @Expose()
  exportedQuantity: number;

  @ApiProperty()
  @Expose()
  exportedActualQuantity: number;

  @ApiProperty()
  @Expose()
  warehouseExportId: number;

  @ApiProperty()
  @Expose()
  @Type(() => ItemResponse)
  item: ItemResponse[];
}

export class GetWarehouseExportProposalItemsResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  requestedQuantity: number;

  @ApiProperty()
  @Expose()
  exportedQuantity: number;

  @ApiProperty()
  @Expose()
  exportedActualQuantity: number;

  @ApiProperty()
  @Expose()
  exportableQuantity: number;
  
  @ApiProperty()
  @Expose()
  importedQuantity: number;

  @ApiProperty()
  @Expose()
  importedActualQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => ItemResponse)
  item: ItemResponse[];

  @ApiProperty()
  @Expose()
  @Type(() => LotResponse)
  lots: LotResponse[];
}