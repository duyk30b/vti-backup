import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty, keyBy } from 'lodash';
import * as moment from 'moment';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';

@Injectable()
export class WarehouseExportProposalImport extends ImportDataAbstract {
  private readonly FIELD_TEMPLATE_CONST = {
    DEPARTMENT_SETTING_ID: {
      DB_COL_NAME: 'departmentSettingId',
      COL_NAME: ['Department setting ID', '倉庫コード', 'Mã đơn vị (bộ phận)'],
      ALLOW_NULL: true,
    },
    SUGGESTED_BY: {
      DB_COL_NAME: 'suggestedBy',
      COL_NAME: ['Suggested by', '倉庫コード', 'Tên người đề nghị'],
      ALLOW_NULL: true,
    },
    GREETING_TITLE: {
      DB_COL_NAME: 'greetingTitle',
      COL_NAME: ['Greeting title', '倉庫名', 'Kính gửi'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    RECEIVER_INFO: {
      DB_COL_NAME: 'receiverInfo',
      COL_NAME: ['Receiver infomation', '倉庫名', 'Tên người lĩnh'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    CONSTRUCTION_CODE: {
      DB_COL_NAME: 'constructionCode',
      COL_NAME: ['Construction code', '倉庫種類', 'Mã công trình'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REASON: {
      DB_COL_NAME: 'reason',
      COL_NAME: ['Reason', '倉庫種類', 'Lý do sử dụng'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    RECEIPT_DATE: {
      DB_COL_NAME: 'receiptDate',
      COL_NAME: ['Receipt date', '倉庫種類', 'Ngày lập giấy'],
      ALLOW_NULL: true,
    },
    ITEM_CODE: {
      DB_COL_NAME: 'itemCode',
      COL_NAME: ['Item code', '倉庫種類', 'Mã vật tư'],
      ALLOW_NULL: true,
    },
    ITEM_NAME: {
      DB_COL_NAME: 'itemName',
      COL_NAME: ['Item name', '倉庫種類', 'Tên vật tư'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    ITEM_DETAIL: {
      DB_COL_NAME: 'itemDetail',
      COL_NAME: ['Item detail', '倉庫種類', 'Thông tin chi tiết'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    UNIT_ID: {
      DB_COL_NAME: 'unitName',
      COL_NAME: ['Unit name', '倉庫種類', 'Đơn vị tính'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REQUESTED_QUANTITY: {
      DB_COL_NAME: 'requestedQuantity',
      COL_NAME: ['Requested quantity', '倉庫種類', 'SL yêu cầu'],
      MAX_LENGTH: 255,
    },
    NOTE: {
      DB_COL_NAME: 'note',
      COL_NAME: ['Note', '倉庫種類', 'Ghi chú'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 0,
  };

  constructor(
    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,
    @Inject('SaleServiceInterface')
    private readonly saleService: SaleServiceInterface,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    this.fieldsMap.groupSet(
      [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
      [
        this.FIELD_TEMPLATE_CONST.DEPARTMENT_SETTING_ID,
        this.FIELD_TEMPLATE_CONST.SUGGESTED_BY,
        this.FIELD_TEMPLATE_CONST.GREETING_TITLE,
        this.FIELD_TEMPLATE_CONST.RECEIVER_INFO,
        this.FIELD_TEMPLATE_CONST.CONSTRUCTION_CODE,
        this.FIELD_TEMPLATE_CONST.REASON,
        this.FIELD_TEMPLATE_CONST.RECEIPT_DATE,
        this.FIELD_TEMPLATE_CONST.ITEM_CODE,
        this.FIELD_TEMPLATE_CONST.ITEM_NAME,
        this.FIELD_TEMPLATE_CONST.ITEM_DETAIL,
        this.FIELD_TEMPLATE_CONST.UNIT_ID,
        this.FIELD_TEMPLATE_CONST.REQUESTED_QUANTITY,
        this.FIELD_TEMPLATE_CONST.NOTE,
      ],
    );
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
  ): Promise<ImportResponseDto | any> {
    if (!isEmpty(logs)) {
      const response = new ImportResponseDto();
      response.result = logs;
      response.totalCount = logs.length;
      response.successCount = 0;
      return response;
    }
    const itemCodes = dataDto.map((data) => data.itemCode);
    const unitNames = dataDto
      .filter((data) => !!data.unitName)
      .map((data) => data.unitName);
    const [itemsData, itemUnitSettings] = await Promise.all([
      this.itemService.getItemByCodes(itemCodes),
      this.itemService.getItemUnitSettingByNames(unitNames, true),
    ]);
    const itemsByCode = keyBy(itemsData, 'code');

    const items = dataDto.map((data) => ({
      itemId: itemsByCode[data.itemCode]?.id,
      itemCode: data.itemCode,
      itemName: itemsByCode[data.itemCode]?.name || data.itemName,
      itemDetail: data.itemDetail,
      unitId: itemUnitSettings[data.unitName]?.id,
      requestedQuantity: data.requestedQuantity,
      note: data.note,
    }));

    const construction = await this.saleService.getConstructionByCode(
      dataDto[0]?.constructionCode,
    );
    return {
      suggestedBy: dataDto[0]?.suggestedBy,
      greetingTitle: dataDto[0]?.greetingTitle,
      receiverInfo: dataDto[0]?.receiverInfo,
      constructionId: construction?.id,
      reason: dataDto[0]?.reason,
      receiptDate: new Date(
        moment(dataDto[0]?.receiptDate, 'DD/MM/YYYY').format(),
      ),
      items: [...items],
    };
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto> | any> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_CONST.REQUIRED_COL_NUM,
      true,
    );
  }
}
