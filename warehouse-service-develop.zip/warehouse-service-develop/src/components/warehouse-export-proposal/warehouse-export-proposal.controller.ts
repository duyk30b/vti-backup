import { isEmpty } from 'lodash';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Res,
} from '@nestjs/common';
import { ApiConsumes, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateWarehouseExportProposalRequestDto } from './dto/request/create-warehouse-export-proposal.request.dto';
import { WarehouseExportProposalServiceInterface } from './interface/warehouse-export-proposal.service.interface';
import { ResponsePayload } from '@utils/response-payload';
import { WarehouseExportProposalResponseDto } from './dto/response/warehouse-export-proposal.response.dto';
import { DetailWarehouseExportProposalRequestDto } from './dto/request/detail-warehouse-export-proposal.request.dto';
import { GetListWarehouseExportProposalRequestDto } from './dto/request/get-list-warehouse-export-proposal.request.dto';
import { DeleteWarehouseExportProposalRequestDto } from './dto/request/delete-warehouse-export-proposal.request.dto';
import {
  ChangeStatusWarehouseExportProposalBody,
  ChangeStatusWarehouseExportProposalRequestDto,
} from './dto/request/change-status-warehouse-export-porposal.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { UpdateWarehouseExportProposalBodyDto } from './dto/request/update-warehouse-export-proposal.request.dto';
import { RequestItemCodeWarehouseExportProposalBodyDto } from './dto/request/request-item-code-proposal.request.dto';
import { UpdateWarehouseExportProposalAfterConfirmBodyDto } from './dto/request/update-warehouse-export-proposal-after-confirm.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CONFIRM_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION,
  CREATE_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION,
  DELETE_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION,
  DETAIL_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION,
  LIST_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION,
  REJECT_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION,
  UPDATE_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION,
  UPDATE_WAREHOUSE_EXPORT_PROPOSAL_AFTER_CONFIRM_PERMISSION,
  REQUEST_ITEM_CODE_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION,
  EXPORT_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION,
} from '@utils/permissions/warehouse-export-proposal';
import { GetWarehouseExportProposalItemsQueryDto } from './dto/request/get-warehouse-export-proposal-items.request.dto';
import { MessagePattern } from '@nestjs/microservices';
import { Response } from 'express';
import * as contentDisposition from 'content-disposition';
import { ImportWarehouseExportProposalRequestDto } from './dto/request/import-warehouse-export-proposal.request.dto';
import { UpdateItemRemainingWarehouseExportProposalRequestDto } from './dto/request/update-item-planning-warehouse-export-proposal.request.dto';
import { UpdateItemExportedWarehouseExportProposalRequestDto } from './dto/request/update-item-exported-warehouse-export-proposal.request.dto';
import { GetListWarehoseExportProposalByIdsRequestDto } from './dto/request/get-list-warehouse-export-proposal-by-ids.request';
import { NATS_WAREHOUSE } from '@config/nats.config';

@Controller('warehouse-export-proposals')
export class WarehouseExportProposalController {
  constructor(
    @Inject('WarehouseExportProposalServiceInterface')
    private readonly warehouseExportProposalService: WarehouseExportProposalServiceInterface,
  ) {}

  @PermissionCode(CREATE_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION.code)
  @Post('/create')
  @ApiOperation({
    tags: ['Warehouse Export Proposal'],
    summary: 'Create warehouse export proposal',
    description: 'Tạo mới giấy đề nghị xuất vật tư',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    // type: WarehouseExportProposalRespons
  })
  async create(
    @Body() payload: CreateWarehouseExportProposalRequestDto,
  ): Promise<ResponsePayload<WarehouseExportProposalResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseExportProposalService.create(request);
  }

  @PermissionCode(CREATE_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION.code)
  @Post('/import')
  @ApiOperation({
    tags: ['Warehouse Export Proposal'],
    summary: 'Import warehouse export proposal',
    description: 'Import giấy đề nghị xuất vật tư',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  @ApiConsumes('multipart/form-data')
  async import(
    @Body() payload: ImportWarehouseExportProposalRequestDto,
  ): Promise<ResponsePayload<WarehouseExportProposalResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseExportProposalService.import(request);
  }

  @PermissionCode(DETAIL_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Warehouse Export Proposal '],
    summary: 'Detail warehouse export proposal',
    description: 'Chi tiet warehouse export proposal',
  })
  @ApiResponse({
    status: 200,
    description: 'Get detail successfully',
    type: WarehouseExportProposalResponseDto,
  })
  public async detail(
    @Param() param: DetailWarehouseExportProposalRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseExportProposalService.detail(request.id);
  }

  @PermissionCode(LIST_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION.code)
  @Get('list')
  @ApiOperation({
    tags: ['Warehouse Export Proposal '],
    summary: 'Detail warehouse export proposal',
    description: 'Danh sách warehouse export proposal',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
    type: WarehouseExportProposalResponseDto,
  })
  public async getList(
    @Query() query: GetListWarehouseExportProposalRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseExportProposalService.getList(request);
  }

  @PermissionCode(DELETE_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Warehouse Export Proposal '],
    summary: 'Delete warehouse export proposal',
    description: 'Xoá warehouse export proposal',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: WarehouseExportProposalResponseDto,
  })
  public async delete(
    @Param() param: DeleteWarehouseExportProposalRequestDto,
  ): Promise<any> {
    const { responseError, request } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseExportProposalService.delete(request);
  }

  @PermissionCode(CONFIRM_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Warehouse Export Proposal'],
    summary: 'Confirm Warehouse Export Proposal',
    description: 'Phê duyệt giấy đề nghị xuất vật tư',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: SuccessResponse,
  })
  public async confirm(
    @Param('id', new ParseIntPipe()) id,
    @Body() body: ChangeStatusWarehouseExportProposalBody,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.warehouseExportProposalService.confirm(request);
  }

  @PermissionCode(REJECT_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Warehouse Export Proposal'],
    summary: 'Reject Warehouse Export Proposal ',
    description: 'Từ chối giấy đề nghị xuất vật tư',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: SuccessResponse,
  })
  public async reject(
    @Param() param: ChangeStatusWarehouseExportProposalRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseExportProposalService.reject(request);
  }

  @PermissionCode(UPDATE_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Warehouse Export Proposal'],
    summary: 'Update Warehouse Export Proposal Before Confirm',
    description: 'Sửa giấy đề nghị xuất vật tư trước xác nhận',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: SuccessResponse,
  })
  public async updateBeforeConfirm(
    @Body() payload: UpdateWarehouseExportProposalBodyDto,
    @Param('id', new ParseIntPipe()) id: number,
  ) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.warehouseExportProposalService.updateEntity(request);
  }

  @PermissionCode(
    UPDATE_WAREHOUSE_EXPORT_PROPOSAL_AFTER_CONFIRM_PERMISSION.code,
  )
  @Put('/:id/export')
  @ApiOperation({
    tags: ['Warehouse Export Proposal'],
    summary: 'Update Warehouse Export Proposal After Confirm',
    description: 'Sửa giấy đề nghị xuất vật tư sau khi xác nhận',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  public async updateProposalAfterConfirm(
    @Body() payload: UpdateWarehouseExportProposalAfterConfirmBodyDto,
    @Param('id', new ParseIntPipe()) id: number,
  ) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.warehouseExportProposalService.updateEntityAfterConfirm(
      request,
    );
  }
  @PermissionCode(REQUEST_ITEM_CODE_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION.code)
  @Put('/:id/request-item')
  @ApiOperation({
    tags: ['Warehouse Export Proposal'],
    summary: 'Request Item Code Warehouse Export Proposal After Confirm',
    description: 'Yêu cầu cấp mã vật tư',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  public async requestItemCode(
    @Body() payload: RequestItemCodeWarehouseExportProposalBodyDto,
    @Param('id', new ParseIntPipe()) id: number,
  ) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.warehouseExportProposalService.requestItemCode(request);
  }

  @Get('/:id/items')
  @ApiOperation({
    tags: ['Warehouse Export Proposal'],
    summary: 'Get Item From Warehouse Export Proposal',
    description: 'Danh sách vật tư trong giấy đề nghị xuất vật tư',
  })
  @ApiResponse({
    status: 200,
    type: SuccessResponse,
  })
  public async getWarehouseExportProposalItems(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() query: GetWarehouseExportProposalItemsQueryDto,
  ) {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseExportProposalService.getWarehouseExportProposalItems(
      id,
      request.warehouseId,
    );
  }

  @MessagePattern(`${NATS_WAREHOUSE}.get_warehouse_export_proposal_detail`)
  public async detailTcp(
    @Body() body: DetailWarehouseExportProposalRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseExportProposalService.detail(request.id);
  }

  @PermissionCode(EXPORT_WAREHOUSE_EXPORT_PROPOSAL_PERMISSION.code)
  @Get('/export/:id')
  @ApiOperation({
    tags: ['Warehouse Export Proposal'],
    summary: 'Export Warehouse Export Proposal',
    description: 'Xuất giấy đề nghị xuất vật tư',
  })
  @ApiResponse({
    status: 200,
    description: 'Export ticket successfully',
    type: SuccessResponse,
  })
  public async exportSupplyExportProposal(
    @Res({ passthrough: true }) res: Response,
    @Param() param: DetailWarehouseExportProposalRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    const result =
      await this.warehouseExportProposalService.exportSupplyExportProposal(
        request.id,
      );
    if (!result.nameFile) {
      return result;
    }
    res.header(
      'Content-Disposition',
      contentDisposition(result.nameFile + '.docx'),
    );
    res.header('Access-Control-Expose-Headers', '*');
    return result.result;
  }

  @MessagePattern(
    `${NATS_WAREHOUSE}.update_remaining_quantity_warehouse_export_proposal`,
  )
  @ApiOperation({
    tags: ['Warehouse Export Proposal'],
    summary: 'Export Warehouse Export Proposal',
    description: 'Update Item Remaining giấy đề nghị xuất vật tư',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  public async updateItemRemainingWarehouseExportProposal(
    @Body() body: UpdateItemRemainingWarehouseExportProposalRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseExportProposalService.updateItemRemainingWarehouseExportProposal(
      request,
    );
  }

  @MessagePattern(
    `${NATS_WAREHOUSE}.rollback_remaining_quantity_warehouse_export_proposal`,
  )
  @ApiOperation({
    tags: ['Warehouse Export Proposal'],
    summary: 'Export Warehouse Export Proposal',
    description: 'Rollback Item Remaining giấy đề nghị xuất vật tư',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  public async rollbackItemRemainingWarehouseExportProposal(
    @Body() body: UpdateItemRemainingWarehouseExportProposalRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseExportProposalService.rollbackItemRemainingWarehouseExportProposal(
      request,
    );
  }

  @MessagePattern(
    `${NATS_WAREHOUSE}.update_exported_quantity_warehouse_export_proposal`,
  )
  @ApiOperation({
    tags: ['Warehouse Export Proposal'],
    summary: 'Export Warehouse Export Proposal',
    description: 'Update Item Remaining giấy đề nghị xuất vật tư',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  public async updateItemExportedWarehouseExportProposal(
    @Body() body: UpdateItemExportedWarehouseExportProposalRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseExportProposalService.updateItemExportedWarehouseExportProposal(
      request,
    );
  }

  @MessagePattern(`${NATS_WAREHOUSE}.get_warehouse_export_proposal_by_ids`)
  public async getWarehouseExportProposalByIds(
    @Body() body: GetListWarehoseExportProposalByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseExportProposalService.getWarehouseExportProposalByIds(
      request,
    );
  }

  @MessagePattern(`${NATS_WAREHOUSE}.get_warehouse_export_proposal_by_codes`)
  public async getWarehouseExportProposalByCodes(
    codes: string[],
  ): Promise<any> {
    return await this.warehouseExportProposalService.getWarehouseExportProposalByCodes(
      codes,
    );
  }
}
