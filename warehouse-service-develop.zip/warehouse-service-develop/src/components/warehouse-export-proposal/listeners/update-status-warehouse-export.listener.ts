import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { UpdateStatusWarehouseExportEvent } from '../events/update-status-warehouse-export.event';
import { WarehouseExportProposalDetailChildRepositoryInterface } from '../interface/warehouse-export-proposal-detail-child.repository.interface';
import { WarehouseExportProposalRepositoryInterface } from '../interface/warehouse-export-proposal.repository.interface';
import {
  EventChangeStatusEnumWarehouseExport,
  StatusExportWarehouseEnum,
  StatusWarehouseExportProposalEnum,
} from '../warehouse-export-proposal.constants';
import { isEmpty } from 'lodash';

@Injectable()
export class UpdateStatusWarehouseExportListener {
  constructor(
    @Inject('WarehouseExportProposalDetailChildRepositoryInterface')
    private readonly warehouseExportProposalDetailChildRepository: WarehouseExportProposalDetailChildRepositoryInterface,

    @Inject('WarehouseExportProposalRepositoryInterface')
    private readonly warehouseExportProposalRepository: WarehouseExportProposalRepositoryInterface,
  ) {}

  @OnEvent(EventChangeStatusEnumWarehouseExport.update)
  async handleUpdateStatusEvent(event: UpdateStatusWarehouseExportEvent) {
    const { id } = event;
    const warehouseExportProposal =
      await this.warehouseExportProposalRepository.findOneById(id);
    if (isEmpty(warehouseExportProposal)) {
      return;
    }
    const isComplete =
      await this.warehouseExportProposalRepository.checkIsCompleteQuantityWarehouseExport(
        id,
      );
    if (isComplete) {
      warehouseExportProposal.exportStatus =
        StatusExportWarehouseEnum.COMPLETED;
      await this.warehouseExportProposalRepository.create(
        warehouseExportProposal,
      );
    }
  }
}
