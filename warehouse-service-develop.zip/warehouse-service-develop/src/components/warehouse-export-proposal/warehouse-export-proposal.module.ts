import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { WarehouseService } from './../warehouse/warehouse.service';
import { ItemModule } from '@components/item/item.module';
import { ItemService } from '@components/item/item.service';
import { SaleModule } from '@components/sale/sale.module';
import { SaleService } from '@components/sale/sale.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { WarehouseExportProposalDetailChildEntity } from '@entities/warehouse-export-proposal/warehouse-export-proposal-detail-child.entity';
import { WarehouseExportProposalDetailEntity } from '@entities/warehouse-export-proposal/warehouse-export-proposal-detail.entity';
import { WarehouseExportProposalEntity } from '@entities/warehouse-export-proposal/warehouse-export-proposal.entity';
import { Warehouse } from '@entities/warehouse/warehouse.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WarehouseExportProposalDetailChildRepository } from '@repositories/warehouse-export-proposal-detail-child.repository';
import { WarehouseExportProposalDetailRepository } from '@repositories/warehouse-export-proposal-detail.repository';
import { WarehouseExportProposalRepository } from '@repositories/warehouse-export-proposal.repository';
import { WarehouseRepository } from '@repositories/warehouse.repository';
import { WarehouseExportProposalController } from './warehouse-export-proposal.controller';
import { WarehouseExportProposalService } from './warehouse-export-proposal.service';
import { WarehouseExportProposalImport } from './import/warehouse-export-proposal.import.helper';
import { UpdateStatusWarehouseExportListener } from './listeners/update-status-warehouse-export.listener';
import { FileEntity } from '@entities/file/file.entity';
import { FileModule } from '@components/file/file.module';
import { FileRepository } from '@repositories/file.repository';
import { FileService } from '@components/file/file.service';
import { ConfigService } from '@config/config.service';
import { ConfigModule } from '@nestjs/config';
import { TransactionBussinessTypeRepository } from '@repositories/transaction-business-type.repository';
import { TransactionBussinessTypeEntity } from '@entities/bussiness-types/transaction-bussiness-type.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      WarehouseExportProposalEntity,
      WarehouseExportProposalDetailEntity,
      WarehouseExportProposalDetailChildEntity,
      Warehouse,
      FileEntity,
      TransactionBussinessTypeEntity,
    ]),
    UserModule,
    ItemModule,
    SaleModule,
    WarehouseModule,
    FileModule,
    ConfigModule,
  ],
  providers: [
    {
      provide: 'WarehouseExportProposalRepositoryInterface',
      useClass: WarehouseExportProposalRepository,
    },
    {
      provide: 'WarehouseExportProposalServiceInterface',
      useClass: WarehouseExportProposalService,
    },
    {
      provide: 'WarehouseExportProposalDetailRepositoryInterface',
      useClass: WarehouseExportProposalDetailRepository,
    },
    {
      provide: 'WarehouseExportProposalDetailChildRepositoryInterface',
      useClass: WarehouseExportProposalDetailChildRepository,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'TransactionBussinessTypeRepositoryInterface',
      useClass: TransactionBussinessTypeRepository,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'WarehouseExportProposalImport',
      useClass: WarehouseExportProposalImport,
    },
    {
      provide: 'FileRepositoryInterface',
      useClass: FileRepository,
    },
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
    {
      provide: 'ConfigServiceInterface',
      useClass: ConfigService,
    },
    ConfigService,
    FileRepository,
    UpdateStatusWarehouseExportListener,
  ],
  exports: [
    {
      provide: 'WarehouseExportProposalRepositoryInterface',
      useClass: WarehouseExportProposalRepository,
    },
    {
      provide: 'WarehouseExportProposalServiceInterface',
      useClass: WarehouseExportProposalService,
    },
    {
      provide: 'WarehouseExportProposalDetailRepositoryInterface',
      useClass: WarehouseExportProposalDetailRepository,
    },
    {
      provide: 'WarehouseExportProposalDetailChildRepositoryInterface',
      useClass: WarehouseExportProposalDetailChildRepository,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'TransactionBussinessTypeRepositoryInterface',
      useClass: TransactionBussinessTypeRepository,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'WarehouseExportProposalImport',
      useClass: WarehouseExportProposalImport,
    },
  ],
  controllers: [WarehouseExportProposalController],
})
export class WarehouseExportProposalModule {}
