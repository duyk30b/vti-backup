export class UpdateStatusWarehouseExportEvent {
  constructor({ id }) {
    this.id = id;
  }
  id: number;
}
