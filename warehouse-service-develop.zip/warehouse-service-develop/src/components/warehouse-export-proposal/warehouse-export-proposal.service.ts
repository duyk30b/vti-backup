import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { ResponsePayload } from '@utils/response-payload';
import { ItemService } from '@components/item/item.service';
import {
  uniq,
  isEmpty,
  map,
  keyBy,
  groupBy,
  flatMap,
  compact,
  has,
  values,
} from 'lodash';
import { WarehouseExportProposalEntity } from '@entities/warehouse-export-proposal/warehouse-export-proposal.entity';
import { Inject, Injectable } from '@nestjs/common';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { CreateWarehouseExportProposalRequestDto } from './dto/request/create-warehouse-export-proposal.request.dto';
import { WarehouseExportProposalDetailRepositoryInterface } from './interface/warehouse-export-proposal-detail.repository.interface';
import { WarehouseExportProposalRepositoryInterface } from './interface/warehouse-export-proposal.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In, IsNull } from 'typeorm';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { WarehouseExportProposalResponseDto } from './dto/response/warehouse-export-proposal.response.dto';
import { plainToClass, plainToInstance } from 'class-transformer';
import { GetListWarehouseExportProposalRequestDto } from './dto/request/get-list-warehouse-export-proposal.request.dto';
import { PagingResponse } from '@utils/paging.response';
import { DeleteWarehouseExportProposalRequestDto } from './dto/request/delete-warehouse-export-proposal.request.dto';
import { ChangeStatusWarehouseExportProposalRequestDto } from './dto/request/change-status-warehouse-export-porposal.request.dto';
import {
  CONFIRMABLE_WAREHOUSE_EXPORT_PROPOSAL_STATUSES,
  EventChangeStatusEnumWarehouseExport,
  REJECTABLE_WAREHOUSE_EXPORT_PROPOSAL_STATUSES,
  StatusExportWarehouseEnum,
  StatusRequestItemCodeEnum,
  StatusWarehouseExportProposalEnum,
  STATUS_TO_UPDATE_WAREHOUSE_EXPORT_PROPOSAL,
  TABLE_WAREHOUSE_EXPORT_ITEMS,
  TABLE_WAREHOUSE_EXPORT_SIGNATURE,
  WAREHOUSE_EXORT_PROPOSAL,
} from './warehouse-export-proposal.constants';
import { ApiError } from '@utils/api.error';
import { WarehouseExportProposalDetailEntity } from '@entities/warehouse-export-proposal/warehouse-export-proposal-detail.entity';
import { UpdateWarehouseExportProposalRequestDto } from './dto/request/update-warehouse-export-proposal.request.dto';
import { WarehouseExportProposalServiceInterface } from './interface/warehouse-export-proposal.service.interface';
import { RequestItemCodeWarehouseExportPorposalRequestDto } from './dto/request/request-item-code-proposal.request.dto';
import { WarehouseExportProposalDetailChildRepositoryInterface } from './interface/warehouse-export-proposal-detail-child.repository.interface';
import { UpdateWarehouseExportProposalAfterConfirmRequestDto } from './dto/request/update-warehouse-export-proposal-after-confirm.request.dto';
import * as Moment from 'moment';
import { GetWarehouseExportProposalItemsResponseDto } from './dto/response/get-warehouse-export-proposal-items.response.dto';
import {
  CreateItemPlanningQuantitiesRequestDto,
  CreateItemPlanningQuantityRequestDto,
} from '@components/item/dto/request/create-item-planning-quantity.request.dto';
import { OrderTypeEnum } from '@constant/order.constant';
import {
  CheckItemStockAvailableRequestDto,
  GetItemStockAvailableRequestDto,
} from '@components/item/dto/request/get-item-stock-available.request.dto';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import {
  AlignmentType,
  Document,
  Paragraph,
  Table,
  TableCell,
  TableRow,
  TextRun,
  VerticalAlign,
  Packer,
} from 'docx';
import { FONT_NAME, WORD_FILE_CONFIG } from '@utils/constant';
import { plus, minus } from '@utils/common';
import {
  wordFileStyle,
  setHeight,
  setWidth,
  formatNumber,
} from 'src/common/word-common.styles';
import { WarehouseExportProposalDetailChildEntity } from '@entities/warehouse-export-proposal/warehouse-export-proposal-detail-child.entity';
import { SettingServiceInterface } from '@components/setting/interface/setting.service.interface';
import {
  CreateRequestItemCodesRequestDto,
  RequestItemCodeRequestDto,
} from '@components/item/dto/request/create-request-item-code.request.dto';
import { ImportWarehouseExportProposalRequestDto } from './dto/request/import-warehouse-export-proposal.request.dto';
import { WarehouseExportProposalImport } from './import/warehouse-export-proposal.import.helper';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { UpdateItemRemainingWarehouseExportProposalRequestDto } from './dto/request/update-item-planning-warehouse-export-proposal.request.dto';
import { UpdateItemExportedWarehouseExportProposalRequestDto } from './dto/request/update-item-exported-warehouse-export-proposal.request.dto';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { FileRepositoryInterface } from '@components/file/interface/file.repository.interface';
import { FileService } from '@components/file/file.service';
import { ConfigService } from '@config/config.service';
import { UploadFileRequestDto } from '@components/file/dto/request/upload-file.request.dto';
import { FileResource } from '@components/file/file.constants';
import { GetItemAllStockAvailableRequestDto } from '@components/item/dto/request/get-item-stock-available-all-warehouse.request.dto';
import { TransactionBussinessTypeRepositoryInterface } from '@components/bussiness-types/interface/transaction-bussiness-type.repository.interface';
import { BusinessTypeAttributeDefaultEnum } from '@components/bussiness-types/bussiness-type.constants';
import { GetBusinessTransactionValueRequestDto } from '@components/bussiness-types/dto/request/get-business-transaction-value-by-order.request.dto';
import { GetListWarehoseExportProposalByIdsRequestDto } from './dto/request/get-list-warehouse-export-proposal-by-ids.request';
@Injectable()
export class WarehouseExportProposalService
  implements WarehouseExportProposalServiceInterface
{
  constructor(
    @Inject('WarehouseExportProposalRepositoryInterface')
    private readonly warehouseExportProposalRepository: WarehouseExportProposalRepositoryInterface,

    @Inject('WarehouseExportProposalDetailRepositoryInterface')
    private readonly warehouseExportProposalDetailRepository: WarehouseExportProposalDetailRepositoryInterface,

    @Inject('WarehouseExportProposalDetailChildRepositoryInterface')
    private readonly warehouseExportProposalDetailChildRepository: WarehouseExportProposalDetailChildRepositoryInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemService,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('SaleServiceInterface')
    protected readonly saleService: SaleServiceInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('SettingServiceInterface')
    private readonly settingService: SettingServiceInterface,

    @Inject('WarehouseExportProposalImport')
    private readonly warehouseExportProposalImport: WarehouseExportProposalImport,

    @Inject('FileRepositoryInterface')
    private readonly fileRepository: FileRepositoryInterface,

    @Inject('TransactionBussinessTypeRepositoryInterface')
    private readonly transactionBusinessTypeRepository: TransactionBussinessTypeRepositoryInterface,

    @Inject('FileServiceInterface')
    private readonly fileService: FileService,

    private configService: ConfigService,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,

    private eventEmitter: EventEmitter2,
  ) {}
  private async generateCodeWarehouseExportProposal(
    userId: number,
  ): Promise<string> {
    const userResponse = await this.userService.getUserById(userId);

    const departmentSettingCode = userResponse.departmentSettings?.[0].code;
    const currentDate = Moment().utcOffset(7).format('MMYYYY');
    const lastProposalInDay =
      await this.warehouseExportProposalRepository.getLastWarehouseExportProposalByGenerateCode(
        currentDate,
        departmentSettingCode,
      );
    if (!isEmpty(lastProposalInDay)) {
      const lastCodeDepartmentSetting = lastProposalInDay?.code.substring(
        10,
        lastProposalInDay?.code.length,
      );
      if (departmentSettingCode === lastCodeDepartmentSetting) {
        const lastIncreaseId = Number(lastProposalInDay.code.slice(6, 10));
        const newIncreaseId = lastIncreaseId + 1;
        return `${currentDate}${newIncreaseId.toString().padStart(4, '0')}`;
      }
    }
    return `${currentDate}0000`;
  }

  private async uploadFiles(files) {
    const uploadFileRequest = {
      files,
      service: this.configService.get('serviceName'),
      resource: WAREHOUSE_EXORT_PROPOSAL,
    } as UploadFileRequestDto;
    const result = await this.fileService.uploadFiles(uploadFileRequest);
    return result?.data;
  }

  async create(request: CreateWarehouseExportProposalRequestDto): Promise<any> {
    const { items, userId } = request;
    let validateAttributeItem = true;
    const itemIds = uniq(map(items, 'itemId'));
    const listItemIds = itemIds.filter((item) => item);
    let itemsExist = [];
    let validItem = true;
    for (let i = 0; i < items?.length; i++) {
      if (items[i].itemId === undefined) {
        if (!items[i].itemName) {
          validateAttributeItem = false;
        }
      }
      if (
        items[i].itemId !== undefined &&
        items[i].itemId !== null &&
        !isEmpty(listItemIds)
      ) {
        itemsExist = await this.itemService.getItems(listItemIds);
        if (!itemsExist || listItemIds.length !== itemsExist.length) {
          const itemIdsExist = itemsExist
            ? itemsExist.map((e) => e.itemId)
            : [];
          request.items.filter((e) => !itemIdsExist.includes(e.itemId));
          validItem = false;
        }
      }
      if (!validateAttributeItem) {
        break;
      }
      if (!validItem) {
        break;
      }
    }
    if (!validateAttributeItem) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.ITEM_CODE_OR_ITEM_NAM_IS_NOT_EMPTY'),
        )
        .build();
    }

    if (!validItem) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }
    const userResponse = await this.userService.getUserById(userId);
    const code = await this.generateCodeWarehouseExportProposal(userId);
    request.departmentSettingId = userResponse.departmentSettings?.[0].id;
    const warehouseExportProposalDetailEntities = items.map((record) => {
      const warehouseExportProposalDetailEntity =
        this.warehouseExportProposalDetailRepository.createEntity({
          ...record,
          itemId: record.itemId ? record.itemId : null,
          itemCode: record.itemCode ? record.itemCode : null,
          itemName: record.itemName ? record.itemName : null,
          unitId: record.unitId ? record.unitId : null,
          requestedQuantity: record.requestedQuantity
            ? record.requestedQuantity
            : 0,
        } as any);
      return warehouseExportProposalDetailEntity;
    });
    const warehouseExportProposalEntity =
      this.warehouseExportProposalRepository.createEntityWithRelation(
        request,
        warehouseExportProposalDetailEntities,
      );
    // const itemsWarehouseExportProposalDetail =
    //   warehouseExportProposalEntity.warehouseExportProposalDetails?.map(
    //     (item) => ({
    //       itemId: item?.itemId,
    //     }),
    //   );
    warehouseExportProposalEntity.code = `${code}${userResponse.departmentSettings?.[0].code}`;
    // warehouseExportProposalEntity.receiptNumber = `${code}${userResponse.departmentSettings?.[0].code}`;
    // const allItemStockAvailable =
    //   await this.itemService.getAllItemStockAvailableByConditions({
    //     items: itemsWarehouseExportProposalDetail,
    //   } as GetItemAllStockAvailableRequestDto);
    // const itemAllStockAvailableByItemId = keyBy(
    //   allItemStockAvailable,
    //   'itemId',
    // );
    // let validRequestQuantity = false;
    // warehouseExportProposalEntity.warehouseExportProposalDetails?.forEach(
    //   (warehouseExport) => {
    //     const key = warehouseExport.itemId;
    //     if (
    //       warehouseExport.requestedQuantity >
    //       itemAllStockAvailableByItemId[key].quantity
    //     ) {
    //       validRequestQuantity = true;
    //     }
    //   },
    // );
    // if (validRequestQuantity) {
    //   return new ResponseBuilder()
    //     .withCode(ResponseCodeEnum.BAD_REQUEST)
    //     .withMessage(
    //       await this.i18n.translate(
    //         'error.THE_REQUEST_QUANTITY_NOT_GREATER_THAN_CAN_BE_EXPORTED',
    //       ),
    //     )
    //     .build();
    // }
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const response = await queryRunner.manager.save(
        warehouseExportProposalEntity,
      );
      await queryRunner.commitTransaction();

      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'message.defineWarehouseExportProposal.createSuccess',
          ),
        )
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error);
    } finally {
      await queryRunner.release();
    }
  }
  async detail(id: number): Promise<any> {
    try {
      const warehouseExportProposal =
        await this.warehouseExportProposalRepository.getDetail(id);
      if (!warehouseExportProposal) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'));
      }

      const constructionIds = [warehouseExportProposal.constructionId];
      const factoryIds = [warehouseExportProposal.factoryId];
      const departmentSettingIds = [
        warehouseExportProposal.departmentSettingId,
      ];
      if (!isEmpty(departmentSettingIds)) {
        const departmentSettings =
          await this.userService.getDepartmentSettingByIds(
            departmentSettingIds,
            true,
          );
        warehouseExportProposal.departmentSetting =
          departmentSettings[warehouseExportProposal.departmentSettingId];
      }
      if (!isEmpty(factoryIds)) {
        const factories = await this.userService.getFactoriesByIds(
          uniq(factoryIds),
          true,
        );
        warehouseExportProposal.factory =
          factories[warehouseExportProposal.factoryId];
      }
      if (!isEmpty(constructionIds)) {
        const constructions = await this.saleService.getConstructionByIds(
          uniq(constructionIds),
          true,
        );
        warehouseExportProposal.construction =
          constructions[warehouseExportProposal.constructionId];
      }

      const objectCategoryIds = uniq(
        map(warehouseExportProposal.items, 'objectCategoryId'),
      );
      const manufacturingCountryIds = uniq(
        map(warehouseExportProposal.items, 'manufacturingCountryId'),
      );
      const itemQuanlityIds = uniq(
        map(warehouseExportProposal.items, 'itemQuanlityId'),
      );
      const itemTypeSettingIds = uniq(
        compact(warehouseExportProposal.items.map((e) => e.itemTypeSettingId)),
      );
      const updatedByDetailsIds = uniq(
        map(warehouseExportProposal.items, 'updatedBy'),
      );

      const unitIds = uniq(map(warehouseExportProposal.items, 'unitId'));
      const [
        objectCategories,
        manufacturingCountries,
        itemQuanlities,
        users,
        unitSetiings,
        itemTypeSettings,
      ] = await Promise.all([
        this.itemService.getObjectCategoryByIds(uniq(objectCategoryIds), true),
        this.itemService.getManufacturingCountryByIds(
          uniq(manufacturingCountryIds),
          true,
        ),
        this.itemService.getItemQuanlityByIds(uniq(itemQuanlityIds), true),
        this.userService.getUserByIds(uniq(updatedByDetailsIds), true),
        this.itemService.getItemUnitSettingByIds(unitIds, true),
        this.itemService.getItemTypeSettingByIds(itemTypeSettingIds, true),
      ]);
      warehouseExportProposal.items?.map((item) => {
        item.objectCategory = objectCategories[item.objectCategoryId];
        item.manufacturingCountry =
          manufacturingCountries[item.manufacturingCountryId];
        item.itemQuanlity = itemQuanlities[item.itemQuanlityId];
        item.updatedBy = users[item.updatedBy];
        item.itemUnit = unitSetiings[item.unitId];
        item.itemTypeSetting = itemTypeSettings[item.itemTypeSettingId];
      });
      const childrenResponse = warehouseExportProposal?.items?.map((item) => {
        return item.childrens;
      });

      const itemIds = map(warehouseExportProposal?.items, 'itemId');
      const itemChildrenIds = map(flatMap(childrenResponse), 'itemId');
      const updatedByChildIds = uniq(
        map(flatMap(childrenResponse), 'updatedBy'),
      );
      const warehouseExportIds = map(
        flatMap(childrenResponse),
        'warehouseExportId',
      );
      let warehouseExports = [];
      if (!isEmpty(warehouseExportIds)) {
        warehouseExports = await this.warehouseRepository.findByCondition({
          id: In(warehouseExportIds),
        });
      }
      const warehouseExportMap = keyBy(warehouseExports, 'id');
      const itemWarehouseSources = warehouseExportProposal.items?.map((item) =>
        item.childrens?.map((itemChild) => ({
          itemId: itemChild?.itemId,
          lotNumber: itemChild?.lotNumber,
          warehouseId: itemChild?.warehouseExportId,
        })),
      );
      const itemsWarehouseExportProposalDetail = warehouseExportProposal?.items
        ?.filter((i) => i?.itemId !== null)
        ?.map((item) => ({
          itemId: item?.itemId,
        }));
      const itemStockAvailable =
        await this.itemService.getItemStockAvailableByConditions({
          order: {
            orderId: warehouseExportProposal.id,
            orderType: OrderTypeEnum.PROPOSAL,
          },
          items: flatMap(itemWarehouseSources),
        } as GetItemStockAvailableRequestDto);
      const allItemStockAvailable =
        await this.itemService.getAllItemStockAvailableByConditions({
          order: {
            orderId: warehouseExportProposal.id,
            orderType: OrderTypeEnum.PROPOSAL,
          },
          items: itemsWarehouseExportProposalDetail,
        } as GetItemAllStockAvailableRequestDto);
      const itemStockAvailableByItemId = groupBy(itemStockAvailable, 'itemId');
      const itemAllStockAvailableByItemId = groupBy(
        allItemStockAvailable,
        'itemId',
      );
      let items = [];
      let userUpdatedChidlResponse = [];
      if (!isEmpty(compact(itemIds)) && isEmpty(itemChildrenIds)) {
        [items, userUpdatedChidlResponse] = await Promise.all([
          this.itemService.getItemsInfo([...itemIds, ...itemChildrenIds], true),
          this.userService.getUserByIds(uniq(updatedByChildIds), true),
        ]);
      } else if (!isEmpty(compact(itemIds)) && !isEmpty(itemChildrenIds)) {
        [items, userUpdatedChidlResponse] = await Promise.all([
          this.itemService.getItemsInfo([...itemIds, ...itemChildrenIds], true),
          this.userService.getUserByIds(uniq(updatedByChildIds), true),
        ]);
      } else if (isEmpty(compact(itemIds)) && !isEmpty(itemChildrenIds)) {
        [items, userUpdatedChidlResponse] = await Promise.all([
          this.itemService.getItemsInfo([...itemIds, ...itemChildrenIds], true),
          this.userService.getUserByIds(uniq(updatedByChildIds), true),
        ]);
      }
      for (let i = 0; i < warehouseExportProposal.items.length; i++) {
        if (
          warehouseExportProposal.items[i].itemId !== null &&
          warehouseExportProposal.items[i].itemId !== undefined &&
          !isEmpty(itemIds)
        ) {
          for (const item of warehouseExportProposal.items ?? []) {
            item.itemResponse = items[item.itemId];
            item.exportAbleQuantity = (
              itemAllStockAvailableByItemId[item.itemId] ?? []
            ).reduce((prev, { quantity }) => prev + Number(quantity), 0);

            for (const itemChild of item.childrens ?? []) {
              const stockAvailable =
                itemStockAvailableByItemId[itemChild.itemId] ?? [];
              itemChild.exportableQuantity = stockAvailable[0]?.quantity ?? 0;
              itemChild.requestedQuantity = minus(
                itemChild.exportedQuantity ?? 0,
                itemChild.usedQuantity ?? 0,
              );
              itemChild.itemResponse = items[itemChild.itemId];
              itemChild.warehouseExport =
                warehouseExportMap[itemChild.warehouseExportId];
              itemChild.updatedByChild =
                userUpdatedChidlResponse[itemChild.updatedBy];
            }
          }
        } else {
          if (!isEmpty(itemChildrenIds) && !isEmpty(itemIds)) {
            for (const item of warehouseExportProposal.items ?? []) {
              item.itemResponse = items[item.itemId];
              item.exportAbleQuantity = (
                itemAllStockAvailableByItemId[item.itemId] ?? []
              ).reduce((prev, { quantity }) => prev + Number(quantity), 0);

              for (const itemChild of item.childrens ?? []) {
                const stockAvailable =
                  itemStockAvailableByItemId[itemChild.itemId] ?? [];
                itemChild.exportableQuantity = stockAvailable[0]?.quantity ?? 0;
                itemChild.requestedQuantity = minus(
                  itemChild.exportedQuantity ?? 0,
                  itemChild.usedQuantity ?? 0,
                );
                itemChild.itemResponse = items[itemChild.itemId];
                itemChild.warehouseExport =
                  warehouseExportMap[itemChild.warehouseExportId];
                itemChild.updatedByChild =
                  userUpdatedChidlResponse[itemChild.updatedBy];
              }
            }
          } else if (!isEmpty(itemChildrenIds)) {
            for (const item of warehouseExportProposal.items ?? []) {
              item.itemResponse = items[item.itemId];
              item.exportAbleQuantity = (
                itemAllStockAvailableByItemId[item.itemId] ?? []
              ).reduce((prev, { quantity }) => prev + Number(quantity), 0);

              for (const itemChild of item.childrens ?? []) {
                const stockAvailable =
                  itemStockAvailableByItemId[itemChild.itemId] ?? [];
                itemChild.exportableQuantity = stockAvailable[0]?.quantity ?? 0;
                itemChild.requestedQuantity = minus(
                  itemChild.exportedQuantity ?? 0,
                  itemChild.usedQuantity ?? 0,
                );
                itemChild.itemResponse = items[itemChild.itemId];
                itemChild.warehouseExport =
                  warehouseExportMap[itemChild.warehouseExportId];
                itemChild.updatedByChild =
                  userUpdatedChidlResponse[itemChild.updatedBy];
              }
            }
          }
        }
      }
      const response = await this.generateRespone(warehouseExportProposal);

      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getList(
    request: GetListWarehouseExportProposalRequestDto,
  ): Promise<any> {
    const { page, keyword } = request;
    if (keyword) {
      request.filterDepartmentSettingIds =
        await this.userService.getDepartmentSettingByKeyword(keyword, true);
    }
    const dataRequest = {
      ...request,
      filterDepartmentSettingIds: request.filterDepartmentSettingIds,
    } as any;
    const [data, count] = await this.warehouseExportProposalRepository.getList(
      dataRequest,
    );
    const creatorIds = uniq(data.map((item) => item.createdBy));
    const updaterIds = uniq(data.map((item) => item.updatedBy));
    const constructionIds = uniq(map(data, 'constructionId'));
    const factoryIds = uniq(map(data, 'factoryId'));
    const userIds = [...creatorIds, ...updaterIds];
    const departmentSettingIds = uniq(map(data, 'departmentSettingId'));

    if (!isEmpty(userIds) && !isEmpty(constructionIds)) {
      const users = await this.userService.getUserByIds(uniq(userIds), true);
      const constructions = await this.saleService.getConstructionByIds(
        uniq(constructionIds),
        true,
      );
      const factories = await this.userService.getFactoriesByIds(
        factoryIds,
        true,
      );

      const departmentSettings =
        await this.userService.getDepartmentSettingByIds(
          departmentSettingIds,
          true,
        );
      data.forEach((item) => {
        item.createdBy = users[item.createdBy];
        item.updatedBy = users[item.updatedBy];
        item.departmentSetting = departmentSettings[item.departmentSettingId];
        item.construction = constructions[item.constructionId];
        item.factory = factories[item.factoryId];
      });
    }

    const dataReturn = plainToClass(WarehouseExportProposalResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async delete(request: DeleteWarehouseExportProposalRequestDto): Promise<any> {
    const warehouseExportProposal =
      await this.warehouseExportProposalRepository.findOneWithRelations({
        where: { id: request.id },
        relations: ['warehouseExportProposalDetails'],
      });
    if (!warehouseExportProposal) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    warehouseExportProposal.deletedAt = new Date();
    warehouseExportProposal.deletedBy = request.userId;
    const removeWarehouseExportProposalDetailEnities =
      warehouseExportProposal.warehouseExportProposalDetails?.map((item) => {
        item.deletedAt = new Date();
        item.deletedBy = request.userId;
        return item;
      });

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(warehouseExportProposal);
      await queryRunner.manager.save(
        removeWarehouseExportProposalDetailEnities,
      );
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('message.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error);
    } finally {
      await queryRunner.release();
    }
  }

  public async confirm(
    request: ChangeStatusWarehouseExportProposalRequestDto,
  ): Promise<any> {
    const warehouseExportProposal =
      await this.warehouseExportProposalRepository.findOneById(request.id);
    if (isEmpty(warehouseExportProposal)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (
      !CONFIRMABLE_WAREHOUSE_EXPORT_PROPOSAL_STATUSES.includes(
        warehouseExportProposal.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      warehouseExportProposal.exportStatus =
        StatusExportWarehouseEnum.NO_EXPORT;
      warehouseExportProposal.status =
        StatusWarehouseExportProposalEnum.COMFIRMED;
      await queryRunner.manager.save(warehouseExportProposal);
      if (!isEmpty(request.attachment)) {
        const oldFiles = await this.fileRepository.findByCondition({
          resourceId: warehouseExportProposal.id,
          resource: FileResource.WXP,
        });
        const fileResponse = await this.fileService.uploadFile(
          request.attachment[0],
          FileResource.WXP,
        );
        if (fileResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
          await queryRunner.rollbackTransaction();
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
            .withMessage(await this.i18n.translate(fileResponse?.message))
            .build();
        }
        const fileUploadEntities = this.fileRepository.createEntity({
          resourceId: warehouseExportProposal.id,
          resource: FileResource.WXP,
          fileId: fileResponse?.data?.fileUrl,
        });
        if (!isEmpty(oldFiles)) {
          await queryRunner.manager.remove(oldFiles);
        }
        await queryRunner.manager.save(fileUploadEntities);
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error);
    } finally {
      await queryRunner.release();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(
        await this.i18n.translate(
          'message.defineWarehouseExportProposal.confirmSuccess',
        ),
      )
      .build();
  }
  public async reject(
    request: ChangeStatusWarehouseExportProposalRequestDto,
  ): Promise<any> {
    const warehouseExportProposal =
      await this.warehouseExportProposalRepository.findOneByCondition({
        id: request.id,
      });
    if (!warehouseExportProposal) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (
      !REJECTABLE_WAREHOUSE_EXPORT_PROPOSAL_STATUSES.includes(
        warehouseExportProposal.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }
    try {
      warehouseExportProposal.status =
        StatusWarehouseExportProposalEnum.REJECTED;
      await this.warehouseExportProposalRepository.create(
        warehouseExportProposal,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'message.defineWarehouseExportProposal.rejectSuccess',
          ),
        )
        .build();
    } catch (error) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NOT_ACCEPTABLE'),
      ).toResponse();
    }
  }

  private async generateRespone(
    warehouseExportProposalEntity: WarehouseExportProposalEntity,
  ): Promise<WarehouseExportProposalResponseDto> {
    const userIds = [
      warehouseExportProposalEntity.createdBy,
      warehouseExportProposalEntity.updatedBy,
    ];
    const attachment = await this.fileRepository.findOneByCondition({
      resourceId: warehouseExportProposalEntity.id,
      resource: FileResource.WXP,
    });
    let attachmentDetail;
    if (!isEmpty(attachment)) {
      attachmentDetail = await this.fileService.getFileById(attachment.fileId);
    }
    if (!isEmpty(userIds)) {
      const users = await this.userService.getUserByIds(uniq(userIds), true);

      warehouseExportProposalEntity.createdBy =
        users[warehouseExportProposalEntity.createdBy];
      warehouseExportProposalEntity.updatedBy =
        users[warehouseExportProposalEntity.updatedBy];
    }

    const response = plainToInstance(
      WarehouseExportProposalResponseDto,
      {
        ...warehouseExportProposalEntity,
        attachment: {
          ...attachmentDetail,
          id: attachmentDetail?._id,
        },
      },
      {
        excludeExtraneousValues: true,
      },
    );
    return response;
  }

  async updateEntity(
    request: UpdateWarehouseExportProposalRequestDto,
  ): Promise<any> {
    const { items } = request;
    const warehouseExportProposal =
      await this.warehouseExportProposalRepository.findOneById(request.id);
    if (!warehouseExportProposal) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const itemIds = uniq(map(items, 'itemId'));
    const listItemIds = itemIds.filter((item) => item);
    let itemsExist = [];
    let validItem = true;
    let validateAttributeItem = true;
    for (let i = 0; i < items.length; i++) {
      if (items[i].itemId === undefined) {
        if (!items[i].itemName) {
          validateAttributeItem = false;
        }
      }
      if (
        items[i].itemId !== undefined &&
        items[i].itemId !== null &&
        !isEmpty(listItemIds)
      ) {
        itemsExist = await this.itemService.getItems(listItemIds);
        if (!itemsExist || listItemIds.length !== itemsExist.length) {
          const itemIdsExist = itemsExist
            ? itemsExist.map((e) => e.itemId)
            : [];
          request.items.filter((e) => !itemIdsExist.includes(e.itemId));
          validItem = false;
        }
      }

      if (!validateAttributeItem) {
        break;
      }
      if (!validItem) {
        break;
      }
    }
    if (!validateAttributeItem) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.ITEM_CODE_OR_ITEM_NAM_IS_NOT_EMPTY'),
        )
        .build();
    }

    if (!validItem) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }
    const warehouseExportProposalEntity =
      await this.warehouseExportProposalRepository.updateEntity(
        warehouseExportProposal,
        request,
      );
    if (
      warehouseExportProposalEntity.status ===
      StatusWarehouseExportProposalEnum.REJECTED
    ) {
      warehouseExportProposalEntity.status =
        StatusWarehouseExportProposalEnum.PENDING;
    }
    return await this.save(warehouseExportProposalEntity, request);
  }

  private async save(
    warehouseExportProposalEntity: WarehouseExportProposalEntity,
    payload: CreateWarehouseExportProposalRequestDto,
  ): Promise<any> {
    const { items, constructionId } = payload;
    const isUpdate = warehouseExportProposalEntity.id != undefined;
    let construction = {};
    if (constructionId) {
      construction = await this.saleService.getConstructionById(constructionId);
      if (isEmpty(construction)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.CONSTRUCTION_NOT_FOUND'),
          )
          .build();
      }
    }

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const warehouseExportProposal = await queryRunner.manager.save(
        warehouseExportProposalEntity,
      );
      const warehouseExportProposalDetailEntities = [];
      items?.forEach((record) => {
        if (!record.id) {
          warehouseExportProposalDetailEntities.push(
            this.warehouseExportProposalDetailRepository.createEntity({
              ...record,
              warehouseExportProposalId: warehouseExportProposal.id,
              itemId: record.itemId ? record.itemId : null,
              itemCode: record.itemCode ? record.itemCode : null,
              itemName: record.itemName ? record.itemName : null,
              unitId: record.unitId ? record.unitId : null,
              itemDetail: record.itemDetail ? record.itemDetail : null,
              requestedQuantity: record.requestedQuantity
                ? record.requestedQuantity
                : 0,
              note: record.note ? record.note : null,
              updatedBy: payload.userId,
            }),
          );
        }
      });
      if (isUpdate) {
        await queryRunner.manager.delete(WarehouseExportProposalDetailEntity, {
          warehouseExportProposalId: warehouseExportProposal.id,
        });
      }
      await queryRunner.manager.save(warehouseExportProposalDetailEntities);
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          isUpdate
            ? await this.i18n.translate(
                'message.defineWarehouseExportProposal.updateSuccess',
              )
            : await this.i18n.translate(
                'message.defineWarehouseExportProposal.createSuccess',
              ),
        )
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
  }
  async requestItemCode(
    request: RequestItemCodeWarehouseExportPorposalRequestDto,
  ): Promise<any> {
    const { items } = request;

    const warehouseExportProposal =
      await this.warehouseExportProposalRepository.findOneWithRelations({
        where: { id: request.id },
        relations: ['warehouseExportProposalDetails'],
      });
    if (!warehouseExportProposal) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (
      !STATUS_TO_UPDATE_WAREHOUSE_EXPORT_PROPOSAL.includes(
        warehouseExportProposal.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }
    const objectCategoryIds = uniq(
      compact(items.map((e) => e.objectCategoryId)),
    );
    const manufacturingCountryIds = uniq(
      compact(items.map((e) => e.manufacturingCountryId)),
    );
    const itemQuanlityIds = uniq(compact(items?.map((e) => e.itemQuanlityId)));
    const itemTypeSettingIds = uniq(
      compact(items.map((e) => e.itemTypeSettingId)),
    );
    const [
      objectCategoryExist,
      manufacturingCountryExist,
      itemQuanlityExist,
      itemTypeSettingExist,
    ] = await Promise.all([
      this.itemService.getObjectCategoryByIds(objectCategoryIds),
      this.itemService.getManufacturingCountryByIds(manufacturingCountryIds),
      this.itemService.getItemQuanlityByIds(itemQuanlityIds),
      this.itemService.getItemTypeSettingByIds(itemTypeSettingIds, false),
    ]);
    if (
      !isEmpty(objectCategoryIds) &&
      objectCategoryIds.length !== objectCategoryExist.length
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.REQUEST_OBJECT_CATEGORY_NOT_FOUND'),
        )
        .build();
    }
    if (
      !isEmpty(manufacturingCountryIds) &&
      manufacturingCountryIds.length !== manufacturingCountryExist.length
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.MANUFACTURING_COUNTRY_NOT_FOUND'),
        )
        .build();
    }
    if (
      !isEmpty(itemQuanlityExist) &&
      itemQuanlityExist.length !== itemQuanlityExist.length
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.ITEM_QUANLITY_NOT_FOUND'))
        .build();
    }
    if (
      !isEmpty(itemTypeSettingExist) &&
      itemTypeSettingExist.length !== itemTypeSettingExist.length
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.ITEM_TYPE_SETTING_NOT_FOUND'),
        )
        .build();
    }

    const serializeWarehouseExportProposal = keyBy(
      warehouseExportProposal.warehouseExportProposalDetails,
      'id',
    );
    const invalidWarehouseExportProposalDetail = items.some(
      (item) =>
        !has(serializeWarehouseExportProposal, item.detailId) ||
        serializeWarehouseExportProposal[item.detailId]?.isProvideCode === true,
    );
    if (invalidWarehouseExportProposalDetail) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const warehouseExportProposalDetailEntities = [];
    const requestItemCode = new CreateRequestItemCodesRequestDto();
    requestItemCode.items = items.map((item) => {
      return {
        orderId: warehouseExportProposal.id,
        orderType: OrderTypeEnum.PROPOSAL,
        orderDetailId: item.detailId,
        itemName: item?.itemName,
        manufacturingCountryId: item?.manufacturingCountryId,
        objectCategoryId: item?.objectCategoryId,
        itemUnitId: item?.unitId,
        itemTypeId: item?.itemTypeSettingId,
        itemQualityId: item?.itemQuanlityId,
      } as RequestItemCodeRequestDto;
    });
    items.forEach((item) => {
      const warehouseExportProposalDetail =
        serializeWarehouseExportProposal[item.detailId];
      warehouseExportProposalDetail.itemName = item?.itemName;
      warehouseExportProposalDetail.objectCategoryId = item.objectCategoryId;
      warehouseExportProposalDetail.manufacturingCountryId =
        item?.manufacturingCountryId;
      warehouseExportProposalDetail.itemQuanlityId = item?.itemQuanlityId;
      warehouseExportProposalDetail.itemTypeSettingId = item?.itemTypeSettingId;
      warehouseExportProposalDetail.statusRequestCode =
        StatusRequestItemCodeEnum.WAITING;
      warehouseExportProposalDetail.isProvideCode = true;
      warehouseExportProposalDetail.updatedBy = request.userId;
      warehouseExportProposalDetailEntities.push(warehouseExportProposalDetail);
    });
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(
        WarehouseExportProposalDetailEntity,
        warehouseExportProposalDetailEntities,
      );
      const responseRequestItemCode =
        await this.itemService.createRequestItemCode(requestItemCode);
      if (responseRequestItemCode.statusCode !== ResponseCodeEnum.SUCCESS) {
        await queryRunner.rollbackTransaction();
        return responseRequestItemCode;
      }
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('message.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error);
    } finally {
      await queryRunner.release();
    }
  }

  async updateEntityAfterConfirm(
    request: UpdateWarehouseExportProposalAfterConfirmRequestDto,
  ): Promise<any> {
    const warehouseExportProposal =
      await this.warehouseExportProposalRepository.findOneWithRelations({
        where: { id: request.id },
        relations: ['warehouseExportProposalDetails'],
      });
    if (isEmpty(warehouseExportProposal)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (
      !STATUS_TO_UPDATE_WAREHOUSE_EXPORT_PROPOSAL.includes(
        warehouseExportProposal.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    if (
      warehouseExportProposal.exportStatus ===
      StatusExportWarehouseEnum.COMPLETED
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }
    const warehouseExportProposalDetailEntity =
      warehouseExportProposal.warehouseExportProposalDetails?.map(
        (item, index) => {
          item.importedQuantity = request.items[index]?.importedQuantity
            ? request.items[index]?.importedQuantity
            : item.importedQuantity;
          item.updatedBy = item.updatedBy ? item.updatedBy : request.userId;
          item.isProvideCode = request.items[index]?.isProvideCode
            ? request.items[index]?.isProvideCode
            : item.isProvideCode;
          return item;
        },
      );
    let validExportedQuantityChild = false;
    request.items.forEach((item) => {
      const totalExportedQuantityRequest = item?.childrens.reduce(
        (acc, cur) => plus(acc, cur.exportedQuantity),
        0,
      );
      if (totalExportedQuantityRequest > item.requestedQuantity) {
        validExportedQuantityChild = true;
      }
    });
    if (validExportedQuantityChild) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.TOTAL_EXPORTED_QUANTITY_MUST_BE_LESS_THAN_REQUESTED_QUANTITY_OF_ITEM',
          ),
        )
        .build();
    }

    const itemPlanning: CreateItemPlanningQuantityRequestDto[] = [];
    const warehouseExportProposalDetailChildEntities: WarehouseExportProposalDetailChildEntity[] =
      [];
    request.items.forEach((item) => {
      item.childrens?.forEach((itemChild) => {
        if (!itemChild.id) {
          warehouseExportProposalDetailChildEntities.push(
            this.warehouseExportProposalDetailChildRepository.createEntity({
              ...itemChild,
              warehouseExportProposalId: warehouseExportProposal.id,
              warehouseExportProposalDetailId: item.id,
              updatedBy: request.userId,
              createdBy: request.userId,
            }),
          );

          if (itemChild.isKeepSlot) {
            itemPlanning.push({
              itemId: itemChild.itemId,
              warehouseId: itemChild.warehouseExportId,
              planQuantity: itemChild.exportedQuantity,
              orderId: warehouseExportProposal.id,
              orderType: OrderTypeEnum.PROPOSAL,
            } as CreateItemPlanningQuantityRequestDto);
          }
        }
      });
    });
    if (!isEmpty(warehouseExportProposalDetailChildEntities)) {
      const requestValidateExport = new CheckItemStockAvailableRequestDto();
      requestValidateExport.items =
        warehouseExportProposalDetailChildEntities.map((itemChild) => ({
          itemId: itemChild.itemId,
          warehouseId: itemChild.warehouseExportId,
          lotNumber: itemChild.lotNumber
            ? itemChild.lotNumber.toUpperCase()
            : null,
          quantity: itemChild.exportedQuantity,
        }));
      const validExport = await this.warehouseService.validateItemExport(
        requestValidateExport,
      );
      if (validExport.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validExport;
      }
    }
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(warehouseExportProposal);

      await queryRunner.manager.save(warehouseExportProposalDetailEntity);
      await queryRunner.manager.save(
        warehouseExportProposalDetailChildEntities,
      );

      // TODO: Tiến hành giữ chỗ nếu có yêu cầu
      if (!isEmpty(itemPlanning)) {
        const keepSlot = await this.keepSlot(itemPlanning);
        if (keepSlot.statusCode !== ResponseCodeEnum.SUCCESS) {
          await queryRunner.rollbackTransaction();
          return keepSlot;
        }
      }
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('message.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  private async keepSlot(
    itemPlanning: CreateItemPlanningQuantityRequestDto[],
  ): Promise<ResponsePayload<any>> {
    const requestCreateItemPlanning =
      new CreateItemPlanningQuantitiesRequestDto();
    requestCreateItemPlanning.items = itemPlanning;

    const createItemPlanning =
      await this.itemService.createItemPlanningQuantities(
        requestCreateItemPlanning,
      );
    return createItemPlanning;
  }

  public async getWarehouseExportProposalItems(
    id: number,
    warehouseId: number,
  ): Promise<any> {
    const warehouseExportProposal =
      await this.warehouseExportProposalRepository.getDetail(id);
    if (!warehouseExportProposal) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }

    const itemIds = uniq(map(warehouseExportProposal?.items, 'itemId'));

    const items = await this.itemService.getItems(itemIds);
    const itemByIds = keyBy(items, 'itemId');

    const itemPlanningQuantity =
      await this.itemService.getItemPlanningQuantityByOrder(
        itemIds,
        warehouseId,
        true,
      );

    const warehouseExportProposalItems = warehouseExportProposal?.items?.map(
      (item) => {
        return {
          ...item,
          exportableQuantity:
            itemPlanningQuantity[item.itemId]?.itemQuantity -
            itemPlanningQuantity[item.itemId]?.planQuantity,
          item: {
            ...itemByIds[item.itemId],
            itemUnit: itemByIds[item.itemId]?.itemUnit?.name,
          },
          lots: item.childrens?.map((itemChild) => ({
            ...itemChild,
            item: {
              ...itemByIds[itemChild.itemId],
              itemUnit: itemByIds[itemChild.itemId]?.itemUnit?.name,
            },
          })),
        };
      },
    );

    const response = plainToInstance(
      GetWarehouseExportProposalItemsResponseDto,
      warehouseExportProposalItems,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async exportSupplyExportProposal(id: number): Promise<any> {
    const { data } = await this.detail(id);
    if (!data) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const warehouseExportProposal = await this.i18n.translate(
      `export.warehouseExportProposal`,
    );
    const companyDefault = await this.userService.getCompanyDefault();
    const nameComapny = companyDefault?.name ?? '';
    const codeFile = data?.code ?? '';
    const nameFile = `${warehouseExportProposal.nameFilePrefix}_${codeFile}`;
    const header = warehouseExportProposal.item;
    const subHeader = warehouseExportProposal.subHeader;
    const unit = data?.departmentSetting?.name ?? '';
    const receiptDate = data?.receiptDate ?? '';
    const createdAt = Moment(receiptDate).format('DD MM YYYY');
    const date = await this.i18n.translate(
      `export.warehouseExportProposal.date`,
      {
        args: {
          day: createdAt.split(' ')[0],
          month: createdAt.split(' ')[1],
          year: createdAt.split(' ')[2],
        },
      },
    );
    const code = data?.code ?? '';
    const title = warehouseExportProposal.title;
    const dear = data?.greetingTitle ?? '';
    const nameAndAddress = data?.receiverInfo ?? '';
    const reasonFile = data?.reason ?? '';
    const propose = warehouseExportProposal.propose;
    const itemData = data?.items?.map((el, index) => {
      const itemDetail = el?.itemDetail ?? '';
      let itemName = el?.itemName ? el?.itemName : el?.itemResponse?.name ?? '';
      itemName = itemName + `\n` + itemDetail;
      const itemCode = el?.itemCode
        ? el?.itemCode
        : el?.itemResponse?.code ?? '';
      const itemUnit = el?.itemUnit?.name
        ? el?.itemUnit?.name
        : el?.itemResponse?.itemUnit?.name ?? '';
      const requestedQuantity = el?.requestedQuantity ?? '';
      const requestedQuantityString = formatNumber(requestedQuantity, 2);
      return {
        stt: plus(index ?? 0, 1).toString(),
        itemCode: itemCode,
        itemName: itemName,
        itemUnit: itemUnit,
        requestedQuantity: requestedQuantityString ?? '',
        note: el?.note ?? '',
      };
    });
    while (itemData.length < 9) {
      itemData.push({
        stt: '',
        itemCode: '',
        itemName: '',
        itemUnit: '',
        requestedQuantity: '',
        note: '',
      });
    }
    const tableItems = new Table({
      width: setWidth(WORD_FILE_CONFIG.TABLE_WIDTH_PAGE_A4),
      rows: [
        new TableRow({
          tableHeader: true,
          height: setHeight(WORD_FILE_CONFIG.TABLE_HEADER_HEIGHT),
          children: TABLE_WAREHOUSE_EXPORT_ITEMS.map((item) => {
            if (item.name === 'itemName') {
              return new TableCell({
                width: setWidth(item.width),
                verticalAlign: VerticalAlign.CENTER,
                children: [
                  new Paragraph({
                    children: [
                      new TextRun({
                        text: header[item.name].split('\n')[0],
                        ...wordFileStyle.text_style_small,
                      }),
                    ],
                    alignment: AlignmentType.CENTER,
                  }),
                  new Paragraph({
                    children: [
                      new TextRun({
                        text: header[item.name].split('\n')[1],
                        ...wordFileStyle.text_style_small,
                      }),
                    ],
                    alignment: AlignmentType.CENTER,
                  }),
                ],
              });
            }
            return new TableCell({
              width: setWidth(item.width),
              verticalAlign: VerticalAlign.CENTER,
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: header[item.name],
                      ...wordFileStyle.text_style_small,
                    }),
                  ],
                  alignment: AlignmentType.CENTER,
                }),
              ],
            });
          }),
        }),
        new TableRow({
          tableHeader: true,
          height: setHeight(WORD_FILE_CONFIG.TABLE_HEADER_HEIGHT),
          children: TABLE_WAREHOUSE_EXPORT_ITEMS.map((item, index) => {
            return new TableCell({
              width: setWidth(item.width),
              verticalAlign: VerticalAlign.CENTER,
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: subHeader[index],
                      ...wordFileStyle.text_style_small,
                    }),
                  ],
                  alignment: AlignmentType.CENTER,
                }),
              ],
            });
          }),
        }),
        ...itemData.map((item) => {
          const itemValue = Object.values(item);
          return new TableRow({
            height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
            children: [
              ...itemValue?.map((text: string, index: number) => {
                let alignmentText = AlignmentType.CENTER;
                let mar = {};
                switch (index) {
                  case 1:
                  case 2:
                  case 5:
                    alignmentText = AlignmentType.LEFT;
                    mar = wordFileStyle.margin_left;
                    break;
                  case 4:
                    alignmentText = AlignmentType.RIGHT;
                    mar = wordFileStyle.margin_right;
                    break;
                  default:
                    break;
                }
                if (!isEmpty(text)) {
                  if (text.includes('\n') && !isEmpty(text.split('\n')[1])) {
                    return new TableCell({
                      columnSpan: null,
                      verticalAlign: VerticalAlign.CENTER,
                      margins: mar,
                      children: [
                        new Paragraph({
                          alignment: alignmentText,
                          children: [
                            new TextRun({
                              text: text.split('\n')[0],
                              ...wordFileStyle.text_style,
                            }),
                          ],
                        }),
                        new Paragraph({
                          alignment: alignmentText,
                          children: [
                            new TextRun({
                              text: text.split('\n')[1],
                              ...wordFileStyle.text_style,
                            }),
                          ],
                        }),
                      ],
                    });
                  } else if (isEmpty(text.split('\n')[1])) {
                    return new TableCell({
                      columnSpan: null,
                      verticalAlign: VerticalAlign.CENTER,
                      margins: mar,
                      children: [
                        new Paragraph({
                          alignment: alignmentText,
                          children: [
                            new TextRun({
                              text: text.split('\n')[0],
                              ...wordFileStyle.text_style,
                            }),
                          ],
                        }),
                      ],
                    });
                  }
                }
                return new TableCell({
                  columnSpan: null,
                  verticalAlign: VerticalAlign.CENTER,
                  margins: mar,
                  children: [
                    new Paragraph({
                      alignment: alignmentText,
                      children: [
                        new TextRun({
                          text,
                          ...wordFileStyle.text_style,
                        }),
                      ],
                    }),
                  ],
                });
              }),
            ],
          });
        }),
      ],
    });
    const signatureRow = new Table({
      width: setWidth(WORD_FILE_CONFIG.TABLE_WIDTH_PAGE_A4),
      borders: wordFileStyle.border_none,
      rows: [
        new TableRow({
          children: [
            ...TABLE_WAREHOUSE_EXPORT_SIGNATURE.map((item) => {
              return new TableCell({
                width: setWidth(item.width),
                children: [
                  new Paragraph({
                    alignment: AlignmentType.CENTER,
                    children: [
                      new TextRun({
                        text: warehouseExportProposal[item.name],
                        ...wordFileStyle.company_info_style,
                        size: WORD_FILE_CONFIG.WORD_FONT_SIZE_9,
                      }),
                    ],
                  }),
                  new Paragraph({
                    alignment: AlignmentType.CENTER,
                    children: [
                      new TextRun({
                        break: 3,
                        text: '',
                        ...wordFileStyle.text_style_bold,
                        size: WORD_FILE_CONFIG.WORD_FONT_SIZE_9,
                      }),
                    ],
                  }),
                ],
                borders: wordFileStyle.border_none,
                verticalAlign: VerticalAlign.CENTER,
              });
            }),
          ],
        }),
      ],
    });

    const headerDoc = new Table({
      borders: wordFileStyle.border_none,
      rows: [
        new TableRow({
          children: [
            new TableCell({
              borders: wordFileStyle.border_none,
              width: setWidth(7),
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: nameComapny.toUpperCase(),
                      ...wordFileStyle.address_company_info_style,
                      allCaps: true,
                    }),
                  ],
                  style: 'formatSpacing',
                }),
              ],
            }),
            new TableCell({
              borders: wordFileStyle.border_none,
              width: setWidth(7),
              children: [new Paragraph('')],
            }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: warehouseExportProposal.unit,
                      bold: WORD_FILE_CONFIG.WORD_BOLD,
                      size: WORD_FILE_CONFIG.WORD_FONT_SIZE_9,
                    }),
                    new TextRun({
                      text: unit,
                      size: WORD_FILE_CONFIG.WORD_FONT_SIZE_9,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
            new TableCell({
              children: [
                new Paragraph({
                  alignment: AlignmentType.RIGHT,
                  indent: { right: 500 },
                  children: [
                    new TextRun({
                      text: date,
                      italics: WORD_FILE_CONFIG.WORD_ITALIC,
                      size: WORD_FILE_CONFIG.WORD_FONT_SIZE_9,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({
              children: [
                new Paragraph({
                  children: [],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
            new TableCell({
              children: [
                new Paragraph({
                  alignment: AlignmentType.RIGHT,
                  indent: { right: 500 },
                  children: [
                    new TextRun({
                      text: warehouseExportProposal.receiptNumber,
                      ...wordFileStyle.text_style_small,
                      bold: WORD_FILE_CONFIG.WORD_BOLD,
                    }),
                    new TextRun({
                      text: code,
                      ...wordFileStyle.text_style_small,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
          ],
        }),
      ],
    });

    const doc = new Document({
      styles: {
        paragraphStyles: [
          {
            id: 'formatSpacing',
            name: 'Format Spacing',
            basedOn: 'Normal',
            paragraph: {
              spacing: {
                after: WORD_FILE_CONFIG.WORD_PARAGRAPH_SPACING,
              },
            },
          },
        ],
      },
      sections: [
        {
          properties: {
            page: {
              size: wordFileStyle.pagesize_a4,
            },
          },
          children: [
            headerDoc,
            new Paragraph({
              style: 'formatSpacing',
              alignment: AlignmentType.CENTER,
              spacing: {
                before: WORD_FILE_CONFIG.SPACING_BEFORE,
              },
              children: [
                new TextRun({
                  text: title,
                  size: WORD_FILE_CONFIG.WORD_FONT_SIZE_14,
                  bold: WORD_FILE_CONFIG.WORD_BOLD,
                  font: FONT_NAME,
                  allCaps: true,
                }),
              ],
            }),
            new Paragraph({
              indent: { left: 3000 },
              spacing: { after: 500 },
              alignment: AlignmentType.LEFT,
              children: [
                new TextRun({
                  text: warehouseExportProposal.dear,
                  ...wordFileStyle.text_style_size_12_bold,
                }),
                new TextRun({
                  text: dear,
                  ...wordFileStyle.text_style_size_12_normal,
                }),
              ],
            }),
            new Paragraph({
              indent: { left: 500 },
              children: [
                new TextRun({
                  text: warehouseExportProposal.nameAndAddress,
                  ...wordFileStyle.text_style_size_12_bold,
                }),
                new TextRun({
                  text: nameAndAddress,
                  ...wordFileStyle.text_style_size_12_normal,
                }),
              ],
            }),
            new Paragraph({
              indent: { left: 500 },
              children: [
                new TextRun({
                  text: warehouseExportProposal.reason,
                  ...wordFileStyle.text_style_size_12_bold,
                }),
                new TextRun({
                  text: reasonFile,
                  ...wordFileStyle.text_style_size_12_normal,
                }),
              ],
            }),
            new Paragraph({
              indent: { left: 500 },
              spacing: { after: 500 },
              children: [
                new TextRun({
                  text: propose,
                  ...wordFileStyle.text_style_size_12_normal,
                }),
              ],
            }),
            tableItems,
            new Paragraph({
              children: [
                new TextRun({
                  text: '',
                }),
              ],
            }),
            signatureRow,
          ],
        },
      ],
    });

    const result = await Packer.toBuffer(doc);
    return { result, nameFile };
  }

  async import(payload: ImportWarehouseExportProposalRequestDto): Promise<any> {
    const { file, userId } = payload;
    const importRequestDto = {
      buffer: file[0]?.data,
      fileName: file[0]?.filename,
      mimeType: file[0]?.mimetype,
    } as ImportRequestDto;
    const response = await this.warehouseExportProposalImport.importUtil(
      importRequestDto,
    );
    if (response.successCount === 0 || !response.data) {
      return new ResponseBuilder(response?.data?.result)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.UNSUCCESS'))
        .build();
    }
    const userResponse = await this.userService.getUserById(userId);
    const departmentSettingId = userResponse.departmentSettings?.[0]?.id;
    const creatingWEPResponse = await this.create({
      ...response?.data,
      departmentSettingId,
    });

    if (!creatingWEPResponse.success) {
      return new ResponseBuilder({
        success: 0,
        fail: 1,
      })
        .withCode(creatingWEPResponse.statusCode)
        .withMessage(creatingWEPResponse.message)
        .build();
    }

    return new ResponseBuilder({
      success: 1,
      fail: 0,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateItemRemainingWarehouseExportProposal(
    request: UpdateItemRemainingWarehouseExportProposalRequestDto,
  ): Promise<any> {
    const { id, items } = request;
    const warehouseExportProposal =
      await this.warehouseExportProposalRepository.findOneById(id);
    if (isEmpty(warehouseExportProposal)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const conditionFilterItems = items.map((item) => ({
      itemId: item.itemId,
      warehouseExportId: item.warehouseId,
      lotNumber: item?.lotNumber?.toUpperCase() || IsNull(),
      warehouseExportProposalId: id,
    }));

    const warehouseExportProposalItems =
      await this.warehouseExportProposalDetailChildRepository.findByCondition(
        conditionFilterItems,
      );
    if (
      isEmpty(warehouseExportProposalItems) ||
      warehouseExportProposalItems.length !== items.length
    ) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const invalidItem = [];
    const toUpdateItems: WarehouseExportProposalDetailChildEntity[] = items.map(
      (item) => {
        const warehouseExportProposalItem = warehouseExportProposalItems.find(
          (wItem) =>
            item.itemId === wItem.itemId &&
            item.warehouseId === wItem.warehouseExportId &&
            (item?.lotNumber?.toUpperCase() || null) ===
              (wItem?.lotNumber?.toUpperCase() || null),
        );
        warehouseExportProposalItem.usedQuantity = plus(
          warehouseExportProposalItem.usedQuantity,
          Number(item.quantity),
        );
        if (
          warehouseExportProposalItem.usedQuantity >
          warehouseExportProposalItem.exportedQuantity
        ) {
          invalidItem.push(item);
        }
        return warehouseExportProposalItem;
      },
    );

    if (!isEmpty(invalidItem)) {
      return new ResponseBuilder(invalidItem)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.TOTAL_EXPORTED_QUANTITY_MUST_BE_LESS_THAN_REQUESTED_QUANTITY_OF_ITEM',
          ),
        )
        .build();
    }
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (
        warehouseExportProposal.exportStatus ===
        StatusExportWarehouseEnum.NO_EXPORT
      ) {
        warehouseExportProposal.exportStatus =
          StatusExportWarehouseEnum.IN_PROGRESS;
        await queryRunner.manager.save(
          WarehouseExportProposalEntity,
          warehouseExportProposal,
        );
      }
      await queryRunner.manager.save(
        WarehouseExportProposalDetailChildEntity,
        toUpdateItems,
      );
      await queryRunner.commitTransaction();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error);
    } finally {
      await queryRunner.release();
    }
  }

  async rollbackItemRemainingWarehouseExportProposal(
    request: UpdateItemRemainingWarehouseExportProposalRequestDto,
  ): Promise<any> {
    const { id, items } = request;
    const warehouseExportProposal =
      await this.warehouseExportProposalRepository.findOneById(id);
    if (isEmpty(warehouseExportProposal)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const transactionBussinessType =
      await this.transactionBusinessTypeRepository.getBusinessTransactionValueOtherOrder(
        {
          id,
          orderId: request.orderId,
          orderType: request.orderType.toString(),
          attribute:
            BusinessTypeAttributeDefaultEnum.WAREHOUSE_EXPORT_PROPOSAL_ID,
        } as GetBusinessTransactionValueRequestDto,
      );

    const warehouseExportProposalStatus = isEmpty(transactionBussinessType)
      ? StatusExportWarehouseEnum.NO_EXPORT
      : StatusExportWarehouseEnum.IN_PROGRESS;

    const conditionFilterItems = items.map((item) => ({
      itemId: item.itemId,
      warehouseExportId: item.warehouseId,
      lotNumber: item?.lotNumber?.toUpperCase() || IsNull(),
      warehouseExportProposalId: id,
    }));

    const warehouseExportProposalItems =
      await this.warehouseExportProposalDetailChildRepository.findByCondition(
        conditionFilterItems,
      );
    if (
      isEmpty(warehouseExportProposalItems) ||
      warehouseExportProposalItems.length !== items.length
    ) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const invalidItem = [];
    const toUpdateItems: WarehouseExportProposalDetailChildEntity[] = items.map(
      (item) => {
        const warehouseExportProposalItem = warehouseExportProposalItems.find(
          (wItem) =>
            item.itemId === wItem.itemId &&
            item.warehouseId === wItem.warehouseExportId &&
            (item?.lotNumber?.toUpperCase() || null) ===
              (wItem?.lotNumber?.toUpperCase() || null),
        );
        warehouseExportProposalItem.usedQuantity = minus(
          warehouseExportProposalItem.usedQuantity,
          Number(item.quantity),
        );
        if (warehouseExportProposalItem.usedQuantity < 0) {
          invalidItem.push(item);
        }
        return warehouseExportProposalItem;
      },
    );

    if (!isEmpty(invalidItem)) {
      return new ResponseBuilder(invalidItem)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.TOTAL_EXPORTED_QUANTITY_MUST_BE_LESS_THAN_REQUESTED_QUANTITY_OF_ITEM',
          ),
        )
        .build();
    }
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      warehouseExportProposal.exportStatus = warehouseExportProposalStatus;
      await queryRunner.manager.save(
        WarehouseExportProposalEntity,
        warehouseExportProposal,
      );

      await queryRunner.manager.save(
        WarehouseExportProposalDetailChildEntity,
        toUpdateItems,
      );
      await queryRunner.commitTransaction();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error);
    } finally {
      await queryRunner.release();
    }
  }

  async updateItemExportedWarehouseExportProposal(
    request: UpdateItemExportedWarehouseExportProposalRequestDto,
  ): Promise<any> {
    const { id, items } = request;
    const warehouseExportProposal =
      await this.warehouseExportProposalRepository.findOneById(id);
    if (isEmpty(warehouseExportProposal)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.SUCCESS'),
      ).toResponse();
    }

    const conditionFilterItems = items.map((item) => ({
      itemId: item.itemId,
      warehouseExportId: item.warehouseId,
      lotNumber: item?.lotNumber?.toUpperCase() || IsNull(),
      warehouseExportProposalId: id,
    }));

    const warehouseExportProposalChildItems =
      await this.warehouseExportProposalDetailChildRepository.findByCondition(
        conditionFilterItems,
      );
    if (
      isEmpty(warehouseExportProposalChildItems) ||
      warehouseExportProposalChildItems.length !== items.length
    ) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const warehouseExportProposalItems =
      await this.warehouseExportProposalDetailRepository.findByCondition({
        id: In(
          map(
            warehouseExportProposalChildItems,
            'warehouseExportProposalDetailId',
          ),
        ),
      });
    const serializeWarehouseExportProposalItem = keyBy(
      warehouseExportProposalItems,
      'id',
    );
    const invalidItem = [];
    const toUpdateItemChild: WarehouseExportProposalDetailChildEntity[] = [];
    items.forEach((item) => {
      const warehouseExportProposalItemChild =
        warehouseExportProposalChildItems.find(
          (wItem) =>
            item.itemId === wItem.itemId &&
            item.warehouseId === wItem.warehouseExportId &&
            (item?.lotNumber?.toUpperCase() || null) ===
              (wItem?.lotNumber?.toUpperCase() || null),
        );
      warehouseExportProposalItemChild.exportedActualQuantity = plus(
        warehouseExportProposalItemChild.exportedActualQuantity,
        item.quantity,
      );
      warehouseExportProposalItemChild.usedQuantity = minus(
        warehouseExportProposalItemChild.usedQuantity,
        item.diffQuantity,
      );
      if (warehouseExportProposalItemChild.usedQuantity < 0) {
        invalidItem.push(item);
      }
      warehouseExportProposalItems;
      toUpdateItemChild.push(warehouseExportProposalItemChild);
      serializeWarehouseExportProposalItem[
        warehouseExportProposalItemChild.warehouseExportProposalDetailId
      ].exportedActualQuantity = plus(
        serializeWarehouseExportProposalItem[
          warehouseExportProposalItemChild.warehouseExportProposalDetailId
        ].exportedActualQuantity,
        item.quantity,
      );
    });

    if (!isEmpty(invalidItem)) {
      return new ResponseBuilder(invalidItem)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.TOTAL_EXPORTED_QUANTITY_MUST_BE_LESS_THAN_REQUESTED_QUANTITY_OF_ITEM',
          ),
        )
        .build();
    }
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(
        WarehouseExportProposalDetailChildEntity,
        toUpdateItemChild,
      );
      await queryRunner.manager.save(
        WarehouseExportProposalDetailEntity,
        values(serializeWarehouseExportProposalItem),
      );
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error);
    } finally {
      await queryRunner.release();
    }

    this.eventEmitter.emit(EventChangeStatusEnumWarehouseExport.update, {
      id: request.id,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getWarehouseExportProposalByIds(
    request: GetListWarehoseExportProposalByIdsRequestDto,
  ): Promise<any> {
    const { ids } = request;
    const data = await this.warehouseExportProposalRepository.findByCondition({
      id: In(ids),
    });
    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getWarehouseExportProposalByCodes(codes: string[]): Promise<any> {
    const warehouseExportProposals =
      await this.warehouseExportProposalRepository.findWithRelations({
        where: {
          code: In(codes),
        },
      });

    return new ResponseBuilder(warehouseExportProposals)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
}
