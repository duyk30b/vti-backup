import { ResponseCodeEnum } from '@constant/response-code.enum';
import { TemplateSectorEntity } from '@entities/template-sector/template-sector.entity';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { isEmpty } from 'class-validator';
import { isEmpty as isEmpty2 } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { CreateSectorDto } from './dto/request/create-sector.request.dto';
import { GetListSectorRequestDto } from './dto/request/get-list-sector.request.dto';
import { UpdateSectorDto } from './dto/request/update-sector.request.dto';
import { SectorResponseDto } from './dto/response/sector.response.dto';
import { TemplateSectorRepositoryInterface } from './interface/template-sector.repository.interface';
import { TemplateSectorServiceInterface } from './interface/template-sector.service.interface';
import { TemplateSectorTemplateShelfRepositoryInterface } from '@components/template-sector-template-shelf/interface/template-sector-template-shelf.repository.interface';
import { DeleteSectorDto } from './dto/request/delete-sector.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { In } from 'typeorm';
import { stringFormat } from '@utils/object.util';

@Injectable()
export class TemplateSectorService implements TemplateSectorServiceInterface {
  constructor(
    @Inject('TemplateSectorRepositoryInterface')
    private readonly templateSectorRepository: TemplateSectorRepositoryInterface,

    @Inject('TemplateSectorTemplateShelfRepositoryInterface')
    private readonly templateSectorTemplateShelfRepository: TemplateSectorTemplateShelfRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  public async create(request: CreateSectorDto): Promise<ResponsePayload<any>> {
    const newSectorEntity = await this.templateSectorRepository.createEntity(
      request,
    );
    return await this.save(newSectorEntity, request);
  }

  public async update(request: UpdateSectorDto): Promise<ResponsePayload<any>> {
    const sector = await this.templateSectorRepository.findOneById(request.id);
    if (!sector) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    return await this.save(sector, request);
  }

  public async getList(
    request: GetListSectorRequestDto,
  ): Promise<ResponsePayload<any> | any> {
    const { data, total } = await this.templateSectorRepository.getList(
      request,
    );
    const dataReturn = plainToInstance(SectorResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async detail(id: number): Promise<ResponsePayload<any>> {
    const sector = await this.templateSectorRepository.detail(id);
    if (isEmpty(sector)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const response = plainToInstance(SectorResponseDto, sector, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async delete(request: DeleteSectorDto): Promise<ResponsePayload<any>> {
    try {
      const sector = await this.templateSectorRepository.findOneById(
        request.id,
      );
      if (!sector) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const deletedTemplateSectorTemplateShelfs =
        await this.templateSectorTemplateShelfRepository.findByCondition({
          templateSectorId: request.id,
        });
      if (deletedTemplateSectorTemplateShelfs?.length) {
        const deletedTemplateSectorTemplateShelfIds =
          deletedTemplateSectorTemplateShelfs.map((item) => item.id);
        await this.templateSectorTemplateShelfRepository.removeMany(
          deletedTemplateSectorTemplateShelfIds,
        );
      }

      await this.templateSectorRepository.remove(request.id);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const templateSectors = await this.templateSectorRepository.findByCondition(
      {
        id: In(ids),
      },
    );

    const templateSectorIds = templateSectors.map(
      (warehouseShelf) => warehouseShelf.id,
    );
    if (templateSectors.length !== ids.length) {
      ids.forEach((id) => {
        if (!templateSectorIds.includes(id)) failIdsList.push(id);
      });
    }

    const validIds = templateSectors
      .filter((warehouseShelf) => !failIdsList.includes(warehouseShelf.id))
      .map((warehouseShelf) => warehouseShelf.id);

    try {
      if (!isEmpty(validIds)) {
        const deletedTemplateSectorTemplateShelfs =
          await this.templateSectorTemplateShelfRepository.findByCondition({
            templateSectorId: In(validIds),
          });
        if (deletedTemplateSectorTemplateShelfs?.length) {
          const deletedTemplateSectorTemplateShelfIds =
            deletedTemplateSectorTemplateShelfs.map((item) => item.id);
          await this.templateSectorTemplateShelfRepository.removeMany(
            deletedTemplateSectorTemplateShelfIds,
          );
        }

        await this.templateSectorRepository.removeMany(validIds);
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    if (isEmpty2(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  private async save(
    sectorEntity: TemplateSectorEntity,
    request: CreateSectorDto | UpdateSectorDto | any,
  ): Promise<any> {
    try {
      const { name } = request;
      const isUpdate = sectorEntity.id !== undefined;

      const sectorName = await this.templateSectorRepository.findByCondition({
        name,
      });
      if (!isUpdate && sectorName.length) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.NAME_EXIST'),
        ).toResponse();
      }

      if (
        isUpdate &&
        request.name !== sectorEntity.name &&
        sectorName.length > 0
      ) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.NAME_EXIST'),
        ).toResponse();
      }

      if (isUpdate) {
        sectorEntity = await this.templateSectorRepository.updateEntity(
          sectorEntity,
          request,
        );
      }
      const saveSector = await this.templateSectorRepository.update(
        sectorEntity,
      );

      return new ResponseBuilder(saveSector)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(err?.message || err)
        .build();
    }
  }
}
