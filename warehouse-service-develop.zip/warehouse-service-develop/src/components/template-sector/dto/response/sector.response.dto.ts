import { AbstractWarehouseSpaceDataResponseDto } from "@components/warehouse/dto/response/abstract-warehouse-space-data.response.dto";
import { ApiProperty } from "@nestjs/swagger";
import { Expose, Type } from "class-transformer";

class TemplateShelf extends AbstractWarehouseSpaceDataResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  templateSectorTemplateShelfId: number;
}

export class SectorResponseDto extends AbstractWarehouseSpaceDataResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  totalShelfsInSector: number;

  @ApiProperty()
  @Expose()
  @Type(() => TemplateShelf)
  templateShelfs: TemplateShelf[];

  @ApiProperty()
  @Expose()
  createdAt: string;
}