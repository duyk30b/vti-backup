import { CreateSectorDto } from './create-sector.request.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsInt,
  IsNotEmpty,
} from 'class-validator';

export class UpdateSectorBodyDto extends CreateSectorDto {}

export class UpdateSectorDto extends UpdateSectorBodyDto {
  @ApiProperty({ example: 1, description: 'Mã id của Khu VỰC cần update' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
