import { TemplateSectorEntity } from '@entities/template-sector/template-sector.entity';
import { TemplateSectorTemplateShelfEntity } from '@entities/template-sector-template-shelf/template-sector-template-shelf.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TemplateSectorRepository } from '@repositories/template-sector.repository';
import { TemplateSectorTemplateShelfRepository } from '@repositories/template-sector-template-shelf.repository';
import { TemplateSectorController } from './template-sector.controller';
import { TemplateSectorService } from './template-sector.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      TemplateSectorEntity,
      TemplateSectorTemplateShelfEntity,
    ]),
  ],
  providers: [
    {
      provide: 'TemplateSectorServiceInterface',
      useClass: TemplateSectorService,
    },
    {
      provide: 'TemplateSectorRepositoryInterface',
      useClass: TemplateSectorRepository,
    },
    {
      provide: 'TemplateSectorTemplateShelfRepositoryInterface',
      useClass: TemplateSectorTemplateShelfRepository,
    },
  ],
  exports: [
    {
      provide: 'TemplateSectorRepositoryInterface',
      useClass: TemplateSectorRepository,
    },
    {
      provide: 'TemplateSectorTemplateShelfRepositoryInterface',
      useClass: TemplateSectorTemplateShelfRepository,
    },
  ],
  controllers: [TemplateSectorController],
})

export class TemplateSectorModule {}
