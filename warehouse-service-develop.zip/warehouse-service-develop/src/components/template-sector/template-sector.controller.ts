import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { isEmpty } from 'lodash';
import { CreateSectorDto } from './dto/request/create-sector.request.dto';
import { DeleteSectorDto } from './dto/request/delete-sector.request.dto';
import { GetDetailSectorRequestDto } from './dto/request/get-detail-sector.request.dto';
import { GetListSectorRequestDto } from './dto/request/get-list-sector.request.dto';
import { UpdateSectorBodyDto } from './dto/request/update-sector.request.dto';
import { TemplateSectorServiceInterface } from './interface/template-sector.service.interface';
import {
  CREATE_TEMPLATE_SECTOR_PERMISSION,
  UPDATE_TEMPLATE_SECTOR_PERMISSION,
  DELETE_TEMPLATE_SECTOR_PERMISSION,
  LIST_TEMPLATE_SECTOR_PERMISSION,
} from '@utils/permissions/template-sector';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';

@Controller('template-sectors')
export class TemplateSectorController {
  constructor(
    @Inject('TemplateSectorServiceInterface')
    private readonly templateSectorService: TemplateSectorServiceInterface,
  ) {}

  @PermissionCode(CREATE_TEMPLATE_SECTOR_PERMISSION.code)
  @Post('/')
  @ApiOperation({
    tags: ['Warehouse', 'Template sectors'],
    summary: 'Create new template sector',
    description: 'Tạo mới khu vực mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  // @MessagePattern('create_template_sector')
  public async createSector(@Body() payload: CreateSectorDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateSectorService.create(request);
  }

  @PermissionCode(UPDATE_TEMPLATE_SECTOR_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Warehouse', 'Template sectors'],
    summary: 'Update Template Sector',
    description: 'Cập nhật khu vực mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  // @MessagePattern('update_template_sector')
  public async updateItem(
    @Param('id', new ParseIntPipe()) id,
    @Body() body: UpdateSectorBodyDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = Number(id);
    return await this.templateSectorService.update(request);
  }

  @PermissionCode(LIST_TEMPLATE_SECTOR_PERMISSION.code)
  @Get('/')
  @ApiOperation({
    tags: ['Warehouse', 'Template Sectors'],
    summary: 'List Template Sector',
    description: 'Danh sách Thông tin khu vực mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
  })
  // @MessagePattern('get_list_template_sector')
  public async getList(@Query() query: GetListSectorRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.templateSectorService.getList(request);
  }

  // @PermissionCode(DETAIL_TEMPLATE_SECTOR_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Warehouse', 'Template sectors'],
    summary: 'Detail Template Sector',
    description: 'Thông tin khu vực mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  // @MessagePattern('detail_template_sector')
  public async detail(@Param() param: GetDetailSectorRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.templateSectorService.detail(request.id);
  }

  @PermissionCode(DELETE_TEMPLATE_SECTOR_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Warehouse', 'Template Sectors'],
    summary: 'Delete Template Sector',
    description: 'Xóa Thông tin khu vực mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
  })
  // @MessagePattern('delete_template_sector')
  public async delete(@Param() param: DeleteSectorDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateSectorService.delete(request);
  }

  @PermissionCode(DELETE_TEMPLATE_SECTOR_PERMISSION.code)
  @Delete('/multiple')
  @ApiOperation({
    tags: ['Warehouse', 'Template Sectors'],
    summary: 'Delete multiple Template Sector',
    description: 'Xóa nhiều thông tin khu vực mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
  })
  // @MessagePattern('delete_template_sector_multiple')
  public async deleteMultiple(@Query() query: DeleteMultipleDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateSectorService.deleteMultiple(request);
  }
}
