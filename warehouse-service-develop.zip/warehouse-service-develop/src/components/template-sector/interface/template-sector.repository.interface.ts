import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { TemplateSectorEntity } from '@entities/template-sector/template-sector.entity';
import { GetListSectorRequestDto } from '../dto/request/get-list-sector.request.dto';

export interface TemplateSectorRepositoryInterface
  extends BaseInterfaceRepository<TemplateSectorEntity> {
  createEntity(body: any): TemplateSectorEntity;
  updateEntity(
    entity: TemplateSectorEntity,
    request: any,
  ): TemplateSectorEntity;
  getList(request: GetListSectorRequestDto): Promise<any>;
  detail(request: number): Promise<any>;
}
