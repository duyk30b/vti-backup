import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateSectorDto } from '../dto/request/create-sector.request.dto';
import { DeleteSectorDto } from '../dto/request/delete-sector.request.dto';
import { GetListSectorRequestDto } from '../dto/request/get-list-sector.request.dto';
import { UpdateSectorDto } from '../dto/request/update-sector.request.dto';

export interface TemplateSectorServiceInterface {
  create(payload: CreateSectorDto): Promise<ResponsePayload<any>>;
  update(payload: UpdateSectorDto): Promise<ResponsePayload<any>>;
  detail(id: number): Promise<ResponsePayload<any>>;
  delete(id: DeleteSectorDto): Promise<ResponsePayload<any>>;
  deleteMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  getList(payload: GetListSectorRequestDto): Promise<ResponsePayload<any>>;
}
