import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { SaleCronService } from './sale-cron.service';
import { SaleService } from './sale.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
    {
      provide: 'SaleCronServiceInterface',
      useClass: SaleCronService,
    },
  ],
  controllers: [],
})
export class SaleModule {}
