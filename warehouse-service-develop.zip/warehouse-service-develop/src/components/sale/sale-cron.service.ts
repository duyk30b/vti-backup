import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { plainToInstance } from 'class-transformer';
import { keyBy } from 'lodash';
import { ReportTotalOrderRequestDto } from './../dashboard/dto/request/report-total-order.request.dto';
import { CreatePurchasedOrderImportReceiveRequestDto } from './dto/request/create-purchased-order-import-receive.request.dto';
import { GetOrderDetailDto } from './dto/request/get-sale-detail.dto';
import { ConstructionResponseDto } from './dto/response/construction.response.dto';
import { ReasonResponseDto } from './dto/response/reason.response.dto';
import { SaleResponseDtoInterface } from './dto/response/sale.interface.response';
import { SourceResponseDto } from './dto/response/source.response.dto';
import { SaleServiceInterface } from './interface/sale.service.interface';

@Injectable()
export class SaleCronService implements SaleServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  updateSyncStatusPurchasedOrderImport(id: number): Promise<any> {
    throw new Error('Method not implemented.');
  }

  public async updatePOImportWarehouseLotQuantity(
    orderId: any,
    warehouseId: any,
    itemLotOrderDetails: any,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }

  public async updateImportOrderWarehouseLotQuantity(
    orderId: any,
    warehouseId: any,
    itemLotOrderDetails: any,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }

  /**
   *
   * @param getOrderDto
   * @returns
   */
  async getOrderWarehouseDetail(
    getOrderDto: GetOrderDetailDto,
  ): Promise<SaleResponseDtoInterface> {
    throw new Error('Method not implemented.');
  }

  /**
   *
   * @param orderId
   * @param orderType
   * @param orderDetails
   * @param orderWarehouseDetails
   * @returns
   */
  async updateActualQuantity(
    orderId: number,
    orderType: number,
    orderDetails: any,
    orderWarehouseDetails: any,
    itemLots?: any[],
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }

  async updateReturnQuantity(
    orderId: number,
    orderType: number,
    orderDetails: any,
    orderWarehouseDetails: any,
    itemLots?: any[],
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }

  async updateConfirmQuantity(
    orderId: number,
    orderType: number,
    orderDetails: any,
    orderWarehouseDetails: any,
    userId?: number,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }

  async getProductionOrderByIds(ids: number[]): Promise<any> {
    throw new Error('Method not implemented.');
  }

  async getPurchasedOrderByIds(ids: number[]): Promise<any> {
    throw new Error('Method not implemented.');
  }

  async getSaleOrderByIds(ids: number[]): Promise<any> {
    throw new Error('Method not implemented.');
  }

  async getSaleOrderExportByIds(
    ids: number[],
    withDetail = false,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }
  async getPurchasedOrderImportByIds(ids: number[]): Promise<any> {
    throw new Error('Method not implemented.');
  }

  async getOtherOrderByIds(ids: number[]): Promise<any> {
    throw new Error('Method not implemented.');
  }

  async getReturnOrderByIds(ids: number[]): Promise<any> {
    throw new Error('Method not implemented.');
  }

  async updateCollectQuantity(
    orderId: number,
    orderType: number,
    orderDetails: any,
    orderWarehouseDetails: any,
    itemLots?: any[],
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }

  async getDetailSaleOrderExportById(id: number): Promise<any> {
    throw new Error('Method not implemented.');
  }

  async getLatestPOImportSuccess(itemIds: number[]): Promise<any> {
    throw new Error('Method not implemented.');
  }

  public async getConstructionById(id: number): Promise<any> {
    const responseUserService = await this.natsClientService.send(
      'get_detail_construction',
      { id: id },
    );
    if (responseUserService.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return responseUserService.data;
  }

  public async getConstructionByCode(code: string): Promise<any> {
    const responseUserService = await this.natsClientService.send(
      'get_construction_by_code',
      { code },
    );
    if (responseUserService.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return responseUserService.data;
  }

  public async getSourceById(id: number): Promise<any> {
    const responseSaleService = await this.natsClientService.send(
      'get_source_detail',
      { id: id },
    );
    if (responseSaleService.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return responseSaleService.data;
  }
  public async getReasonById(id: number): Promise<any> {
    const responseSaleService = await this.natsClientService.send(
      'get_reason_detail',
      { id: id },
    );
    if (responseSaleService.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return responseSaleService.data;
  }

  async getConstructionByIds(ids: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      'get_construction_by_ids',
      {
        constructionIds: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const dataReturn = plainToInstance(
      ConstructionResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );
    return serilize ? keyBy(dataReturn, 'id') : dataReturn;
  }

  async getVendorByIds(ids: number[]): Promise<any> {
    const response = await this.natsClientService.send('get_vendor_by_ids', {
      ids,
    });
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async getCostTypeByIds(ids: number[]): Promise<any> {
    const response = await this.natsClientService.send('get_cost_type_by_ids', {
      ids,
    });
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async getOrganizationPaymentByIds(ids: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      'get_organization_payment_by_ids',
      { ids },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data?.items;
  }

  async getCategoryContructionByIds(ids: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      'get_category_contruction_by_ids',
      { ids },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async getReceiptByIds(ids: number[]): Promise<any> {
    const response = await this.natsClientService.send('get_receipt_by_ids', {
      ids,
    });
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }
  async getReasonByIds(ids: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send('get_reason_by_ids', {
      reasonIds: ids,
    });
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const dataReturn = plainToInstance(
      ReasonResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );
    return serilize ? keyBy(dataReturn, 'id') : dataReturn;
  }
  async getSourceByIds(ids: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send('get_source_by_ids', {
      sourceIds: ids,
    });
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const dataReturn = plainToInstance(
      SourceResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );
    return serilize ? keyBy(dataReturn, 'id') : dataReturn;
  }

  async reportTotalOrder(request: ReportTotalOrderRequestDto): Promise<any> {
    throw new Error('Method not implemented.');
  }

  async createPoImportReceive(
    request: CreatePurchasedOrderImportReceiveRequestDto,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }
}
