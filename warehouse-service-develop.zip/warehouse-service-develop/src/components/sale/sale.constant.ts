export enum SaleTypeEnum {
  IMPORT = 0,
  EXPORT = 1,
}
