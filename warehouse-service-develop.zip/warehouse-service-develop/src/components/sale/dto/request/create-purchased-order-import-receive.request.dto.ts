import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsBoolean,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsPositive,
  ValidateNested,
} from 'class-validator';

export class PurchasedOrderImportReceiveItemRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @IsPositive()
  actualQuantity: number;
}

export class CreatePurchasedOrderImportReceiveRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  purchasedOrderImportId: number;

  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsBoolean()
  isComplete: boolean;

  @ApiProperty({
    type: PurchasedOrderImportReceiveItemRequestDto,
    isArray: true,
  })
  @IsArray()
  @ArrayUnique<PurchasedOrderImportReceiveItemRequestDto>((item) => item.itemId)
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => PurchasedOrderImportReceiveItemRequestDto)
  items: PurchasedOrderImportReceiveItemRequestDto[];
}
