import { ORDER_ACTION_TYPES, ORDER_TYPES } from '@constant/order.constant';
import { Allow, IsIn, IsInt, IsNotEmpty, IsOptional } from 'class-validator';

export class GetOrderDetailDto {
  @IsInt()
  userId?: number;

  @IsNotEmpty()
  @IsInt()
  id: number;

  @IsNotEmpty()
  @IsInt()
  @IsIn(ORDER_TYPES)
  orderType: number;

  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @IsNotEmpty()
  @IsInt()
  @IsIn(ORDER_ACTION_TYPES)
  actionType: number;

  @IsOptional()
  @IsInt()
  withOrderDefault?: number;

  @Allow()
  user?: any;
}
