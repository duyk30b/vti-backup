// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface SaleResponseDtoInterface {
  id: number;

  code: string;

  status: number;

  type: number;

  departmentReceiptId: number;

  completedAt: Date;

  items: ItemResponseDtoInterface[];

  orderType?: number;

  explanation?: string;
}

export class ItemResponseDtoInterface {
  qcCheck: boolean;

  qcCriteriaId: number;

  detailId: number;

  warehouseId: number;

  warehouseDetailId: number;

  itemId: number;

  quantity: number;

  planQuantity?: number;

  actualQuantity: number;

  entryQuantity: number;

  qcPassQuantity: number;

  lotNumber?: string;

  locations?: any;

  collectedQuantity?: number;

  receivedQuantity?: number;
}
