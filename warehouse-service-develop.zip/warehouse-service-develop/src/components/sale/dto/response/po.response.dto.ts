import { Expose, Type } from 'class-transformer';
import {
  ItemResponseDtoInterface,
  SaleResponseDtoInterface,
} from './sale.interface.response';

export class PurchasedOrderResponseDto implements SaleResponseDtoInterface {
  @Expose({ name: 'poId' })
  id: number;

  @Expose()
  code: string;

  @Expose({ name: 'poStatus' })
  status: number;

  @Expose({ name: 'poType' })
  type: number;

  @Expose()
  departmentReceiptId: number;

  @Expose({ name: 'poCompletedAt' })
  completedAt: Date;

  @Expose()
  @Type(() => PurchaseItemResponseDto)
  items: PurchaseItemResponseDto[];
}

class PurchaseItemResponseDto implements ItemResponseDtoInterface {
  @Expose({ name: 'podId' })
  detailId: number;

  @Expose({ name: 'powdId' })
  warehouseDetailId: number;

  @Expose()
  qcCheck: boolean;

  @Expose()
  qcCriteriaId: number;

  @Expose()
  itemId: number;

  @Expose()
  warehouseId: number;

  @Expose()
  quantity: number;

  @Expose()
  actualQuantity: number;

  @Expose()
  qcPassQuantity: number;

  entryQuantity = 0;
}
