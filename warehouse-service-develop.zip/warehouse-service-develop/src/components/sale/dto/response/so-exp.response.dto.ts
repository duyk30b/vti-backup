import { Expose, Transform, Type } from 'class-transformer';
import {
  ItemResponseDtoInterface,
  SaleResponseDtoInterface,
} from './sale.interface.response';

export class SaleOrderExportResponseDto implements SaleResponseDtoInterface {
  @Expose()
  id: number;

  @Expose()
  status: number;

  @Expose()
  code: string;

  @Expose()
  type: number;

  @Expose()
  explanation: string;

  @Expose()
  departmentReceiptId: number;

  @Expose()
  completedAt: Date;

  @Expose()
  @Type(() => SaleItemResponseDto)
  items: SaleItemResponseDto[];
}

class SaleItemResponseDto implements ItemResponseDtoInterface {
  @Expose()
  @Transform((value) => +value.value)
  detailId: number;

  @Expose()
  @Transform((value) => +value.value)
  warehouseDetailId: number;

  @Expose({ name: 'id' })
  itemId: number;

  @Expose()
  warehouseId: number;

  @Expose()
  quantity: number;

  @Expose()
  lots: any;

  @Expose()
  actualQuantity: number;

  @Expose()
  collectedQuantity: number;

  @Expose()
  returnedQuantity: number;

  @Expose()
  planQuantity: number;

  @Expose()
  qcPassQuantity: number;

  entryQuantity = 0;

  @Expose()
  qcCheck: boolean;

  @Expose()
  qcCriteriaId: number;
}
