import { Expose, Type } from 'class-transformer';
import {
  ItemResponseDtoInterface,
  SaleResponseDtoInterface,
} from './sale.interface.response';

export class SaleOrderResponseDto implements SaleResponseDtoInterface {
  @Expose({ name: 'soId' })
  id: number;

  @Expose({ name: 'soStatus' })
  status: number;

  @Expose()
  code: string;

  @Expose({ name: 'soType' })
  type: number;

  @Expose()
  departmentReceiptId: number;

  @Expose({ name: 'soCompletedAt' })
  completedAt: Date;

  @Expose()
  @Type(() => SaleItemResponseDto)
  items: SaleItemResponseDto[];
}

class SaleItemResponseDto implements ItemResponseDtoInterface {
  warehouseId: number;
  lotNumber?: string;
  @Expose({ name: 'sodId' })
  detailId: number;

  @Expose({ name: 'sowdId' })
  warehouseDetailId: number;

  @Expose()
  itemId: number;

  @Expose()
  quantity: number;

  @Expose()
  actualQuantity: number;

  @Expose()
  qcPassQuantity: number;

  entryQuantity = 0;

  @Expose()
  qcCheck: boolean;

  @Expose()
  qcCriteriaId: number;
}
