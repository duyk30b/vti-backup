import { Expose, Type } from 'class-transformer';
import {
  ItemResponseDtoInterface,
  SaleResponseDtoInterface,
} from './sale.interface.response';

export class ImportOrderResponseDto implements SaleResponseDtoInterface {
  completedAt: Date;
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  status: number;

  @Expose()
  type: number;

  @Expose()
  departmentReceiptId: number;

  @Expose()
  @Type(() => ImportOrderItemResponseDto)
  items: ImportOrderItemResponseDto[];
}

class ImportOrderItemResponseDto implements ItemResponseDtoInterface {
  @Expose()
  detailId: number;

  @Expose()
  warehouseDetailId: number;

  @Expose()
  warehouseId: number;

  @Expose()
  qcCheck: boolean;

  @Expose()
  qcCriteriaId: number;

  @Expose({ name: 'id' })
  itemId: number;

  @Expose()
  quantity: number;

  @Expose()
  planQuantity: number;

  @Expose()
  actualQuantity: number;

  @Expose()
  lots: any;

  @Expose()
  qcPassQuantity: number;

  entryQuantity = 0;
}
