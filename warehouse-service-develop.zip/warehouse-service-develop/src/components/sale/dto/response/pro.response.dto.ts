import { Expose, Type } from 'class-transformer';
import { IsOptional } from 'class-validator';
import {
  ItemResponseDtoInterface,
  SaleResponseDtoInterface,
} from './sale.interface.response';

export class ProductionOrderResponseDto implements SaleResponseDtoInterface {
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  status: number;

  @Expose()
  type: number;

  @Expose()
  @IsOptional()
  orderType: number;

  @Expose()
  completedAt: Date;

  @Expose()
  departmentReceiptId: number;

  @Expose()
  @Type(() => ProductionItemResponseDto)
  items: ProductionItemResponseDto[];
}

class ProductionItemResponseDto implements ItemResponseDtoInterface {
  @Expose()
  detailId: number;

  @Expose()
  warehouseDetailId: number;

  @Expose({ name: 'id' })
  itemId: number;

  @Expose()
  lots: any;

  @Expose()
  warehouseId: number;

  @Expose()
  qcCheck: boolean;

  @Expose()
  qcCriteriaId: number;

  @Expose()
  quantity: number;

  @Expose()
  planQuantity: number;

  @Expose()
  actualQuantity: number;

  @Expose()
  qcPassQuantity: number;

  entryQuantity = 0;
}
