import { Expose, Type } from 'class-transformer';
import { IsOptional } from 'class-validator';
import {
  ItemResponseDtoInterface,
  SaleResponseDtoInterface,
} from './sale.interface.response';

export class PurchasedOrderImportResponseDto
  implements SaleResponseDtoInterface
{
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  status: number;

  @Expose()
  type: number;

  @Expose()
  explanation: string;

  @Expose()
  @IsOptional()
  orderType: number;

  @Expose()
  completedAt: Date;

  @Expose()
  departmentReceiptId: number;

  @Expose()
  @Type(() => PurchaseImportItemResponseDto)
  items: PurchaseImportItemResponseDto[];

  @Expose()
  @Type(() => PurchaseOrderImportDetailResponseDto)
  purchasedOrderImportDetails: PurchaseOrderImportDetailResponseDto[];
}

class PurchaseImportItemResponseDto implements ItemResponseDtoInterface {
  @Expose()
  detailId: number;

  @Expose()
  warehouseDetailId: number;

  @Expose()
  warehouseId: number;

  @Expose()
  qcCheck: boolean;

  @Expose()
  qcCriteriaId: number;

  @Expose({ name: 'id' })
  itemId: number;

  @Expose()
  lots: any;

  @Expose()
  quantity: number;

  @Expose()
  planQuantity: number;

  @Expose()
  receivedQuantity: number;

  @Expose()
  actualQuantity: number;

  @Expose()
  qcPassQuantity: number;

  entryQuantity = 0;
}

class PurchaseOrderImportDetailResponseDto {
  @Expose()
  id: number;

  @Expose()
  itemId: number;

  @Expose()
  price: number;

  @Expose()
  quantity: number;

  @Expose()
  totalPrice: number;
}
