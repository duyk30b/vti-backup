import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class ConstructionResponseDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'construction 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'ABCDEF', description: '' })
  @Expose()
  code: string;
}
