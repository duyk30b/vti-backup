import { WarehouseDataResponseDto } from '@components/warehouse/dto/response/warehouse-data.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class Base {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}
export class OrderResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  companyId: number;

  @ApiProperty()
  @Expose()
  createdByUserId: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  status: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  type: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  ebsId: string;

  @ApiProperty()
  @Expose()
  transactionNumberCreated: string;

  @ApiProperty()
  @Expose()
  deadline: Date;

  @ApiProperty()
  @Expose()
  receiptDate: Date;

  @ApiProperty()
  @Expose()
  purchasedAt: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  transactionDate: Date;

  @ApiProperty()
  @Expose()
  confirmedAt: Date;

  @ApiProperty()
  @Expose()
  approvedAt: Date;

  @ApiProperty()
  @Expose()
  referenceDoc: string;

  @ApiProperty()
  @Expose()
  postedAt: Date;

  @ApiProperty()
  @Expose()
  note: string;

  @ApiProperty()
  @Expose()
  @Type(() => WarehouseDataResponseDto)
  sourceWarehouse: WarehouseDataResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => WarehouseDataResponseDto)
  destinationWarehouse: WarehouseDataResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => Base)
  vendor: Base;

  @ApiProperty()
  @Expose()
  @Type(() => Base)
  customer: Base;
}
