import { ReportTotalOrderRequestDto } from '@components/dashboard/dto/request/report-total-order.request.dto';
import { CreatePurchasedOrderImportReceiveRequestDto } from '../dto/request/create-purchased-order-import-receive.request.dto';
import { GetOrderDetailDto } from '../dto/request/get-sale-detail.dto';
import { SaleResponseDtoInterface } from '../dto/response/sale.interface.response';

export interface SaleServiceInterface {
  getOrderWarehouseDetail(
    getOrderDto: GetOrderDetailDto,
  ): Promise<SaleResponseDtoInterface>;

  updateActualQuantity(
    orderId,
    orderType,
    orderDetails,
    orderWarehouseDetails,
  ): Promise<any>;

  updatePOImportWarehouseLotQuantity(
    orderId,
    warehouseId,
    itemLotOrderDetails,
  ): Promise<any>;

  updateImportOrderWarehouseLotQuantity(
    orderId,
    warehouseId,
    itemLotOrderDetails,
  ): Promise<any>;

  updateCollectQuantity(
    orderId,
    orderType,
    orderDetails,
    orderWarehouseDetails,
  ): Promise<any>;

  getLatestPOImportSuccess(itemIds: number[]): Promise<any>;
  getConstructionById(id: number): Promise<any>;
  getConstructionByIds(ids: number[], serilize?: boolean): Promise<any>;
  getVendorByIds(ids: number[]): Promise<any>;
  getCostTypeByIds(ids: number[]): Promise<any>;
  getOrganizationPaymentByIds(ids: number[]): Promise<any>;
  getSaleOrderExportByIds(ids: number[], withDetail: boolean): Promise<any>;
  getPurchasedOrderImportByIds(ids: number[]): Promise<any>;
  getCategoryContructionByIds(ids: number[]): Promise<any>;
  getReceiptByIds(ids: number[]): Promise<any>;
  getSourceById(id: number): Promise<any>;
  getReasonById(id: number): Promise<any>;
  getSourceByIds(ids: number[], serilize?: boolean): Promise<any>;
  getReasonByIds(ids: number[], serilize?: boolean): Promise<any>;
  reportTotalOrder(request: ReportTotalOrderRequestDto): Promise<any>;
  createPoImportReceive(
    request: CreatePurchasedOrderImportReceiveRequestDto,
  ): Promise<any>;
  getConstructionByCode(code: string): Promise<any>;
  updateSyncStatusPurchasedOrderImport(id: number): Promise<any>;
}
