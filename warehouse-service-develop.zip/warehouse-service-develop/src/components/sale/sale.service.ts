import { NATS_SALE } from '@config/nats.config';
import { OrderTypeEnum } from '@constant/order.constant';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Inject, Injectable } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { plainToInstance } from 'class-transformer';
import { isEmpty, keyBy } from 'lodash';
import { ReportTotalOrderRequestDto } from './../dashboard/dto/request/report-total-order.request.dto';
import { CreatePurchasedOrderImportReceiveRequestDto } from './dto/request/create-purchased-order-import-receive.request.dto';
import { GetOrderDetailDto } from './dto/request/get-sale-detail.dto';
import { ConstructionResponseDto } from './dto/response/construction.response.dto';
import { ImportOrderResponseDto } from './dto/response/imo-import.response.dto';
import { PurchasedOrderImportResponseDto } from './dto/response/po-import.response.dto';
import { ProductionOrderResponseDto } from './dto/response/pro.response.dto';
import { ReasonResponseDto } from './dto/response/reason.response.dto';
import { SaleResponseDtoInterface } from './dto/response/sale.interface.response';
import { SaleOrderExportResponseDto } from './dto/response/so-exp.response.dto';
import { SourceResponseDto } from './dto/response/source.response.dto';
import { SaleServiceInterface } from './interface/sale.service.interface';

@Injectable()
export class SaleService implements SaleServiceInterface {
  constructor(
    private readonly natsClientService: NatsClientService,
    @Inject(REQUEST) private readonly req: any,
  ) {}

  public async updatePOImportWarehouseLotQuantity(
    orderId: any,
    warehouseId: any,
    itemLotOrderDetails: any,
  ): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_SALE}.update_po_import_warehouse_lots`,
      {
        orderId: orderId,
        warehouseId: warehouseId,
        itemLotOrderDetails: itemLotOrderDetails,
      },
    );
  }

  public async updateImportOrderWarehouseLotQuantity(
    orderId: any,
    warehouseId: any,
    itemLotOrderDetails: any,
  ): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_SALE}.update_import_order_warehouse_lots`,
      {
        orderId: orderId,
        warehouseId: warehouseId,
        itemLotOrderDetails: itemLotOrderDetails,
      },
    );
  }

  /**
   *
   * @param getOrderDto
   * @returns
   */
  async getOrderWarehouseDetail(
    getOrderDto: GetOrderDetailDto,
  ): Promise<SaleResponseDtoInterface | any> {
    const { id, orderType, warehouseId, actionType, withOrderDefault, user } =
      getOrderDto;
    let sale: { statusCode: ResponseCodeEnum; data: any },
      data: SaleResponseDtoInterface | PromiseLike<SaleResponseDtoInterface>;
    switch (orderType) {
      case OrderTypeEnum.PO:
        sale = await this.natsClientService.send(
          `${NATS_SALE}.get_purchased_order_import_warehouse`,
          {
            id: id,
            warehouseId: warehouseId,
            type: actionType,
            user: this.req.user,
            userId: getOrderDto?.userId,
            withCompletedOrder: 1,
            withOrderDefault,
          },
        );

        if (sale.statusCode === ResponseCodeEnum.SUCCESS)
          data = plainToInstance(PurchasedOrderImportResponseDto, sale.data, {
            excludeExtraneousValues: true,
          });
        break;
      case OrderTypeEnum.IMO:
      case OrderTypeEnum.EXO:
        sale = await this.natsClientService.send(
          `${NATS_SALE}.get_import_order_warehouse`,
          {
            id: id,
            warehouseId: warehouseId,
            type: actionType,
            user: this.req.user,
          },
        );

        if (sale.statusCode === ResponseCodeEnum.SUCCESS)
          data = plainToInstance(ImportOrderResponseDto, sale.data, {
            excludeExtraneousValues: true,
          });
        break;
      case OrderTypeEnum.PRO:
        sale = await this.natsClientService.send(
          `${NATS_SALE}.get_production_order_warehouse`,
          {
            id: id,
            warehouseId: warehouseId,
            type: actionType,
            user: this.req.user,
          },
        );
        if (sale.statusCode === ResponseCodeEnum.SUCCESS)
          data = plainToInstance(ProductionOrderResponseDto, sale.data, {
            excludeExtraneousValues: true,
          });
        break;
      case OrderTypeEnum.RO:
        sale = await this.natsClientService.send(
          `${NATS_SALE}.get_return_order_warehouse`,
          {
            id: id,
            warehouseId: warehouseId,
            type: actionType,
            user: this.req.user,
          },
        );
        if (sale.statusCode === ResponseCodeEnum.SUCCESS)
          data = plainToInstance(ProductionOrderResponseDto, sale.data, {
            excludeExtraneousValues: true,
          });
        break;
      default:
        sale = await this.natsClientService.send(
          `${NATS_SALE}.get_sale_order_export_warehouse`,
          {
            id: id,
            warehouseId: warehouseId,
            user: this.req.user || user,
            orderType: orderType,
            withOrderDefault,
          },
        );

        if (sale.statusCode === ResponseCodeEnum.SUCCESS)
          data = plainToInstance(SaleOrderExportResponseDto, sale.data, {
            excludeExtraneousValues: true,
          });
        break;
    }
    return data;
  }

  /**
   *
   * @param orderId
   * @param orderType
   * @param orderDetails
   * @param orderWarehouseDetails
   * @returns
   */
  async updateActualQuantity(
    orderId: number,
    orderType: number,
    orderDetails: any,
    orderWarehouseDetails: any,
    itemLots?: any[],
  ): Promise<any> {
    switch (orderType) {
      case OrderTypeEnum.PO:
        return await this.natsClientService.send(
          `${NATS_SALE}.update_po_import_actual_quantity`,
          {
            orderId: orderId,
            orderDetails: orderDetails,
            warehouseOrderDetails: orderWarehouseDetails,
            itemLots: itemLots,
          },
        );
      case OrderTypeEnum.IMO:
      case OrderTypeEnum.EXO:
        return await this.natsClientService.send(
          `${NATS_SALE}.update_import_order_actual_quantity`,
          {
            orderId: orderId,
            orderDetails: orderDetails,
            warehouseOrderDetails: orderWarehouseDetails,
            itemLots: itemLots,
          },
        );
      case OrderTypeEnum.PRO:
        return await this.natsClientService.send(
          `${NATS_SALE}.update_pro_actual_quantity`,
          {
            orderId: orderId,
            orderDetails: orderDetails,
            warehouseOrderDetails: orderWarehouseDetails,
            itemLots: itemLots,
          },
        );
      case OrderTypeEnum.RO:
        return await this.natsClientService.send(
          `${NATS_SALE}.update_return_order_actual_quantity`,
          {
            orderId: orderId,
            orderDetails: orderDetails,
            warehouseOrderDetails: orderWarehouseDetails,
            itemLots: itemLots,
          },
        );

      default:
        return await this.natsClientService.send(
          `${NATS_SALE}.update_sale_order_export_actual_quantity`,
          {
            orderId: orderId,
            orderDetails: orderDetails,
            warehouseOrderDetails: orderWarehouseDetails,
            itemLots: itemLots,
          },
        );
    }
  }

  async updateReturnQuantity(
    orderId: number,
    orderType: number,
    orderDetails: any,
    orderWarehouseDetails: any,
    itemLots?: any[],
  ): Promise<any> {
    switch (orderType) {
      case OrderTypeEnum.PO:
        return await this.natsClientService.send(
          `${NATS_SALE}.update_po_import_return_quantity`,
          {
            orderId: orderId,
            orderDetails: orderDetails,
            warehouseOrderDetails: orderWarehouseDetails,
            itemLots: itemLots,
          },
        );
      case OrderTypeEnum.SO:
        return await this.natsClientService.send(
          `${NATS_SALE}.update_sale_order_export_return_quantity`,
          {
            orderId: orderId,
            orderDetails: orderDetails,
            warehouseOrderDetails: orderWarehouseDetails,
            itemLots: itemLots,
          },
        );
      default:
        break;
    }
  }

  async updateConfirmQuantity(
    orderId: number,
    orderType: number,
    orderDetails: any,
    orderWarehouseDetails: any,
    userId?: number,
  ): Promise<any> {
    switch (orderType) {
      case OrderTypeEnum.PO:
        return await this.natsClientService.send(
          `${NATS_SALE}.update_po_import_confirm_quantity`,
          {
            orderId: orderId,
            orderDetails: orderDetails,
            warehouseOrderDetails: orderWarehouseDetails,
            userId: userId,
          },
        );
      case OrderTypeEnum.IMO:
      case OrderTypeEnum.EXO:
        return await this.natsClientService.send(
          `${NATS_SALE}.update_import_order_confirm_quantity`,
          {
            orderId: orderId,
            orderDetails: orderDetails,
            warehouseOrderDetails: orderWarehouseDetails,
            userId: userId,
          },
        );
      case OrderTypeEnum.PRO:
        return await this.natsClientService.send(
          `${NATS_SALE}.update_pro_confirm_quantity`,
          {
            orderId: orderId,
            orderDetails: orderDetails,
            warehouseOrderDetails: orderWarehouseDetails,
            userId: userId,
          },
        );
      case OrderTypeEnum.RO:
        return await this.natsClientService.send(
          `${NATS_SALE}.update_return_order_confirm_quantity`,
          {
            orderId: orderId,
            orderDetails: orderDetails,
            warehouseOrderDetails: orderWarehouseDetails,
            userId: userId,
          },
        );

      default:
        return await this.natsClientService.send(
          `${NATS_SALE}.update_sale_order_export_confirm_quantity`,
          {
            orderId: orderId,
            orderDetails: orderDetails,
            warehouseOrderDetails: orderWarehouseDetails,
            userId: userId,
          },
        );
    }
  }

  async getProductionOrderByIds(ids: number[]): Promise<any> {
    if (isEmpty(ids)) return [];
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_production_order_by_ids`,
      {
        ids: ids,
      },
    );
    if (response.statusCode === ResponseCodeEnum.SUCCESS) {
      return response.data;
    } else return [];
  }

  async getPurchasedOrderByIds(ids: number[]): Promise<any> {
    if (isEmpty(ids)) return [];
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_purchased_order_by_ids`,
      {
        ids: ids,
      },
    );
    if (response.statusCode === ResponseCodeEnum.SUCCESS) {
      return response.data;
    } else return [];
  }

  async getSaleOrderByIds(ids: number[]): Promise<any> {
    if (isEmpty(ids)) return [];
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_sale_order_by_ids`,
      {
        ids: ids,
      },
    );
    if (response.statusCode === ResponseCodeEnum.SUCCESS) {
      return response.data;
    } else return [];
  }

  async getSaleOrderExportByIds(
    ids: number[],
    withDetail = false,
  ): Promise<any> {
    if (isEmpty(ids)) return [];
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_sale_order_export_by_ids`,
      {
        ids: ids,
        withDetail,
      },
    );
    if (response.statusCode === ResponseCodeEnum.SUCCESS) {
      return response.data;
    }
    return [];
  }
  async getPurchasedOrderImportByIds(ids: number[]): Promise<any> {
    if (isEmpty(ids)) return [];
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_purchased_order_import_by_ids`,
      {
        ids: ids,
      },
    );
    if (response.statusCode === ResponseCodeEnum.SUCCESS) {
      return response.data;
    }

    return [];
  }

  async getOtherOrderByIds(ids: number[]): Promise<any> {
    if (isEmpty(ids)) return [];
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_other_order_by_ids`,
      {
        ids: ids,
      },
    );
    if (response.statusCode === ResponseCodeEnum.SUCCESS) {
      return response.data;
    }
    return [];
  }

  async updateSyncStatusPurchasedOrderImport(id: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.update_sync_status_po_import`,
      {
        id,
      },
    );
    if (response.statusCode === ResponseCodeEnum.SUCCESS) {
      return true;
    }
    return false;
  }

  async getReturnOrderByIds(ids: number[]): Promise<any> {
    if (isEmpty(ids)) return [];
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_return_order_by_ids`,
      {
        ids: ids,
      },
    );
    if (response.statusCode === ResponseCodeEnum.SUCCESS) {
      return response.data;
    }
    return [];
  }

  async updateCollectQuantity(
    orderId: number,
    orderType: number,
    orderDetails: any,
    orderWarehouseDetails: any,
    itemLots?: any[],
  ): Promise<any> {
    switch (orderType) {
      case OrderTypeEnum.SO:
        return await this.natsClientService.send(
          `${NATS_SALE}.update_sale_order_export_collected_quantity`,
          {
            orderId: orderId,
            orderDetails: orderDetails,
            warehouseOrderDetails: orderWarehouseDetails,
            itemLots: itemLots,
          },
        );

      default:
        return [];
    }
  }

  async getDetailSaleOrderExportById(id: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_sale_order_export_detail`,
      { id },
    );
    if (response.statusCode === ResponseCodeEnum.SUCCESS) {
      return response.data;
    }
    return {};
  }

  async getLatestPOImportSuccess(itemIds: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_latest_po_import_success`,
      { itemIds },
    );
    if (response.statusCode === ResponseCodeEnum.SUCCESS) {
      return response.data.doorIds;
    }
    return [];
  }

  public async getConstructionById(id: number): Promise<any> {
    const responseUserService = await this.natsClientService.send(
      `${NATS_SALE}.get_detail_construction`,
      { id: id },
    );
    if (responseUserService.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return responseUserService.data;
  }

  public async getConstructionByCode(code: string): Promise<any> {
    const responseUserService = await this.natsClientService.send(
      `${NATS_SALE}.get_construction_by_code`,
      { code },
    );
    if (responseUserService.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return responseUserService.data;
  }

  public async getSourceById(id: number): Promise<any> {
    const responseSaleService = await this.natsClientService.send(
      `${NATS_SALE}.get_source_detail`,
      { id: id },
    );
    if (responseSaleService.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return responseSaleService.data;
  }
  public async getReasonById(id: number): Promise<any> {
    const responseSaleService = await this.natsClientService.send(
      `${NATS_SALE}.get_reason_detail`,
      { id: id },
    );
    if (responseSaleService.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return responseSaleService.data;
  }

  async getConstructionByIds(ids: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_construction_by_ids`,
      {
        constructionIds: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const dataReturn = plainToInstance(
      ConstructionResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );
    return serilize ? keyBy(dataReturn, 'id') : dataReturn;
  }

  async getVendorByIds(ids: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_vendor_by_ids`,
      {
        ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async getCostTypeByIds(ids: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_cost_type_by_ids`,
      {
        ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async getOrganizationPaymentByIds(ids: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_organization_payment_by_ids`,
      { ids },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data?.items;
  }

  async getCategoryContructionByIds(ids: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_category_contruction_by_ids`,
      { ids },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async getReceiptByIds(ids: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_receipt_by_ids`,
      {
        ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }
  async getReasonByIds(ids: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_reason_by_ids`,
      {
        reasonIds: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const dataReturn = plainToInstance(
      ReasonResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );
    return serilize ? keyBy(dataReturn, 'id') : dataReturn;
  }
  async getSourceByIds(ids: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_source_by_ids`,
      {
        sourceIds: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const dataReturn = plainToInstance(
      SourceResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );
    return serilize ? keyBy(dataReturn, 'id') : dataReturn;
  }
  async reportTotalOrder(request: ReportTotalOrderRequestDto): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.sale_report_total_order`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    return response.data;
  }

  async createPoImportReceive(
    request: CreatePurchasedOrderImportReceiveRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.create_purchased_order_import_receive`,
      request,
    );
    return response;
  }
}
