import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { SettingService } from './setting.service';

@Global()
@Module({
  imports: [ConfigModule],
  providers: [
    ConfigService,
    {
      provide: 'SettingServiceInterface',
      useClass: SettingService,
    },
  ],
  exports: [
    {
      provide: 'SettingServiceInterface',
      useClass: SettingService,
    },
  ],
  controllers: [],
})
export class SettingModule {}
