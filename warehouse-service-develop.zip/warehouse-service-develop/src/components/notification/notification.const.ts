export enum ActionNotificationEnum {
  WAREHOUSE_YARD = 'GO TO WAREHOURSE',
}

export enum TypeNotificationEnum {
  MAIL = 'MAIL',
  WEB = 'WEB',
  APP = 'APP',
}