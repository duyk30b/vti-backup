import { InventoryItemResponse } from '@components/inventory/dto/response/inventory-item.response.dto';
import { GetListReportStockQueryDto } from '@components/warehouse-report/dto/query/get-list-report-stock.query.dto';
import { StockMovementIdByDate } from '@components/warehouse-report/dto/response/report-by-type.response';
import { NATS_ITEM } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Inject, Injectable } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { escapeCharForSearch } from '@utils/common';
import { Filter, PaginationQuery } from '@utils/pagination.query';
import { ResponseService } from '@utils/response-service';
import { plainToInstance } from 'class-transformer';
import { Request } from 'express';
import { isEmpty, keyBy, map } from 'lodash';
import { CheckStockAvailableDto } from './dto/request/check-stock-available.request.dto';
import { CreateItemPlanningQuantitiesRequestDto } from './dto/request/create-item-planning-quantity.request.dto';
import {
  CreateItemStockMovementAndItemWarehouseShelfFloorDto,
  CreateItemStockMovementDto,
} from './dto/request/create-item-stock-movement.request.dto';
import { CreateItemSwiftLocatorRequestDto } from './dto/request/create-item-swift-locator.request.dto';
import { CreateRequestItemCodesRequestDto } from './dto/request/create-request-item-code.request.dto';
import { GetPositionItemsByConditionsRequestDto } from './dto/request/filter-position-items-by-conditions.request.dto';
import { GetFloorExistItemRequestDto } from './dto/request/get-floor-exist-item.request.dto';
import { GetHistoriesItemStockMovements } from './dto/request/get-histories-item-stock-movements.request.dto';
import { GetItemAllStockAvailableRequestDto } from './dto/request/get-item-stock-available-all-warehouse.request.dto';
import { GetItemStockAvailableSwiftLocatorRequestDto } from './dto/request/get-item-stock-available-swift-locator.request.dto';
import { GetItemStockAvailableRequestDto } from './dto/request/get-item-stock-available.request.dto';
import { GetItemStockQuantityRequestDto } from './dto/request/get-item-stock-quantity.request.dto';
import { GetItemStockWarehouseExpireStorageTimeRequestDto } from './dto/request/get-item-stock-warehouse-expire-storage-time.request.dto';
import { GetItemStockMovementInWarehouseLocatorByDay } from './dto/request/get-item-stock-warehouse-locator-by-day.request.dto';
import { GetItemWarehouseStockRequestDto } from './dto/request/get-item-stock.dto';
import { GetPositionItemByFloorResquestDto } from './dto/request/get-position-item-by-floor.request.dto';
import { GetPositionItemWarehouseByIds } from './dto/request/get-position-item-warehouse-by-ids.request.dto';
import { GetPositionItemWarehouseDto } from './dto/request/get-position-item-warehouse.request.dto';
import { GetPositionItemsRequestDto } from './dto/request/get-position-items.request.dto';
import { ItemWarehouseTransferRequestDto } from './dto/request/item-transfer.request.dto';
import { ItemWarehouseRequestDto } from './dto/request/item.dto.request';
import { SuggestLocatorWithItemQuantityRequest } from './dto/request/suggest-locator-with-item-quantity.request.dto';
import { UpdateItemWarehousePlanningQuantityRequestDto } from './dto/request/update-item-warehouse-planning-quantity.request.dto';
import { UpdateStockFromOrderRequest } from './dto/request/update-stock-from-order-request.dto';
import { ItemQualityResponseDto } from './dto/response/item-quality.response.dto';
import { ItemStockMovementWarehouseShelfFloorResponseDto } from './dto/response/item-stock-movement-warehouse-shelf-floor.response.dto';
import { ItemStockMovementsResponseDto } from './dto/response/item-stock-movements.response.dto';
import { ItemWarehouseResponseDto } from './dto/response/item-warehouse.dto.response';
import { ItemResponseDto } from './dto/response/item.dto.response';
import { ManufacturingCountryResponseDto } from './dto/response/manufacturing-country,response';
import { ObjectCategoryResponseDto } from './dto/response/object-category.response.dto';
import { ItemServiceInterface } from './interface/item.service.interface';

@Injectable()
export class ItemService implements ItemServiceInterface {
  constructor(
    private readonly natsClientService: NatsClientService,
    @Inject(REQUEST) private readonly req: Request,
  ) {}

  async getStock(request: GetListReportStockQueryDto): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_for_report`,
      request,
    );
  }

  async getWarning(request: PaginationQuery): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_ITEM}.get_inventory_warning`,
      request,
    );
  }

  async getItemByItemType(itemIds: number[], itemTypeId: number): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_ITEM}.get_item_by_item_type`,
      {
        itemIds: itemIds,
        itemTypeId: itemTypeId,
      },
    );
  }

  async getTranferByDateAndIds(
    data: StockMovementIdByDate[],
    itemTypeId: number,
  ): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_ITEM}.get_transfer_count_by_date`,
      {
        dateIds: data,
        itemTypeId: itemTypeId,
      },
    );
  }

  async getDataReportDaily(
    warehouseId: number,
    warehouseStockMovementInIds: number[],
    warehouseStockMovementOutIds: number[],
  ) {
    return await this.natsClientService.send(`${NATS_ITEM}.get_report_daily`, {
      warehouseId: warehouseId,
      warehouseStockMovementInIds: warehouseStockMovementInIds,
      warehouseStockMovementOutIds: warehouseStockMovementOutIds,
    });
  }

  async getQuantityItemWarehouse(itemTypeId: number): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_ITEM}.get_quantity_item_warehouse`,
      {
        itemTypeId,
      },
    );
  }

  /**
   * @param  {ItemWarehouseRequestDto[]} itemWarehouses
   * @returns Promise
   */
  async getItemWarehouse(
    itemWarehouses: ItemWarehouseRequestDto[],
    warehouseId: number,
    warehouseSectorId?: number,
    warehouseShelfId?: number,
    warehouseShelfFloorId?: number,
  ): Promise<any> {
    const item =
      !warehouseSectorId && !warehouseShelfFloorId && !warehouseShelfId
        ? await this.natsClientService.send(
            `${NATS_ITEM}.get_item_warehouses`,
            {
              items: itemWarehouses,
              warehouseId: warehouseId,
            },
          )
        : await this.natsClientService.send(
            'get_item_warehouse_with_locations',
            {
              items: itemWarehouses,
              warehouseId: warehouseId,
              warehouseSectorId: warehouseSectorId,
              warehouseShelfId: warehouseShelfId,
              warehouseShelfFloorId: warehouseShelfFloorId,
              lotNumber: 'DEFAULT', //TODO
            },
          );
    if (!item?.data) {
      return null;
    }
    const data = plainToInstance(ItemWarehouseResponseDto, item.data, {
      excludeExtraneousValues: true,
    });

    return data;
  }

  /**
   * @returns Promise
   */
  async getItemStockMovementByWarehouseStockMovementId(
    warehouseStockMovementId: number,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_movement_by_warehouse_stock_movement_id`,
      {
        warehouseStockMovementId: warehouseStockMovementId,
      },
    );
    return response.statusCode === ResponseCodeEnum.SUCCESS
      ? response.data
      : [];
  }

  /**
   * @returns Promise
   */
  async getItemStockMovementByWarehouseStockMovementIds(
    warehouseStockMovementIds: number[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_movement_by_warehouse_stock_movement_ids`,
      {
        warehouseStockMovementIds,
      },
    );
    return response.statusCode === ResponseCodeEnum.SUCCESS
      ? response.data
      : [];
  }
  /**
   * @param  {ApproveInventoryItemDto[]} listApproveItem
   * @returns Promise
   */
  async approveInventory(
    listApproveItem: InventoryItemResponse[],
  ): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_ITEM}.update_item_stock_quantity`,
      {
        items: listApproveItem,
      },
    );
  }

  async createItemStockMovement(
    createRequest: CreateItemStockMovementDto[],
  ): Promise<ResponseService> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.create_items_stock_movement`,
      {
        items: createRequest,
      },
    );
    return plainToInstance(ItemStockMovementsResponseDto, response, {
      excludeExtraneousValues: true,
    });
  }

  async createItemStockMovementAndItemWarehouseShelfFloor(
    request: CreateItemStockMovementAndItemWarehouseShelfFloorDto,
  ): Promise<ResponseService> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.create_items_stock_movement`,
      request,
    );
    return plainToInstance(ItemStockMovementsResponseDto, response, {
      excludeExtraneousValues: true,
    });
  }

  async checkStockAvailable(request: CheckStockAvailableDto): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_ITEM}.check_stock_available`,
      request,
    );
  }

  async updateStockFromOrder(
    request: UpdateStockFromOrderRequest,
  ): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_ITEM}.update_stock_from_order`,
      request,
    );
  }

  async getItems(itemIds: number[]): Promise<ItemResponseDto[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_items_by_ids`,
      {
        itemIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const dataReturn = plainToInstance(ItemResponseDto, <any[]>response.data, {
      excludeExtraneousValues: true,
    });

    return dataReturn;
  }
  async getListStorageDateByItemIds(itemIds: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_storage_date_by_item_ids`,
      { itemIds: itemIds },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response;
  }

  async getItemsInfo(
    itemIds: number[],
    serilize?: boolean,
  ): Promise<ItemResponseDto[] | any> {
    let userId;
    if (this.req['query']?.userId) {
      userId = this.req['query']?.userId;
    } else if (this.req['body']?.userId) {
      userId = this.req['body']?.userId;
    } else if (this.req['params']?.userId) {
      userId = this.req['params']?.userId;
    }
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_list`,
      {
        page: 1,
        limit: itemIds.length,
        filter: [{ column: 'itemIds', text: itemIds.join(',') }],
        userId: userId,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const dataReturn = plainToInstance(
      ItemResponseDto,
      <any[]>response.data?.items,
      {
        excludeExtraneousValues: true,
      },
    );
    if (serilize) {
      const items = {};
      dataReturn.forEach((item) => {
        items[item.itemId] = item;
      });

      return items;
    }
    return dataReturn;
  }

  async updateTransferQuantity(
    sourceItems: ItemWarehouseTransferRequestDto[],
    destinationItems: ItemWarehouseTransferRequestDto[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.update_stock_from_transfer`,
      {
        sourceItems,
        destinationItems,
      },
    );
    return response.statusCode === ResponseCodeEnum.SUCCESS;
  }

  async getPositionItemByFloor(
    request: GetPositionItemByFloorResquestDto[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_movement_warehouse_shelf_floor`,
      {
        request,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const dataReturn = plainToInstance(
      ItemStockMovementWarehouseShelfFloorResponseDto,
      response.data,
      {
        excludeExtraneousValues: true,
      },
    );

    return dataReturn;
  }

  async getPositionItemByItemIds(
    itemIds: number[],
    warehoureShelfFloorIds: number[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_movement_warehouse_shelf_floor_by_item_ids`,
      {
        itemIds: itemIds,
        warehoureShelfFloorIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const dataReturn = plainToInstance(
      ItemStockMovementWarehouseShelfFloorResponseDto,
      response.data,
      {
        excludeExtraneousValues: true,
      },
    );

    return dataReturn;
  }

  async getItemStockMovementInWarehouseFloor(
    request: GetPositionItemWarehouseDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_position_item_in_warehouse_floor`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getItemStockMovementInWarehouseFloorByIds(
    request: GetPositionItemWarehouseByIds,
  ): Promise<any[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_movement_warehouse_shelf_floor_by_ids`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getHistoriesItemStockMovements(
    request: GetHistoriesItemStockMovements,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_histories_item_stock_movements`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getPositionItems(
    request: GetPositionItemsRequestDto,
  ): Promise<ItemStockMovementWarehouseShelfFloorResponseDto[] | any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_position_items`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    const dataReturn = plainToInstance(
      ItemStockMovementWarehouseShelfFloorResponseDto,
      response.data,
      {
        excludeExtraneousValues: true,
      },
    );

    return dataReturn;
  }

  async getPackageByIds(ids: number[], serilize?: boolean): Promise<any> {
    if (ids.length === 0) {
      return [];
    }
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_package_by_ids`,
      {
        ids: ids,
      },
    );
    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    if (serilize) {
      return keyBy(response.data, 'id');
    }

    return response.data;
  }

  async getListLotNumberItemStockByItemIds(
    warehouseShelfFloorIds?: number[],
    locatorIds?: number[],
    ids?: number[],
  ): Promise<any[]> {
    const request = {
      warehouseShelfFloorIds:
        warehouseShelfFloorIds.length > 0 ? warehouseShelfFloorIds : [],
      locatorIds: locatorIds.length > 0 ? locatorIds : [],
      itemIds: ids.length > 0 ? ids : [],
    };
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_list_lot_number_of_item_stock`,
      request,
    );
    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    return response.data;
  }

  async getPositionItemsByCondition(
    request: GetPositionItemsByConditionsRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_position_items_by_conditions`,
      request,
    );
    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    return response.data;
  }

  async getItemStockMovementInWarehouseFloorByWarehouseFloorIds(
    warehouseFloorIds: number[],
  ): Promise<any[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_movement_warehouse_shelf_floor_by_warehouse_shelf_floor_ids`,
      { warehouseShelfFloorIds: warehouseFloorIds },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getItemStockMovementInWarehouseByLocatorIds(
    locatorIds: number[],
  ): Promise<any[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_movement_warehouse_locator_by_warehouse_locator_ids`,
      { locatorIds: locatorIds },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getFloorExistItem(
    request: GetFloorExistItemRequestDto,
  ): Promise<any[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_floor_exist_item`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getItemWarehouseByItemIds(
    itemIds: number[],
    warehouseId: number,
  ): Promise<any[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_warehouse_by_item_ids`,
      {
        itemIds,
        warehouseId,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getItemWarehouseByMultipleItemAndWarehouse(
    itemIds: number[],
    warehouseIds: number[],
  ): Promise<any[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_warehouse_by_multiple_item_and_warehouse`,
      {
        itemIds,
        warehouseIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async updateItemWarehousePlanningQuantity(
    request: UpdateItemWarehousePlanningQuantityRequestDto,
  ): Promise<any> {
    await this.natsClientService.send(
      `${NATS_ITEM}.update_item_warehouse_planning_quantity`,
      request,
    );
  }

  async getItemStockQuantity(
    request: GetItemStockQuantityRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_quantity`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getItemWarehouseStock(
    request: GetItemWarehouseStockRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_warehouse_stock`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getItemLotWarehouseStockReport(
    request: GetItemWarehouseStockRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_lot_warehouse_stock_report`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getItemsByConditions(condition: any, sort?: any): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_ITEM}.get_items_by_conditions`,
      {
        condition: condition,
        sort: sort,
      },
    );
  }

  async getItemsByName(filterByName, onlyId?: boolean): Promise<any> {
    if (isEmpty(filterByName)) {
      return [];
    }

    const response = await this.getItemsByConditions(
      'LOWER(unaccent(name)) LIKE ' +
        `LOWER(unaccent('%${escapeCharForSearch(
          filterByName.text,
        )}%')) escape '\\'`,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return onlyId ? keyBy(response.data, 'id') : response.data;
  }

  async getItemsByNameOrCode(keyword: string, onlyId?: boolean): Promise<any> {
    if (isEmpty(keyword)) {
      return [];
    }

    const response = await this.getItemsByConditions(
      `(LOWER(unaccent(name)) LIKE 
        LOWER(unaccent('%${escapeCharForSearch(
          keyword,
        )}%')) escape '\\' OR LOWER(unaccent(code)) LIKE
        LOWER(unaccent('%${escapeCharForSearch(keyword)}%')) escape '\\')`,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return onlyId ? keyBy(response.data, 'id') : response.data;
  }
  async getItemsByCode(filterByCode, onlyId?: boolean): Promise<any> {
    if (isEmpty(filterByCode)) {
      return [];
    }

    const response = await this.getItemsByConditions(
      'LOWER(code) LIKE ' +
        `LOWER('%${escapeCharForSearch(filterByCode.text)}%') escape '\\'`,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (!isEmpty(response.data) && onlyId === true) {
      return map(response.data, 'id');
    }

    return response.data;
  }
  public async getObjectCategoryId(id: number): Promise<any> {
    const responseItemService = await this.natsClientService.send(
      `${NATS_ITEM}.get_detail_object_category`,
      { id: id },
    );
    if (responseItemService.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return responseItemService.data;
  }
  async getObjectCategoryByIds(
    ids: number[],
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_object_category_by_ids`,
      {
        objectCategoryIds: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const dataReturn = plainToInstance(
      ObjectCategoryResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );
    return serilize ? keyBy(dataReturn, 'id') : dataReturn;
  }

  async getManufacturingCountryByIds(
    ids: number[],
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_manufacturing_country_by_ids`,
      {
        manufacturingCountryIds: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const dataReturn = plainToInstance(
      ManufacturingCountryResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );
    return serilize ? keyBy(dataReturn, 'id') : dataReturn;
  }

  async getItemQuanlityByIds(ids: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_quanlity_by_ids`,
      {
        itemQuanlityIds: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const dataReturn = plainToInstance(
      ItemQualityResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );
    return serilize ? keyBy(dataReturn, 'id') : dataReturn;
  }

  async getItemPlanningQuantityByOrder(
    itemIds: number[],
    warehouseId: number,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_planning_quantity_by_order`,
      {
        itemIds,
        warehouseId,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return serilize ? {} : [];
    }

    return serilize ? keyBy(response.data, 'itemId') : response.data;
  }

  async getItemPlanningQuantityByOrderId(
    orderId: number,
    orderType: number,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_planning_quantity_by_order_id`,
      {
        orderId,
        orderType,
      },
    );
    return response.data;
  }

  async getItemPlanningQuantityByLocatorIds(
    locatorIds: number[],
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_planning_quantity_by_locator_ids`,
      {
        locatorIds: locatorIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return serilize ? {} : [];
    }

    return serilize ? keyBy(response.data, 'itemId') : response.data;
  }

  async getItemUnitSettingByIds(
    unitIds: number[],
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_unit_setting_by_ids`,
      {
        unitIds: unitIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return serilize ? {} : [];
    }
    return serilize ? keyBy(response.data, 'id') : response.data;
  }

  async getItemTypeSettingByIds(
    ids: number[],
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_type_setting_by_ids`,
      {
        itemTypeSettingIds: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return serilize ? {} : [];
    }
    return serilize ? keyBy(response.data, 'id') : response.data;
  }

  async createItemPlanningQuantities(
    request: CreateItemPlanningQuantitiesRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.create_item_planning_quantitites`,
      request,
    );
    return response;
  }

  async removeItemPlanningQuantities(
    orderId: number,
    orderType: number,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.remove_item_planning_quantitites`,
      { orderId, orderType },
    );
    return response;
  }

  async createItemStockSwiftLocator(
    request: CreateItemSwiftLocatorRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.create_item_stock_swift_locator`,
      request,
    );
    return response;
  }

  public async getItemStockAvailableByConditions(
    request: GetItemStockAvailableRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_available_by_conditions`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }
  public async getAllItemStockAvailableByConditions(
    request: GetItemAllStockAvailableRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_all_item_stock_available_by_conditions`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }
  public async getItemSockWarehouseLocatorByDay(
    request: GetItemStockMovementInWarehouseLocatorByDay,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_warehouse_locator_by_day`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  public async getItemStockWarehouseExpireStorageTime(
    request: GetItemStockWarehouseExpireStorageTimeRequestDto[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_warehouse_expire_storage_time`,
      {
        data: request,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  public async getWarehouseStockByItemId(itemId: number): Promise<any[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_warehouse_stock_by_item_id`,
      {
        itemId,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  public async getItemStockAvailableSwiftLocator(
    request: GetItemStockAvailableSwiftLocatorRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_available_swift_floor`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  public async createRequestItemCode(
    request: CreateRequestItemCodesRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.create_request_item_code`,
      request,
    );
    return response;
  }

  public async getItemByCodes(itemCodes: string[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_by_codes`,
      {
        codes: JSON.stringify(itemCodes),
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getItemUnitSettingByNames(
    unitNames: string[],
    serilize = false,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_unit_setting_by_names`,
      {
        unitNames,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return serilize ? {} : [];
    }
    return serilize ? keyBy(response.data) : response.data;
  }

  public async getInventoryNormList(filter: Filter[]): Promise<any[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.inventory_time_norm_list`,
      { filter, isGetAll: '1' },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data.items;
  }

  async getItemStockWarehousePrices(request: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_warehouse_prices`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    return response.data;
  }

  async updateItemStockWarehousePriceEbsIn(
    request: any[],
    orderType: any,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.update_item_stock_warehouse_price_ebs_in`,
      {
        items: request,
        orderType: orderType,
      },
    );
    return response;
  }

  async suggestLocatorWithItemQuantity(
    request: SuggestLocatorWithItemQuantityRequest,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.suggest_locator_with_item_quantity`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async suggestLocatorPoimpAutoComplete(request: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.suggest_locator_poimp_auto_complete`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];

    return response.data;
  }
}
