import { Type } from 'class-transformer';
import { IsInt, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class GetPositionItemByFloorResquestDto {
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @IsInt()
  @IsNotEmpty()
  floorId: number;

  @IsOptional()
  @IsString()
  lotNumber: string;
}
