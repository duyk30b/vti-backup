import { ItemStockMovementTypeEnum } from '@components/item/item.constant';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import {
  IsArray,
  IsNotEmpty,
  ValidateNested,
  IsOptional,
} from 'class-validator';

export class CreateItemStockMovementShelfFloorDto {
  itemId: number;

  quantity: number;

  lotNumber: string;

  locatorId: number;

  amount?: number;

  totalAmount?: number;

  mfg: Date;
  constructor(request) {
    this.quantity = request.quantity;
    this.locatorId = request.locatorId || null;
    this.itemId = request.itemId || null;
    this.lotNumber = request.lotNumber || null;
    this.mfg = request.mfg || null;
    this.amount = request.amount;
    this.totalAmount = request.totalAmount;
  }
}
export class CreateItemStockMovementDto {
  @Expose()
  orderId: number;

  @Expose()
  orderType: number;

  @Expose()
  orderCode: string;

  @Expose()
  warehouseStockMovementId: number;

  @Expose()
  itemId: number;

  @Expose()
  warehouseId: number;

  @Expose()
  userId: number;

  @Expose()
  movementOrderDetailId: number;

  @Expose()
  movementOrderWarehouseDetailId: number;

  @Expose()
  quantity: number;

  @Expose()
  itemsStockMovementHistories: CreateItemStockMovementShelfFloorDto[];

  @Expose()
  type: ItemStockMovementTypeEnum;

  @Expose()
  amount: number;

  constructor(
    orderId: number,
    orderCode: string,
    orderType: number,
    warehouseStockMovementId: number,
    itemId: number,
    warehouseId: number,
    userId: number,
    movementOrderDetailId: number,
    movementOrderWarehouseDetailId: number,
    quantity: number,
    type: number,
    itemsStockMovementHistories: CreateItemStockMovementShelfFloorDto[],
    amount?: number,
  ) {
    this.orderId = orderId;
    this.orderCode = orderCode;
    this.orderType = orderType;
    this.warehouseStockMovementId = warehouseStockMovementId;
    this.itemId = itemId;
    this.warehouseId = warehouseId;
    this.userId = userId;
    this.movementOrderDetailId = movementOrderDetailId;
    this.movementOrderWarehouseDetailId = movementOrderWarehouseDetailId;
    this.quantity = quantity;
    this.type = type;
    this.itemsStockMovementHistories = itemsStockMovementHistories;
    this.amount = amount;
  }
}

export class CreateItemStockMovementAndItemWarehouseShelfFloorDto {
  @Expose()
  @IsNotEmpty()
  @ValidateNested()
  @IsArray()
  @Type(() => CreateItemStockMovementDto)
  items: CreateItemStockMovementDto[];
}
