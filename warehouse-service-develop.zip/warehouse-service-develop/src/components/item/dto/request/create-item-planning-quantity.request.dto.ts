import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsInt,
  IsString,
  IsEnum,
  IsPositive,
  IsNumber,
  ArrayNotEmpty,
  ValidateNested,
  IsOptional,
} from 'class-validator';

export class CreateItemPlanningQuantityRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  orderId: number;

  @ApiProperty()
  orderType: number;

  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsPositive()
  @IsNumber()
  planQuantity: number;

  @ApiPropertyOptional()
  @IsString()
  lotNumber: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  locatorId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  orderDetailId: number;
}

export class CreateItemPlanningQuantitiesRequestDto {
  @ApiProperty()
  @ArrayNotEmpty()
  @ValidateNested()
  items: CreateItemPlanningQuantityRequestDto[];
}
