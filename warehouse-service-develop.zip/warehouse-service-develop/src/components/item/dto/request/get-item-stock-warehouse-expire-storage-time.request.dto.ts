import { ApiProperty } from "@nestjs/swagger";
import { IsInt } from "class-validator";

export class GetItemStockWarehouseExpireStorageTimeRequestDto {
  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsInt()
  expiredTime: number;
}