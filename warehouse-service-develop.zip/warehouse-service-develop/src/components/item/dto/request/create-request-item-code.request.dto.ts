import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsString,
  IsOptional,
  IsInt,
  ArrayNotEmpty,
  ValidateNested,
  ArrayUnique,
} from 'class-validator';

export class RequestItemCodeRequestDto {
  @ApiProperty()
  @IsString()
  itemName: string;

  @ApiPropertyOptional()
  @IsInt()
  @IsOptional()
  itemUnitId: number;

  @ApiProperty()
  @IsInt()
  itemTypeId: number;

  @ApiPropertyOptional()
  @IsInt()
  @IsOptional()
  itemQualityId: number;

  @ApiPropertyOptional()
  @IsInt()
  @IsOptional()
  manufacturingCountryId: number;

  @ApiPropertyOptional()
  @IsInt()
  @IsOptional()
  objectCategoryId: number;

  @ApiPropertyOptional()
  @IsInt()
  @IsOptional()
  orderId: number;

  @ApiPropertyOptional()
  @IsInt()
  @IsOptional()
  orderDetailId: number;

  @ApiPropertyOptional()
  @IsInt()
  @IsOptional()
  orderType: number;
}

export class CreateRequestItemCodesRequestDto extends BaseDto {
  @ApiProperty()
  @ArrayNotEmpty()
  @ValidateNested()
  @ArrayUnique()
  @Type(() => RequestItemCodeRequestDto)
  items: RequestItemCodeRequestDto[];
}
