import { WarehouseByLotManagementEnum } from '@components/warehouse/warehouse.constant';
import {
  OrderTypeEnum,
  OrderWarehouseActionTypeEnum,
} from '@constant/order.constant';
import { Expose } from 'class-transformer';

class ItemStockWarehousePrice {
  @Expose()
  itemId: number;

  @Expose()
  warehouseId: number;

  @Expose()
  quantity: number;

  @Expose()
  price: number;

  @Expose()
  totalPrice: number;
}

export class UpdateStockFromOrderRequest {
  @Expose()
  warehouseStockMovementId: number | null;

  @Expose()
  warehouseStockMovementIds: number[];

  @Expose()
  orderType: OrderWarehouseActionTypeEnum;

  @Expose()
  orderId: number;

  @Expose()
  purpose?: string;

  @Expose()
  saleOrderType: OrderTypeEnum;

  @Expose()
  manageByLot: WarehouseByLotManagementEnum;

  @Expose()
  itemStockWarehousePrices: ItemStockWarehousePrice[];

  constructor(
    warehouseStockMovementId?: number,
    orderType?: OrderWarehouseActionTypeEnum,
    orderId?: number,
    saleOrderType?: OrderTypeEnum,
    warehouseStockMovementIds?: number[],
    purpose?: string,
    itemStockWarehousePrices?: ItemStockWarehousePrice[],
    manageByLot?: number,
  ) {
    this.warehouseStockMovementId = warehouseStockMovementId;
    this.orderType = orderType;
    this.orderId = orderId;
    this.saleOrderType = saleOrderType;
    this.warehouseStockMovementIds = warehouseStockMovementIds;
    this.purpose = purpose;
    this.itemStockWarehousePrices = itemStockWarehousePrices;
    this.manageByLot = manageByLot;
  }
}
