import { IsArray, IsNotEmpty } from 'class-validator';

export class GetPositionItemWarehouseDto {
  @IsNotEmpty()
  @IsArray()
  floorIds: number[];

  @IsNotEmpty()
  @IsArray()
  itemIds: number[];
}
