import { IsInt, IsNotEmpty, IsNumber } from 'class-validator';

export class ItemWarehouseTransferRequestDto {
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @IsNotEmpty()
  @IsNumber()
  itemQuantity: number;
}
