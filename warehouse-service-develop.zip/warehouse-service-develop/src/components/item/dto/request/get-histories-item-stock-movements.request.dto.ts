import { IsArray, IsNotEmpty } from 'class-validator';

export class GetHistoriesItemStockMovements {
  @IsNotEmpty()
  @IsArray()
  warehouseStockMovementIds: number[];
}
