import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray, IsOptional } from 'class-validator';

export class GetFloorExistItemRequestDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  floorIds: number[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  itemIds: number[];
}
