import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  Allow,
  ArrayNotEmpty,
  ArrayUnique,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';

class SuggestLocatorWithItemQuantity {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  lotNumber: string;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  actualQuantity: number;

  @Allow()
  locatorVirtualId: number;

  @Allow()
  warehouseId: number;
}

export class SuggestLocatorWithItemQuantityRequest extends BaseDto {
  @ApiProperty({
    type: SuggestLocatorWithItemQuantity,
    isArray: true,
  })
  @ArrayUnique((item: SuggestLocatorWithItemQuantity) => item.itemId)
  @Type(() => SuggestLocatorWithItemQuantity)
  @ArrayNotEmpty()
  items: SuggestLocatorWithItemQuantity[];

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  warehouseId: number;
}
