import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
} from 'class-validator';

class ConditionFilter {
  @ApiProperty()
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  itemId: number;

  @ApiProperty()
  @IsOptional()
  @IsArray()
  locatorIds: number[];

  @ApiProperty()
  @IsOptional()
  warehouseShelfFloorId?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  warehouseShelfFloorIds?: number[];
}
export class GetPositionItemsByConditionsRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  @Type(() => ConditionFilter)
  conditions: ConditionFilter[];
}
