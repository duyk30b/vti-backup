import { IsArray, IsNotEmpty } from 'class-validator';

export class GetPositionItemWarehouseByIds {
  @IsNotEmpty()
  @IsArray()
  ids: number[];
}
