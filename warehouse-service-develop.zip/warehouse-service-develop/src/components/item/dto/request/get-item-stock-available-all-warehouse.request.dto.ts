import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional, ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsInt,
  IsOptional,
  ValidateNested,
  ArrayNotEmpty,
} from 'class-validator';

export class ConditionOrder {
  @ApiProperty()
  @IsInt()
  orderId: number;

  @ApiProperty()
  @IsInt()
  orderType: number;
}

export class FilterItemAllWarehouseByCondition {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @IsOptional()
  locatorIds?: number[];
}

export class GetItemAllStockAvailableRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => ConditionOrder)
  @ValidateNested()
  order: ConditionOrder;

  @ApiProperty()
  @ValidateNested()
  @ArrayNotEmpty()
  @Type(() => FilterItemAllWarehouseByCondition)
  items: FilterItemAllWarehouseByCondition[];
}
