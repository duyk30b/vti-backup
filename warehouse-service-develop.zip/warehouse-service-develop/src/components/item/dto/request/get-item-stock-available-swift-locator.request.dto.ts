import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional, ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsInt,
  IsOptional,
  ValidateNested,
  IsString,
  ArrayNotEmpty,
} from 'class-validator';

export class ConditionOrder {
  @ApiProperty()
  @IsInt()
  orderId: number;

  @ApiProperty()
  @IsInt()
  orderType: number;
}

export class FilterItemByCondition {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  lotNumber: string;

  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  locatorId: number;
}

export class GetItemStockAvailableSwiftLocatorRequestDto extends BaseDto {
  @ApiProperty()
  @ValidateNested({ each: true })
  @ArrayNotEmpty()
  @Type(() => FilterItemByCondition)
  items: FilterItemByCondition[];
}
