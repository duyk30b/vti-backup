import { Expose } from 'class-transformer';

export class ItemWarehouseResponseDto {
  @Expose()
  itemId: number;

  @Expose()
  quantity: number;

  @Expose()
  warehouseSectorId: number;

  @Expose()
  warehouseShelfId: number;

  @Expose()
  warehouseShelfFloorId: number;

  @Expose()
  lotNumber: string;

  @Expose()
  lots: any[];
}
