import { UserResponseDto } from '@components/user/dto/response/user.response.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class ObjectCategoryResponseDto {
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  description: string;

  @Expose()
  status: number;

  @ApiPropertyOptional({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdBy: UserResponseDto;

  @ApiPropertyOptional({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  updatedBy: UserResponseDto;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty()
  @Expose()
  updatedAt: string;
}
