import { ResponseService } from '@utils/response-service';
import { Expose } from 'class-transformer';

export class ItemStockMovementResponseDto {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  itemType: string;

  @Expose()
  itemUnit: string;

  @Expose()
  package: any;

  @Expose()
  warehouseStockMovementId: number;

  @Expose()
  itemId: number;

  @Expose()
  warehouseId: number;

  @Expose()
  warehouseSectorId: number;

  @Expose()
  warehouseShelfId: number;

  @Expose()
  warehouseShelfFloorId: number;

  @Expose()
  movementOrderDetailId: number;

  @Expose()
  quantity: number;

  @Expose()
  lotNumber: string;

  @Expose()
  mfg: string;
}

export class ItemStockMovementsResponseDto extends ResponseService {
  @Expose()
  data: ItemStockMovementResponseDto[];
}
