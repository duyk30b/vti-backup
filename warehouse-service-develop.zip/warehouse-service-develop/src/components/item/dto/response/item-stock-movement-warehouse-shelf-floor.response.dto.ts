import { Expose } from 'class-transformer';

export class ItemStockMovementWarehouseShelfFloorResponseDto {
  @Expose()
  id: number;

  @Expose()
  itemId: number;

  @Expose()
  warehouseId: number;

  @Expose()
  locatorId: number;

  @Expose()
  quantity: number;

  @Expose()
  mfg: string;

  @Expose()
  lotNumber: string;
}
