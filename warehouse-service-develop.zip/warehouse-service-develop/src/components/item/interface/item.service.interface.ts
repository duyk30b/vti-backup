import { GetItemStockAvailableRequestDto } from './../dto/request/get-item-stock-available.request.dto';
import { InventoryItemResponse } from '@components/inventory/dto/response/inventory-item.response.dto';
import { ItemWarehouseRequestDto } from '../dto/request/item.dto.request';
import {
  CreateItemStockMovementAndItemWarehouseShelfFloorDto,
  CreateItemStockMovementDto,
} from '../dto/request/create-item-stock-movement.request.dto';
import { CheckStockAvailableDto } from '../dto/request/check-stock-available.request.dto';
import { UpdateStockFromOrderRequest } from '../dto/request/update-stock-from-order-request.dto';
import { ItemResponseDto } from '../dto/response/item.dto.response';
import { ItemWarehouseTransferRequestDto } from '../dto/request/item-transfer.request.dto';
import { StockMovementIdByDate } from '@components/warehouse-report/dto/response/report-by-type.response';
import { GetListReportStockQueryDto } from '@components/warehouse-report/dto/query/get-list-report-stock.query.dto';
import { GetPositionItemWarehouseDto } from '../dto/request/get-position-item-warehouse.request.dto';
import { GetPositionItemWarehouseByIds } from '../dto/request/get-position-item-warehouse-by-ids.request.dto';
import { GetPositionItemByFloorResquestDto } from '../dto/request/get-position-item-by-floor.request.dto';
import { Filter, PaginationQuery } from '@utils/pagination.query';
import { GetHistoriesItemStockMovements } from '../dto/request/get-histories-item-stock-movements.request.dto';
import { GetPositionItemsByConditionsRequestDto } from '../dto/request/filter-position-items-by-conditions.request.dto';
import { GetPositionItemsRequestDto } from '../dto/request/get-position-items.request.dto';
import { ItemStockMovementWarehouseShelfFloorResponseDto } from '../dto/response/item-stock-movement-warehouse-shelf-floor.response.dto';
import { GetItemStockQuantityRequestDto } from '../dto/request/get-item-stock-quantity.request.dto';
import { CreateItemPlanningQuantitiesRequestDto } from '../dto/request/create-item-planning-quantity.request.dto';
import { GetItemWarehouseStockRequestDto } from '../dto/request/get-item-stock.dto';
import { GetItemStockMovementInWarehouseLocatorByDay } from '../dto/request/get-item-stock-warehouse-locator-by-day.request.dto';
import { GetItemStockWarehouseExpireStorageTimeRequestDto } from '../dto/request/get-item-stock-warehouse-expire-storage-time.request.dto';
import { CreateRequestItemCodesRequestDto } from '../dto/request/create-request-item-code.request.dto';
import { GetItemAllStockAvailableRequestDto } from '../dto/request/get-item-stock-available-all-warehouse.request.dto';
import { SuggestLocatorWithItemQuantityRequest } from '../dto/request/suggest-locator-with-item-quantity.request.dto';

export interface ItemServiceInterface {
  getObjectCategoryId(id: number): Promise<any>;
  getObjectCategoryByIds(ids: number[], serilize?: boolean): Promise<any>;
  getItemWarehouse(
    items: ItemWarehouseRequestDto[],
    warehouseId: number,
    warehouseSectorId?: number,
    warehouseShelfId?: number,
    warehouseShelfFloorId?: number,
  ): Promise<any>;
  approveInventory(listApproveItem: InventoryItemResponse[]): Promise<any>;
  createItemStockMovement(
    createRequest: CreateItemStockMovementDto[],
  ): Promise<any>;
  checkStockAvailable(request: CheckStockAvailableDto): Promise<any>;
  updateStockFromOrder(request: UpdateStockFromOrderRequest): Promise<any>;
  getItems(itemIds: number[]): Promise<ItemResponseDto[]>;
  getItemsInfo(
    itemIds: number[],
    serilize?: boolean,
  ): Promise<ItemResponseDto[] | any>;
  updateTransferQuantity(
    sourceItems: ItemWarehouseTransferRequestDto[],
    destinationItems: ItemWarehouseTransferRequestDto[],
  ): Promise<any>;
  getDataReportDaily(
    warehouseId: number,
    warehouseStockMovementInIds: number[],
    warehouseStockMovementOutIds: number[],
  );
  getQuantityItemWarehouse(itemTypeId: number): Promise<any>;
  getTranferByDateAndIds(
    data: StockMovementIdByDate[],
    itemTypeId: number,
  ): Promise<any>;
  getStock(request: GetListReportStockQueryDto): Promise<any>;
  getItemByItemType(itemIds: number[], itemTypeId: number): Promise<any>;
  getPositionItemByFloor(
    request: GetPositionItemByFloorResquestDto[],
  ): Promise<any>;
  createItemStockMovementAndItemWarehouseShelfFloor(
    request: CreateItemStockMovementAndItemWarehouseShelfFloorDto,
  ): Promise<any>;
  getItemStockMovementInWarehouseFloor(
    request: GetPositionItemWarehouseDto,
  ): Promise<any>;
  getItemStockMovementInWarehouseFloorByIds(
    request: GetPositionItemWarehouseByIds,
  ): Promise<any[]>;
  getWarning(request: PaginationQuery): Promise<any>;
  getHistoriesItemStockMovements(
    request: GetHistoriesItemStockMovements,
  ): Promise<any>;
  getPackageByIds(ids: number[], serilize?: boolean): Promise<any>;
  getListLotNumberItemStockByItemIds(
    warehouseShelfFloorIds?: number[],
    ids?: number[],
  ): Promise<any[]>;
  getItemStockMovementInWarehouseFloorByWarehouseFloorIds(
    warehouseFloorIds: number[],
  ): Promise<any[]>;
  getItemStockMovementInWarehouseByLocatorIds(
    locatorIds: number[],
  ): Promise<any[]>;
  getPositionItemsByCondition(
    request: GetPositionItemsByConditionsRequestDto,
  ): Promise<any>;
  getItemWarehouseByMultipleItemAndWarehouse(
    itemIds: number[],
    warehouseIds: number[],
  ): Promise<any[]>;
  getPositionItems(
    request: GetPositionItemsRequestDto,
  ): Promise<ItemStockMovementWarehouseShelfFloorResponseDto[] | any>;
  getItemStockQuantity(request: GetItemStockQuantityRequestDto): Promise<any>;

  getItemsByConditions(condition: any, sort?: any): Promise<any>;
  getItemsByName(filterByName, onlyId?: boolean): Promise<any>;
  getItemsByNameOrCode(keyword: string, onlyId?: boolean): Promise<any>;
  getItemsByCode(filterByCode, onlyId?: boolean): Promise<any>;
  getItemQuanlityByIds(ids: number[], serilize?: boolean): Promise<any>;
  getManufacturingCountryByIds(ids: number[], serilize?: boolean): Promise<any>;
  getItemPlanningQuantityByOrder(
    itemIds: number[],
    warehouseId: number,
    serilize?: boolean,
  ): Promise<any>;
  getItemPlanningQuantityByLocatorIds(
    locatorIds: number[],
    serilize?: boolean,
  ): Promise<any>;
  createItemPlanningQuantities(
    request: CreateItemPlanningQuantitiesRequestDto,
  ): Promise<any>;
  getItemWarehouseStock(request: GetItemWarehouseStockRequestDto): Promise<any>;
  getItemSockWarehouseLocatorByDay(
    request: GetItemStockMovementInWarehouseLocatorByDay,
  ): Promise<any>;
  getItemUnitSettingByIds(unitIds: number[], serilize?: boolean): Promise<any>;
  getItemStockWarehouseExpireStorageTime(
    request: GetItemStockWarehouseExpireStorageTimeRequestDto[],
  ): Promise<any>;
  getItemStockAvailableByConditions(
    request: GetItemStockAvailableRequestDto,
  ): Promise<any>;
  getItemLotWarehouseStockReport(
    request: GetItemWarehouseStockRequestDto,
  ): Promise<any>;
  getItemPlanningQuantityByOrderId(orderId: number, orderType: number);
  createRequestItemCode(request: CreateRequestItemCodesRequestDto);
  getItemByCodes(itemCodes: string[]): Promise<any>;
  getItemUnitSettingByNames(
    unitNames: string[],
    serilize: boolean,
  ): Promise<any>;
  getItemTypeSettingByIds(ids: number[], serilize?: boolean): Promise<any>;
  getListStorageDateByItemIds(itemIds: number[]): Promise<any>;
  getInventoryNormList(filter: Filter[]): Promise<any[]>;
  getItemStockWarehousePrices(request: any): Promise<any>;
  getAllItemStockAvailableByConditions(
    request: GetItemAllStockAvailableRequestDto,
  ): Promise<any>;
  updateItemStockWarehousePriceEbsIn(
    request: any[],
    manageByLot: any,
  ): Promise<any>;
  getWarehouseStockByItemId(itemId: number): Promise<any[]>;
  suggestLocatorWithItemQuantity(
    request: SuggestLocatorWithItemQuantityRequest,
  ): Promise<any>;
  suggestLocatorPoimpAutoComplete(request: any): Promise<any>;
  removeItemPlanningQuantities(id: number, orderType: number): Promise<any>;
}
