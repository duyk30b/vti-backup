import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ItemCronService } from './item-cron.service';
import { ItemService } from './item.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'ItemCronServiceInterface',
      useClass: ItemCronService,
    },
  ],
  controllers: [],
})
export class ItemModule {}
