import { InventoryItemResponse } from '@components/inventory/dto/response/inventory-item.response.dto';
import { GetListReportStockQueryDto } from '@components/warehouse-report/dto/query/get-list-report-stock.query.dto';
import { StockMovementIdByDate } from '@components/warehouse-report/dto/response/report-by-type.response';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { escapeCharForSearch } from '@utils/common';
import { Filter, PaginationQuery } from '@utils/pagination.query';
import { ResponseService } from '@utils/response-service';
import { plainToInstance } from 'class-transformer';
import { isEmpty, keyBy, map } from 'lodash';
import { CheckStockAvailableDto } from './dto/request/check-stock-available.request.dto';
import { CreateItemPlanningQuantitiesRequestDto } from './dto/request/create-item-planning-quantity.request.dto';
import {
  CreateItemStockMovementAndItemWarehouseShelfFloorDto,
  CreateItemStockMovementDto,
} from './dto/request/create-item-stock-movement.request.dto';
import { CreateRequestItemCodesRequestDto } from './dto/request/create-request-item-code.request.dto';
import { GetPositionItemsByConditionsRequestDto } from './dto/request/filter-position-items-by-conditions.request.dto';
import { GetHistoriesItemStockMovements } from './dto/request/get-histories-item-stock-movements.request.dto';
import { GetItemAllStockAvailableRequestDto } from './dto/request/get-item-stock-available-all-warehouse.request.dto';
import { GetItemStockAvailableSwiftLocatorRequestDto } from './dto/request/get-item-stock-available-swift-locator.request.dto';
import { GetItemStockAvailableRequestDto } from './dto/request/get-item-stock-available.request.dto';
import { GetItemStockQuantityRequestDto } from './dto/request/get-item-stock-quantity.request.dto';
import { GetItemStockWarehouseExpireStorageTimeRequestDto } from './dto/request/get-item-stock-warehouse-expire-storage-time.request.dto';
import { GetItemStockMovementInWarehouseLocatorByDay } from './dto/request/get-item-stock-warehouse-locator-by-day.request.dto';
import { GetItemWarehouseStockRequestDto } from './dto/request/get-item-stock.dto';
import { GetPositionItemByFloorResquestDto } from './dto/request/get-position-item-by-floor.request.dto';
import { GetPositionItemWarehouseByIds } from './dto/request/get-position-item-warehouse-by-ids.request.dto';
import { GetPositionItemWarehouseDto } from './dto/request/get-position-item-warehouse.request.dto';
import { GetPositionItemsRequestDto } from './dto/request/get-position-items.request.dto';
import { ItemWarehouseTransferRequestDto } from './dto/request/item-transfer.request.dto';
import { ItemWarehouseRequestDto } from './dto/request/item.dto.request';
import { SuggestLocatorWithItemQuantityRequest } from './dto/request/suggest-locator-with-item-quantity.request.dto';
import { UpdateStockFromOrderRequest } from './dto/request/update-stock-from-order-request.dto';
import { ItemQualityResponseDto } from './dto/response/item-quality.response.dto';
import { ItemStockMovementWarehouseShelfFloorResponseDto } from './dto/response/item-stock-movement-warehouse-shelf-floor.response.dto';
import { ItemStockMovementsResponseDto } from './dto/response/item-stock-movements.response.dto';
import { ItemWarehouseResponseDto } from './dto/response/item-warehouse.dto.response';
import { ItemResponseDto } from './dto/response/item.dto.response';
import { ManufacturingCountryResponseDto } from './dto/response/manufacturing-country,response';
import { ObjectCategoryResponseDto } from './dto/response/object-category.response.dto';
import { ItemServiceInterface } from './interface/item.service.interface';

@Injectable()
export class ItemCronService implements ItemServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}
  removeItemPlanningQuantities(id: number, orderType: number): Promise<any> {
    throw new Error('Method not implemented.');
  }

  suggestLocatorPoimpAutoComplete(request: any): Promise<any> {
    throw new Error('Method not implemented.');
  }
  suggestLocatorWithItemQuantity(
    request: SuggestLocatorWithItemQuantityRequest,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }
  getItemStockWarehousePrices(request: any): Promise<any> {
    throw new Error('Method not implemented.');
  }
  getAllItemStockAvailableByConditions(
    request: GetItemAllStockAvailableRequestDto,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }
  getListStorageDateByItemIds(itemIds: number[]): Promise<any> {
    throw new Error('Method not implemented.');
  }
  getItemUnitSettingByNames(
    unitNames: string[],
    serilize: boolean,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }
  getItemByCodes(itemCodes: string[]): Promise<any> {
    throw new Error('Method not implemented.');
  }
  getItemsByNameOrCode(keyword: string, onlyId?: boolean): Promise<any> {
    throw new Error('Method not implemented.');
  }
  getItemStockWarehouseExpireStorageTime(
    request: GetItemStockWarehouseExpireStorageTimeRequestDto[],
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }
  async getItemSockWarehouseLocatorByDay(
    request: GetItemStockMovementInWarehouseLocatorByDay,
  ): Promise<any> {
    return await this.natsClientService.send(
      'get_item_stock_warehouse_locator_by_day',
      request,
    );
  }
  async getItemWarehouseStock(
    request: GetItemWarehouseStockRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'get_item_warehouse_stock',
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }
  async getItemLotWarehouseStockReport(
    request: GetItemWarehouseStockRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'get_item_lot_warehouse_stock_report',
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }
  getItemPlanningQuantityByOrder(
    itemIds: number[],
    warehouseId: number,
    serilize?: boolean,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }
  getItemStockQuantity(request: GetItemStockQuantityRequestDto): Promise<any> {
    throw new Error('Method not implemented.');
  }
  getItemWarehouseByMultipleItemAndWarehouse(
    itemIds: number[],
    warehouseIds: number[],
  ): Promise<any[]> {
    throw new Error('Method not implemented.');
  }
  getPositionItems(request: GetPositionItemsRequestDto): Promise<any> {
    throw new Error('Method not implemented.');
  }

  getItemStockAvailableByConditions(
    request: GetItemStockAvailableRequestDto,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }

  async getStock(request: GetListReportStockQueryDto): Promise<any> {
    return await this.natsClientService.send(
      'get_item_stock_for_report',
      request,
    );
  }

  async getWarning(request: PaginationQuery): Promise<any> {
    return await this.natsClientService.send('get_inventory_warning', request);
  }

  async getItemByItemType(itemIds: number[], itemTypeId: number): Promise<any> {
    return await this.natsClientService.send('get_item_by_item_type', {
      itemIds: itemIds,
      itemTypeId: itemTypeId,
    });
  }
  async getItemTypeSettingByIds(
    ids: number[],
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'get_item_type_setting_by_ids',
      {
        itemTypeSettingIds: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return serilize ? {} : [];
    }
    return serilize ? keyBy(response.data, 'id') : response.data;
  }

  async getTranferByDateAndIds(
    data: StockMovementIdByDate[],
    itemTypeId: number,
  ): Promise<any> {
    return await this.natsClientService.send('get_transfer_count_by_date', {
      dateIds: data,
      itemTypeId: itemTypeId,
    });
  }

  async getDataReportDaily(
    warehouseId: number,
    warehouseStockMovementInIds: number[],
    warehouseStockMovementOutIds: number[],
  ) {
    return await this.natsClientService.send('get_report_daily', {
      warehouseId: warehouseId,
      warehouseStockMovementInIds: warehouseStockMovementInIds,
      warehouseStockMovementOutIds: warehouseStockMovementOutIds,
    });
  }

  async getQuantityItemWarehouse(itemTypeId: number): Promise<any> {
    return await this.natsClientService.send('get_quantity_item_warehouse', {
      itemTypeId,
    });
  }

  /**
   * @param  {ItemWarehouseRequestDto[]} itemWarehouses
   * @returns Promise
   */
  async getItemWarehouse(
    itemWarehouses: ItemWarehouseRequestDto[],
    warehouseId: number,
    warehouseSectorId?: number,
    warehouseShelfId?: number,
    warehouseShelfFloorId?: number,
  ): Promise<any> {
    const item =
      !warehouseSectorId && !warehouseShelfFloorId && !warehouseShelfId
        ? await this.natsClientService.send('get_item_warehouses', {
            items: itemWarehouses,
            warehouseId: warehouseId,
          })
        : await this.natsClientService.send(
            'get_item_warehouse_with_locations',
            {
              items: itemWarehouses,
              warehouseId: warehouseId,
              warehouseSectorId: warehouseSectorId,
              warehouseShelfId: warehouseShelfId,
              warehouseShelfFloorId: warehouseShelfFloorId,
            },
          );
    if (!item?.data) {
      return null;
    }
    const data = plainToInstance(ItemWarehouseResponseDto, item.data, {
      excludeExtraneousValues: true,
    });

    return data;
  }

  /**
   * @returns Promise
   */
  async getItemStockMovementByWarehouseStockMovementId(
    warehouseStockMovementId: number,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'get_item_stock_movement_by_warehouse_stock_movement_id',
      {
        warehouseStockMovementId: warehouseStockMovementId,
      },
    );
    return response.statusCode === ResponseCodeEnum.SUCCESS
      ? response.data
      : [];
  }

  /**
   * @param  {ApproveInventoryItemDto[]} listApproveItem
   * @returns Promise
   */
  async approveInventory(
    listApproveItem: InventoryItemResponse[],
  ): Promise<any> {
    return await this.natsClientService.send('update_item_stock_quantity', {
      items: listApproveItem,
    });
  }

  async createItemStockMovement(
    createRequest: CreateItemStockMovementDto[],
  ): Promise<ResponseService> {
    const response = await this.natsClientService.send(
      'create_items_stock_movement',
      {
        items: createRequest,
      },
    );
    return plainToInstance(ItemStockMovementsResponseDto, response, {
      excludeExtraneousValues: true,
    });
  }

  async createItemStockMovementAndItemWarehouseShelfFloor(
    request: CreateItemStockMovementAndItemWarehouseShelfFloorDto,
  ): Promise<ResponseService> {
    const response = await this.natsClientService.send(
      'create_items_stock_movement',
      request,
    );
    return plainToInstance(ItemStockMovementsResponseDto, response, {
      excludeExtraneousValues: true,
    });
  }

  async checkStockAvailable(request: CheckStockAvailableDto): Promise<any> {
    return await this.natsClientService.send('check_stock_available', request);
  }

  async updateStockFromOrder(
    request: UpdateStockFromOrderRequest,
  ): Promise<any> {
    return await this.natsClientService.send(
      'update_stock_from_order',
      request,
    );
  }

  async getItems(itemIds: number[]): Promise<ItemResponseDto[]> {
    const response = await this.natsClientService.send('get_items_by_ids', {
      itemIds,
    });
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const dataReturn = plainToInstance(ItemResponseDto, <any[]>response.data, {
      excludeExtraneousValues: true,
    });

    return dataReturn;
  }

  async getItemsInfo(
    itemIds: number[],
    serilize?: boolean,
  ): Promise<ItemResponseDto[] | any> {
    const response = await this.natsClientService.send('get_item_list', {
      page: 1,
      limit: itemIds.length,
      filter: [{ column: 'itemIds', text: itemIds.join(',') }],
      userId: 1, // TODO implement cross token
    });
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const dataReturn = plainToInstance(
      ItemResponseDto,
      <any[]>response.data?.items,
      {
        excludeExtraneousValues: true,
      },
    );
    if (serilize) {
      const items = {};
      dataReturn.forEach((item) => {
        items[item.itemId] = item;
      });

      return items;
    }
    return dataReturn;
  }

  async updateTransferQuantity(
    sourceItems: ItemWarehouseTransferRequestDto[],
    destinationItems: ItemWarehouseTransferRequestDto[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'update_stock_from_transfer',
      {
        sourceItems,
        destinationItems,
      },
    );
    return response.statusCode === ResponseCodeEnum.SUCCESS;
  }

  async getPositionItemByFloor(
    request: GetPositionItemByFloorResquestDto[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'get_item_stock_movement_warehouse_shelf_floor',
      {
        request,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const dataReturn = plainToInstance(
      ItemStockMovementWarehouseShelfFloorResponseDto,
      response.data,
      {
        excludeExtraneousValues: true,
      },
    );

    return dataReturn;
  }

  async getItemStockMovementInWarehouseFloor(
    request: GetPositionItemWarehouseDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'get_position_item_in_warehouse_floor',
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getItemStockMovementInWarehouseFloorByIds(
    request: GetPositionItemWarehouseByIds,
  ): Promise<any[]> {
    const response = await this.natsClientService.send(
      'get_item_stock_movement_warehouse_shelf_floor_by_ids',
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getHistoriesItemStockMovements(
    request: GetHistoriesItemStockMovements,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'get_histories_item_stock_movements',
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getPackageByIds(ids: number[], serilize?: boolean): Promise<any> {
    if (ids.length === 0) {
      return [];
    }
    const response = await this.natsClientService.send('get_package_by_ids', {
      ids: ids,
    });
    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    if (serilize) {
      return keyBy(response.data, 'id');
    }

    return response.data;
  }

  async getListLotNumberItemStockByItemIds(ids: number[]): Promise<any[]> {
    const response = await this.natsClientService.send(
      'get_list_lot_number_of_item_stock',
      { itemIds: ids },
    );
    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    return response.data;
  }

  async getItemStockMovementInWarehouseFloorByWarehouseFloorIds(
    warehouseFloorIds: number[],
  ): Promise<any[]> {
    const response = await this.natsClientService.send(
      'get_item_stock_movement_warehouse_shelf_floor_by_warehouse_shelf_floor_ids',
      { warehouseFloorIds: warehouseFloorIds },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }
  async getItemStockMovementInWarehouseByLocatorIds(
    locatorIds: number[],
  ): Promise<any[]> {
    const response = await this.natsClientService.send(
      'get_item_stock_movement_warehouse_locator_by_warehouse_locator_ids',
      { locatorIds: locatorIds },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  getPositionItemsByCondition(
    request: GetPositionItemsByConditionsRequestDto,
  ): Promise<any> {
    return;
  }

  async getItemsByConditions(condition: any, sort?: any): Promise<any> {
    return await this.natsClientService.send('get_items_by_conditions', {
      condition: condition,
      sort: sort,
    });
  }

  async getItemsByName(filterByName, onlyId?: boolean): Promise<any> {
    if (isEmpty(filterByName)) {
      return [];
    }

    const response = await this.getItemsByConditions(
      'LOWER(unaccent(name)) LIKE ' +
        `LOWER(unaccent('%${escapeCharForSearch(
          filterByName.text,
        )}%')) escape '\\'`,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (!isEmpty(response.data) && onlyId === true) {
      return map(response.data, 'id');
    }

    return response.data;
  }
  async getItemsByCode(filterByCode, onlyId?: boolean): Promise<any> {
    if (isEmpty(filterByCode)) {
      return [];
    }

    const response = await this.getItemsByConditions(
      'LOWER(code) LIKE ' +
        `LOWER('%${escapeCharForSearch(filterByCode.text)}%') escape '\\'`,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (!isEmpty(response.data) && onlyId === true) {
      return map(response.data, 'id');
    }

    return response.data;
  }
  public async getObjectCategoryId(id: number): Promise<any> {
    const responseItemService = await this.natsClientService.send(
      'get_detail_object_category',
      { id: id },
    );
    if (responseItemService.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return responseItemService.data;
  }

  async getObjectCategoryByIds(
    ids: number[],
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'get_list_object_category',
      {
        constructionIds: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const dataReturn = plainToInstance(
      ObjectCategoryResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );
    const serilizeObjectCategories = {};
    if (serilize) {
      response.data?.items?.forEach((objectCategory) => {
        serilizeObjectCategories[objectCategory.id] = objectCategory;
      });

      return serilizeObjectCategories;
    }
    return dataReturn;
  }
  async getManufacturingCountryByIds(
    ids: number[],
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'get_manufacturing_country_by_ids',
      {
        manufacturingCountryIds: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const dataReturn = plainToInstance(
      ManufacturingCountryResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );
    return serilize ? keyBy(dataReturn, 'id') : dataReturn;
  }
  async getItemUnitSettingByIds(
    unitIds: number[],
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'get_item_unit_setting_by_ids',
      {
        unitIds: unitIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return serilize ? {} : [];
    }
    return serilize ? keyBy(response.data, 'id') : response.data;
  }

  async getItemQuanlityByIds(ids: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      'get_item_quanlity_by_ids',
      {
        itemQuanlityIds: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const dataReturn = plainToInstance(
      ItemQualityResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );
    return serilize ? keyBy(dataReturn, 'id') : dataReturn;
  }

  async getItemPlanningQuantityByLocatorIds(
    locatorIds: number[],
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'get_item_planning_quantity_by_locator_ids',
      {
        locatorIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return serilize ? {} : [];
    }

    return serilize ? keyBy(response.data, 'itemId') : response.data;
  }

  async createItemPlanningQuantities(
    request: CreateItemPlanningQuantitiesRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'create_item_planning_quantitites',
      request,
    );
    return response;
  }

  public async getItemStockAvailableSwiftLocator(
    request: GetItemStockAvailableSwiftLocatorRequestDto,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }

  async getItemPlanningQuantityByOrderId(
    orderId: number,
    orderType: number,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'get_item_planning_quantity_by_order_id',
      {
        orderId,
        orderType,
      },
    );
    return response.data;
  }

  public async createRequestItemCode(
    request: CreateRequestItemCodesRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'create_request_item_code',
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  public async getInventoryNormList(filter: Filter[]): Promise<any[]> {
    const response = await this.natsClientService.send('inventory_norm_list', {
      filter,
    });
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async updateItemStockWarehousePriceEbsIn(
    request: any[],
    orderType: any,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'update_item_stock_warehouse_price_ebs_in',
      {
        items: request,
        orderType: orderType,
      },
    );
    return response;
  }

  public async getWarehouseStockByItemId(itemId: number): Promise<any[]> {
    const response = await this.natsClientService.send(
      'get_warehouse_stock_by_item_id',
      {
        itemId,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }
}
