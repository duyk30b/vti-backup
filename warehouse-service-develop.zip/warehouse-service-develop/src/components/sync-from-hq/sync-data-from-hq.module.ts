import { UserModule } from '@components/user/user.module';
import { BussinessTypeAttributeEntity } from '@entities/bussiness-types/bussiness-type-attributes.entity';
import { BussinessTypeEntity } from '@entities/bussiness-types/bussiness-types.entity';
import { TransactionBussinessTypeEntity } from '@entities/bussiness-types/transaction-bussiness-type.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BussinessTypeAttributeRepository } from '@repositories/bussiness-type-atttribute.repository';
import { BussinessTypeRepository } from '@repositories/bussiness-type.repository';
import { SyncDataFromHqController } from './sync-data-from-hq.controller';
import { SyncDataFromHqService } from './sync-data-from-hq.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      BussinessTypeEntity,
      BussinessTypeAttributeEntity,
      TransactionBussinessTypeEntity,
    ]),
    UserModule,
  ],
  controllers: [SyncDataFromHqController],
  providers: [
    {
      provide: 'SyncDataFromHqServiceInterface',
      useClass: SyncDataFromHqService,
    },
    {
      provide: 'BusinessTypeRepositoryInterface',
      useClass: BussinessTypeRepository,
    },
    {
      provide: 'BussinessTypeAttributeRepositoryInterface',
      useClass: BussinessTypeAttributeRepository,
    },
  ],
  exports: [],
})
export class SyncDataFromHqModule {}
