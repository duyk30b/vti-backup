import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsDateString,
  IsDefined,
  IsEnum,
  IsInt,
  IsNotEmptyObject,
  IsObject,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import {
  ActionTypeEnum,
  CompanyCreatedEnum,
  MasterDataTypeEnum,
} from '../sync-data-from-hq.constant';
import { OrderTypeEnum } from '@constant/order.constant';

export enum StatusEnum {
  ACTIVE = 1,
  INACTIVE = 0,
}

export class MasterDataAbstract {
  @ApiProperty({ example: '', description: '' })
  @IsInt()
  id: number;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  name: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  code: string;
}

export class SyncItem<T extends MasterDataAbstract> {
  @ApiProperty({ example: 1, description: '' })
  @IsEnum(ActionTypeEnum)
  actionType: ActionTypeEnum;

  @ApiProperty({ example: 0, description: '' })
  @IsEnum(MasterDataTypeEnum)
  masterDataType: MasterDataTypeEnum;

  @ApiProperty({ example: 0, description: '' })
  @IsOptional()
  @IsEnum(OrderTypeEnum)
  orderType: OrderTypeEnum;

  @ApiProperty({ example: 1, description: '' })
  createdFrom: string;

  @ApiProperty({ example: '', description: '' })
  @IsObject()
  data: T;
}

export class MetaData {
  @ApiProperty({
    example: 10,
    type: Number,
  })
  @IsInt()
  total: number;

  @ApiProperty({
    example: new Date(),
    type: Date,
  })
  @IsDateString()
  syncTime: Date;
}

export class SyncDataFromHqRequest<
  T extends MasterDataAbstract,
> extends BaseDto {
  @ApiProperty({ description: '', type: SyncItem, isArray: true })
  @IsArray()
  @ValidateNested()
  @Type(() => SyncItem<T>)
  items: SyncItem<T>[];

  @ApiProperty({ example: '', description: '', type: MetaData })
  @IsDefined()
  @IsNotEmptyObject()
  @ValidateNested()
  @Type(() => MetaData)
  meta: MetaData;
}
