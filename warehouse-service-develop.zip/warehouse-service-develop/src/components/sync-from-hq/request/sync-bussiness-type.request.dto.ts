import {
  MasterDataAbstract,
  StatusEnum,
  SyncDataFromHqRequest,
} from './sync-from-hq.request.abstract.dto';

export class BussinessType extends MasterDataAbstract {
  id: number;
  name: string;
  code: string;
  description: string;
  status: StatusEnum;
  prefixNumber: string;
  parentBusiness: number;
  bussinessTypeAttributes: BussinessTypeAttribute[];
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date;
}

export class BussinessTypeAttribute {
  id: number;
  name: string;
  code: string;
  fieldName: string;
  ebsLabel: string;
  type: number;
  columnName: number;
  tableName: number;
  required: boolean;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date;
}

export class SyncBussinessTypeFromHqRequest extends SyncDataFromHqRequest<BussinessType> {}
