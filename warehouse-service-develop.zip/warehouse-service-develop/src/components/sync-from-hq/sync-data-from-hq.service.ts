import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { SyncDataFromHqServiceInterface } from './interface/sync-data-from-hq.service.interface';
import { keyBy } from 'lodash';
import { DataSource, In } from 'typeorm';
import {
  MasterDataAbstract,
  SyncDataFromHqRequest,
  SyncItem,
} from './request/sync-from-hq.request.abstract.dto';

import { InjectDataSource } from '@nestjs/typeorm';

import { BussinessTypeRepository } from '@repositories/bussiness-type.repository';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { BussinessTypeAttributeRepository } from '@repositories/bussiness-type-atttribute.repository';
import {
  BussinessType,
  SyncBussinessTypeFromHqRequest,
} from './request/sync-bussiness-type.request.dto';
import { BussinessTypeAttributeEntity } from '@entities/bussiness-types/bussiness-type-attributes.entity';
import { BussinessTypeEntity } from '@entities/bussiness-types/bussiness-types.entity';
import { I18nRequestScopeService } from 'nestjs-i18n';

@Injectable()
export class SyncDataFromHqService implements SyncDataFromHqServiceInterface {
  constructor(
    @Inject('BusinessTypeRepositoryInterface')
    private readonly bussinessTypeRepository: BussinessTypeRepository,

    @Inject('BussinessTypeAttributeRepositoryInterface')
    private readonly bussinessTypeAttributeRepository: BussinessTypeAttributeRepository,

    @InjectDataSource()
    private readonly dataSource: DataSource,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async syncBussinessType(
    request: SyncBussinessTypeFromHqRequest,
  ): Promise<any> {
    const requestItems = request.items.map((item: SyncItem<BussinessType>) => {
      return item.data;
    });
    const saveItems = await this.generateDataToSave(
      requestItems,
      this.bussinessTypeRepository,
      BussinessTypeEntity,
    );
    const existBusinessTypeIds = saveItems
      .filter((item) => item.id)
      .map((item) => item.id);
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.delete(BussinessTypeAttributeEntity, {
        bussinessTypeId: In(existBusinessTypeIds),
      });
      await queryRunner.manager.save(BussinessTypeEntity, saveItems);
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.UNSUCCESS'))
        .build();
    } finally {
      await queryRunner.release();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async syncMasterDataFromHQ<T extends MasterDataAbstract, E>(
    request: SyncDataFromHqRequest<T>,
    repo: BaseInterfaceRepository<E>,
  ): Promise<any> {
    const requestItems = request.items.map((item: SyncItem<T>) => {
      return item.data;
    });
    const itemIdMap = keyBy(requestItems, 'id');
    const uniqItems = Object.values(itemIdMap) as MasterDataAbstract[];
    const ItemCodes = uniqItems.map((item) => item.code);
    const existedItems = (await repo.findByCondition({
      code: In(ItemCodes),
    })) as unknown[] as MasterDataAbstract[];
    const itemCodeMap = keyBy(uniqItems, 'code');
    const existedItemCodeMap = keyBy(existedItems, 'code');
    existedItems.forEach((item) => {
      Object.assign(item, itemCodeMap[item.code]);
    });
    const newItems = uniqItems.filter((item) => !existedItemCodeMap[item.code]);
    newItems.forEach((item) => {
      item.id = undefined;
    });
    try {
      await repo.create([...existedItems, ...newItems]);
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.UNSUCCESS'))
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async generateDataToSave<T>(
    items: T[],
    repo: BaseInterfaceRepository<T>,
    EntityType: { new (): T },
  ): Promise<T[]> {
    items.sort((a, b) => {
      const dateA = new Date(a['updatedAt']);
      const dateB = new Date(b['updatedAt']);
      return dateA.getTime() - dateB.getTime();
    });
    const itemCodeMap = keyBy(items, 'code');
    const uniqItems = Object.values(itemCodeMap) as MasterDataAbstract[];
    const ItemCodes = uniqItems.map((item) => item.code);
    const existedItems = await repo.findByCondition({
      code: In(ItemCodes),
    });
    const existedItemCodeMap = keyBy(existedItems, 'code');
    existedItems.forEach((item) => {
      if (itemCodeMap[item['code']]?.updatedAt < item['updatedAt']) {
        //only assign extra Data (relation data) to existed item
        const extraData = Object.create(itemCodeMap[item['code']]);
        Object.assign(extraData, item);
        item = Object.assign(item, extraData);
      } else {
        const itemData = itemCodeMap[item['code']];
        delete itemData.id;
        Object.assign(item, itemData);
      }
    });
    const newItems = uniqItems
      .filter((item) => !existedItemCodeMap[item.code])
      .map((item) => {
        const entity = new EntityType();
        delete item.id;
        Object.assign(entity, item);
        return entity;
      });
    const result = [...existedItems, ...newItems];
    return result;
  }
}
