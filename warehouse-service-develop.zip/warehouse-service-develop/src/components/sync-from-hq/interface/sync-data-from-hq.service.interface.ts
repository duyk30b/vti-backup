import { SyncBussinessTypeFromHqRequest } from '../request/sync-bussiness-type.request.dto';

export interface SyncDataFromHqServiceInterface {
  syncBussinessType(request: SyncBussinessTypeFromHqRequest): Promise<any>;
}
