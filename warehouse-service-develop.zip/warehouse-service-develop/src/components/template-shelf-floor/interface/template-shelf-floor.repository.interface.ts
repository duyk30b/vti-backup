import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { TemplateShelfFloorEntity } from '@entities/template-shelf-floor/template-shelf-floor.entity';
import { GetListShelfFloorRequestDto } from '../dto/request/get-list-shelf-floor.request.dto';

export interface TemplateShelfFloorRepositoryInterface
  extends BaseInterfaceRepository<TemplateShelfFloorEntity> {
  createEntity(body: any): TemplateShelfFloorEntity;
  updateEntity(
    entity: TemplateShelfFloorEntity,
    request: any,
  ): TemplateShelfFloorEntity;
  getList(request: GetListShelfFloorRequestDto): Promise<any>;
  detail(request: number): Promise<any>;
}
