import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateShelfFloorRequestDto } from '../dto/request/create-shelf-floor.request.dto';
import { DeleteShelfFloorDto } from '../dto/request/delete-shelf-floor.request.dto';
import { GetListShelfFloorRequestDto } from '../dto/request/get-list-shelf-floor.request.dto';

export interface TemplateShelfFloorServiceInterface {
  detail(id: number): Promise<ResponsePayload<any>>;
  delete(id: DeleteShelfFloorDto): Promise<ResponsePayload<any>>;
  deleteMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  getList(payload: GetListShelfFloorRequestDto): Promise<ResponsePayload<any>>;
  save(request: CreateShelfFloorRequestDto): Promise<any>;
}
