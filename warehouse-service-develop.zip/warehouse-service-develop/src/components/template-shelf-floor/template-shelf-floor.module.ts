import { TemplateShelfFloorEntity } from '@entities/template-shelf-floor/template-shelf-floor.entity';
import { TemplateShelfTemplateShelfFloorEntity } from '@entities/template-shelf-template-shelf-floor/template-shelf-template-shelf-floor.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TemplateShelfFloorRepository } from '@repositories/template-shelf-floor.repository';
import { TemplateShelfTemplateShelfFloorRepository } from '@repositories/template-shelf-template-shelf-floor.repository';
import { TemplateShelfFloorController } from './template-shelf-floor.controller';
import { TemplateShelfFloorService } from './template-shelf-floor.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      TemplateShelfFloorEntity,
      TemplateShelfTemplateShelfFloorEntity,
    ]),
  ],
  providers: [
    {
      provide: 'TemplateShelfFloorServiceInterface',
      useClass: TemplateShelfFloorService,
    },
    {
      provide: 'TemplateShelfFloorRepositoryInterface',
      useClass: TemplateShelfFloorRepository,
    },
    {
      provide: 'TemplateShelfTemplateShelfFloorRepositoryInterface',
      useClass: TemplateShelfTemplateShelfFloorRepository,
    }
  ],
  exports: [
    {
      provide: 'TemplateShelfFloorRepositoryInterface',
      useClass: TemplateShelfFloorRepository,
    },
    {
      provide: 'TemplateShelfTemplateShelfFloorRepositoryInterface',
      useClass: TemplateShelfTemplateShelfFloorRepository,
    }
  ],
  controllers: [TemplateShelfFloorController],
})

export class TemplateShelfFloorModule {}
