import { AbstractWarehouseSpaceDataResponseDto } from "@components/warehouse/dto/response/abstract-warehouse-space-data.response.dto";
import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from "@nestjs/swagger";
import { Expose } from "class-transformer";

export class ShelfFloorResponseDto extends AbstractWarehouseSpaceDataResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  createdAt: string;
}