import { Controller, Delete, Get, Inject, Param, Query } from '@nestjs/common';
import { isEmpty } from 'lodash';
import { DeleteShelfFloorDto } from './dto/request/delete-shelf-floor.request.dto';
import { GetDetailShelfFloorRequestDto } from './dto/request/get-detail-shelf-floor.request.dto';
import { GetListShelfFloorRequestDto } from './dto/request/get-list-shelf-floor.request.dto';
import { TemplateShelfFloorServiceInterface } from './interface/template-shelf-floor.service.interface';
import {
  DELETE_TEMPLATE_SHELF_FLOOR_PERMISSION,
  DETAIL_TEMPLATE_SHELF_FLOOR_PERMISSION,
  LIST_TEMPLATE_SHELF_FLOOR_PERMISSION,
} from '@utils/permissions/template-shelf-floor';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';

@Controller('template-shelf-floors')
export class TemplateShelfFloorController {
  constructor(
    @Inject('TemplateShelfFloorServiceInterface')
    private readonly templateShelfFloorService: TemplateShelfFloorServiceInterface,
  ) {}

  @PermissionCode(LIST_TEMPLATE_SHELF_FLOOR_PERMISSION.code)
  // @MessagePattern('get_list_template_shelf_floor')
  @Get('/list')
  @ApiOperation({
    tags: ['Warehouse', 'Template Shelf Floors'],
    summary: 'List Template Shelf Floor',
    description: 'Danh sách Thông tin tầng mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
  })
  public async getList(
    @Query() body: GetListShelfFloorRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.templateShelfFloorService.getList(request);
  }

  @PermissionCode(DETAIL_TEMPLATE_SHELF_FLOOR_PERMISSION.code)
  // @MessagePattern('detail_template_shelf_floor')
  @Get('/:id')
  @ApiOperation({
    tags: ['Warehouse', 'Template shelf floors'],
    summary: 'Detail Template Shelf Floor',
    description: 'Thông tin tầng mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  public async detail(
    @Param() param: GetDetailShelfFloorRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.templateShelfFloorService.detail(request.id);
  }

  @PermissionCode(DELETE_TEMPLATE_SHELF_FLOOR_PERMISSION.code)
  // @MessagePattern('delete_template_shelf_floor')
  @Delete('/:id')
  @ApiOperation({
    tags: ['Warehouse', 'Template Shelf Floors'],
    summary: 'Delete Template Shelf Floor',
    description: 'Xóa Thông tin tầng mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
  })
  public async delete(@Param() param: DeleteShelfFloorDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateShelfFloorService.delete(request);
  }

  @PermissionCode(DELETE_TEMPLATE_SHELF_FLOOR_PERMISSION.code)
  // @MessagePattern('delete_template_shelf_floor_multiple')
  @Delete('/multiple')
  @ApiOperation({
    tags: ['Warehouse', 'Template Shelf Floors'],
    summary: 'Delete multiple Template Shelf Floor',
    description: 'Xóa nhiều thông tin tầng mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
  })
  public async deleteMultiple(@Query() query: DeleteMultipleDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateShelfFloorService.deleteMultiple(request);
  }
}
