import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';

export class GetDetailTemplateSectorTemplateShelfRequestDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'Mã của khu vực' })
  @IsNotEmpty()
  @IsInt()
  @Transform((obj) => Number(obj.value))
  id: number;
}
