import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsInt } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';

export class DeleteTemplateSectorTemplateShelfDto extends BaseDto {
  @ApiProperty({ example: 1, description: '' })
  @IsNotEmpty()
  @IsInt()
  @Transform((obj) => Number(obj.value))
  id: number;
}
