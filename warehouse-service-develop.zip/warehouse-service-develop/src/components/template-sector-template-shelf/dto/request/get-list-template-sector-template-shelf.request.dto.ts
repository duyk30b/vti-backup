import { ApiPropertyOptional } from "@nestjs/swagger";
import { PaginationQuery } from "@utils/pagination.query";
import { IsEnum, IsOptional } from "class-validator";

export class GetListTemplateSectorTemplateShelfRequestDto extends PaginationQuery {
  @ApiPropertyOptional({
    example: '1',
  })
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;
}