import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsOptional,
  IsInt,
  ValidateNested,
  MaxLength,
  IsString,
} from 'class-validator';
import { Type } from 'class-transformer';
import {
  DesignRequest,
} from '@components/warehouse/dto/request/unit-measures.request.dto';
import { BaseDto } from '@core/dto/base.dto';

export class TemplateSectorTemplateShelfNewItemRequestDto {
  @ApiProperty({ example: 'Kệ A', description: 'Tên kệ trong khu vực' })
  @IsNotEmpty()
  @MaxLength(255)
  @IsString()
  name: string;
  
  @ApiProperty({ example: 1, description: 'Mã khu vực' })
  @IsNotEmpty()
  @IsInt()
  templateSectorId: number;

  @ApiProperty({ example: 1, description: 'Mã kệ' })
  @IsNotEmpty()
  @IsInt()
  templateShelfId: number;

  @ApiProperty({
    example: { x: 0, y: 0, rotate: 0 },
    description: '',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => DesignRequest)
  design: DesignRequest;
}

export class TemplateSectorTemplateShelfItemRequestDto {
  @ApiProperty({ example: 1, description: '' })
  @IsOptional()
  @IsInt()
  id: number;

  @ApiProperty({ example: 'Kệ A', description: 'Tên kệ trong khu vực' })
  @IsNotEmpty()
  @MaxLength(255)
  @IsString()
  name: string;
  
  @ApiProperty({
    example: { x: 0, y: 0, rotate: 0 },
    description: '',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => DesignRequest)
  design: DesignRequest;
}

export class SaveTemplateSectorTemplateShelfRequestDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'Mã khu vực' })
  @IsNotEmpty()
  @IsInt()
  templateSectorId: number;

  @ApiProperty({ example: 1, description: 'Mã kệ' })
  @IsNotEmpty()
  @IsInt()
  templateShelfId: number;

  @ApiProperty({
    example: [TemplateSectorTemplateShelfItemRequestDto],
    description: '',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => TemplateSectorTemplateShelfItemRequestDto)
  data: TemplateSectorTemplateShelfItemRequestDto[]
}
