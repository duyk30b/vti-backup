import { AbstractWarehouseSpaceDataResponseDto } from "@components/warehouse/dto/response/abstract-warehouse-space-data.response.dto";
import { UnitMeaseuresAbstractResponse } from "@components/warehouse/dto/response/unit-measures-abstract.response.dto";
import { ApiProperty } from "@nestjs/swagger";
import { Approve } from "@utils/approve.response.dto";
import { Expose, Type } from "class-transformer";

export class TemplateSectorTemplateShelfResponseDto extends AbstractWarehouseSpaceDataResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  createdAt: string;
}