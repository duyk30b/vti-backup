import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Query,
} from '@nestjs/common';
import { isEmpty } from 'lodash';
import { SaveTemplateSectorTemplateShelfRequestDto } from './dto/request/save-template-sector-template-shelf.request.dto';
import { DeleteTemplateSectorTemplateShelfDto } from './dto/request/delete-template-sector-template-shelf.request.dto';
import { GetDetailTemplateSectorTemplateShelfRequestDto } from './dto/request/detail-template-sector-template-shelf.request.dto';
import { GetListTemplateSectorTemplateShelfRequestDto } from './dto/request/get-list-template-sector-template-shelf.request.dto';
import { TemplateSectorTemplateShelfServiceInterface } from './interface/template-sector-template-shelf.service.interface';
import {
  CREATE_TEMPLATE_SHELF_PERMISSION,
  DELETE_TEMPLATE_SHELF_PERMISSION,
  DETAIL_TEMPLATE_SHELF_PERMISSION,
  LIST_TEMPLATE_SHELF_PERMISSION,
} from '@utils/permissions/template-shelf';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';

@Controller('template-sector-template-shelfs')
export class TemplateSectorTemplateShelfController {
  constructor(
    @Inject('TemplateSectorTemplateShelfServiceInterface')
    private readonly templateSectorTemplateShelfService: TemplateSectorTemplateShelfServiceInterface,
  ) {}

  @PermissionCode(CREATE_TEMPLATE_SHELF_PERMISSION.code)
  // @MessagePattern('create_template_sector_template_shelf')
  @Post('/')
  @ApiOperation({
    tags: ['Warehouse', 'Template sector template shelf'],
    summary: 'Create new template sector template shelf',
    description: 'Tạo mới tầng mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  public async saveTemplateSectorTemplateShelf(
    @Body() payload: SaveTemplateSectorTemplateShelfRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateSectorTemplateShelfService.save(request);
  }

  @PermissionCode(LIST_TEMPLATE_SHELF_PERMISSION.code)
  // @MessagePattern('get_list_template_sector_template_shelf')
  @Get('/list')
  @ApiOperation({
    tags: ['Warehouse', 'Template Sector Template Shelf'],
    summary: 'List Template Sector Template Shelf',
    description: 'Danh sách Thông tin tầng mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
  })
  public async getList(
    @Query() query: GetListTemplateSectorTemplateShelfRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.templateSectorTemplateShelfService.getList(request);
  }

  @PermissionCode(DETAIL_TEMPLATE_SHELF_PERMISSION.code)
  // @MessagePattern('detail_template_sector_template_shelf')
  @Get('/:id')
  @ApiOperation({
    tags: ['Warehouse', 'Template shelf template shelf floor'],
    summary: 'Detail Template Shelf Template Shelf Floor',
    description: 'Thông tin tầng mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  public async detail(
    @Param() param: GetDetailTemplateSectorTemplateShelfRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateSectorTemplateShelfService.detail(request.id);
  }

  @PermissionCode(DELETE_TEMPLATE_SHELF_PERMISSION.code)
  // @MessagePattern('delete_template_sector_template_shelf')
  @Delete('/:id')
  @ApiOperation({
    tags: ['Warehouse', 'Template Shelf Template Shelf Floor'],
    summary: 'Delete Template Shelf Template Shelf Floor',
    description: 'Xóa Thông tin tầng mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
  })
  public async delete(
    @Param() param: DeleteTemplateSectorTemplateShelfDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateSectorTemplateShelfService.delete(request);
  }
}
