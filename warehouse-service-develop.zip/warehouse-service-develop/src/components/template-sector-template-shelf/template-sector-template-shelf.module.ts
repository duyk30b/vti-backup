import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TemplateSectorTemplateShelfEntity } from '@entities/template-sector-template-shelf/template-sector-template-shelf.entity';
import { TemplateSectorEntity } from '@entities/template-sector/template-sector.entity';
import { TemplateShelfEntity } from '@entities/template-shelf/template-shelf.entity';
import { TemplateSectorTemplateShelfRepository } from '@repositories/template-sector-template-shelf.repository';
import { TemplateSectorTemplateShelfController } from './template-sector-template-shelf.controller';
import { TemplateSectorTemplateShelfService } from './template-sector-template-shelf.service';
import { TemplateSectorRepository } from '@repositories/template-sector.repository';
import { TemplateShelfRepository } from '@repositories/template-shelf.repository';
import { TemplateSectorModule } from '@components/template-sector/template-sector.module';
import { TemplateShelfModule } from '@components/template-shelf/template-shelf.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      TemplateSectorTemplateShelfEntity,
      TemplateSectorEntity,
      TemplateShelfEntity,
    ]),
    TemplateSectorModule,
    TemplateShelfModule,
  ],
  providers: [
    {
      provide: 'TemplateSectorTemplateShelfServiceInterface',
      useClass: TemplateSectorTemplateShelfService,
    },
    {
      provide: 'TemplateSectorTemplateShelfRepositoryInterface',
      useClass: TemplateSectorTemplateShelfRepository,
    },
    {
      provide: 'TemplateSectorRepositoryInterface',
      useClass: TemplateSectorRepository
    },
    {
      provide: 'TemplateShelfRepositoryInterface',
      useClass: TemplateShelfRepository
    },
  ],
  exports: [
    {
      provide: 'TemplateSectorTemplateShelfRepositoryInterface',
      useClass: TemplateSectorTemplateShelfRepository,
    },
    {
      provide: 'TemplateSectorTemplateShelfServiceInterface',
      useClass: TemplateSectorTemplateShelfService,
    },
  ],
  controllers: [TemplateSectorTemplateShelfController],
})

export class TemplateSectorTemplateShelfModule {}
