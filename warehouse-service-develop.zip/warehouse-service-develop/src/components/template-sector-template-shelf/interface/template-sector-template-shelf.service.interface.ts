import { ResponsePayload } from '@utils/response-payload';
import { SaveTemplateSectorTemplateShelfRequestDto } from '../dto/request/save-template-sector-template-shelf.request.dto';
import { DeleteTemplateSectorTemplateShelfDto } from '../dto/request/delete-template-sector-template-shelf.request.dto';
import { GetListTemplateSectorTemplateShelfRequestDto } from '../dto/request/get-list-template-sector-template-shelf.request.dto';

export interface TemplateSectorTemplateShelfServiceInterface {
  save(payload: SaveTemplateSectorTemplateShelfRequestDto): Promise<ResponsePayload<any>>;
  detail(id: number): Promise<ResponsePayload<any>>;
  delete(id: DeleteTemplateSectorTemplateShelfDto): Promise<ResponsePayload<any>>;
  getList(payload: GetListTemplateSectorTemplateShelfRequestDto): Promise<ResponsePayload<any>>;
}
