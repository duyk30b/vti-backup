import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { TemplateSectorTemplateShelfEntity } from '@entities/template-sector-template-shelf/template-sector-template-shelf.entity';
import { GetListTemplateSectorTemplateShelfRequestDto } from '../dto/request/get-list-template-sector-template-shelf.request.dto';

export interface TemplateSectorTemplateShelfRepositoryInterface
  extends BaseInterfaceRepository<TemplateSectorTemplateShelfEntity> {
  createEntity(body: any): TemplateSectorTemplateShelfEntity;
  updateEntity(
    entity: TemplateSectorTemplateShelfEntity,
    request: any,
  ): TemplateSectorTemplateShelfEntity;
  getList(request: GetListTemplateSectorTemplateShelfRequestDto): Promise<any>;
  detail(request: number): Promise<any>;
}
