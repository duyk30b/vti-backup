import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { isEmpty } from 'class-validator';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { SaveTemplateSectorTemplateShelfRequestDto } from './dto/request/save-template-sector-template-shelf.request.dto';
import { GetListTemplateSectorTemplateShelfRequestDto } from './dto/request/get-list-template-sector-template-shelf.request.dto';
import { TemplateSectorTemplateShelfResponseDto } from './dto/response/template-sector-template-shelf.response.dto';
import { DeleteTemplateSectorTemplateShelfDto } from './dto/request/delete-template-sector-template-shelf.request.dto';
import { TemplateSectorTemplateShelfRepositoryInterface } from './interface/template-sector-template-shelf.repository.interface';
import { TemplateSectorTemplateShelfServiceInterface } from './interface/template-sector-template-shelf.service.interface';
import { TemplateSectorRepositoryInterface } from '@components/template-sector/interface/template-sector.repository.interface';
import { TemplateShelfRepositoryInterface } from '@components/template-shelf/interface/template-shelf.repository.interface';

@Injectable()
export class TemplateSectorTemplateShelfService
  implements TemplateSectorTemplateShelfServiceInterface
{
  constructor(
    @Inject('TemplateSectorTemplateShelfRepositoryInterface')
    private readonly templateSectorTemplateShelfRepository: TemplateSectorTemplateShelfRepositoryInterface,

    @Inject('TemplateSectorRepositoryInterface')
    private readonly templateSectorRepository: TemplateSectorRepositoryInterface,

    @Inject('TemplateShelfRepositoryInterface')
    private readonly templateShelfRepository: TemplateShelfRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  public async getList(
    request: GetListTemplateSectorTemplateShelfRequestDto,
  ): Promise<ResponsePayload<any> | any> {
    const { data, total } =
      await this.templateSectorTemplateShelfRepository.getList(request);
    const dataReturn = plainToInstance(
      GetListTemplateSectorTemplateShelfRequestDto,
      data,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async detail(id: number): Promise<ResponsePayload<any>> {
    const sector = await this.templateSectorTemplateShelfRepository.detail(id);
    if (isEmpty(sector)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const response = plainToInstance(
      TemplateSectorTemplateShelfResponseDto,
      sector,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async delete(
    request: DeleteTemplateSectorTemplateShelfDto,
  ): Promise<ResponsePayload<any>> {
    const sector = await this.templateSectorTemplateShelfRepository.findOneById(
      request.id,
    );
    if (!sector) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    try {
      await this.templateSectorTemplateShelfRepository.remove(request.id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async save(
    request: SaveTemplateSectorTemplateShelfRequestDto,
  ): Promise<any> {
    try {
      const { templateSectorId, templateShelfId } = request;

      const [templateSector, templateShelf] = await Promise.all([
        this.templateSectorRepository.findOneByCondition({
          id: templateSectorId,
        }),
        this.templateShelfRepository.findOneByCondition({
          id: templateShelfId,
        }),
      ]);

      if (isEmpty(templateSector)) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.TEMPLATE_SECTOR_NOT_EXIST'),
        ).toResponse();
      }

      if (isEmpty(templateShelf)) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.TEMPLATE_SHELF_NOT_EXIST'),
        ).toResponse();
      }

      if (templateShelf.volume > templateSector.volume) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate(
            'error.TOTAL_SHELF_VOLUME_EXCEEDS_SECTOR_VOLUME',
          ),
        ).toResponse();
      }

      const currentShelfsInTemplateSector =
        await this.templateSectorTemplateShelfRepository.findByCondition({
          templateSectorId,
        });
      if (currentShelfsInTemplateSector?.length) {
        await this.templateSectorTemplateShelfRepository.removeMany(
          currentShelfsInTemplateSector.map((item) => item.id),
        );
      }

      const newEntities = request.data.map((item) =>
        this.templateSectorTemplateShelfRepository.createEntity({
          templateSectorId,
          templateShelfId,
          design: item.design,
          name: item.name,
        }),
      );
      await this.templateSectorTemplateShelfRepository.createMany(newEntities);

      return new ResponseBuilder([])
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(err?.message || err)
        .build();
    }
  }
}
