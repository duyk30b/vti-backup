import { TypeBussinessAttributeEnum } from '@components/bussiness-types/bussiness-type.constants';
import { UserResponseDto } from './user.response.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsInt, IsString } from 'class-validator';

class BussinessTypeAttribute {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  bussinessTypeId: number;

  @ApiProperty()
  @Expose()
  bussinessTypeAttributeId: number;

  @ApiProperty({ example: '' })
  @Expose()
  fieldName: string;

  @ApiProperty({ example: '' })
  @Expose()
  ebsLabel: string;

  @ApiPropertyOptional({ example: 'TEXT = 0,LIST = 1 ,DATE = 2,' })
  @Expose()
  type: TypeBussinessAttributeEnum;

  @ApiPropertyOptional({ example: '' })
  @Expose()
  columnName: string;

  @ApiPropertyOptional({ example: '' })
  @Expose()
  tableName: string;

  @ApiPropertyOptional({ example: 'true' })
  @Expose()
  required: boolean;

  @ApiPropertyOptional()
  @Expose()
  value: any;

  @ApiProperty()
  @IsString()
  @Expose()
  apiPath: string;

  @ApiPropertyOptional()
  @Expose()
  orderId: number;

  @ApiPropertyOptional()
  @Expose()
  orderType: string;
}

export class BussinessTypeResponseDto {
  @ApiProperty({ example: 1 })
  @Expose()
  id: number;

  @ApiProperty({ example: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: '' })
  @Expose()
  description: string;

  @ApiProperty({ example: 'ABCDEF', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 1, description: '1: active, 0:inactive' })
  @Expose()
  status: number;

  @ApiProperty({ example: 'ABCDEF', description: '' })
  @Expose()
  parentBussiness: number;

  @ApiPropertyOptional({ example: 'ABCDEF', description: '' })
  @Expose()
  prefixNumber: string;

  @ApiProperty({ example: 'ABCDEF', description: '' })
  @Expose()
  createdFrom: string;

  @ApiPropertyOptional({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdBy: UserResponseDto;

  @ApiPropertyOptional({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  updatedBy: UserResponseDto;

  @ApiPropertyOptional({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  deletedBy: UserResponseDto;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty()
  @Expose()
  @Type(() => BussinessTypeAttribute)
  bussinessTypeAttributes: BussinessTypeAttribute[];
}
