import { TypeBussinessAttributeEnum } from "@components/bussiness-types/bussiness-type.constants";
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { Expose } from "class-transformer";

export class GetTransactionBussinessTypeResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  bussinessTypeId: number;

  @ApiProperty()
  @Expose()
  bussinessTypeAttributeId: number;

  @ApiProperty({ example: '' })
  @Expose()
  fieldName: string;

  @ApiProperty({ example: '' })
  @Expose()
  ebsLabel: string;

  @ApiPropertyOptional({ example: 'TEXT = 0,LIST = 1 ,DATE = 2,' })
  @Expose()
  type: TypeBussinessAttributeEnum;

  @ApiPropertyOptional({ example: '' })
  @Expose()
  columnName: string;

  @ApiPropertyOptional({ example: '' })
  @Expose()
  tableName: string;

  @ApiProperty({ example: '' })
  @Expose()
  values: string;

  @ApiPropertyOptional({ example: 'true' })
  @Expose()
  required: boolean;
}