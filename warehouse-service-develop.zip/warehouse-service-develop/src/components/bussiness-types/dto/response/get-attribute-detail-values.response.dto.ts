import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class GetAttributeDetailValuesResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  contractNumber?: string;

  @ApiProperty()
  @Expose()
  receiptNumber?: string;

  @ApiProperty()
  @Expose()
  receiptDate?: Date;
}
