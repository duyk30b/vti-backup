import { BusinessTypeAttributeDefaultEnum } from '@components/bussiness-types/bussiness-type.constants';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { Allow, IsEnum, IsInt, IsString } from 'class-validator';

export class GetBusinessTransactionValueRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  orderId: number;

  @ApiProperty()
  @IsString()
  orderType: string;

  @ApiProperty()
  @IsEnum(BusinessTypeAttributeDefaultEnum)
  attribute: string;

  @Allow()
  id: number;
}
