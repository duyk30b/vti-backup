import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';
import { CreateBussinessTypeRequestDto } from './create-bussiness-type.request.dto';
export class UpdateBussinessTypeBodyDto extends CreateBussinessTypeRequestDto {}
export class UpdateBussinessTypeRequestDto extends UpdateBussinessTypeBodyDto {
  @ApiProperty({ example: 'id:1' })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
