import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsNumber, IsOptional, IsString } from 'class-validator';

export class GetTransactionBussinessTypeRequestDto extends BaseDto {
  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsNumber()
  bussinessTypeId: number;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsNumber()
  orderId: number;

  @ApiProperty()
  @IsString()
  orderType: string;
}
