import { TypeBussinessAttributeEnum } from "@components/bussiness-types/bussiness-type.constants";
import { OrderTypeEnum } from "@constant/order.constant";
import { BaseDto } from "@core/dto/base.dto";
import { Transform, Type } from "class-transformer";
import { IsEnum, IsInt, IsNotEmpty, IsOptional, IsString } from "class-validator";

export class SaveTransactionBusinessTypeRequestDto {
  @IsInt()
  orderId: number;

  @IsInt()
  businessTypeId: number;

  @IsInt()
  businessTypeAttributeId: number;

  @IsOptional()
  @IsEnum(OrderTypeEnum)
  @Transform(({ value }) => (value ? value.toString() : value))
  orderType?: string;

  @IsString()
  values: string;

  @IsEnum(TypeBussinessAttributeEnum)
  type: number;
}

export class SaveTransactionBusinessTypeBodyDto extends BaseDto {
  @IsNotEmpty()
  @Type(() => SaveTransactionBusinessTypeRequestDto)
  data: SaveTransactionBusinessTypeRequestDto[];
}