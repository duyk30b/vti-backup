import {
  BusinessTypeAttributeDefaultEnum,
  ParentBussinessEnum,
  RULE_BUSSINESS,
  TableNameEnum,
  TypeBussinessAttributeEnum,
  WarehouseEnumCreatedFrom,
} from '@components/bussiness-types/bussiness-type.constants';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsEnum,
  IsInt,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';

class BussinessTypeAttribute {
  @ApiPropertyOptional({ example: '' })
  @IsString()
  @MaxLength(RULE_BUSSINESS.FIELD_NAME.MAX_LENGTH)
  fieldName: string;

  @ApiPropertyOptional({ example: '' })
  @IsOptional()
  @IsString()
  @MaxLength(RULE_BUSSINESS.EBS_LABEL.MAX_LENGTH)
  ebsLabel: string;

  @ApiPropertyOptional({ example: 'RECEIPT_ID' })
  @IsOptional()
  @IsEnum(BusinessTypeAttributeDefaultEnum)
  code?: string;

  @ApiPropertyOptional({ example: 'TEXT = 0,LIST = 1 ,DATE = 2,' })
  @IsEnum(TypeBussinessAttributeEnum)
  type: TypeBussinessAttributeEnum;

  @ApiPropertyOptional({ example: '' })
  @IsOptional()
  @MaxLength(RULE_BUSSINESS.COLUMN_NAME.MAX_LENGTH)
  @IsString()
  columnName: string;

  @ApiPropertyOptional({ example: '' })
  @IsOptional()
  @IsString()
  @MaxLength(RULE_BUSSINESS.TABLE_NAME.MAX_LENGTH)
  @IsEnum(TableNameEnum)
  tableName: string;

  @ApiPropertyOptional({ example: 'true' })
  @IsOptional()
  required: boolean;
}
export class CreateBussinessTypeRequestDto extends BaseDto {
  @ApiProperty({ example: '' })
  @IsString()
  @MaxLength(RULE_BUSSINESS.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: 'ABCDEF', description: '' })
  @IsString()
  @MaxLength(RULE_BUSSINESS.CODE.MAX_LENGTH)
  code: string;

  @ApiProperty({ example: 'ABCDEF', description: '' })
  @IsInt()
  @IsEnum(ParentBussinessEnum)
  parentBussiness: ParentBussinessEnum;

  @ApiPropertyOptional({ example: 'ABCDEF', description: '' })
  @IsString()
  @IsOptional()
  @MaxLength(RULE_BUSSINESS.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ApiPropertyOptional({ example: 'ABCDEF', description: '' })
  @IsString()
  @IsOptional()
  @MaxLength(RULE_BUSSINESS.PREFIX_NUMBER.MAX_LENGTH)
  prefixNumber: string;

  @ApiPropertyOptional({ example: 'category 1', description: '' })
  @IsString()
  @IsEnum(WarehouseEnumCreatedFrom)
  @MaxLength(RULE_BUSSINESS.CREATED_FROM.MAX_LENGTH)
  @IsOptional()
  createdFrom: WarehouseEnumCreatedFrom;

  @ApiProperty({ type: BussinessTypeAttribute, isArray: true })
  @IsArray()
  @ArrayUnique()
  @ValidateNested({ each: true })
  @Type(() => BussinessTypeAttribute)
  bussinessTypeAttributes: BussinessTypeAttribute[];
}
