import { AbstractFindByIdRequestDto } from '@core/dto/abtract-find-by-id.request.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsIn, IsInt, IsOptional, IsString } from 'class-validator';

export class DetailBussinessTypeRequestDto extends AbstractFindByIdRequestDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  @Transform(({ value }) => Number(value))
  orderId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  orderType: string;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  code: string;
}
