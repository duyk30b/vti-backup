import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

export class DetailTransactionBussinessTypeRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  code: string;

  @ApiPropertyOptional()
  @IsOptional()
  values: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  orderType: string;
}
