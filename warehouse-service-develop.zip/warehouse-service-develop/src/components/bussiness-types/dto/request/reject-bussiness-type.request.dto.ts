import { AbstractFindByIdRequestDto } from '@core/dto/abtract-find-by-id.request.dto';

export class RejectBussinessTypeRequestDto extends AbstractFindByIdRequestDto {}
