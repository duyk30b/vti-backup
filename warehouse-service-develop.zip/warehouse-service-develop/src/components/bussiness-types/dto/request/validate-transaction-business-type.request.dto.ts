import {
  TableNameEnum,
  TypeBussinessAttributeEnum,
} from '@components/bussiness-types/bussiness-type.constants';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsBoolean,
  IsEnum,
  IsInt,
  IsOptional,
  IsString,
} from 'class-validator';

export class Attribute {
  @ApiProperty()
  @IsString()
  fieldName: string;

  @ApiProperty({ example: 'TEXT = 0,LIST = 1 ,DATE = 2,' })
  @IsEnum(TypeBussinessAttributeEnum)
  type: TypeBussinessAttributeEnum;

  @ApiProperty()
  @IsBoolean()
  required: boolean;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  columnName?: string;

  @ApiPropertyOptional()
  @IsEnum(TableNameEnum)
  @IsOptional()
  tableName?: string;
}

export class ValidateTransactionBusinessTypeRequestDto {
  @ApiProperty()
  value: any;

  @ApiProperty()
  @IsInt()
  businessTypeId: number;

  @ApiProperty()
  @IsInt()
  attrId: number;
}

export class ValidateTransactioinBusinessTypeWithAttribute {
  @ApiProperty()
  value: any;

  @ApiProperty()
  @Type(() => Attribute)
  attr: Attribute;
}

export class ValidateTransactionBusinessTypeBodyDto extends BaseDto {
  @ApiProperty()
  @Type(() => ValidateTransactionBusinessTypeRequestDto)
  data: ValidateTransactionBusinessTypeRequestDto[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  sourceId: number;
}
