import { TableNameEnum } from '@components/bussiness-types/bussiness-type.constants';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import { IsArray, IsEnum, IsString, ValidateNested } from 'class-validator';
import { isJson } from 'src/helper/string.helper';

class FilterRequest {
  @ApiProperty()
  @IsEnum(TableNameEnum)
  tableName: string;

  @ApiProperty()
  @IsString()
  id: string;
}

export class GetAttributeDetailValuesRequestDto extends BaseDto {
  @ApiProperty()
  @Transform(({ value }) => {
    if (typeof value !== 'string') return value;

    if (value) value = value.replace(/\\/g, '');

    if (isJson(value)) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    }
  })
  @IsArray()
  @Type(() => FilterRequest)
  @ValidateNested({ each: true })
  filter: FilterRequest[];
}
