export const RULE_BUSSINESS = {
  NAME: {
    MAX_LENGTH: 255,
  },
  VALUES: {
    MAX_LENGTH: 255,
  },
  BELONG_TO: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 20,
  },
  PREFIX_NUMBER: {
    MAX_LENGTH: 45,
  },
  COLUMN_NAME: {
    MAX_LENGTH: 45,
  },
  TABLE_NAME: {
    MAX_LENGTH: 45,
  },
  FIELD_NAME: {
    MAX_LENGTH: 45,
  },
  ORDER_TYPE: {
    MAX_LENGTH: 45,
  },
  CREATED_FROM: {
    MAX_LENGTH: 255,
  },
  EBS_LABEL: {
    MAX_LENGTH: 255,
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
};
export enum TypeBussinessAttributeEnum {
  TEXT = 0,
  LIST = 1,
  DATE = 2,
  FILE = 4,
  NUMBER = 5,
}

export enum TableNameEnum {
  DEPARTMENT_RECEIPT = 'department_receipts',
  VENDOR = 'vendors',
  COST_TYPE = 'cost_types',
  ORGANIZATION_PAYMENT = 'organization_payments',
  SALE_ORDER_EXPORT = 'sale_order_exports',
  PURCHASED_ORDER_IMPORT = 'purchased_order_imports',
  WAREHOUSE_EXPORT_PROPOSAL = 'warehouse_export_proposals',
  CONSTRUCTION = 'constructions',
  CATEGORY_CONSTRUCTION = 'category_constructions',
  RECEIP = 'receipts',
}

export const COLUMN_NAME_BY_TABLE = {
  [TableNameEnum.DEPARTMENT_RECEIPT]: ['code'],
  [TableNameEnum.VENDOR]: ['code'],
  [TableNameEnum.COST_TYPE]: ['code'],
  [TableNameEnum.ORGANIZATION_PAYMENT]: ['code'],
  [TableNameEnum.SALE_ORDER_EXPORT]: ['id'],
  [TableNameEnum.PURCHASED_ORDER_IMPORT]: ['id'],
  [TableNameEnum.WAREHOUSE_EXPORT_PROPOSAL]: ['id'],
  [TableNameEnum.CONSTRUCTION]: ['id'],
  [TableNameEnum.CATEGORY_CONSTRUCTION]: ['id'],
  [TableNameEnum.RECEIP]: ['id'],
};

export enum WarehouseEnumCreatedFrom {
  Avenue = 'Avenue',
}

export enum ParentBussinessEnum {
  IMPORT = 0,
  EXPORT = 1,
  TRANSFER = 2,
}

export enum StatusBussinessEnum {
  INACTIVE = 0,
  ACTIVE = 1,
}

export const CAN_CONFIRM_BUSSINESS_TYPE_STATUS = [StatusBussinessEnum.INACTIVE];

export const CAN_REJECT_BUSSINESS_TYPE_STATUS = [StatusBussinessEnum.ACTIVE];

export enum OrderTypeEnum {
  IMPORT = '0',
  EXPORT = '1',
}

export enum BusinessTypeAttributeDefaultEnum {
  RECEIPT_ID = 'RECEIPT_ID',
  WAREHOUSE_EXPORT_PROPOSAL_ID = 'WAREHOUSE_EXPORT_PROPOSAL_ID',
  SO_EXPORT_ID = 'SO_EXPORT_ID',
  PO_IMPORT_ID = 'PO_IMPORT_ID',
  CONSTRUCTION_ID = 'CONSTRUCTION_ID',
  CATEGORY_CONSTRUCTION_ID = 'CATEGORY_CONSTRUCTION_ID',
}

export const VALID_DEFAULT_FIELDS_FOR_TYPE_IMPORT = [
  BusinessTypeAttributeDefaultEnum.RECEIPT_ID,
  BusinessTypeAttributeDefaultEnum.WAREHOUSE_EXPORT_PROPOSAL_ID,
  BusinessTypeAttributeDefaultEnum.SO_EXPORT_ID,
  BusinessTypeAttributeDefaultEnum.CONSTRUCTION_ID,
  BusinessTypeAttributeDefaultEnum.CATEGORY_CONSTRUCTION_ID,
];

export const VALID_DEFAULT_FIELDS_FOR_TYPE_EXPORT = [
  BusinessTypeAttributeDefaultEnum.WAREHOUSE_EXPORT_PROPOSAL_ID,
  BusinessTypeAttributeDefaultEnum.PO_IMPORT_ID,
  BusinessTypeAttributeDefaultEnum.CONSTRUCTION_ID,
  BusinessTypeAttributeDefaultEnum.CATEGORY_CONSTRUCTION_ID,
];

export const VALID_DEFAULT_FIELDS_FOR_TYPE_TRANSFER = [
  BusinessTypeAttributeDefaultEnum.CONSTRUCTION_ID,
  BusinessTypeAttributeDefaultEnum.CATEGORY_CONSTRUCTION_ID,
];

export const RESOURCE_SAVE_TRANSACTION_BUSINESS_TYPE =
  'transaction_bussiness_types';

export const BUSINESS_TYPE_ATTRIBUTE_API_PATH = {
  [TableNameEnum.DEPARTMENT_RECEIPT]: '/api/v1/users/department-receipts/list',
  [TableNameEnum.VENDOR]: '/api/v1/sales/vendors/list',
  [TableNameEnum.COST_TYPE]: '/api/v1/sales/cost-types/list',
  [TableNameEnum.ORGANIZATION_PAYMENT]:
    '/api/v1/sales/organization-payments/list',
  [TableNameEnum.SALE_ORDER_EXPORT]: '/api/v1/sales/sale-order-exports/list',
  [TableNameEnum.PURCHASED_ORDER_IMPORT]:
    '/api/v1/sales/purchased-order-imports/list',
  [TableNameEnum.WAREHOUSE_EXPORT_PROPOSAL]:
    '/api/v1/warehouses/warehouse-export-proposals/list',
  [TableNameEnum.CONSTRUCTION]: '/api/v1/sales/constructions/list',
  [TableNameEnum.CATEGORY_CONSTRUCTION]:
    '/api/v1/sales/construction-categories/list',
  [TableNameEnum.RECEIP]: '/api/v1/sales/receipts/list',
};
