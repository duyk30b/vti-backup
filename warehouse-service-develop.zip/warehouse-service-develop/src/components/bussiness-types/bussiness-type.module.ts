import { WarehouseExportProposalModule } from './../warehouse-export-proposal/warehouse-export-proposal.module';
import { WarehouseExportProposalService } from './../warehouse-export-proposal/warehouse-export-proposal.service';
import { FileService } from '@components/file/file.service';
import { SaleService } from '@components/sale/sale.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { ConfigService } from '@config/config.service';
import { BussinessTypeAttributeEntity } from '@entities/bussiness-types/bussiness-type-attributes.entity';
import { BussinessTypeEntity } from '@entities/bussiness-types/bussiness-types.entity';
import { TransactionBussinessTypeEntity } from '@entities/bussiness-types/transaction-bussiness-type.entity';
import { WarehouseExportProposalEntity } from '@entities/warehouse-export-proposal/warehouse-export-proposal.entity';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BussinessTypeAttributeRepository } from '@repositories/bussiness-type-atttribute.repository';
import { BussinessTypeRepository } from '@repositories/bussiness-type.repository';
import { TransactionBussinessTypeRepository } from '@repositories/transaction-business-type.repository';
import { WarehouseExportProposalRepository } from '@repositories/warehouse-export-proposal.repository';
import { BussinessTypeController } from './bussiness-type.controller';
import { BussinessTypeService } from './bussiness-type.service';
import { FileEntity } from '@entities/file/file.entity';
import { FileModule } from '@components/file/file.module';
import { FileRepository } from '@repositories/file.repository';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      BussinessTypeEntity,
      BussinessTypeAttributeEntity,
      TransactionBussinessTypeEntity,
      WarehouseExportProposalEntity,
      FileEntity,
    ]),
    UserModule,
    ConfigModule,
    FileModule,
    WarehouseExportProposalModule,
  ],
  providers: [
    {
      provide: 'BussinessTypeRepositoryInterface',
      useClass: BussinessTypeRepository,
    },
    {
      provide: 'BussinessTypeAttributeRepositoryInterface',
      useClass: BussinessTypeAttributeRepository,
    },
    {
      provide: 'TransactionBusinessTypeRepositoryInterface',
      useClass: TransactionBussinessTypeRepository,
    },
    {
      provide: 'BussinessTypeServiceInterface',
      useClass: BussinessTypeService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
    {
      provide: 'WarehouseExportProposalRepositoryInterface',
      useClass: WarehouseExportProposalRepository,
    },
    {
      provide: 'WarehouseExportProposalServiceInterface',
      useClass: WarehouseExportProposalService,
    },
    {
      provide: 'FileRepositoryInterface',
      useClass: FileRepository,
    },
    {
      provide: 'ConfigServiceInterface',
      useClass: ConfigService,
    },
    ConfigService,
  ],
  exports: [
    {
      provide: 'BussinessTypeServiceInterface',
      useClass: BussinessTypeService,
    },
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
  ],
  controllers: [BussinessTypeController],
})
export class BussinessTypeModule {}
