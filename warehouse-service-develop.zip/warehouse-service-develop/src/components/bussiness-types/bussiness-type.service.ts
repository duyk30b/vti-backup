import { BussinessTypeEntity } from '@entities/bussiness-types/bussiness-types.entity';
import { Inject, Injectable } from '@nestjs/common';
import { ResponsePayload } from '@utils/response-payload';
import { CreateBussinessTypeRequestDto } from './dto/request/create-bussiness-type.request.dto';
import { BussinessTypeAttributeRepositoryInterface } from './interface/bussiness-type-attribute.repository.interface';
import { BussinessTypeRepositoryInterface } from './interface/bussiness-type.repository.interface';
import {
  isEmpty,
  uniq,
  map,
  keyBy,
  values,
  groupBy,
  compact,
  first,
} from 'lodash';
import { DataSource, In, Not } from 'typeorm';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { InjectDataSource } from '@nestjs/typeorm';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { BussinessTypeAttributeEntity } from '@entities/bussiness-types/bussiness-type-attributes.entity';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { GetListBussinessTypeRequestDto } from './dto/request/get-list-bussiness-type.request.dto';
import { plainToInstance } from 'class-transformer';
import { BussinessTypeResponseDto } from './dto/response/bussiness-type.response.dto';
import { PagingResponse } from '@utils/paging.response';
import { BussinessTypeServiceInterface } from './interface/bussiness-type.interface.service';
import { DetailBussinessTypeRequestDto } from './dto/request/detail-bussiness-type.request.dto';
import { UpdateBussinessTypeRequestDto } from './dto/request/update-bussiness-type.request.dto';
import { ApiError } from '@utils/api.error';
import {
  BusinessTypeAttributeDefaultEnum,
  BUSINESS_TYPE_ATTRIBUTE_API_PATH,
  CAN_CONFIRM_BUSSINESS_TYPE_STATUS,
  CAN_REJECT_BUSSINESS_TYPE_STATUS,
  COLUMN_NAME_BY_TABLE,
  ParentBussinessEnum,
  RESOURCE_SAVE_TRANSACTION_BUSINESS_TYPE,
  StatusBussinessEnum,
  TableNameEnum,
  TypeBussinessAttributeEnum,
  VALID_DEFAULT_FIELDS_FOR_TYPE_EXPORT,
  VALID_DEFAULT_FIELDS_FOR_TYPE_IMPORT,
  VALID_DEFAULT_FIELDS_FOR_TYPE_TRANSFER,
} from './bussiness-type.constants';
import { UserResponseDto } from './dto/response/user.response.dto';
import { ConfirmBussinessTypeRequestDto } from './dto/request/confirm-bussiness-type.request.dto';
import { RejectBussinessTypeRequestDto } from './dto/request/reject-bussiness-type.request.dto';
import { BaseTransactionBusinessTypeService } from '@core/components/transaction-business-type/base-transaction-business-type.service';
import {
  ValidateTransactionBusinessTypeBodyDto,
  ValidateTransactionBusinessTypeRequestDto,
} from './dto/request/validate-transaction-business-type.request.dto';
import { ValidateTransactionBusinessTypeResponseDto } from '@core/dto/transaction-business-type/response/validate-transaction-business-type.response.dto';
import { SaveTransactionBusinessTypeRequestDto } from './dto/request/save-transaction-business-type.request.dto';
import { FileServiceInterface } from '@components/file/interface/file.service.interface';
import { UploadFileRequestDto } from '@components/file/dto/request/upload-file.request.dto';
import { TransactionBussinessTypeRepositoryInterface } from './interface/transaction-bussiness-type.repository.interface';
import { ConfigService } from '@nestjs/config';
import { GetTransactionBussinessTypeRequestDto } from './dto/request/get-transaction-bussiness-type.request.dto';
import { GetTransactionBussinessTypeResponseDto } from './dto/response/get-transaction-bussiness-type.response.dto';
import { GetAttributeDetailValuesRequestDto } from './dto/request/get-attribute-detail-values.request.dto';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { WarehouseExportProposalRepositoryInterface } from '@components/warehouse-export-proposal/interface/warehouse-export-proposal.repository.interface';
import { GetAttributeDetailValuesResponseDto } from './dto/response/get-attribute-detail-values.response.dto';
import { GetBusinessTransactionValueRequestDto } from './dto/request/get-business-transaction-value-by-order.request.dto';
import { GetBussinessTypeWarehouseExportProposalByOrderRequestDto } from './dto/request/get-bussiness-type-warehouse-export-proposal-by-order.request.dto';
import { WarehouseExportProposalServiceInterface } from '@components/warehouse-export-proposal/interface/warehouse-export-proposal.service.interface';
import { DetailTransactionBussinessTypeRequestDto } from './dto/request/detail-transaction-business-type.request.dto';

@Injectable()
export class BussinessTypeService implements BussinessTypeServiceInterface {
  @Inject('BussinessTypeRepositoryInterface')
  private readonly bussinessTypeRepository: BussinessTypeRepositoryInterface;

  @Inject('BussinessTypeAttributeRepositoryInterface')
  private readonly bussinessTypeAttributeRepository: BussinessTypeAttributeRepositoryInterface;

  @Inject('TransactionBusinessTypeRepositoryInterface')
  private readonly transactionBusinessTypeRepository: TransactionBussinessTypeRepositoryInterface;

  @Inject('UserServiceInterface')
  private readonly userService: UserServiceInterface;

  @Inject()
  private readonly i18n: I18nRequestScopeService;

  @InjectDataSource()
  private readonly connection: DataSource;

  @Inject('FileServiceInterface')
  private readonly fileService: FileServiceInterface;

  @Inject('SaleServiceInterface')
  private readonly saleService: SaleServiceInterface;

  @Inject('WarehouseExportProposalRepositoryInterface')
  private readonly warehouseExportProposalRepository: WarehouseExportProposalRepositoryInterface;

  @Inject('WarehouseExportProposalServiceInterface')
  private readonly warehouseExportProposalService: WarehouseExportProposalServiceInterface;

  private readonly configService: ConfigService;

  async create(request: CreateBussinessTypeRequestDto): Promise<any> {
    const bussinessTypeEntity = await this.bussinessTypeRepository.createEntity(
      request,
    );
    return this.save(
      bussinessTypeEntity,
      request,
      [],
      'message.defineBussinessType.createSuccess',
    );
  }
  async getList(request: GetListBussinessTypeRequestDto): Promise<any> {
    const { result, count } = await this.bussinessTypeRepository.getList(
      request,
    );
    const userIds = uniq(map(result, 'createdBy'));
    if (!isEmpty(userIds)) {
      const userResponse = await this.userService.getUserByIds(userIds, true);
      result.forEach((user) => {
        user.createdBy = userResponse[user.createdBy];
      });
    }
    const response = plainToInstance(
      BussinessTypeResponseDto,
      result.map((businessType) => ({
        ...businessType,
        bussinessTypeAttributes: businessType.bussinessTypeAttributes?.map(
          (attr) => ({
            ...attr,
            apiPath: BUSINESS_TYPE_ATTRIBUTE_API_PATH[attr.tableName],
          }),
        ),
      })),
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  async getListByIds(ids: number[]): Promise<any> {
    const result = await this.bussinessTypeRepository.findByCondition({
      id: In(ids),
    });
    return new ResponseBuilder()
      .withData(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  async detail(request: DetailBussinessTypeRequestDto): Promise<any> {
    const bussinessType = await this.bussinessTypeRepository.detail(request);
    if (!bussinessType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const userIds = [bussinessType.createdBy, bussinessType.updatedBy];
    if (!isEmpty(userIds)) {
      const userResponse = await this.userService.getUserByIds(userIds, true);
      bussinessType.createdBy = plainToInstance(
        UserResponseDto,
        userResponse[bussinessType.createdBy]
          ? userResponse[bussinessType.createdBy]
          : {},
        { excludeExtraneousValues: true },
      );
      bussinessType.updatedBy = plainToInstance(
        UserResponseDto,
        userResponse[bussinessType.updatedBy]
          ? userResponse[bussinessType.updatedBy]
          : {},
        { excludeExtraneousValues: true },
      );
    }

    const response = plainToInstance(BussinessTypeResponseDto, bussinessType, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  async getDetailWithTransaction(
    request: DetailBussinessTypeRequestDto,
  ): Promise<any> {
    const bussinessType =
      await this.bussinessTypeRepository.detailWithTransaction(request);
    if (!bussinessType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const userIds = [bussinessType.createdBy, bussinessType.updatedBy];
    if (!isEmpty(userIds)) {
      const userResponse = await this.userService.getUserByIds(userIds, true);
      bussinessType.createdBy = plainToInstance(
        UserResponseDto,
        userResponse[bussinessType.createdBy]
          ? userResponse[bussinessType.createdBy]
          : {},
        { excludeExtraneousValues: true },
      );
      bussinessType.updatedBy = plainToInstance(
        UserResponseDto,
        userResponse[bussinessType.updatedBy]
          ? userResponse[bussinessType.updatedBy]
          : {},
        { excludeExtraneousValues: true },
      );
    }

    const response = plainToInstance(BussinessTypeResponseDto, bussinessType, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  async getBusinessTransactionValueByCondition(
    request: DetailTransactionBussinessTypeRequestDto,
  ): Promise<any> {
    const result =
      await this.transactionBusinessTypeRepository.getBusinessTransactionValueByCondition(
        request,
      );
    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  async update(request: UpdateBussinessTypeRequestDto): Promise<any> {
    const bussinessType = await this.bussinessTypeRepository.findOneById(
      request.id,
    );
    if (!bussinessType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const bussinesTypeAttributes =
      await this.bussinessTypeAttributeRepository.findByCondition({
        bussinessTypeId: request.id,
      });
    const bussinessTypeAttributeIds = uniq(map(bussinesTypeAttributes, 'id'));
    bussinessType.updatedBy = request.userId;
    const bussinessTypeEntity = this.bussinessTypeRepository.updateEntity(
      bussinessType,
      { ...request },
    );
    return this.save(
      bussinessTypeEntity,
      request,
      bussinessTypeAttributeIds,
      'message.defineBussinessType.updateSuccess',
    );
  }

  async delete(request: DetailBussinessTypeRequestDto): Promise<any> {
    const bussinessType = await this.bussinessTypeRepository.findOneById(
      request.id,
    );
    if (!bussinessType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    try {
      bussinessType.deletedAt = new Date();
      bussinessType.deletedBy = request.userId;
      await this.bussinessTypeRepository.create(bussinessType);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'message.defineBussinessType.deleteSuccess',
          ),
        )
        .build();
    } catch (error) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_DELETE'),
      ).toResponse();
    }
  }

  async confirm(request: ConfirmBussinessTypeRequestDto): Promise<any> {
    const bussinessType = await this.bussinessTypeRepository.findOneById(
      request.id,
    );
    if (!bussinessType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_CONFIRM_BUSSINESS_TYPE_STATUS.includes(bussinessType.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.CANNOT_CONFIRM'))
        .build();
    }
    try {
      bussinessType.status = StatusBussinessEnum.ACTIVE;
      await this.bussinessTypeRepository.create(bussinessType);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'message.defineBussinessType.confirmSuccess',
          ),
        )
        .build();
    } catch (error) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CANNOT_CONFIRM'),
      ).toResponse();
    }
  }

  async reject(request: RejectBussinessTypeRequestDto): Promise<any> {
    const bussinessType = await this.bussinessTypeRepository.findOneById(
      request.id,
    );
    if (!bussinessType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_REJECT_BUSSINESS_TYPE_STATUS.includes(bussinessType.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.CANNOT_REJECT'))
        .build();
    }
    try {
      bussinessType.status = StatusBussinessEnum.INACTIVE;
      await this.bussinessTypeRepository.create(bussinessType);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'message.defineBussinessType.rejectSuccess',
          ),
        )
        .build();
    } catch (error) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CANNOT_REJECT'),
      ).toResponse();
    }
  }

  public async save(
    bussinessTypeEntity: BussinessTypeEntity,
    payload: CreateBussinessTypeRequestDto,
    ids: any,
    message?: string,
  ): Promise<ResponsePayload<any> | any> {
    const conditionCheckExistCode = {
      code: bussinessTypeEntity.code,
    } as any;
    const { bussinessTypeAttributes, parentBussiness } = payload;
    if (bussinessTypeEntity.id) {
      conditionCheckExistCode.id = Not(bussinessTypeEntity.id);
    }
    const checkExistCode =
      await this.bussinessTypeRepository.findOneByCondition(
        conditionCheckExistCode,
      );
    if (checkExistCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_ALREADY_EXISTS'))
        .build();
    }

    // Validate attributes by parent bussiness
    let errorValidateBussinessTypeAttr;
    switch (parentBussiness) {
      case ParentBussinessEnum.IMPORT:
        errorValidateBussinessTypeAttr =
          await this.validateAttributesByParentBussinessImport(
            bussinessTypeAttributes,
          );
        if (errorValidateBussinessTypeAttr) {
          return errorValidateBussinessTypeAttr;
        }
        break;
      case ParentBussinessEnum.EXPORT:
        errorValidateBussinessTypeAttr =
          await this.validateAttributesByParentBussinessExport(
            bussinessTypeAttributes,
          );
        if (errorValidateBussinessTypeAttr) {
          return errorValidateBussinessTypeAttr;
        }
        break;
      case ParentBussinessEnum.TRANSFER:
        errorValidateBussinessTypeAttr =
          await this.validateAttributesByParentBussinessTransfer(
            bussinessTypeAttributes,
          );
        if (errorValidateBussinessTypeAttr) {
          return errorValidateBussinessTypeAttr;
        }
        break;
      default:
        break;
    }

    let validAttributeTypeText = true;
    let validAttributeTypeList = { success: true, message: '' };
    for (let i = 0; i < bussinessTypeAttributes.length; i++) {
      switch (bussinessTypeAttributes[i].type) {
        case TypeBussinessAttributeEnum.TEXT:
          validAttributeTypeText = this.checkAttributeTypeText(
            bussinessTypeAttributes[i],
          );
          break;
        case TypeBussinessAttributeEnum.LIST:
          validAttributeTypeList = this.checkAttributeTypeList(
            bussinessTypeAttributes[i],
          );
          break;
        default:
          break;
      }
      if (!validAttributeTypeText) {
        break;
      }
      if (!validAttributeTypeList.success) {
        break;
      }
    }
    if (!validAttributeTypeText) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.FIELDNAME_IS_NOT_EMPTY'))
        .build();
    }
    if (!validAttributeTypeList.success) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate(validAttributeTypeList.message))
        .build();
    }
    const bussinessTypeAttributeEntities = bussinessTypeAttributes.map(
      (bussinessTypeAttribute: any) =>
        this.bussinessTypeAttributeRepository.createEntity({
          type: bussinessTypeAttribute.type,
          fieldName: bussinessTypeAttribute.fieldName,
          columnName: bussinessTypeAttribute.columnName,
          tableName: bussinessTypeAttribute.tableName,
          required: bussinessTypeAttribute.required,
          code: bussinessTypeAttribute.code,
          ebsLabel: bussinessTypeAttribute.ebsLabel,
        }),
    );
    bussinessTypeEntity.bussinessTypeAttributes =
      bussinessTypeAttributeEntities;
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (!isEmpty(ids)) {
        await queryRunner.manager.delete(BussinessTypeAttributeEntity, ids);
      }
      const result = await queryRunner.manager.save(bussinessTypeEntity);

      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate(message || 'message.success'))
        .withData(result)
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  private checkAttributeTypeText(bussinessTypeAttribute: any) {
    return bussinessTypeAttribute?.fieldName?.length;
  }

  private checkAttributeTypeList(bussinessTypeAttribute: any) {
    if (
      !bussinessTypeAttribute?.tableName ||
      !bussinessTypeAttribute?.columnName
    ) {
      return {
        success: false,
        message: 'error.TABLENAME_OR_COLUMNNAME_IS_NOT_EMPTY',
      };
    } else if (
      !Object.values(TableNameEnum).includes(bussinessTypeAttribute?.tableName)
    ) {
      return {
        success: false,
        message: 'error.TABLENAME_IS_INVALID',
      };
    } else if (
      !COLUMN_NAME_BY_TABLE[bussinessTypeAttribute?.tableName].includes(
        bussinessTypeAttribute?.columnName,
      )
    ) {
      return {
        success: false,
        message: 'error.COLUMNNAME_IS_INVALID',
      };
    }

    return {
      success: true,
      message: 'message.SUCCESS',
    };
  }

  private async validateAttributesByParentBussinessImport(
    bussinessTypeAttribute,
  ) {
    const invalidDefaultAttrs = bussinessTypeAttribute.filter(
      (attr) =>
        attr.code && !VALID_DEFAULT_FIELDS_FOR_TYPE_IMPORT.includes(attr.code),
    );
    if (!isEmpty(invalidDefaultAttrs)) {
      return new ResponseBuilder()
        .withData(invalidDefaultAttrs)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.INVALID_DEFAULT_ATTRIBUTES'),
        )
        .build();
    }

    const attrNeedValidate = [
      BusinessTypeAttributeDefaultEnum.WAREHOUSE_EXPORT_PROPOSAL_ID,
      BusinessTypeAttributeDefaultEnum.SO_EXPORT_ID,
    ];
    const defaultAttributes = bussinessTypeAttribute.filter((attr) =>
      attrNeedValidate.includes(attr.code),
    );

    // Only one of 2 fields WAREHOUSE_EXPORT_PROPOSAL_ID/SO_EXPORT_ID is selected
    if (
      defaultAttributes.some(
        (attr) =>
          attr.code ===
          BusinessTypeAttributeDefaultEnum.WAREHOUSE_EXPORT_PROPOSAL_ID,
      ) &&
      defaultAttributes.some(
        (attr) => attr.code === BusinessTypeAttributeDefaultEnum.SO_EXPORT_ID,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.SELECT_WAREHOUSE_EXPORT_PROPOSAL_OR_SO_EXPORT_ID_ONLY',
          ),
        )
        .build();
    }

    // Field WAREHOUSE_EXPORT_PROPOSAL_ID must be selected if select RECEIPT_ID
    if (
      bussinessTypeAttribute.some(
        (attr) => attr.code === BusinessTypeAttributeDefaultEnum.RECEIPT_ID,
      ) &&
      !bussinessTypeAttribute.some(
        (attr) =>
          attr.code ===
          BusinessTypeAttributeDefaultEnum.WAREHOUSE_EXPORT_PROPOSAL_ID,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.FIELD_WAREHOUSE_EXPORT_PROPOSAL_ID_MUST_BE_IF_SELECT_RECEIPT_ID',
          ),
        )
        .build();
    }

    // Field CONSTRUCTION_ID must be selected if select CATEGORY_CONSTRUCTION_ID
    if (
      bussinessTypeAttribute.some(
        (attr) =>
          attr.code ===
          BusinessTypeAttributeDefaultEnum.CATEGORY_CONSTRUCTION_ID,
      ) &&
      !bussinessTypeAttribute.some(
        (attr) =>
          attr.code === BusinessTypeAttributeDefaultEnum.CONSTRUCTION_ID,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.FIELD_CONSTRUCTION_ID_MUST_BE_IF_SELECT_CATEGORY_CONSTRUCTION_ID',
          ),
        )
        .build();
    }
  }

  private async validateAttributesByParentBussinessExport(
    bussinessTypeAttribute,
  ) {
    const invalidDefaultAttrs = bussinessTypeAttribute.filter(
      (attr) =>
        attr.code && !VALID_DEFAULT_FIELDS_FOR_TYPE_EXPORT.includes(attr.code),
    );
    if (!isEmpty(invalidDefaultAttrs)) {
      return new ResponseBuilder()
        .withData(invalidDefaultAttrs)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.INVALID_DEFAULT_ATTRIBUTES'),
        )
        .build();
    }

    const attrNeedValidate = [
      BusinessTypeAttributeDefaultEnum.WAREHOUSE_EXPORT_PROPOSAL_ID,
      BusinessTypeAttributeDefaultEnum.PO_IMPORT_ID,
    ];
    const defaultAttributes = bussinessTypeAttribute.filter((attr) =>
      attrNeedValidate.includes(attr.code),
    );

    // Only one of 2 fields WAREHOUSE_EXPORT_PROPOSAL_ID/PO_IMPORT_ID is selected
    if (
      defaultAttributes.some(
        (attr) =>
          attr.code ===
          BusinessTypeAttributeDefaultEnum.WAREHOUSE_EXPORT_PROPOSAL_ID,
      ) &&
      defaultAttributes.some(
        (attr) => attr.code === BusinessTypeAttributeDefaultEnum.PO_IMPORT_ID,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.SELECT_WAREHOUSE_EXPORT_PROPOSAL_OR_PO_IMPORT_ID_ONLY',
          ),
        )
        .build();
    }
  }

  private async validateAttributesByParentBussinessTransfer(
    bussinessTypeAttribute,
  ) {
    const invalidDefaultAttrs = bussinessTypeAttribute.filter(
      (attr) =>
        attr.code &&
        !VALID_DEFAULT_FIELDS_FOR_TYPE_TRANSFER.includes(attr.code),
    );
    if (!isEmpty(invalidDefaultAttrs)) {
      return new ResponseBuilder()
        .withData(invalidDefaultAttrs)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.INVALID_DEFAULT_ATTRIBUTES'),
        )
        .build();
    }

    if (
      bussinessTypeAttribute.some(
        (attr) =>
          attr.code ===
          BusinessTypeAttributeDefaultEnum.CATEGORY_CONSTRUCTION_ID,
      ) &&
      !bussinessTypeAttribute.some(
        (attr) =>
          attr.code === BusinessTypeAttributeDefaultEnum.CONSTRUCTION_ID,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.SELECT_CATEGORY_CONSTRUCTION_ID_OR_CONSTRUCTION_ID_ONLY',
          ),
        )
        .build();
    }
  }

  async validateBusinessTypeAttrs(
    payload: ValidateTransactionBusinessTypeBodyDto,
  ): Promise<any> {
    const conditions = payload?.data?.map((validationData) => ({
      id: validationData.attrId,
      bussinessTypeId: validationData.businessTypeId,
    }));

    const uniqConditions = values(
      keyBy(conditions, (condition) => values(condition).join('_')),
    );
    const businessTypeAttrs =
      await this.bussinessTypeAttributeRepository.findByCondition(
        uniqConditions,
      );

    if (
      isEmpty(businessTypeAttrs) ||
      businessTypeAttrs.length !== uniqConditions.length
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const businessTypeAttrsById = keyBy(businessTypeAttrs, 'id');
    const validationResults = payload?.data?.map(
      (validatationData: ValidateTransactionBusinessTypeRequestDto) => {
        const attr = businessTypeAttrsById[validatationData.attrId];
        const baseTransactionBusinessType =
          new BaseTransactionBusinessTypeService(attr.type);
        return baseTransactionBusinessType.validate({
          value: validatationData.value,
          attr,
        });
      },
    );
    let attributeDetailValues: any = {};
    if (payload.sourceId) {
      const sourceResponse = await this.saleService.getSourceById(
        payload.sourceId,
      );
      if (!isEmpty(payload.data)) {
        const attributeGroup = groupBy(payload.data, 'tableName');
        const request = new GetAttributeDetailValuesRequestDto();
        const attributeKeys = Object.keys(attributeGroup).filter(
          (el) => !el.match('null'),
        );
        request.filter = attributeKeys.map((key) => {
          return {
            tableName: key,
            id: compact(map(attributeGroup[key], 'value')).join(','),
          };
        });
        attributeDetailValues = await this.getAttributeDetailValues(request);
        if (!isEmpty(attributeDetailValues?.data?.cost_types)) {
          const costType = first(attributeDetailValues?.data?.cost_types);
          if (sourceResponse?.accountant !== costType?.code) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
              .withMessage(
                await this.i18n.translate(
                  'error.THE_TYPE_OF_EXPENSE_MUS_MATCH_SEGMENT_FOUR_OF_THE_ACCOUNTING_ACCOUNT',
                ),
              )
              .build();
          }
        }
      }
    }

    if (validationResults.some((result) => !result.validationResult)) {
      const error: ValidateTransactionBusinessTypeResponseDto =
        validationResults.find((result) => !result.validationResult);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(error.message, {
            args: { property: error.property },
          }),
        )
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.success'))
      .build();
  }

  async saveBusinessTypeAttrs(
    payload: SaveTransactionBusinessTypeRequestDto[],
  ): Promise<any> {
    const files = payload
      .filter((data) => data.type === TypeBussinessAttributeEnum.FILE)
      .map((data) => data.values);
    let fileUrls = {};
    if (!isEmpty(files)) {
      fileUrls = await this.uploadFiles(files);
      if (!fileUrls || Object.values(fileUrls).some((url) => !url)) {
        return new ResponseBuilder(
          await this.i18n.translate('error.CANNOT_UPLOAD_FILE'),
        )
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .build();
      }
    }

    const conditions = payload.map((data) => ({
      orderId: data.orderId,
      orderType: data.orderType,
      bussinessAttributeId: data.businessTypeAttributeId,
    }));
    const transactionBusinessTypes =
      await this.transactionBusinessTypeRepository.findByCondition(conditions);

    const entities = payload.map(
      (data: SaveTransactionBusinessTypeRequestDto) => {
        const { type } = data;
        if (type === TypeBussinessAttributeEnum.FILE) {
          data.values = fileUrls[data.businessTypeAttributeId];
        }
        const baseTransactionBusinessType =
          new BaseTransactionBusinessTypeService(type);
        return baseTransactionBusinessType.createEntity(data);
      },
    );

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.remove(transactionBusinessTypes);
      const result = await queryRunner.manager.save(entities);

      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('message.success'))
        .withData(result)
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  private async uploadFiles(files) {
    const uploadFileRequest = {
      files,
      service: this.configService.get('serviceName'),
      resource: RESOURCE_SAVE_TRANSACTION_BUSINESS_TYPE,
    } as UploadFileRequestDto;
    const result = await this.fileService.uploadFiles(uploadFileRequest);
    return result?.data;
  }

  public async getTransactionBussinessType(
    request: GetTransactionBussinessTypeRequestDto,
  ): Promise<any> {
    const transactions =
      await this.transactionBusinessTypeRepository.getTransactionBussinessType(
        request,
      );
    if (!transactions) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const response = plainToInstance(
      GetTransactionBussinessTypeResponseDto,
      transactions,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  public async getAttributeDetailValues(
    request: GetAttributeDetailValuesRequestDto,
  ): Promise<any> {
    const { filter } = request;
    const handlers = filter.map((item) => {
      switch (item.tableName) {
        case TableNameEnum.DEPARTMENT_RECEIPT:
          return this.userService.getDepartmentReceiptByIds(
            item.id.split(',')?.map((id) => Number(id)),
          );
        case TableNameEnum.VENDOR:
          return this.saleService.getVendorByIds(
            item.id.split(',')?.map((id) => Number(id)),
          );
        case TableNameEnum.COST_TYPE:
          return this.saleService.getCostTypeByIds(
            item.id.split(',')?.map((id) => Number(id)),
          );
        case TableNameEnum.ORGANIZATION_PAYMENT:
          return this.saleService.getOrganizationPaymentByIds(
            item.id.split(',')?.map((id) => Number(id)),
          );
        case TableNameEnum.SALE_ORDER_EXPORT:
          return this.saleService.getSaleOrderExportByIds(
            item.id.split(',')?.map((id) => Number(id)),
            false,
          );
        case TableNameEnum.PURCHASED_ORDER_IMPORT:
          return this.saleService.getPurchasedOrderImportByIds(
            item.id.split(',')?.map((id) => Number(id)),
          );
        case TableNameEnum.WAREHOUSE_EXPORT_PROPOSAL:
          if (item?.id?.length) {
            return this.warehouseExportProposalRepository.findByCondition({
              id: In(item.id.split(',')),
            });
          } else {
            return [];
          }
        case TableNameEnum.CONSTRUCTION:
          return this.saleService.getConstructionByIds(
            item.id.split(',')?.map((id) => Number(id)),
          );
        case TableNameEnum.CATEGORY_CONSTRUCTION:
          return this.saleService.getCategoryContructionByIds(
            item.id.split(',')?.map((id) => Number(id)),
          );
        case TableNameEnum.RECEIP:
          return this.saleService.getReceiptByIds(
            item.id.split(',')?.map((id) => Number(id)),
          );
      }
    });
    const data = await Promise.all(handlers);
    const response = filter
      .map((item, index) => {
        const result = plainToInstance(
          GetAttributeDetailValuesResponseDto,
          data[index],
          {
            excludeExtraneousValues: true,
          },
        );
        return {
          [item.tableName]: result,
        };
      })
      .reduce((prev, cur) => ({ ...prev, ...cur }), {});

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  public async getBusinessTransactionValueByOrder(
    request: GetBusinessTransactionValueRequestDto,
  ): Promise<any> {
    const businessTypeTransaction =
      await this.transactionBusinessTypeRepository.getBusinessTransactionValueByOrder(
        request,
      );
    return new ResponseBuilder({
      id: businessTypeTransaction?.values,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  public async getBussinessTypeWarehouseExportProposalByOrder(
    request: GetBussinessTypeWarehouseExportProposalByOrderRequestDto,
  ): Promise<any> {
    const { orderId, orderType } = request;
    const transactionBussinessType =
      await this.transactionBusinessTypeRepository.getBusinessTransactionValueByOrder(
        {
          orderId: orderId,
          orderType: orderType,
          attribute:
            BusinessTypeAttributeDefaultEnum.WAREHOUSE_EXPORT_PROPOSAL_ID,
        } as GetBusinessTransactionValueRequestDto,
      );
    if (isEmpty(transactionBussinessType)) {
      return new ResponseBuilder({})
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('message.SUCCESS'))
        .build();
    }
    return new ResponseBuilder(transactionBussinessType)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  async getBusinessByCode(code: string): Promise<any> {
    const businessType =
      await this.bussinessTypeRepository.findOneWithRelations({
        where: {
          code: code,
        },
        relations: ['bussinessTypeAttributes'],
      });

    if (isEmpty(businessType)) {
      return new ResponseBuilder().withCode(ResponseCodeEnum.NOT_FOUND).build();
    }

    return new ResponseBuilder(businessType)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async getBusinessByCodes(codes: string[]): Promise<any> {
    const businessTypes = await this.bussinessTypeRepository.findWithRelations({
      where: {
        code: In(codes),
      },
      relations: ['bussinessTypeAttributes'],
    });

    return new ResponseBuilder(businessTypes)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
}
