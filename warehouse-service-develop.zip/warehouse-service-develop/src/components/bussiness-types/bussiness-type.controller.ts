import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateBussinessTypeRequestDto } from './dto/request/create-bussiness-type.request.dto';
import { BussinessTypeResponseDto } from './dto/response/bussiness-type.response.dto';
import { BussinessTypeServiceInterface } from './interface/bussiness-type.interface.service';
import { isEmpty } from 'lodash';
import { ResponsePayload } from '@utils/response-payload';
import { GetListBussinessTypeRequestDto } from './dto/request/get-list-bussiness-type.request.dto';
import { DetailBussinessTypeRequestDto } from './dto/request/detail-bussiness-type.request.dto';
import { UpdateBussinessTypeBodyDto } from './dto/request/update-bussiness-type.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CONFIRM_BUSSINESS_TYPE_PERMISSION,
  CREATE_BUSSINESS_TYPE_PERMISSION,
  DELETE_BUSSINESS_TYPE_PERMISSION,
  DETAIL_BUSSINESS_TYPE_PERMISSION,
  LIST_BUSSINESS_TYPE_PERMISSION,
  REJECT_BUSSINESS_TYPE_PERMISSION,
  UPDATE_BUSSINESS_TYPE_PERMISSION,
} from '@utils/permissions/bussiness-type';
import { ConfirmBussinessTypeRequestDto } from './dto/request/confirm-bussiness-type.request.dto';
import { RejectBussinessTypeRequestDto } from './dto/request/reject-bussiness-type.request.dto';
import { MessagePattern } from '@nestjs/microservices';
import { ValidateTransactionBusinessTypeBodyDto } from './dto/request/validate-transaction-business-type.request.dto';
import { SaveTransactionBusinessTypeBodyDto } from './dto/request/save-transaction-business-type.request.dto';
import { GetTransactionBussinessTypeRequestDto } from './dto/request/get-transaction-bussiness-type.request.dto';
import { GetAttributeDetailValuesRequestDto } from './dto/request/get-attribute-detail-values.request.dto';
import { GetBusinessTransactionValueRequestDto } from './dto/request/get-business-transaction-value-by-order.request.dto';
import { GetBussinessTypeWarehouseExportProposalByOrderRequestDto } from './dto/request/get-bussiness-type-warehouse-export-proposal-by-order.request.dto';
import { DetailTransactionBussinessTypeRequestDto } from './dto/request/detail-transaction-business-type.request.dto';
import { NATS_WAREHOUSE } from '@config/nats.config';

@Controller('bussiness-types')
export class BussinessTypeController {
  @Inject('BussinessTypeServiceInterface')
  private readonly bussinessService: BussinessTypeServiceInterface;

  @PermissionCode(CREATE_BUSSINESS_TYPE_PERMISSION.code)
  @Post('/create')
  @ApiOperation({
    tags: ['bussiness'],
    summary: 'Create bussiness Type',
    description: 'Tạo mới nghiệp vụ',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: BussinessTypeResponseDto,
  })
  async create(
    @Body() payload: CreateBussinessTypeRequestDto,
  ): Promise<ResponsePayload<BussinessTypeResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bussinessService.create(request);
  }

  // @PermissionCode(LIST_BUSSINESS_TYPE_PERMISSION.code)
  @Get('/list')
  @ApiOperation({
    tags: ['bussiness'],
    summary: 'List bussiness Type',
    description: 'Danh sách nghiệp vụ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: BussinessTypeResponseDto,
  })
  async getList(
    @Query() payload: GetListBussinessTypeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bussinessService.getList(request);
  }

  @PermissionCode(DETAIL_BUSSINESS_TYPE_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['bussiness'],
    summary: 'Detail bussiness Type',
    description: 'Chi tiết nghiệp vụ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: BussinessTypeResponseDto,
  })
  async detail(@Param() param: DetailBussinessTypeRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bussinessService.detail(request);
  }

  @Get('/attribute-details')
  @ApiOperation({
    tags: ['bussiness'],
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  async getAttributeDetailValues(
    @Query() query: GetAttributeDetailValuesRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bussinessService.getAttributeDetailValues(request);
  }

  @MessagePattern(`${NATS_WAREHOUSE}.get_attribute_detail_values`)
  async getAttributeDetailValuesTcp(
    @Body() body: GetAttributeDetailValuesRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bussinessService.getAttributeDetailValues(request);
  }

  @PermissionCode(UPDATE_BUSSINESS_TYPE_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['bussiness'],
    summary: 'Update bussiness Type',
    description: 'Sửa nghiệp vụ',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: BussinessTypeResponseDto,
  })
  async update(
    @Body() body: UpdateBussinessTypeBodyDto,
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.bussinessService.update(request);
  }

  @PermissionCode(DELETE_BUSSINESS_TYPE_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['bussiness'],
    summary: 'Delete bussiness Type',
    description: 'Xoá nghiệp vụ',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: BussinessTypeResponseDto,
  })
  async delete(@Param() param: DetailBussinessTypeRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bussinessService.delete(request);
  }

  @PermissionCode(CONFIRM_BUSSINESS_TYPE_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['bussiness'],
    summary: 'Confirm bussiness Type',
    description: 'Confirm nghiệp vụ',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: BussinessTypeResponseDto,
  })
  async confirm(@Param() param: ConfirmBussinessTypeRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bussinessService.confirm(request);
  }

  @PermissionCode(REJECT_BUSSINESS_TYPE_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['bussiness'],
    summary: 'Reject bussiness Type',
    description: 'Reject nghiệp vụ',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: BussinessTypeResponseDto,
  })
  async reject(@Param() param: RejectBussinessTypeRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bussinessService.reject(request);
  }

  @Get('/transaction-by-order')
  @ApiOperation({
    tags: ['bussiness'],
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  async getBusinessTransactionValueByOrder(
    @Query() query: GetBusinessTransactionValueRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bussinessService.getBusinessTransactionValueByOrder(
      request,
    );
  }

  @MessagePattern(`${NATS_WAREHOUSE}.validate_business_type_attrs`)
  async validateBusinessTypeAttrs(
    @Body() payload: ValidateTransactionBusinessTypeBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bussinessService.validateBusinessTypeAttrs(request);
  }

  @MessagePattern(`${NATS_WAREHOUSE}.save_business_type_attrs`)
  async saveBusinessTypeAttrs(
    @Body() payload: SaveTransactionBusinessTypeBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bussinessService.saveBusinessTypeAttrs(request);
  }

  @MessagePattern(`${NATS_WAREHOUSE}.get_list_business_type_by_ids`)
  public async getListByIdsTcp(ids: number[]): Promise<any> {
    return await this.bussinessService.getListByIds(ids);
  }

  @MessagePattern(`${NATS_WAREHOUSE}.get_business_type_detail`)
  async detailTcp(@Body() body: DetailBussinessTypeRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bussinessService.detail(request);
  }

  @MessagePattern(`${NATS_WAREHOUSE}.get_business_type_detail_with_transaction`)
  async detailWithTransactionTcp(
    @Body() body: DetailBussinessTypeRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bussinessService.getDetailWithTransaction(request);
  }
  @MessagePattern(`${NATS_WAREHOUSE}.get_business_type_values_by_condition`)
  async getBusinessTransactionValueByConditionTcp(
    @Body() query: DetailTransactionBussinessTypeRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bussinessService.getBusinessTransactionValueByCondition(
      request,
    );
  }

  @MessagePattern(`${NATS_WAREHOUSE}.get_transaction_business_type`)
  async getTransactionBussinessType(
    @Body() body: GetTransactionBussinessTypeRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bussinessService.getTransactionBussinessType(request);
  }

  @MessagePattern(
    `${NATS_WAREHOUSE}.get_bussiness_type_warehouse_export_proposal_by_order`,
  )
  async getBussinessTypeWarehouseExportProposalByOrder(
    @Body() body: GetBussinessTypeWarehouseExportProposalByOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bussinessService.getBussinessTypeWarehouseExportProposalByOrder(
      request,
    );
  }

  @MessagePattern(`${NATS_WAREHOUSE}.get_business_type_by_code`)
  public async getBusinessByCode(code: string): Promise<any> {
    return await this.bussinessService.getBusinessByCode(code);
  }

  @MessagePattern(`${NATS_WAREHOUSE}.get_business_type_by_codes`)
  public async getBusinessByCodes(codes: string[]): Promise<any> {
    return await this.bussinessService.getBusinessByCodes(codes);
  }
}
