import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { BussinessTypeEntity } from '@entities/bussiness-types/bussiness-types.entity';
import { CreateBussinessTypeRequestDto } from '../dto/request/create-bussiness-type.request.dto';
import { DetailBussinessTypeRequestDto } from '../dto/request/detail-bussiness-type.request.dto';
import { GetListBussinessTypeRequestDto } from '../dto/request/get-list-bussiness-type.request.dto';
import { UpdateBussinessTypeRequestDto } from '../dto/request/update-bussiness-type.request.dto';

export interface BussinessTypeRepositoryInterface
  extends BaseAbstractRepository<BussinessTypeEntity> {
  createEntity(request: CreateBussinessTypeRequestDto): BussinessTypeEntity;
  getList(request: GetListBussinessTypeRequestDto): Promise<any>;
  detail(request: DetailBussinessTypeRequestDto): Promise<any>;
  detailWithTransaction(request: DetailBussinessTypeRequestDto): Promise<any>;
  updateEntity(
    bussinessTypeUpdate: BussinessTypeEntity,
    request: UpdateBussinessTypeRequestDto | any,
  ): BussinessTypeEntity;
}
