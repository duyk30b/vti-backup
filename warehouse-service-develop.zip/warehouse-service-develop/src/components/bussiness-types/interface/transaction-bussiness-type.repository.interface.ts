import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { TransactionBussinessTypeEntity } from '@entities/bussiness-types/transaction-bussiness-type.entity';
import { DetailTransactionBussinessTypeRequestDto } from '../dto/request/detail-transaction-business-type.request.dto';
import { GetBusinessTransactionValueRequestDto } from '../dto/request/get-business-transaction-value-by-order.request.dto';
import { GetTransactionBussinessTypeRequestDto } from '../dto/request/get-transaction-bussiness-type.request.dto';

export interface TransactionBussinessTypeRepositoryInterface
  extends BaseAbstractRepository<TransactionBussinessTypeEntity> {
  getTransactionBussinessType(
    request: GetTransactionBussinessTypeRequestDto,
  ): Promise<any>;
  getBusinessTransactionValueByOrder(
    request: GetBusinessTransactionValueRequestDto,
  ): Promise<any>;
  getBusinessTransactionValueOtherOrder(
    request: GetBusinessTransactionValueRequestDto,
  ): Promise<any>;
  getBusinessTransactionValueByCondition(
    request: DetailTransactionBussinessTypeRequestDto,
  ): Promise<any>;
}
