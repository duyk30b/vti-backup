import { ConfirmBussinessTypeRequestDto } from '../dto/request/confirm-bussiness-type.request.dto';
import { CreateBussinessTypeRequestDto } from '../dto/request/create-bussiness-type.request.dto';
import { DetailBussinessTypeRequestDto } from '../dto/request/detail-bussiness-type.request.dto';
import { DetailTransactionBussinessTypeRequestDto } from '../dto/request/detail-transaction-business-type.request.dto';
import { GetAttributeDetailValuesRequestDto } from '../dto/request/get-attribute-detail-values.request.dto';
import { GetBusinessTransactionValueRequestDto } from '../dto/request/get-business-transaction-value-by-order.request.dto';
import { GetBussinessTypeWarehouseExportProposalByOrderRequestDto } from '../dto/request/get-bussiness-type-warehouse-export-proposal-by-order.request.dto';
import { GetListBussinessTypeRequestDto } from '../dto/request/get-list-bussiness-type.request.dto';
import { GetTransactionBussinessTypeRequestDto } from '../dto/request/get-transaction-bussiness-type.request.dto';
import { RejectBussinessTypeRequestDto } from '../dto/request/reject-bussiness-type.request.dto';
import { SaveTransactionBusinessTypeRequestDto } from '../dto/request/save-transaction-business-type.request.dto';
import { UpdateBussinessTypeRequestDto } from '../dto/request/update-bussiness-type.request.dto';
import { ValidateTransactionBusinessTypeBodyDto } from '../dto/request/validate-transaction-business-type.request.dto';

export interface BussinessTypeServiceInterface {
  create(request: CreateBussinessTypeRequestDto): Promise<any>;
  getList(request: GetListBussinessTypeRequestDto): Promise<any>;
  detail(request: DetailBussinessTypeRequestDto): Promise<any>;
  getDetailWithTransaction(
    request: DetailBussinessTypeRequestDto,
  ): Promise<any>;
  update(request: UpdateBussinessTypeRequestDto): Promise<any>;
  delete(request: DetailBussinessTypeRequestDto): Promise<any>;
  confirm(request: ConfirmBussinessTypeRequestDto): Promise<any>;
  reject(request: RejectBussinessTypeRequestDto): Promise<any>;
  getListByIds(ids: number[]): Promise<any>;
  validateBusinessTypeAttrs(
    payload: ValidateTransactionBusinessTypeBodyDto,
    sourceId?: number,
  ): Promise<any>;
  saveBusinessTypeAttrs(
    payload: SaveTransactionBusinessTypeRequestDto[],
  ): Promise<any>;
  getTransactionBussinessType(
    request: GetTransactionBussinessTypeRequestDto,
  ): Promise<any>;
  getAttributeDetailValues(
    request: GetAttributeDetailValuesRequestDto,
  ): Promise<any>;
  getBusinessTransactionValueByOrder(
    request: GetBusinessTransactionValueRequestDto,
  ): Promise<any>;
  getBussinessTypeWarehouseExportProposalByOrder(
    request: GetBussinessTypeWarehouseExportProposalByOrderRequestDto,
  ): Promise<any>;
  getBusinessTransactionValueByCondition(
    request: DetailTransactionBussinessTypeRequestDto,
  ): Promise<any>;
  getBusinessByCode(code: string): Promise<any>;
  getBusinessByCodes(codes: string[]): Promise<any>;
}
