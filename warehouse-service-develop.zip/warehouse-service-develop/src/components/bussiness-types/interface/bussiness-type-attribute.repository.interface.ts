import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { BussinessTypeAttributeEntity } from '@entities/bussiness-types/bussiness-type-attributes.entity';

export interface BussinessTypeAttributeRepositoryInterface
  extends BaseAbstractRepository<BussinessTypeAttributeEntity> {
  createEntity(data: any): BussinessTypeAttributeEntity;
}
