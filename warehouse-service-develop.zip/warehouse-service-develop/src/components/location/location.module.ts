import { LocationEntity } from '@entities/location/location.entity';
import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LocationController } from './location.controller';
import { LocationRepository } from '@repositories/location.repository';
import { LocationService } from './location.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { LocationSegmentRepository } from '@repositories/location-segment.repository';
import { LocationSegmentEntity } from '@entities/location-segment/location-segment.entity';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([LocationEntity, LocationSegmentEntity]),
    UserModule,
  ],
  exports: [],
  providers: [
    {
      provide: 'LocationRepositoryInterface',
      useClass: LocationRepository,
    },
    {
      provide: 'LocationSegmentRepositoryInterface',
      useClass: LocationSegmentRepository,
    },
    {
      provide: 'LocationServiceInterface',
      useClass: LocationService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
  ],
  controllers: [LocationController],
})
export class LocationModule {}
