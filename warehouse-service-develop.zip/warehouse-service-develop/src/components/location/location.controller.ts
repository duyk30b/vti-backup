import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { CreateLocationTreeRequestDto } from './dto/request/create-location-tree.request.dto';
import { LocationServiceInterface } from './interface/location.service.interface';
import { isEmpty } from 'lodash';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateLocationRequestDto } from './dto/request/create-location.request.dto';
import { LocationResponseDto } from './dto/response/location.response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { GetLocationDetailRequestDto } from './dto/request/get-location.request.dto';
import { UpdateLocationBodyDto } from './dto/request/update-location.request.dto';
import { PagingResponse } from '@utils/paging.response';
import { GetLocationListRequestDto } from './dto/request/get-location-list.request.dto';
import {
  CREATE_LOCATION_PERMISSION,
  DELETE_LOCATION_PERMISSION,
  DETAIL_LOCATION_PERMISSION,
  LIST_LOCATION_PERMISSION,
  UPDATE_LOCATION_PERMISSION,
} from '@utils/permissions/location';
import { PermissionCode } from '@core/decorator/get-code.decorator';

@Controller('locations')
export class LocationController {
  constructor(
    @Inject('LocationServiceInterface')
    private readonly locationService: LocationServiceInterface,
  ) {}

  @PermissionCode(CREATE_LOCATION_PERMISSION.code)
  @Post('create/tree')
  @ApiOperation({
    tags: ['Location'],
    summary: 'Create new location tree',
    description: 'Tạo cấu trúc vị trí mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  async createTree(@Body() body: CreateLocationTreeRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locationService.createTree(request);
  }

  @PermissionCode(CREATE_LOCATION_PERMISSION.code)
  @Post('create')
  @ApiOperation({
    tags: ['Location'],
    summary: 'Create new warehouse structure',
    description: 'Tạo vị trí mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  async create(@Body() body: CreateLocationRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locationService.create(request);
  }

  @PermissionCode(UPDATE_LOCATION_PERMISSION.code)
  @Put(':id')
  @ApiOperation({
    tags: ['Location'],
    summary: 'update new warehouse structure',
    description: 'Cập nhập vị trí',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: LocationResponseDto,
  })
  async update(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() body: UpdateLocationBodyDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.locationService.update(request);
  }

  @PermissionCode(LIST_LOCATION_PERMISSION.code)
  @Get('/list')
  @ApiOperation({
    tags: ['Location'],
    summary: 'location remove',
    description: 'Danh sách vị trí',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: PagingResponse,
  })
  async getList(@Query() query: GetLocationListRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locationService.getList(request);
  }

  @PermissionCode(DETAIL_LOCATION_PERMISSION.code)
  @Get(':id')
  @ApiOperation({
    tags: ['Location'],
    summary: 'location detail',
    description: 'Chi tiết vị trí',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SuccessResponse,
  })
  async getDetail(@Param() param: GetLocationDetailRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locationService.getDetail(request);
  }

  @PermissionCode(DELETE_LOCATION_PERMISSION.code)
  @Delete(':id')
  @ApiOperation({
    tags: ['Location'],
    summary: 'location remove',
    description: 'Xóa vị trí',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SuccessResponse,
  })
  async delete(@Param() param: GetLocationDetailRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locationService.delete(request);
  }
}
