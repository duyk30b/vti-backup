export const LOCATION_RULES = {
  NAME: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 20,
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
};
