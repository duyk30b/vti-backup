import { ApiProperty } from '@nestjs/swagger';
import { UserResponseDto } from '@components/user/dto/response/user.response.dto';
import { Expose, Type } from 'class-transformer';

export class LocationTreeResponseDto {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  level: number;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdBy: UserResponseDto;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  updatedBy: UserResponseDto;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  @Type(() => LocationTreeResponseDto)
  children: LocationTreeResponseDto[];
}
