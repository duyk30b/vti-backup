import { LOCATION_RULES } from '@components/location/location.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsOptional, IsString, MaxLength } from 'class-validator';

export class CreateLocationRequestDto extends BaseDto {
  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(LOCATION_RULES.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(LOCATION_RULES.CODE.MAX_LENGTH)
  code: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(LOCATION_RULES.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ApiProperty({ example: '', description: '' })
  @IsInt()
  level: number;

  @ApiProperty({ example: '', description: '' })
  @IsOptional()
  @IsInt()
  parentId: number;
}
