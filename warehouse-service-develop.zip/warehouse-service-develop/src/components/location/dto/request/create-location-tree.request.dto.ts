import { LOCATION_RULES } from '@components/location/location.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsInt, IsString, MaxLength } from 'class-validator';

export class CreateLocationTreeRequestDto extends BaseDto {
  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(LOCATION_RULES.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(LOCATION_RULES.CODE.MAX_LENGTH)
  code: string;

  @ApiProperty({ example: '', description: '' })
  @IsInt()
  level: number;

  @ApiProperty({ example: '', description: '' })
  @IsInt()
  locationSegmentId: number;

  @ApiProperty({ example: '', description: '' })
  @IsArray()
  children: CreateLocationTreeRequestDto[];
}
