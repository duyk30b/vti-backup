import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';
import { CreateLocationRequestDto } from './create-location.request.dto';

export class UpdateLocationBodyDto extends CreateLocationRequestDto {}

export class UpdateLocationRequestDto extends UpdateLocationBodyDto {
  @ApiProperty({ example: '', description: '' })
  @Transform(({ value }) => Number(value))
  @IsInt()
  id: number;
}
