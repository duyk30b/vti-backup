import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { LocationEntity } from '@entities/location/location.entity';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, ILike, Not, QueryRunner } from 'typeorm';
import { CreateLocationTreeRequestDto } from './dto/request/create-location-tree.request.dto';
import { LocationRepositoryInterface } from './interface/location.repository.interface';
import { LocationServiceInterface } from './interface/location.service.interface';
import { clone, uniq } from 'lodash';
import { plainToInstance } from 'class-transformer';
import { LocationSegmentRepositoryInterface } from '@components/location-segment/interface/location-segment.repository.interface';
import { CreateLocationRequestDto } from './dto/request/create-location.request.dto';
import { LocationResponseDto } from './dto/response/location.response.dto';
import { UpdateLocationRequestDto } from './dto/request/update-location.request.dto';
import { GetLocationDetailRequestDto } from './dto/request/get-location.request.dto';
import { DeleteLocationRequestDto } from './dto/request/delete-location.request.dto';
import { GetLocationListRequestDto } from './dto/request/get-location-list.request.dto';
import { PagingResponse } from '@utils/paging.response';
@Injectable()
export class LocationService implements LocationServiceInterface {
  constructor(
    @InjectDataSource()
    private readonly connection: DataSource,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('LocationRepositoryInterface')
    private readonly locationRepository: LocationRepositoryInterface,
    @Inject('LocationSegmentRepositoryInterface')
    private readonly locationSegmentRepository: LocationSegmentRepositoryInterface,
    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateLocationRequestDto): Promise<any> {
    await this.locationSegmentRepository.findOneByCondition({
      level: request.level,
    });
    const location = this.locationRepository.createEntity(request);
    const existLocationCode = await this.locationRepository.findOneByCondition({
      code: location.code,
    });
    if (existLocationCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(this.i18n.translate('error.CODE_IS_EXIST'))
        .build();
    }
    return this.save(location);
  }

  async update(request: UpdateLocationRequestDto): Promise<any> {
    let location = await this.locationRepository.findOneById(request.id);
    if (!location) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    location = this.locationRepository.updateEntity(location, request);
    const existLocationCode = await this.locationRepository.findOneByCondition({
      id: Not(request.id),
      code: request.code,
    });
    if (existLocationCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(this.i18n.translate('error.CODE_IS_EXIST'))
        .build();
    }
    return this.save(location);
  }

  async getDetail(request: GetLocationDetailRequestDto): Promise<any> {
    const location = await this.locationRepository.findOneById(request.id);
    if (!location) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = await this.generateRespone(location);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  async delete(request: DeleteLocationRequestDto): Promise<any> {
    const location = await this.locationRepository.findOneByCondition({
      id: request.id,
    });
    if (!location) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const descendantLocations = await queryRunner.manager.find(
        LocationEntity,
        {
          where: {
            mpath: ILike(`${location.mpath}%`),
          },
          order: {
            id: 'DESC',
          },
        },
      );
      descendantLocations.forEach((location) => {
        location.deletedBy = request.userId;
        location.deletedAt = new Date();
      });
      await queryRunner.manager.save(descendantLocations);
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  async getList(request: GetLocationListRequestDto): Promise<any> {
    const { page } = request;
    const [data, count] = await this.locationRepository.getList(request);
    const creatorIds = uniq(data.map((item) => item.createdBy));
    const updaterIds = uniq(data.map((item) => item.updatedBy));
    const userIds = [...creatorIds, ...updaterIds];
    const users = await this.userService.getUserByIds(uniq(userIds), true);

    data.forEach((item) => {
      item.createdBy = users[item.createdBy];
      item.updatedBy = users[item.updatedBy];
    });

    const dataReturn = plainToInstance(LocationResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async save(location: LocationEntity): Promise<any> {
    if (location.level > 0 && !location.parentId) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          this.i18n.translate('error.LOCATION_LEVEL_MUST_HAVE_PARENT'),
        )
        .build();
    }
    if (location.parentId) {
      const parentLocation = await this.locationRepository.findOneById(
        location.parentId,
      );
      if (!parentLocation) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(this.i18n.translate('error.LOCATION_PARENT_NOT_FOUND'))
          .build();
      }
      if (parentLocation.level + 1 !== location.level) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(this.i18n.translate('error.LOCATION_LEVEL_INVALID'))
          .build();
      }
    }
    const locationSegment =
      await this.locationSegmentRepository.findOneByCondition({
        level: location.level,
      });
    if (!locationSegment) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(this.i18n.translate('error.LOCATION_SEGMENT_NOT_FOUND'))
        .build();
    }
    location.locationSegmentId = locationSegment.id;
    try {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      const tempLocation = await queryRunner.manager.save(location);
      const mpath = tempLocation.id + '.';
      if (tempLocation.parentId) {
        const parent = await queryRunner.manager.findOne(LocationEntity, {
          where: { id: tempLocation.parentId },
        });
        location.mpath = parent.mpath + mpath;
      }
      const result = await queryRunner.manager.save(location);
      await queryRunner.commitTransaction();
      const data = await this.generateRespone(result);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(data)
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  private async generateRespone(
    locationEntity: LocationEntity,
  ): Promise<LocationResponseDto> {
    const userIds = [locationEntity.createdBy, locationEntity.updatedBy];
    const users = await this.userService.getUserByIds(uniq(userIds), true);
    locationEntity.createdBy = users[locationEntity.createdBy];
    locationEntity.updatedBy = users[locationEntity.updatedBy];
    locationEntity.locationSegment =
      await this.locationSegmentRepository.findOneById(
        locationEntity.locationSegmentId,
      );
    const response = plainToInstance(LocationResponseDto, locationEntity, {
      excludeExtraneousValues: true,
    });

    return response;
  }

  async createTree(request: CreateLocationTreeRequestDto): Promise<any> {
    const locationTree = this.locationRepository.createLocationTree(request);
    const [flatternTree, parentIds] =
      this.locationRepository.flatTree(locationTree);
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const locations = await queryRunner.manager.save(flatternTree);

      locations.map((location, index) => {
        const parentIndex = parentIds[index];
        if (parentIndex !== null) {
          const locationParent = locations[parentIndex];
          location.parentId = locationParent.id;
        }
      });

      locations
        .slice()
        .reverse()
        .forEach((location) => {
          location.mpath = this.genMPath(location, locations, [])
            .reverse()
            .join('.')
            .concat('.');
        });
      await queryRunner.manager.save(locations);
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  genMPath(
    currentLocation: LocationEntity,
    locations: LocationEntity[],
    locationPath: number[] = [],
  ) {
    if (!currentLocation) {
      return locationPath;
    }
    locationPath.push(currentLocation.id);
    const locationParent = locations.find(
      (location) => location.id === currentLocation.parentId,
    );
    return this.genMPath(locationParent, locations, locationPath);
  }

  saveTree = async (
    locationNode: LocationEntity,
    queryRunner: QueryRunner,
  ): Promise<LocationEntity> => {
    const parent = await queryRunner.manager.save(locationNode);

    const saveChild = locationNode.children.map(async (child) => {
      child.parent = clone(parent);
      child.parent.children = [];
      return this.saveTree(child, queryRunner);
    });
    parent.children = await Promise.all(saveChild);
    return parent;
  };
}
