import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { LocationEntity } from '@entities/location/location.entity';
import { CreateLocationRequestDto } from '../dto/request/create-location.request.dto';
import { CreateLocationTreeRequestDto } from '../dto/request/create-location-tree.request.dto';
import { UpdateLocationRequestDto } from '../dto/request/update-location.request.dto';
import { GetLocationListRequestDto } from '../dto/request/get-location-list.request.dto';

export interface LocationRepositoryInterface
  extends BaseInterfaceRepository<LocationEntity> {
  updateEntity(
    location: LocationEntity,
    request: UpdateLocationRequestDto,
  ): LocationEntity;
  findTrees(): any;
  createEntity(request: CreateLocationRequestDto): LocationEntity;
  createLocationTree(request: CreateLocationTreeRequestDto): LocationEntity;
  getList(request: GetLocationListRequestDto): Promise<any>;
  flatTree(tree: LocationEntity, flat?: any[]): [LocationEntity[], number[]];
}
