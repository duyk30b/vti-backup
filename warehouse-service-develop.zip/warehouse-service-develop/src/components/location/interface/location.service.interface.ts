import { CreateLocationRequestDto } from '../dto/request/create-location.request.dto';
import { CreateLocationTreeRequestDto } from '../dto/request/create-location-tree.request.dto';
import { UpdateLocationRequestDto } from '../dto/request/update-location.request.dto';
import { GetLocationDetailRequestDto } from '../dto/request/get-location.request.dto';
import { DeleteLocationRequestDto } from '../dto/request/delete-location.request.dto';
import { GetLocationListRequestDto } from '../dto/request/get-location-list.request.dto';

export interface LocationServiceInterface {
  createTree(request: CreateLocationTreeRequestDto): Promise<any>;
  create(request: CreateLocationRequestDto): Promise<any>;
  update(request: UpdateLocationRequestDto): Promise<any>;
  getDetail(request: GetLocationDetailRequestDto): Promise<any>;
  getList(request: GetLocationListRequestDto): Promise<any>;
  delete(request: DeleteLocationRequestDto): Promise<any>;
}
