import { LOCATOR_RULES } from '@components/locator/locator.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNumber, IsString, MaxLength } from 'class-validator';

export class CreateLocatorRequestDto extends BaseDto {
  @ApiProperty({ example: '', description: '' })
  @IsInt()
  locationId: number;

  @ApiProperty({ example: '', description: '' })
  @MaxLength(LOCATOR_RULES.DESCRIPTION.MAX_LENGTH)
  @IsString()
  description: string;

  @ApiProperty({ example: '', description: '' })
  @IsInt()
  itemId: number;

  @ApiProperty({ example: '', description: '' })
  @IsNumber()
  capacity: number;
}
