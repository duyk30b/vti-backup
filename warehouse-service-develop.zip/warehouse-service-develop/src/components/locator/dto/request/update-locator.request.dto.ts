import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';
import { CreateLocatorRequestDto } from './create-locator.request.dto';

export class UpdateLocatorBodyDto extends CreateLocatorRequestDto {}

export class UpdateLocatorRequestDto extends UpdateLocatorBodyDto {
  @ApiProperty({ example: '', description: '' })
  @Transform(({ value }) => Number(value))
  @IsInt()
  id: number;
}
