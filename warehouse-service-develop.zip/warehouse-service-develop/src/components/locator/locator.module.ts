import { LocatorEntity } from '@entities/locator/locator.entity';
import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LocatorController } from './locator.controller';
import { LocatorRepository } from '@repositories/locator.repository';
import { LocatorService } from './locator.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { ItemService } from '@components/item/item.service';
import { LocationRepository } from '@repositories/location.repository';
import { LocationEntity } from '@entities/location/location.entity';
import { ItemModule } from '@components/item/item.module';
import { LocationModule } from '@components/location/location.module';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([LocatorEntity, LocationEntity]),
    UserModule,
    ItemModule,
    LocationModule,
  ],
  exports: [],
  providers: [
    {
      provide: 'LocatorRepositoryInterface',
      useClass: LocatorRepository,
    },
    {
      provide: 'LocatorServiceInterface',
      useClass: LocatorService,
    },
    {
      provide: 'LocationRepositoryInterface',
      useClass: LocationRepository,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
  ],
  controllers: [LocatorController],
})
export class LocatorModule {}
