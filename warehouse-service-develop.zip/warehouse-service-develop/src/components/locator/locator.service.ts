import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { LocationRepositoryInterface } from '@components/location/interface/location.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { LocatorEntity } from '@entities/locator/locator.entity';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In, Not } from 'typeorm';
import { CreateLocatorRequestDto } from './dto/request/create-locator.request.dto';
import { DeleteLocatorRequestDto } from './dto/request/delete-locator.request.dto';
import { GetLocatorListRequestDto } from './dto/request/get-locator-list.request.dto';
import { GetLocatorDetailRequestDto } from './dto/request/get-locator.request.dto';
import { UpdateLocatorRequestDto } from './dto/request/update-locator.request.dto';
import { LocatorRepositoryInterface } from './interface/locator.repository.interface';
import { LocatorServiceInterface } from './interface/locator.service.interface';
import { uniq } from 'lodash';
import { plainToInstance } from 'class-transformer';
import { LocatorResponseDto } from './dto/response/locator.response.dto';
import { PagingResponse } from '@utils/paging.response';
import { isEmpty } from 'lodash';
import { LocatorItemEntity } from '@entities/locator/locator-item.entity';
import { REGEX } from './locator.constant';

@Injectable()
export class LocatorService implements LocatorServiceInterface {
  constructor(
    @InjectDataSource()
    private readonly connection: DataSource,
    @Inject('LocatorRepositoryInterface')
    private readonly locatorRepository: LocatorRepositoryInterface,
    @Inject('LocationRepositoryInterface')
    private readonly locationRepository: LocationRepositoryInterface,
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,
    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,
    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateLocatorRequestDto): Promise<any> {
    const location = await this.locationRepository.findOneById(
      request.locationId,
    );
    if (!location) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    const fullLocations = await this.locationRepository.findByCondition({
      id: In(location.mpath.match(REGEX.LOCATION_ID)),
    });
    fullLocations.sort((a, b) => {
      return a.id - b.id;
    });
    const locatorEntity = this.locatorRepository.createEntity(
      request,
      location,
      fullLocations.map((l) => l.code),
    );
    const locationIdPaths = location.mpath.match(REGEX.LOCATION_ID_PATH);
    locationIdPaths.reduce((curPath, prePath, ind, arr) => {
      curPath += prePath;
      arr[ind] = curPath;
      return curPath;
    });
    const isLocatorExist = await this.locatorRepository.findOneByCondition({
      locationIdPath: In(locationIdPaths),
    });
    if (isLocatorExist) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.LOCATOR_ALREADY_EXIST'));
    }
    return this.save(locatorEntity);
  }

  async update(request: UpdateLocatorRequestDto): Promise<any> {
    const existLocator = await this.locatorRepository.findOneWithRelations({
      relations: ['locatorItems'],
      where: {
        id: request.id,
      },
    });
    if (!isEmpty(existLocator.locatorItems)) {
      try {
        await this.connection
          .createQueryBuilder()
          .delete()
          .from(LocatorItemEntity)
          .where('locatorId = :id', { id: existLocator.id })
          .execute();
      } catch (error) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(
            await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
          );
      }
    }
    if (!isEmpty()) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    if (!existLocator) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    const newLocation = await this.locationRepository.findOneById(
      request.locationId,
    );
    if (!newLocation) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    const fullLocations = await this.locationRepository.findByCondition({
      id: In(newLocation.mpath.match(REGEX.LOCATION_ID)),
    });
    fullLocations.sort((a, b) => {
      return a.level - b.level;
    });
    const locationIdPaths = newLocation.mpath.match(REGEX.LOCATION_ID_PATH);
    locationIdPaths.reduce((curPath, prePath, ind, arr) => {
      curPath += prePath;
      arr[ind] = curPath;
      return curPath;
    });
    const isLocatorExist = await this.locatorRepository.findOneByCondition({
      locationIdPath: In(locationIdPaths),
      id: Not(request.id),
    });
    const locatorEntity = this.locatorRepository.updateEntity(
      request,
      existLocator,
      newLocation,
      fullLocations.map((l) => l.code),
    );
    if (isLocatorExist) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.LOCATOR_ALREADY_EXIST'));
    }
    return this.save(locatorEntity);
  }

  async getDetail(request: GetLocatorDetailRequestDto): Promise<any> {
    const locator = await this.locatorRepository.getDetail(request.id);
    console.log(locator);
    if (!locator) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    const response = await this.generateRespone(locator);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'));
  }

  async getList(request: GetLocatorListRequestDto): Promise<any> {
    const { page } = request;
    const [data, count] = await this.locatorRepository.getList(request);
    const creatorIds = uniq(data.map((item) => item.createdBy));
    const updaterIds = uniq(data.map((item) => item.updatedBy));
    const userIds = [...creatorIds, ...updaterIds];
    const users = await this.userService.getUserByIds(uniq(userIds), true);

    data.forEach((item) => {
      item.createdBy = users[item.createdBy];
      item.updatedBy = users[item.updatedBy];
    });

    const dataResponse = data.map((locator) => {
      return {
        ...locator,
        itemId:
          locator.locatorItems.length > 0
            ? locator.locatorItems[0].itemId
            : null,
        capacity:
          locator.locatorItems.length > 0
            ? locator.locatorItems[0].capacity
            : null,
      };
    });
    const dataReturn = plainToInstance(LocatorResponseDto, dataResponse, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async delete(request: DeleteLocatorRequestDto): Promise<any> {
    const locator = await this.locatorRepository.findOneById(request.id);
    if (!locator) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    try {
      locator.deletedAt = new Date();
      locator.deletedBy = request.userId;
      await this.locatorRepository.update(locator);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'));
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'));
    }
  }

  private async save(locatorEntity: LocatorEntity): Promise<any> {
    const existItem = await this.itemService.getItems(
      locatorEntity.locatorItems.map((item) => item.itemId),
    );
    if (existItem.length === 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }

    try {
      const result = await this.locatorRepository.create(locatorEntity);
      const response = await this.generateRespone(result);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(response)
        .withMessage(await this.i18n.translate('error.SUCCESS'));
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'));
    }
  }

  private async generateRespone(
    locatorEntity: LocatorEntity,
  ): Promise<LocatorResponseDto> {
    const userIds = [locatorEntity.createdBy, locatorEntity.updatedBy];
    const users = await this.userService.getUserByIds(uniq(userIds), true);
    locatorEntity.createdBy = users[locatorEntity.createdBy];
    locatorEntity.updatedBy = users[locatorEntity.updatedBy];

    const response = plainToInstance(
      LocatorResponseDto,
      {
        ...locatorEntity,
        itemId:
          locatorEntity.locatorItems.length > 0
            ? locatorEntity.locatorItems[0].itemId
            : null,
        capacity:
          locatorEntity.locatorItems.length > 0
            ? locatorEntity.locatorItems[0].capacity
            : null,
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return response;
  }
}
