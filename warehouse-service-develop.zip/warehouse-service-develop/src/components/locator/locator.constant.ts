export const LOCATOR_RULES = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
};
export const REGEX = {
  LOCATION_ID: /\d+/g,
  LOCATION_ID_PATH: /([\d]+.)/g,
};
