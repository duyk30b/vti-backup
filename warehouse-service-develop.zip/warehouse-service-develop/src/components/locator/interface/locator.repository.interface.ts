import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { LocatorEntity } from '@entities/locator/locator.entity';
import { CreateLocatorRequestDto } from '../dto/request/create-locator.request.dto';
import { UpdateLocatorRequestDto } from '../dto/request/update-locator.request.dto';
import { GetLocatorListRequestDto } from '../dto/request/get-locator-list.request.dto';
import { LocationEntity } from '@entities/location/location.entity';

export interface LocatorRepositoryInterface
  extends BaseInterfaceRepository<LocatorEntity> {
  updateEntity(
    request: UpdateLocatorRequestDto,
    locator: LocatorEntity,
    newLocation: LocationEntity,
    newCode: string[],
  ): LocatorEntity;
  createEntity(
    request: CreateLocatorRequestDto,
    location: LocationEntity,
    code: string[],
  ): LocatorEntity;
  getDetail(id: number): Promise<any>;
  getList(request: GetLocatorListRequestDto): Promise<any>;
}
