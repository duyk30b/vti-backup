import { CreateLocatorRequestDto } from '../dto/request/create-locator.request.dto';
import { UpdateLocatorRequestDto } from '../dto/request/update-locator.request.dto';
import { GetLocatorDetailRequestDto } from '../dto/request/get-locator.request.dto';
import { DeleteLocatorRequestDto } from '../dto/request/delete-locator.request.dto';
import { GetLocatorListRequestDto } from '../dto/request/get-locator-list.request.dto';

export interface LocatorServiceInterface {
  create(request: CreateLocatorRequestDto): Promise<any>;
  update(request: UpdateLocatorRequestDto): Promise<any>;
  getDetail(request: GetLocatorDetailRequestDto): Promise<any>;
  getList(request: GetLocatorListRequestDto): Promise<any>;
  delete(request: DeleteLocatorRequestDto): Promise<any>;
}
