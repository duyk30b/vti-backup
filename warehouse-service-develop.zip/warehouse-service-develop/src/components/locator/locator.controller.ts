import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import {
  CREATE_LOCATOR_PERMISSION,
  DELETE_LOCATOR_PERMISSION,
  DETAIL_LOCATOR_PERMISSION,
  LIST_LOCATOR_PERMISSION,
  UPDATE_LOCATOR_PERMISSION,
} from '@utils/permissions/locator';
import { isEmpty } from 'lodash';
import { CreateLocatorRequestDto } from './dto/request/create-locator.request.dto';
import { DeleteLocatorRequestDto } from './dto/request/delete-locator.request.dto';
import { GetLocatorListRequestDto } from './dto/request/get-locator-list.request.dto';
import { GetLocatorDetailRequestDto } from './dto/request/get-locator.request.dto';
import { UpdateLocatorBodyDto } from './dto/request/update-locator.request.dto';
import { LocatorServiceInterface } from './interface/locator.service.interface';

@Controller('locators')
export class LocatorController {
  constructor(
    @Inject('LocatorServiceInterface')
    private readonly locatorService: LocatorServiceInterface,
  ) {}

  @PermissionCode(CREATE_LOCATOR_PERMISSION.code)
  @Post('create')
  public async create(@Body() body: CreateLocatorRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.create(request);
  }

  @PermissionCode(UPDATE_LOCATOR_PERMISSION.code)
  @Put(':id')
  public async update(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() body: UpdateLocatorBodyDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.locatorService.update(request);
  }

  @PermissionCode(LIST_LOCATOR_PERMISSION.code)
  @Get('list')
  public async getList(@Query() query: GetLocatorListRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.getList(request);
  }

  @PermissionCode(DETAIL_LOCATOR_PERMISSION.code)
  @Get('/:id')
  public async get(@Param() param: GetLocatorDetailRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.getDetail(request);
  }

  @PermissionCode(DELETE_LOCATOR_PERMISSION.code)
  @Delete('/:id')
  public async delete(@Param() param: DeleteLocatorRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.delete(request);
  }
}
