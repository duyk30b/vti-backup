import { AbstractWarehouseSpaceDataResponseDto } from "@components/warehouse/dto/response/abstract-warehouse-space-data.response.dto";
import { UnitMeaseuresAbstractResponse } from "@components/warehouse/dto/response/unit-measures-abstract.response.dto";
import { ApiProperty } from "@nestjs/swagger";
import { Approve } from "@utils/approve.response.dto";
import { Expose, Type } from "class-transformer";

export class SectorResponseDto extends AbstractWarehouseSpaceDataResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  warehouseName: string;

  @ApiProperty()
  @Expose()
  warehouseId: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  @Type(() => Approve)
  approve: Approve;
}