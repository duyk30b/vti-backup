import { ApiProperty } from "@nestjs/swagger";
import { Expose, Type } from "class-transformer";
import { IsArray } from "class-validator";


class WarehouseShelfFloor {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  position: number;
}

class WarehouseShelf {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  position: number;

  @ApiProperty({ type: WarehouseShelfFloor })
  @Expose()
  @IsArray()
  @Type(() => WarehouseShelfFloor)
  warehouseShelfFloor: WarehouseShelfFloor[];
}

export class DesignWarehouseResponseDto  {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  position: number;

  @ApiProperty({ type: WarehouseShelf })
  @Expose()
  @IsArray()
  @Type(() => WarehouseShelf)
  warehouseShelf: WarehouseShelf[];
}