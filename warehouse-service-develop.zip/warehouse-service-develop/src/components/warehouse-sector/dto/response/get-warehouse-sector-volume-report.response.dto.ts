import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

class ShelftFloorReport {
  @Expose()
  @ApiProperty()
  id: number;

  @Expose()
  @ApiProperty()
  name: string;

  @Expose()
  @ApiProperty()
  code: string;

  @Expose()
  @ApiProperty()
  position: number;

  @Expose()
  @ApiProperty()
  fullmentPercent: number;
}

class ShelftReport {
  @Expose()
  @ApiProperty()
  id: number;

  @Expose()
  @ApiProperty()
  name: string;

  @Expose()
  @ApiProperty()
  position: number;

  @Expose()
  @ApiProperty({ type: ShelftFloorReport, isArray: true })
  floors: ShelftFloorReport[];
}

class WarehouseSector {
  @Expose()
  @ApiProperty()
  id: number;

  @Expose()
  @ApiProperty()
  name: string;

  @Expose()
  @ApiProperty()
  position: number;

  @Expose()
  @ApiProperty()
  fullmentPercent: number;

  @Expose()
  @ApiProperty({ type: ShelftReport, isArray: true })
  shelfs: ShelftReport[];
}

export class WarehouseSectorVolumeReportResponse {
  @Expose()
  @ApiProperty()
  id: number;

  @Expose()
  @ApiProperty()
  name: string;

  @Expose()
  @ApiProperty()
  fullmentPercent: number;

  @Expose()
  @ApiProperty({ type: WarehouseSector, isArray: true })
  sectors: WarehouseSector[];
}
