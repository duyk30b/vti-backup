import { UnitMeasuresRequest } from '@components/warehouse/dto/request/unit-measures.request.dto';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  ValidateNested,
} from 'class-validator';
class Design {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  x: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  y: number;
}

class WarehouseShelfFloor {
  @ApiProperty({ example: 1, description: 'Id WarehouseShelfFloor' })
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty({ example: 1, description: 'Position WarehouseShelfFloor' })
  @IsOptional()
  @IsInt()
  position: number;
}

class WarehouseShelf {
  @ApiProperty({ example: 1, description: 'Id WarehouseShelf' })
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty({ example: 1, description: 'Position WarehouseShelf' })
  @IsOptional()
  @IsInt()
  position: number;

  @ApiProperty({ type: Design })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => Design)
  design: Design;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Chiều rộng' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  width: UnitMeasuresRequest;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Chiều Cao' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  height: UnitMeasuresRequest;

  @ApiPropertyOptional({ type: WarehouseShelfFloor, isArray: true })
  @IsOptional()
  @IsArray()
  @ValidateNested()
  @Type(() => WarehouseShelfFloor)
  warehouseShelfFloor: WarehouseShelfFloor[];
}

class WarehouseDesign {
  @ApiProperty({ example: 1, description: 'Id Sectors' })
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty({ example: 1, description: 'Position Sectors' })
  @IsOptional()
  @IsInt()
  position: number;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Chiều rộng' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  width: UnitMeasuresRequest;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Chiều Cao' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  height: UnitMeasuresRequest;

  @ApiProperty({ type: Design })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => Design)
  design: Design;

  @ApiPropertyOptional({ type: WarehouseShelf, isArray: true })
  @IsOptional()
  @IsArray()
  @ValidateNested()
  @Type(() => WarehouseShelf)
  warehouseShelf: WarehouseShelf[];
}

export class UpdateDesignRequestDto extends BaseDto {
  @ApiPropertyOptional({ type: WarehouseDesign, isArray: true })
  @IsNotEmpty()
  @IsArray()
  @ValidateNested()
  @Type(() => WarehouseDesign)
  warehouse: WarehouseDesign[];
}
