import {
  DesignRequest,
  DistanceRequest,
  UnitMeasuresRequest,
} from '@components/warehouse/dto/request/unit-measures.request.dto';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
export class UpdateSectorBody extends BaseDto {}
export class UpdateSectorDto extends UpdateSectorBody {
  @ApiProperty({ example: 1, description: 'Mã id của Khu VỰC cần update' })
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty({ example: 'C0021', description: 'Mã Khu Vực' })
  @IsNotEmpty()
  @MaxLength(50)
  @IsString()
  code: string;

  @ApiProperty({ example: 'Khu vực A', description: 'Tên Khu Vực' })
  @IsNotEmpty()
  @MaxLength(255)
  @IsString()
  name: string;

  @ApiProperty({ example: 1, description: 'Mã của kho' })
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Chiều Dài' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  long: UnitMeasuresRequest;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Chiều rộng' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  width: UnitMeasuresRequest;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Chiều Cao' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  height: UnitMeasuresRequest;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Lề trước' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => DistanceRequest)
  frontMargin: DistanceRequest;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Lề sau' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => DistanceRequest)
  behindMargin: DistanceRequest;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Lề trái' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => DistanceRequest)
  leftMargin: DistanceRequest;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Lề phải' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => DistanceRequest)
  rightMargin: DistanceRequest;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'lề trên' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => DistanceRequest)
  topMargin: DistanceRequest;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Lề dười' })
  @IsOptional()
  @ValidateNested()
  @Type(() => DistanceRequest)
  bottomMargin: DistanceRequest;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;

  @ApiProperty({
    example: { x: 0, y: 0, rotate: 0 },
    description: '',
  })
  @IsOptional()
  @ValidateNested()
  @Type(() => DesignRequest)
  design: DesignRequest;
}
