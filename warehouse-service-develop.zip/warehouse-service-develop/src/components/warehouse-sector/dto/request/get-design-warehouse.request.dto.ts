import { Expose, Transform } from 'class-transformer';
import { IsNotEmpty, IsInt } from 'class-validator';
import { BaseDto } from '../../../../core/dto/base.dto';
export class GetDesignWarehouseDto extends BaseDto {
  @Expose()
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
