import { ApiProperty } from '@nestjs/swagger';
import {
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import {
  DesignRequest,
  DistanceRequest,
  UnitMeasuresRequest,
} from '@components/warehouse/dto/request/unit-measures.request.dto';
import { BaseDto } from '@core/dto/base.dto';

export class CreateSectorDto extends BaseDto {
  @ApiProperty({ example: 'Khu vực A', description: 'Tên Khu Vực' })
  @IsNotEmpty()
  @MaxLength(255)
  @IsString()
  name: string;

  @ApiProperty({ example: 'C0021', description: 'Mã Khu Vực' })
  @IsNotEmpty()
  @MaxLength(50)
  @IsString()
  code: string;

  @ApiProperty({ example: 1, description: 'Mã của kho' })
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Chiều Dài' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  long: UnitMeasuresRequest;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Chiều rộng' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  width: UnitMeasuresRequest;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'Chiều Cao' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  height: UnitMeasuresRequest;

  @ApiProperty({
    example: { x: 0, y: 0, rotate: 0 },
    description: '',
  })
  @IsOptional()
  @ValidateNested()
  @Type(() => DesignRequest)
  design: DesignRequest;
}
