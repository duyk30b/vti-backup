import { WarehouseStructureDesignRepositoryInterface } from '@components/warehouse/interface/warehouse-structure-design.repository.interface';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { WarehouseStatusEnum } from '@components/warehouse/warehouse.contant';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { WarehouseSectorEntity } from '@entities/warehouse-sector/warehouse-sector.entity';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { isEmpty } from 'class-validator';
import { isEmpty as isEmpty2 } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource } from 'typeorm';
import { CreateSectorDto } from './dto/request/create-sector.request.dto';
import { GetListSectorRequestDto } from './dto/request/get-list-sector.request.dto';
import { GetWarehouseSectorVolumeReportRequestDto } from './dto/request/get-warehouse-sector-volume-report.request.dto';
import { UpdateSectorDto } from './dto/request/update-sector-request.dto';
import { SectorResponseDto } from './dto/response/sector.response.dto';
import { WarehouseSectorVolumeReportResponse } from './dto/response/get-warehouse-sector-volume-report.response.dto';
import { WarehouseSectorRepositoryInterface } from './interface/warehouse-sector.repository.interface';
import { WarehouseSectorServiceInterface } from './interface/warehouse-sector.sevice.interface';
import {
  CAN_DELETE_SECTOR_STATUS,
  CAN_UPDATE_SECTOR_STATUS,
  SectorStatusEnum,
} from './warehouse-sector.constant';
import { DeleteSectorDto } from './dto/request/delete-sector.request.dto';
import { SetStatusRequestDto } from './dto/request/set-status-request.dto';
import { GetDesignWarehouseDto } from './dto/request/get-design-warehouse.request.dto';
import { DesignWarehouseResponseDto } from './dto/response/design-warehouse.response.dto';
import { Warehouse } from '@entities/warehouse/warehouse.entity';
import {
  calculateActualVolume,
  calculateArea,
  div,
  minus,
  mul,
  plus,
} from '@utils/common';
import { UpdateDesignRequestDto } from './dto/request/update-design-warehouse.request.dto';
import { WarehouseShelfEntity } from '@entities/warehouse-shelf/warehouse-shelf.entity';
import { WarehouseShelfFloorEntity } from '@entities/warehouse-shelf-floor/warehouse-shelf-floor.entity';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { WarehouseSectorImport } from './import/warehouse-sector.import.helper';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { WarehouseSectorResponseDto } from '@components/warehouse/dto/response/warehouse-sectors.response.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { In } from 'typeorm';
import { stringFormat } from '@utils/object.util';

@Injectable()
export class WarehouseSectorService implements WarehouseSectorServiceInterface {
  constructor(
    @Inject('WarehouseSectorRepositoryInterface')
    private readonly warehouseSectorRepository: WarehouseSectorRepositoryInterface,

    @Inject('WarehouseStructureDesignRepositoryInterface')
    private readonly warehouseStructureDesignRepository: WarehouseStructureDesignRepositoryInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('WarehouseSectorImport')
    private readonly warehouseSectorImport: WarehouseSectorImport,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  importSector(request: FileUploadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
    } as ImportRequestDto;
    return this.warehouseSectorImport.importUtil(importRequestDto);
  }

  public async getSectorVolumeReport(
    payload: GetWarehouseSectorVolumeReportRequestDto,
  ): Promise<any> {
    const warehouse = await this.warehouseRepository.findOneById(
      payload.warehouseId,
    );

    if (!warehouse) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const data = await this.warehouseSectorRepository.getSectorVolumeReport(
      payload,
    );
    const { width, height } = warehouse;
    warehouse['fullmentPercent'] = 100;
    let areaWarehouse = 0;
    if (!isEmpty(width) && !isEmpty(height)) {
      areaWarehouse = calculateArea(warehouse.width, warehouse.height);
      let areaSectors = 0;
      data.forEach((sector) => {
        areaSectors += calculateArea(sector.width, sector.height);
      });
      warehouse['fullmentPercent'] = this.calculateFullmentPercentArea(
        areaWarehouse,
        areaSectors,
      ).toFixed(2);
    }
    data?.map((sector) => {
      const areaSector = calculateArea(sector.width, sector.height);
      let areaShelf = 0;
      sector.shelfs.forEach((shelf) => {
        areaShelf += calculateArea(shelf.width, shelf.height);
      });
      sector.fullmentPercent = this.calculateFullmentPercentArea(
        areaSector,
        areaShelf,
      ).toFixed(2);
    });
    warehouse.sectors = data;

    const response = plainToInstance(
      WarehouseSectorVolumeReportResponse,
      warehouse,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private calculateFullmentPercentArea(
    container: number,
    item: number,
  ): number {
    if (item === 0) {
      return 100;
    }
    const fullmentPercent = mul(
      div(minus(container, item), container || 1),
      100,
    );
    return fullmentPercent < 0 ? 0 : fullmentPercent;
  }

  public async create(request: CreateSectorDto): Promise<ResponsePayload<any>> {
    const newSectorEntity = await this.warehouseSectorRepository.createEntity(
      request,
    );
    return await this.save(newSectorEntity, request);
  }

  public async update(request: UpdateSectorDto): Promise<ResponsePayload<any>> {
    const sector = await this.warehouseSectorRepository.findOneById(request.id);
    if (!sector) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (!CAN_UPDATE_SECTOR_STATUS.includes(sector.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE_IN_CONFIRM_SECTOR'),
      ).toResponse();
    }
    return await this.save(sector, request);
  }

  public async getList(
    request: GetListSectorRequestDto,
  ): Promise<ResponsePayload<any> | any> {
    const { data, total } = await this.warehouseSectorRepository.getList(
      request,
    );
    const dataReturn = plainToInstance(SectorResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async detail(id: number): Promise<ResponsePayload<any>> {
    const sector = await this.warehouseSectorRepository.detail(id);
    if (isEmpty(sector)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const response = plainToInstance(SectorResponseDto, sector, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async delete(request: DeleteSectorDto): Promise<ResponsePayload<any>> {
    const sector = await this.warehouseSectorRepository.findOneById(request.id);
    if (!sector) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    if (!CAN_DELETE_SECTOR_STATUS.includes(sector.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE_IN_CONFIRM_SECTOR'),
      ).toResponse();
    }

    try {
      await this.warehouseSectorRepository.remove(request.id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const warehouseSectors =
      await this.warehouseSectorRepository.findByCondition({
        id: In(ids),
      });

    const warehouseSectorIds = warehouseSectors.map(
      (warehouseSector) => warehouseSector.id,
    );
    if (warehouseSectors.length !== ids.length) {
      ids.forEach((id) => {
        if (!warehouseSectorIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < warehouseSectors.length; i++) {
      const warehouseSector = warehouseSectors[i];
      if (!CAN_DELETE_SECTOR_STATUS.includes(warehouseSector.status))
        failIdsList.push(warehouseSector.id);
    }

    const validIds = warehouseSectors
      .filter((warehouseSector) => !failIdsList.includes(warehouseSector.id))
      .map((warehouseSector) => warehouseSector.id);

    const queryRunner = await this.connection.createQueryRunner();
    try {
      if (!isEmpty(validIds)) {
        await queryRunner.startTransaction();
        await queryRunner.manager.delete(WarehouseSectorEntity, validIds);
        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    console.log(validIds.length, ids.length, failIdsList.length, failIdsList);
    await queryRunner.release();
    if (isEmpty2(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, userId } = request;
    const sector = await this.warehouseSectorRepository.findOneById(id);

    if (!sector) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_UPDATE_SECTOR_STATUS.includes(sector.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CAN_NOT_UPDATE_IN_CONFIRM_SECTOR'),
        )
        .build();
    }

    sector.approverId = userId;
    sector.approvedAt = new Date(Date.now());
    sector.status = SectorStatusEnum.CONFIRMED;
    const result = await this.warehouseSectorRepository.create(sector);
    const response = plainToInstance(SectorResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }
  public async reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, userId } = request;
    const sector = await this.warehouseSectorRepository.findOneById(id);

    if (!sector) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (SectorStatusEnum.CREATED !== sector.status) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CAN_NOT_UPDATE_IN_REJECT_SECTOR'),
        )
        .build();
    }

    sector.approverId = userId;
    sector.approvedAt = new Date(Date.now());
    sector.status = SectorStatusEnum.REJECT;
    const result = await this.warehouseSectorRepository.create(sector);
    const response = plainToInstance(SectorResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  private async save(
    sectorEntity: WarehouseSectorEntity,
    request: CreateSectorDto | UpdateSectorDto | any,
  ): Promise<any> {
    try {
      const { name, warehouseId, code } = request;
      const isUpdate = sectorEntity.id !== undefined;
      const warehouse = await this.warehouseRepository.findOneById(warehouseId);
      if (!warehouse) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'),
        ).toResponse();
      }

      if (WarehouseStatusEnum.InActive === warehouse.status) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.WAREHOUSE_IN_ACTIVE'),
        ).toResponse();
      }

      const sectorCode = await this.warehouseSectorRepository.findByCondition({
        code,
      });
      if (!isUpdate && sectorCode.length) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.CODE_EXIST'),
        ).toResponse();
      }

      if (
        isUpdate &&
        request.code !== sectorEntity.code &&
        sectorCode.length > 0
      ) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.CODE_EXIST'),
        ).toResponse();
      }

      const sectorName = await this.warehouseSectorRepository.findByCondition({
        name,
      });
      if (!isUpdate && sectorName.length) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.NAME_EXIST'),
        ).toResponse();
      }

      if (
        isUpdate &&
        request.name !== sectorEntity.name &&
        sectorName.length > 0
      ) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.NAME_EXIST'),
        ).toResponse();
      }

      if (!request.position) {
        request.position = await this.warehouseSectorRepository.getNextPosition(
          request.warehouseId,
        );
      }

      if (isUpdate) {
        sectorEntity = await this.warehouseSectorRepository.updateEntity(
          sectorEntity,
          request,
        );
      }
      const saveSector = await this.warehouseSectorRepository.update(
        sectorEntity,
      );

      return new ResponseBuilder(saveSector)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(err?.message || err)
        .build();
    }
  }

  async getListWarehouseDesign(request: GetDesignWarehouseDto): Promise<any> {
    const data = await this.warehouseSectorRepository.getListByWarehouse(
      request.id,
    );
    const response = plainToInstance(DesignWarehouseResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async validateSectorVolume(
    warehouse: Warehouse,
    warehouseSectorNew: WarehouseSectorEntity,
    warehouseSectorOld?: WarehouseSectorEntity,
  ): Promise<boolean> {
    const warehouseSector =
      await this.warehouseSectorRepository.findByCondition({
        warehouseId: warehouse.id,
      });

    const warehouseSectorNewVolume = calculateActualVolume(
      warehouseSectorNew.width,
      warehouseSectorNew.height,
      warehouseSectorNew.long,
      warehouseSectorNew.topMargin,
      warehouseSectorNew.bottomMargin,
      warehouseSectorNew.rightMargin,
      warehouseSectorNew.leftMargin,
      warehouseSectorNew.frontMargin,
      warehouseSectorNew.behindMargin,
    );

    let warehouseSectorOldVolume = 0;
    if (warehouseSectorOld) {
      warehouseSectorOldVolume = calculateActualVolume(
        warehouseSectorOld.width,
        warehouseSectorOld.height,
        warehouseSectorOld.long,
        warehouseSectorOld.topMargin,
        warehouseSectorOld.bottomMargin,
        warehouseSectorOld.rightMargin,
        warehouseSectorOld.leftMargin,
        warehouseSectorOld.frontMargin,
        warehouseSectorOld.behindMargin,
      );
    }

    let totalWarehouseSectorVolume = minus(
      warehouseSectorNewVolume,
      warehouseSectorOldVolume,
    );

    if (!isEmpty(warehouseSector)) {
      warehouseSector.forEach((record) => {
        totalWarehouseSectorVolume = plus(
          totalWarehouseSectorVolume,
          calculateActualVolume(
            record.width,
            record.height,
            record.long,
            record.topMargin,
            record.bottomMargin,
            record.rightMargin,
            record.leftMargin,
            record.frontMargin,
            record.behindMargin,
          ),
        );
      });
    }
    return Number(warehouse.volume.value) < totalWarehouseSectorVolume;
  }

  async updateWarehouseDesign(request: UpdateDesignRequestDto): Promise<any> {
    const { warehouse } = request;
    let response, message;
    let code = ResponseCodeEnum.SUCCESS;
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const sectors = [];
      const sectorShelfs = [];
      const sectorShelfFloors = [];
      warehouse.forEach((s) => {
        sectors.push({
          id: s.id,
          position: s.position,
          design: s.design,
          width: s.width,
          height: s.height,
        });
        if (s.warehouseShelf) {
          s.warehouseShelf.forEach((ws) => {
            sectorShelfs.push({
              id: ws.id,
              position: ws.position,
              design: s.design,
              width: s.width,
              height: s.height,
            });
            if (ws.warehouseShelfFloor) {
              ws.warehouseShelfFloor.forEach((wsf) => {
                sectorShelfFloors.push({
                  id: wsf.id,
                  position: wsf.position,
                });
              });
            }
          });
        }
      });
      if (!isEmpty(sectors)) {
        await queryRunner.manager.save(WarehouseSectorEntity, sectors);
      }
      if (!isEmpty(sectorShelfs)) {
        await queryRunner.manager.save(WarehouseShelfEntity, sectorShelfs);
      }
      if (!isEmpty(sectorShelfFloors)) {
        await queryRunner.manager.save(
          WarehouseShelfFloorEntity,
          sectorShelfFloors,
        );
      }

      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    } finally {
      await queryRunner.release();
      return new ResponseBuilder()
        .withCode(code)
        .withData(response)
        .withMessage(
          code === ResponseCodeEnum.SUCCESS
            ? await this.i18n.translate('error.SUCCESS')
            : message,
        )
        .build();
    }
  }
  async getWarehouseSectorsByNameKeyword(nameKeyword: string): Promise<any> {
    const warehouseSectors =
      await this.warehouseSectorRepository.findWarehouseSectorsByNameKeyword(
        nameKeyword,
      );
    const response = plainToInstance(
      WarehouseSectorResponseDto,
      warehouseSectors,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
}
