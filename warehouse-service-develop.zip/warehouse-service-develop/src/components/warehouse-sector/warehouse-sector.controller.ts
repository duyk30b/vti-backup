import { GetDesignWarehouseDto } from '@components/warehouse-sector/dto/request/get-design-warehouse.request.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { isEmpty } from 'lodash';
import { CreateSectorDto } from './dto/request/create-sector.request.dto';
import { DeleteSectorDto } from './dto/request/delete-sector.request.dto';
import { GetDetailSectorRequestDto } from './dto/request/get-detail-sector.request.dto';
import { GetListSectorRequestDto } from './dto/request/get-list-sector.request.dto';
import { GetWarehouseSectorVolumeReportRequestDto } from './dto/request/get-warehouse-sector-volume-report.request.dto';
import { SetStatusRequestDto } from './dto/request/set-status-request.dto';
import { UpdateSectorBody } from './dto/request/update-sector-request.dto';
import { WarehouseSectorServiceInterface } from './interface/warehouse-sector.sevice.interface';
import {
  CREATE_WAREHOUSE_SECTOR_PERMISSION,
  UPDATE_WAREHOUSE_SECTOR_PERMISSION,
  DELETE_WAREHOUSE_SECTOR_PERMISSION,
  DETAIL_WAREHOUSE_SECTOR_PERMISSION,
  LIST_WAREHOUSE_SECTOR_PERMISSION,
  IMPORT_WAREHOUSE_SECTOR_PERMISSION,
} from '@utils/permissions/warehouse-sector';
import {
  CREATE_WAREHOUSE_DESIGN_PERMISSION,
  LIST_WAREHOUSE_DESIGN_PERMISSION,
} from '@utils/permissions/warehouse-design';
import {
  CREATE_WAREHOUSE_SHELF_PERMISSION,
  UPDATE_WAREHOUSE_SHELF_PERMISSION,
} from '@utils/permissions/warehouse-shelf';
import {
  CREATE_WAREHOUSE_SHELF_FLOOR_PERMISSION,
  UPDATE_WAREHOUSE_SHELF_FLOOR_PERMISSION,
} from '@utils/permissions/warehouse-shelf-floor';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { DETAIL_WAREHOUSE_SPACE_PERMISSION } from '@utils/permissions/warehouse-space';
import { generatePermissionCodes } from '@utils/common';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { WarehouseSectorVolumeReportResponse } from './dto/response/get-warehouse-sector-volume-report.response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { NATS_WAREHOUSE } from '@config/nats.config';
const PERMISSION_LIST_WAREHOUSE_DESIGN = generatePermissionCodes([
  CREATE_WAREHOUSE_DESIGN_PERMISSION.code,
  CREATE_WAREHOUSE_SECTOR_PERMISSION.code,
  UPDATE_WAREHOUSE_SECTOR_PERMISSION.code,
  CREATE_WAREHOUSE_SHELF_PERMISSION.code,
  UPDATE_WAREHOUSE_SHELF_PERMISSION.code,
  CREATE_WAREHOUSE_SHELF_FLOOR_PERMISSION.code,
  UPDATE_WAREHOUSE_SHELF_FLOOR_PERMISSION.code,
  LIST_WAREHOUSE_DESIGN_PERMISSION.code,
]);

@Controller('sectors')
export class WarehouseSectorController {
  constructor(
    @Inject('WarehouseSectorServiceInterface')
    private readonly warehouseSectorService: WarehouseSectorServiceInterface,
  ) {}

  @PermissionCode(IMPORT_WAREHOUSE_SECTOR_PERMISSION.code)
  // @MessagePattern(`${NATS_WAREHOUSE}.import_warehouse_sector`)
  @Post('sectors/import')
  @ApiOperation({
    tags: ['Khu Vuc'],
    summary: 'Import khu vuc',
    description: 'Nhập một loạt khu vuc',
  })
  @ApiResponse({
    status: 200,
    description: 'Import successfully',
    type: ImportResponseDto,
  })
  public async importWarehouseSector(
    @Body() body: FileUploadRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseSectorService.importSector(request);
  }

  @PermissionCode(DETAIL_WAREHOUSE_SPACE_PERMISSION.code)
  // @MessagePattern(`${NATS_WAREHOUSE}.get_sector_volume_report`)
  @Get('/reports/:warehouseId/sectors/volumes')
  @ApiOperation({
    tags: ['Report', 'Warehouse', 'Sector', 'Volume'],
    summary: 'Get warehouse sector volume report',
    description: 'Báo cáo khoảng trống tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: WarehouseSectorVolumeReportResponse,
  })
  public async getSectorVolumeReport(
    @Param() param: GetWarehouseSectorVolumeReportRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseSectorService.getSectorVolumeReport(request);
  }

  @PermissionCode(CREATE_WAREHOUSE_SECTOR_PERMISSION.code)
  // @MessagePattern(`${NATS_WAREHOUSE}.create_sector`)
  @Post('/create')
  @ApiOperation({
    tags: ['Warehouse', 'Sectors'],
    summary: 'Create new Sector',
    description: 'Tạo mới khu vực',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async createSector(@Body() payload: CreateSectorDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseSectorService.create(request);
  }

  @PermissionCode(UPDATE_WAREHOUSE_SECTOR_PERMISSION.code)
  // @MessagePattern(`${NATS_WAREHOUSE}.update_sector`)
  @Put('/:id')
  @ApiOperation({
    tags: ['Warehouse', 'Sectors'],
    summary: 'Update Sector',
    description: 'Cập nhật khu vực',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  public async updateItem(
    @Param('id', new ParseIntPipe()) id,
    @Body() body: UpdateSectorBody,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = Number(id);
    return await this.warehouseSectorService.update(request);
  }

  @PermissionCode(LIST_WAREHOUSE_SECTOR_PERMISSION.code)
  // @MessagePattern(`${NATS_WAREHOUSE}.get_list_sector`)
  @Get('/list')
  @ApiOperation({
    tags: ['Warehouse', 'Sectors'],
    summary: 'List Sector',
    description: 'Danh sách Thông tin khu vực',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: null,
  })
  public async getList(@Query() query: GetListSectorRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseSectorService.getList(request);
  }

  @PermissionCode(DETAIL_WAREHOUSE_SECTOR_PERMISSION.code)
  // @MessagePattern(`${NATS_WAREHOUSE}.detail_sector`)
  @Get('/:id')
  @ApiOperation({
    tags: ['Warehouse', 'Sectors'],
    summary: 'Detail Sector',
    description: 'Thông tin khu vực',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async detail(@Param() param: GetDetailSectorRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseSectorService.detail(request.id);
  }

  @PermissionCode(DELETE_WAREHOUSE_SECTOR_PERMISSION.code)
  // @MessagePattern(`${NATS_WAREHOUSE}.delete_sector`)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Warehouse', 'Sectors'],
    summary: 'Delete Sector',
    description: 'Xóa Thông tin khu vực',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async delete(@Param() param: DeleteSectorDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseSectorService.delete(request);
  }

  @PermissionCode(DELETE_WAREHOUSE_SECTOR_PERMISSION.code)
  // @MessagePattern(`${NATS_WAREHOUSE}.delete_sector_multiple`)
  @Delete('sectors/multiple')
  @ApiOperation({
    tags: ['Warehouse', 'Sectors'],
    summary: 'Delete multiple Sector',
    description: 'Xóa nhiều Thông tin khu vực',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteMultiple(@Query() query: DeleteMultipleDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseSectorService.deleteMultiple(request);
  }

  // @MessagePattern(`${NATS_WAREHOUSE}.confirm_sector`)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Sector Confirm'],
    summary: 'Confirmed data ',
    description: 'Confirm data',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: null,
  })
  public async confirm(@Param() param: SetStatusRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseSectorService.confirm(request);
  }

  // @MessagePattern(`${NATS_WAREHOUSE}.reject_sector`)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Sector Confirm'],
    summary: 'Reject data ',
    description: 'Reject data',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: null,
  })
  public async reject(@Param() param: SetStatusRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseSectorService.reject(request);
  }

  @PermissionCode(PERMISSION_LIST_WAREHOUSE_DESIGN)
  // @MessagePattern(`${NATS_WAREHOUSE}.get_design_by_warehouse`)
  @Get('/:id/design')
  @ApiOperation({
    tags: ['warehouse'],
    description: 'Get Design By Warehouse',
  })
  public async getWarehouseDesign(
    @Param() param: GetDesignWarehouseDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseSectorService.getListWarehouseDesign(request);
  }

  @MessagePattern(`${NATS_WAREHOUSE}.get_warehouse_sector_by_name_keyword`)
  public async getItemByConditions(@Body() payload: any): Promise<any> {
    return await this.warehouseSectorService.getWarehouseSectorsByNameKeyword(
      payload.nameKeyword,
    );
  }

  //TODO remove when refactor done
  @MessagePattern(`${NATS_WAREHOUSE}.get_warehouse_sector_by_name_keyword`)
  public async getItemByConditionsTcp(@Body() payload: any): Promise<any> {
    return await this.warehouseSectorService.getWarehouseSectorsByNameKeyword(
      payload.nameKeyword,
    );
  }
}
