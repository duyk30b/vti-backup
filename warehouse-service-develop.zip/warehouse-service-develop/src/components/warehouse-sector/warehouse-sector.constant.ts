export enum SectorStatusEnum {
  CREATED,
  CONFIRMED,
  REJECT,
}
export const CAN_UPDATE_SECTOR_STATUS: number[] = [
  SectorStatusEnum.CREATED,
  SectorStatusEnum.REJECT,
];

export const CAN_CONFIRM_WAREHOUSE_SECTOR_STATUS: number[] = [
  SectorStatusEnum.CREATED,
  SectorStatusEnum.REJECT,
];

export const CAN_DELETE_SECTOR_STATUS: number[] = [
  SectorStatusEnum.CREATED,
  SectorStatusEnum.REJECT,
];
