import {
  DistanceRequest,
  UnitMeasuresRequest,
} from '@components/warehouse/dto/request/unit-measures.request.dto';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { UnitMeasuresEnum } from '@components/warehouse/warehouse.contant';
import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { WarehouseSectorEntity } from '@entities/warehouse-sector/warehouse-sector.entity';
import { Warehouse } from '@entities/warehouse/warehouse.entity';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectDataSource } from '@nestjs/typeorm';
import { calculateActualVolume, minus, plus } from '@utils/common';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty, keyBy } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { FIELD_TEMPLATE_WAREHOUSE_SECTOR_CONST } from '../const/field-template.const';
import { WarehouseSectorRepositoryInterface } from '../interface/warehouse-sector.repository.interface';
@Injectable()
export class WarehouseSectorImport extends ImportDataAbstract {
  constructor(
    @Inject('WarehouseSectorRepositoryInterface')
    private readonly warehouseSectorRepository: WarehouseSectorRepositoryInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,
    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    this.fieldsMap.groupSet(
      [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
      [
        FIELD_TEMPLATE_WAREHOUSE_SECTOR_CONST.CODE,
        FIELD_TEMPLATE_WAREHOUSE_SECTOR_CONST.NAME,
        FIELD_TEMPLATE_WAREHOUSE_SECTOR_CONST.WAREHOUSE_NAME,
        FIELD_TEMPLATE_WAREHOUSE_SECTOR_CONST.LONG,
        FIELD_TEMPLATE_WAREHOUSE_SECTOR_CONST.WIDTH,
        FIELD_TEMPLATE_WAREHOUSE_SECTOR_CONST.HEIGHT,
        FIELD_TEMPLATE_WAREHOUSE_SECTOR_CONST.DESCRIPTION,
        FIELD_TEMPLATE_WAREHOUSE_SECTOR_CONST.FRONT_MARGIN,
        FIELD_TEMPLATE_WAREHOUSE_SECTOR_CONST.BEHIND_MARGIN,
        FIELD_TEMPLATE_WAREHOUSE_SECTOR_CONST.LEFT_MARGIN,
        FIELD_TEMPLATE_WAREHOUSE_SECTOR_CONST.RIGHT_MARGIN,
        FIELD_TEMPLATE_WAREHOUSE_SECTOR_CONST.TOP_MARGIN,
        FIELD_TEMPLATE_WAREHOUSE_SECTOR_CONST.BOTTOM_MARGIN,
      ],
    );
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
  ): Promise<ImportResponseDto> {
    const findByCode = await this.warehouseSectorRepository.findWithRelations({
      where: {
        code: In(dataDto.map((i) => i.warehouseSectorCode)),
      },
    });
    const findByName = await this.warehouseSectorRepository.findWithRelations({
      where: {
        name: In(dataDto.map((i) => i.name)),
      },
    });

    findByCode.forEach((i) => Object.assign(i, { type: 'old' }));
    findByName.forEach((i) => Object.assign(i, { type: 'old' }));

    const findByCodeMap = keyBy(findByCode, 'code');
    const findByNameMap = keyBy(findByName, 'name');
    const entities = [];
    const valid = [];
    const {
      duplicateCodeOrNameMsg,
      codeNotExistMsg,
      successMsg,
      unsuccessMsg,
      addText,
      updateText,
      warehouseNotFound,
      totalSectorVolumeExceedsShelfVolume,
    } = await this.getMessage();
    for (let index = 0; index < dataDto.length; index++) {
      const data = dataDto[index];
      const {
        i,
        action,
        warehouseSectorCode,
        warehouseSectorName,
        warehouseName,
        long,
        width,
        height,
        description,
        frontMargin,
        behindMargin,
        leftMargin,
        rightMargin,
        topMargin,
        bottomMargin,
      } = data;
      const logRow = {
        id: i,
        row: i,
        action,
      } as ImportResultDto;
      const msgLogs = [];

      const dataWarehouse = await this.warehouseRepository.findOneByCondition({
        name: warehouseName,
      });

      if (!dataWarehouse) {
        msgLogs.push(warehouseNotFound);
        logRow.log = msgLogs;
        logs.push(logRow);
        continue;
      }

      const longValue = new UnitMeasuresRequest();
      longValue.value = long;
      longValue.unit =
        +UnitMeasuresEnum[dataWarehouse?.long.unit] || UnitMeasuresEnum.CM;

      const widthValue = new UnitMeasuresRequest();
      widthValue.value = width;
      widthValue.unit =
        +UnitMeasuresEnum[dataWarehouse?.width.unit] || UnitMeasuresEnum.CM;

      const heightValue = new UnitMeasuresRequest();
      heightValue.value = height;
      heightValue.unit =
        +UnitMeasuresEnum[dataWarehouse?.height.unit] || UnitMeasuresEnum.CM;

      const frontMarginValue = new DistanceRequest();
      frontMarginValue.value = frontMargin || 0;
      frontMarginValue.unit =
        +UnitMeasuresEnum[dataWarehouse?.long.unit] || UnitMeasuresEnum.CM;

      const behindMarginValue = new DistanceRequest();
      behindMarginValue.value = behindMargin || 0;
      behindMarginValue.unit =
        +UnitMeasuresEnum[dataWarehouse?.long.unit] || UnitMeasuresEnum.CM;

      const leftMarginValue = new DistanceRequest();
      leftMarginValue.value = leftMargin || 0;
      leftMarginValue.unit =
        +UnitMeasuresEnum[dataWarehouse?.long.unit] || UnitMeasuresEnum.CM;

      const rightMarginValue = new DistanceRequest();
      rightMarginValue.value = rightMargin || 0;
      rightMarginValue.unit =
        +UnitMeasuresEnum[dataWarehouse?.long.unit] || UnitMeasuresEnum.CM;

      const topMarginValue = new DistanceRequest();
      topMarginValue.value = topMargin || 0;
      topMarginValue.unit =
        +UnitMeasuresEnum[dataWarehouse?.long.unit] || UnitMeasuresEnum.CM;

      const bottomMarginValue = new DistanceRequest();
      bottomMarginValue.value = bottomMargin || 0;
      bottomMarginValue.unit =
        +UnitMeasuresEnum[dataWarehouse?.long.unit] || UnitMeasuresEnum.CM;

      const entitySector = new WarehouseSectorEntity();
      entitySector.code = warehouseSectorCode?.trim();
      entitySector.name = warehouseSectorName?.trim();
      entitySector.warehouseId = dataWarehouse?.id;
      entitySector.long = longValue;
      entitySector.width = widthValue;
      entitySector.height = heightValue;
      entitySector.frontMargin = frontMarginValue;
      entitySector.behindMargin = behindMarginValue;
      entitySector.leftMargin = leftMarginValue;
      entitySector.rightMargin = rightMarginValue;
      entitySector.topMargin = topMarginValue;
      entitySector.bottomMargin = bottomMarginValue;
      entitySector.description = description?.trim() || '';

      if (action.toLowerCase() === addText) {
        if (
          findByCodeMap[warehouseSectorCode] ||
          findByNameMap[warehouseSectorName]
        ) {
          msgLogs.push(duplicateCodeOrNameMsg);
        } else {
          const entity =
            this.warehouseSectorRepository.createEntity(entitySector);
          const isValidSectorVolume = await this.validateSectorVolume(
            dataWarehouse,
            entity,
          );
          if (isValidSectorVolume) {
            msgLogs.push(totalSectorVolumeExceedsShelfVolume);
            logRow.log = msgLogs;
            logs.push(logRow);
            continue;
          }
          entities.push(entity);
          Object.assign(entity, { type: 'new' });
          findByCodeMap[warehouseSectorCode] = entity;
          findByNameMap[warehouseSectorName] = entity;
        }
      } else if (action.toLowerCase() === updateText) {
        if (
          findByCodeMap[warehouseSectorCode] &&
          findByCodeMap[warehouseSectorCode]?.['type'] === 'old'
        ) {
          if (
            findByNameMap[warehouseSectorName] &&
            findByNameMap[warehouseSectorName].id !=
              findByCodeMap[warehouseSectorCode].id
          ) {
            msgLogs.push(duplicateCodeOrNameMsg);
          } else {
            const entity = this.warehouseSectorRepository.updateEntity(
              findByCodeMap[warehouseSectorCode],
              entitySector,
            );
            entity.id = findByCodeMap[warehouseSectorCode].id;
            const warehouseSector =
              await this.warehouseSectorRepository.findOneById(
                findByCodeMap[warehouseSectorCode].id,
              );
            const isValidSectorVolume = await this.validateSectorVolume(
              dataWarehouse,
              entity,
              warehouseSector,
            );
            if (isValidSectorVolume) {
              msgLogs.push(totalSectorVolumeExceedsShelfVolume);
              logRow.log = msgLogs;
              logs.push(logRow);
              continue;
            }
            entities.push(entity);
            Object.assign(entity, { type: 'new' });
            findByCodeMap[warehouseSectorCode] = entity;
            findByNameMap[warehouseSectorName] = entity;
          }
        } else {
          msgLogs.push(codeNotExistMsg);
        }
      }
      if (isEmpty(msgLogs)) {
        logRow.log = [successMsg];
        valid.push(logRow);
      } else {
        logRow.log = msgLogs;
        logs.push(logRow);
      }
    }
    const response = new ImportResponseDto();
    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(entities);
        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        await queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((l) => (l.log = [unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }
    response.result = logs;
    response.totalCount = logs.length;
    response.result;
    return response;
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto | any>> {
    return super.importUtil(
      request,
      FIELD_TEMPLATE_WAREHOUSE_SECTOR_CONST.REQUIRED_COL_NUM,
    );
  }

  private async validateSectorVolume(
    warehouse: Warehouse,
    warehouseSectorNew: WarehouseSectorEntity,
    warehouseSectorOld?: WarehouseSectorEntity,
  ): Promise<boolean> {
    const warehouseSector =
      await this.warehouseSectorRepository.findByCondition({
        warehouseId: warehouse.id,
      });

    const warehouseSectorNewVolume = calculateActualVolume(
      warehouseSectorNew.width,
      warehouseSectorNew.height,
      warehouseSectorNew.long,
      warehouseSectorNew.topMargin,
      warehouseSectorNew.bottomMargin,
      warehouseSectorNew.rightMargin,
      warehouseSectorNew.leftMargin,
      warehouseSectorNew.frontMargin,
      warehouseSectorNew.behindMargin,
    );

    let warehouseSectorOldVolume = 0;
    if (warehouseSectorOld) {
      warehouseSectorOldVolume = calculateActualVolume(
        warehouseSectorOld.width,
        warehouseSectorOld.height,
        warehouseSectorOld.long,
        warehouseSectorOld.topMargin,
        warehouseSectorOld.bottomMargin,
        warehouseSectorOld.rightMargin,
        warehouseSectorOld.leftMargin,
        warehouseSectorOld.frontMargin,
        warehouseSectorOld.behindMargin,
      );
    }

    let totalWarehouseSectorVolume = minus(
      warehouseSectorNewVolume,
      warehouseSectorOldVolume,
    );

    if (!isEmpty(warehouseSector)) {
      warehouseSector.forEach((record) => {
        totalWarehouseSectorVolume = plus(
          totalWarehouseSectorVolume,
          calculateActualVolume(
            record.width,
            record.height,
            record.long,
            record.topMargin,
            record.bottomMargin,
            record.rightMargin,
            record.leftMargin,
            record.frontMargin,
            record.behindMargin,
          ),
        );
      });
    }
    return Number(warehouse.volume.value) < totalWarehouseSectorVolume;
  }
}
