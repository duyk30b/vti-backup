import { WarehouseSectorEntity } from '@entities/warehouse-sector/warehouse-sector.entity';
import { WarehouseStructureDesignEntity } from '@entities/warehouse/warehouse-structure-design.entity';
import { Warehouse } from '@entities/warehouse/warehouse.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WarehouseSectorRepository } from '@repositories/warehouse-sector.repository';
import { WarehouseStructureDesignRepository } from '@repositories/warehouse-structure-design.repository';
import { WarehouseRepository } from '@repositories/warehouse.repository';
import { WarehouseSectorImport } from './import/warehouse-sector.import.helper';
import { WarehouseSectorController } from './warehouse-sector.controller';
import { WarehouseSectorService } from './warehouse-sector.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      WarehouseSectorEntity,
      WarehouseStructureDesignEntity,
      Warehouse,
    ]),
  ],
  providers: [
    {
      provide: 'WarehouseStructureDesignRepositoryInterface',
      useClass: WarehouseStructureDesignRepository,
    },
    {
      provide: 'WarehouseSectorServiceInterface',
      useClass: WarehouseSectorService,
    },
    {
      provide: 'WarehouseSectorRepositoryInterface',
      useClass: WarehouseSectorRepository,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'WarehouseSectorImport',
      useClass: WarehouseSectorImport,
    },
  ],
  exports: [
    {
      provide: 'WarehouseSectorRepositoryInterface',
      useClass: WarehouseSectorRepository,
    },
    {
      provide: 'WarehouseSectorServiceInterface',
      useClass: WarehouseSectorService,
    },
    {
      provide: 'WarehouseStructureDesignRepositoryInterface',
      useClass: WarehouseStructureDesignRepository,
    },
    {
      provide: 'WarehouseSectorImport',
      useClass: WarehouseSectorImport,
    },
  ],
  controllers: [WarehouseSectorController],
})
export class WarehouseSectorModule {}
