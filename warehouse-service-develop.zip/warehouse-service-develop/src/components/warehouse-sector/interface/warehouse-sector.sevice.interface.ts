import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateSectorDto } from '../dto/request/create-sector.request.dto';
import { DeleteSectorDto } from '../dto/request/delete-sector.request.dto';
import { GetDesignWarehouseDto } from '../dto/request/get-design-warehouse.request.dto';
import { GetDetailSectorRequestDto } from '../dto/request/get-detail-sector.request.dto';
import { GetListSectorRequestDto } from '../dto/request/get-list-sector.request.dto';
import { GetWarehouseSectorVolumeReportRequestDto } from '../dto/request/get-warehouse-sector-volume-report.request.dto';
import { SetStatusRequestDto } from '../dto/request/set-status-request.dto';
import { UpdateDesignRequestDto } from '../dto/request/update-design-warehouse.request.dto';
import { UpdateSectorDto } from '../dto/request/update-sector-request.dto';

export interface WarehouseSectorServiceInterface {
  importSector(request : FileUploadRequestDto): Promise<any>;
  getSectorVolumeReport(
    payload: GetWarehouseSectorVolumeReportRequestDto,
  ): Promise<any>;
  create(payload: CreateSectorDto): Promise<ResponsePayload<any>>;
  update(payload: UpdateSectorDto): Promise<ResponsePayload<any>>;
  detail(id: number): Promise<ResponsePayload<any>>;
  delete(id: DeleteSectorDto): Promise<ResponsePayload<any>>;
  deleteMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  confirm(request: SetStatusRequestDto): Promise<ResponsePayload<any>>;
  reject(request: SetStatusRequestDto): Promise<ResponsePayload<any>>;
  getList(payload: GetListSectorRequestDto): Promise<ResponsePayload<any>>;
  getListWarehouseDesign(request: GetDesignWarehouseDto): Promise<any>;
  updateWarehouseDesign(request: UpdateDesignRequestDto): Promise<any>;
  getWarehouseSectorsByNameKeyword(nameKeyword: string): Promise<any>;
}
