import { ReportGapsInStockQuery } from '@components/warehouse-report/dto/query/report-gaps-in-stock.query';
import { WarehouseSectorDesignRequestDto } from '@components/warehouse/dto/request/update-warehouse-design.request.dto';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WarehouseSectorEntity } from '@entities/warehouse-sector/warehouse-sector.entity';
import { WarehouseShelfEntity } from '@entities/warehouse-shelf/warehouse-shelf.entity';
import { GetListSectorRequestDto } from '../dto/request/get-list-sector.request.dto';
import { GetWarehouseSectorVolumeReportRequestDto } from '../dto/request/get-warehouse-sector-volume-report.request.dto';

export interface WarehouseSectorRepositoryInterface
  extends BaseInterfaceRepository<WarehouseSectorEntity> {
  getSectorVolumeReport(
    payload: GetWarehouseSectorVolumeReportRequestDto,
  ): Promise<any>;
  createEntity(body: any): WarehouseSectorEntity;
  createEntityDesign(
    warehouseId: number,
    code: string,
    request: WarehouseSectorDesignRequestDto,
    shelfEntites: WarehouseShelfEntity[],
  ): WarehouseSectorEntity;
  updateEntity(
    entity: WarehouseSectorEntity,
    request: any,
  ): WarehouseSectorEntity;
  updateEntityDesign(
    entity: WarehouseSectorEntity,
    request: any,
    shelfEntites: WarehouseShelfEntity[],
  ): WarehouseSectorEntity;
  getList(request: GetListSectorRequestDto): Promise<any>;
  detail(request: number): Promise<any>;
  getListByWarehouse(id: number): Promise<any>;
  getNextPosition(id: number): Promise<any>;
  getGapsInStock(request: ReportGapsInStockQuery): Promise<any[]>;
  findWarehouseSectorsByNameKeyword(nameKeyword: string): Promise<any>;
}
