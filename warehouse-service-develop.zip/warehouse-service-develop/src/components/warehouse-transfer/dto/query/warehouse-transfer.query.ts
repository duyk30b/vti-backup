import { WarehouseTransferStatusEnum } from '@components/warehouse/warehouse.constant';
import { ApiPropertyOptional } from "@nestjs/swagger";
import { PaginationQuery } from '@utils/pagination.query';
import { Transform } from 'class-transformer';
import { IsDateString, IsEnum, IsOptional, IsString } from 'class-validator';

export class GetWarehouseTransferListQuery extends PaginationQuery {
  @IsOptional()
  type: number;

  @IsOptional()
  @IsEnum(WarehouseTransferStatusEnum, { each: true })
  @Transform((data) => {
    return data.value
      .split(',')
      .map((e) => Number(e))
      .filter((e) => Number.isInteger(e));
  })
  status: [WarehouseTransferStatusEnum];

  @IsOptional()
  @IsDateString()
  startDate: Date;

  @IsOptional()
  @IsDateString()
  endDate: Date;

  @ApiPropertyOptional({ example: '0', description: '' })
  @IsOptional()
  @IsString()
  isGetAll: string;
}
