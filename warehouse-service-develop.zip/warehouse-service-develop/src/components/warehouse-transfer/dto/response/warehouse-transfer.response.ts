import { BussinessTypeResponseDto } from '@components/bussiness-types/dto/response/bussiness-type.response.dto';
import { ReasonResponseDto } from '@components/sale/dto/response/reason.response.dto';
import { SourceResponseDto } from '@components/sale/dto/response/source.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class User {
  @Expose()
  id: number;

  @Expose()
  username: string;

  @Expose()
  fullName: string;
}

class Factory {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;
}

class Warehouse {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  @Type(() => Factory)
  factory: Factory;

  @ApiProperty()
  @Expose()
  manageByLot: number;
}

class DataResponse {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;
}

class Item {
  @Expose()
  id: number;

  @Expose()
  planQuantity: number;

  @Expose()
  actualQuantity: number;
}

export class WarehouseTransferResponse {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  ebsId: string;

  @Expose()
  status: string;

  @Expose()
  syncStatus: string;

  @Expose()
  syncCode: string;

  @Expose()
  type: number;

  @Expose()
  createdByUserId: number;

  @Expose()
  quantity: number;

  @Expose()
  receiptDate: Date;

  @Expose()
  @Type(() => Warehouse)
  sourceWarehouse: Warehouse;

  @Expose()
  @Type(() => Warehouse)
  destinationWarehouse: Warehouse;

  @Expose()
  @Type(() => Item)
  @IsArray()
  items: Item[];

  @Expose()
  createdAt: Date;

  @Expose()
  updatedAt: Date;

  @Expose()
  approvedAt: Date;

  @Expose()
  @Type(() => User)
  createdByUser: User;

  @Expose()
  @Type(() => User)
  approver: User;

  @Expose()
  isSameWarehouse: number;

  @Expose()
  warehouseTransferReceiveId: number;

  @Expose()
  sourceId: number;

  @Expose()
  reasonId: number;

  @Expose()
  bussinessTypeId: number;

  @Expose()
  @Type(() => DataResponse)
  bussinessType: DataResponse;

  @Expose()
  @Type(() => DataResponse)
  source: DataResponse;

  @Expose()
  @Type(() => DataResponse)
  reason: DataResponse;

  @Expose()
  receiver: string;

  @Expose()
  explanation: string;

  @Expose()
  @Type(() => User)
  updatedBy: User;
}
