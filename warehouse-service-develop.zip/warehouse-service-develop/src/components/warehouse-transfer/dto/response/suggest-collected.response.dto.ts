import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class ItemLotOrderExport {
  @ApiProperty()
  @Expose()
  locationId: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  collectedQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  stockQuantity: number;
}

class LocationOrderExport {
  @ApiProperty()
  @Expose()
  locationName: string;

  @ApiProperty()
  @Expose()
  locationCode: string;

  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty({ type: ItemLotOrderExport, isArray: true })
  @Expose()
  @Type(() => ItemLotOrderExport)
  lots: ItemLotOrderExport[];
}

class ItemsCollectedExport {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  stockQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  collectedQuantity: number;

  @ApiProperty()
  @Expose()
  exportedQuantity: number;

  @ApiProperty({ type: LocationOrderExport, isArray: true })
  @Expose()
  @Type(() => LocationOrderExport)
  locations: LocationOrderExport[];
}
class TransferWarehouse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}
export class SuggestCollectExportOrderResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty({ description: 'O: chuển kho 1 bước | 1: chuyển kho 2 bước' })
  @Expose()
  type: number;

  @ApiProperty({ description: 'Ngày dự kiến chuyển' })
  @Expose()
  transferOn: string;

  @ApiProperty({ description: 'Ngày tạo' })
  @Expose()
  createdOn: string;

  @ApiProperty({ description: 'Ngày  xác nhận' })
  @Expose()
  approvedAt: string;

  @ApiProperty({ description: 'Mô tả' })
  @Expose()
  description: string;

  @ApiProperty({ type: TransferWarehouse })
  @Expose()
  @Type(() => TransferWarehouse)
  sourceWarehouse: TransferWarehouse;

  @ApiProperty()
  @Expose()
  @Type(() => TransferWarehouse)
  destinationWarehouse: TransferWarehouse;

  @ApiProperty({ type: ItemsCollectedExport, isArray: true })
  @Expose()
  @Type(() => ItemsCollectedExport)
  items: ItemsCollectedExport[];
}
