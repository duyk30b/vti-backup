import { MovementResponseDto } from '@components/warehouse/dto/response/movement.response.dto';
import { Expose, Type } from 'class-transformer';

class TransferResponse {
  @Expose()
  id: number;

  @Expose()
  sourceWarehouseName: string;

  @Expose()
  type: number;

  @Expose()
  status: number;

  @Expose()
  destinationWarehouseName: string;

  @Expose()
  transferOn: Date;

  @Expose()
  code: string;
}

export class WarehouseTransferTransactionResponseDto extends MovementResponseDto {
  @Expose()
  @Type(() => TransferResponse)
  transfer: TransferResponse;
}
