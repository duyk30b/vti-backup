import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { ItemGroup, ItemType, ItemUnit, PackageResponse } from './warehouse-transfer-detail.response';

class Door {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  warehouseName: string;
}

class Warehouse {
  @ApiProperty()
  @Expose()
  id: 0;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class Lot {
  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;
}

class WarehouseTransferItem {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty({ type: ItemType })
  @Expose()
  @Type(() => ItemType)
  itemType: ItemType;
  
  @ApiProperty({ type: ItemGroup })
  @Expose()
  @Type(() => ItemGroup)
  itemGroup: ItemGroup;

  @ApiProperty({ type: ItemUnit })
  @Expose()
  @Type(() => ItemUnit)
  itemUnit: ItemUnit;

  @ApiProperty({ type: Lot })
  @Expose()
  @Type(() => Lot)
  lots: Lot[]

  @ApiProperty({ type: PackageResponse })
  @Expose()
  @Type(() => PackageResponse)
  package: PackageResponse;
}

class WarehouseTransferDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  warehouseTransferId: number;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  exportedQuantity: number;
}

class WarehouseTransfer {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  transferOn: string;

  @ApiProperty()
  @Expose()
  createdOn: string;

  @ApiProperty()
  @Expose()
  approvedAt: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty({ type: Warehouse })
  @Expose()
  @Type(() => Warehouse)
  sourceWarehouse: Warehouse;

  @ApiProperty({ type: Warehouse })
  @Expose()
  @Type(() => Warehouse)
  destinationWarehouse: Warehouse;

  @ApiProperty({ type: WarehouseTransferItem })
  @Expose()
  @Type(() => WarehouseTransferItem)
  items: WarehouseTransferItem[];

  @ApiProperty({ type: WarehouseTransferDetail })
  @Expose()
  @Type(() => WarehouseTransferDetail)
  warehouseTransferDetails: WarehouseTransferDetail[]
}

class WarehouseTransferReceiveDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  itemCode: string;

  @ApiProperty()
  @Expose()
  itemName: string;

  @ApiProperty()
  @Expose()
  itemUnit: string;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  collectedQuantity: number;

  @ApiProperty()
  @Expose()
  exportedQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  receivedQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => Lot)
  lots: Lot[]
}

export class GetWarehouseTransferReceiveDetailResponseDto {
  @ApiProperty()
  @Expose()
  id: number

  @ApiProperty({ type: Door })
  @Expose()
  @Type(() => Door)
  door: Door;

  @ApiProperty()
  @Expose()
  referenceDoc: string;
  
  @ApiProperty()
  @Expose()
  postedAt: string;

  @ApiProperty()
  @Expose()
  doorId: number;

  @ApiProperty()
  @Expose()
  note: string;

  @ApiProperty({ type: WarehouseTransfer })
  @Expose()
  @Type(() => WarehouseTransfer)
  warehouseTransfer: WarehouseTransfer;

  @ApiProperty()
  @Expose()
  createdAt: string

  @ApiProperty({ type: WarehouseTransferReceiveDetail })
  @Expose()
  @Type(() => WarehouseTransferReceiveDetail)
  items: WarehouseTransferReceiveDetail[]
}
