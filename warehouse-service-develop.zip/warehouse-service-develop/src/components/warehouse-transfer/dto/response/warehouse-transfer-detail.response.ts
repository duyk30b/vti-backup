import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { WarehouseTransferResponse } from './warehouse-transfer.response';

export class ItemType {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class Locator {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  locatorId: string;
}

export class ItemUnit {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

export class ItemGroup {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class Factory {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;
}

class LotNumber {
  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;
}

class ItemStockLocation {
  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => Locator)
  locator: Locator;

  @ApiProperty()
  @Expose()
  @IsArray()
  @Type(() => LotNumber)
  lots: LotNumber[];
}
class StorageDateResponse {
  @ApiProperty()
  @Expose()
  storageDate: Date;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  locatorId: number;
}

class Item {
  @Expose({ name: 'itemId' })
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  planQuantity: number;

  @Expose()
  actualQuantity: number;

  @Expose()
  exportedQuantity: number;

  @Expose()
  exportableQuantity: number;

  @Expose()
  quantity: number;

  @ApiProperty({ type: ItemType })
  @Expose()
  // @Type(() => ItemType)
  itemType: ItemType;

  @ApiProperty()
  @Expose()
  @Type(() => ItemGroup)
  itemGroup: ItemGroup;

  @ApiProperty({ type: ItemUnit })
  @Expose()
  @Type(() => ItemUnit)
  itemUnit: ItemUnit;

  @ApiProperty({ type: LotNumber, isArray: true })
  @Expose()
  @Type(() => LotNumber)
  lots: LotNumber[];

  @ApiProperty()
  @Expose()
  @IsArray()
  @Type(() => ItemStockLocation)
  locations: any;

  @ApiProperty()
  @Expose()
  @IsArray()
  @Type(() => StorageDateResponse)
  storageDates: StorageDateResponse;
}
class ItemWarehouseSource {
  @Expose()
  warehouseId: number;

  @ApiProperty({})
  @Expose()
  accounting: string;
}
class ItemResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty({ example: 1 })
  @Expose()
  @Transform(() => 10)
  planQuantity: number;

  @Expose()
  code: string;

  @ApiProperty({ type: ItemType })
  @Expose()
  @Type(() => ItemType)
  itemType: ItemType;

  @ApiProperty()
  @Expose()
  @Type(() => ItemGroup)
  itemGroup: ItemGroup;

  @ApiProperty({ type: ItemUnit })
  @Expose()
  @Type(() => ItemUnit)
  itemUnit: ItemUnit;

  @Expose()
  @Type(() => ItemWarehouseSource)
  itemWarehouseSources: ItemWarehouseSource[];
}

export class PackageResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

export class WarehouseTransferDetailResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  warehouseTransferId: number;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  exportableQuantity: number;

  @ApiProperty()
  @Expose()
  debitAccount: string;

  @ApiProperty()
  @Expose()
  creditAccount: string;

  @ApiProperty()
  @Expose()
  storageDate: Date;

  @ApiProperty()
  @Expose()
  isExistInDestinationWarehouse: number;

  @ApiProperty()
  @Expose()
  exportedQuantity: number;

  @ApiProperty({
    type: () => ItemResponse,
    isArray: true,
  })
  @Expose()
  @IsArray()
  @Type(() => ItemResponse)
  item: ItemResponse[];
}

export class WarehouseTransferDetailLotResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  locatorId: number;

  @ApiProperty()
  @Expose()
  @Type(() => Locator)
  locator: Locator;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  warehouseTransferId: number;

  @ApiProperty()
  @Expose()
  warehouseTransferDetailId: number;

  @ApiProperty()
  @Expose()
  debitAccount: string;

  @ApiProperty()
  @Expose()
  creditAccount: string;

  @ApiProperty({ example: '', description: 'Ngày nhập kho' })
  @Expose()
  storageDate: Date;

  @ApiProperty()
  @Expose()
  isExistInDestinationWarehouse: number;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @Expose()
  exportedQuantity: number;

  @ApiProperty()
  @Expose()
  exportableQuantity: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  mfg: string;

  @ApiProperty()
  @Expose()
  packageId: number;

  @ApiProperty()
  @Expose()
  amount: number;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty({ type: PackageResponse })
  @Type(() => PackageResponse)
  @Expose()
  package: PackageResponse;

  @ApiProperty({
    type: () => ItemResponse,
    isArray: true,
  })
  @Expose()
  @IsArray()
  @Type(() => ItemResponse)
  item: ItemResponse[];
}

class LotExport {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  mfg: string;

  @ApiProperty()
  @Expose()
  inventoryQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  exportedQuantity: number;

  @ApiProperty()
  @Expose()
  collectedQuantity: number;

  @ApiProperty()
  @Expose()
  receivedQuantity: number;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  warehouseShelfFloorId: number;

  @ApiProperty()
  @Expose()
  locationId: number;
}
class ItemExport {
  @Expose({ name: 'itemId' })
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  price: string;

  @Expose()
  planQuantity: number;

  @ApiProperty({ type: ItemUnit })
  @Expose()
  @Type(() => ItemUnit)
  itemUnit: ItemUnit;

  @Expose()
  actualQuantity: number;

  @Expose()
  exportedQuantity: number;

  @Expose()
  quantity: number;

  @ApiProperty({ type: LotExport })
  @Expose()
  @Type(() => LotExport)
  lots: LotExport[];
}

export class AttributeResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  bussinessTypeId: number;

  @ApiProperty()
  @Expose()
  fieldName: string;

  @ApiProperty()
  @Expose()
  ebsLabel: string;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  columnName: string;

  @ApiProperty()
  @Expose()
  tableName: string;

  @ApiProperty()
  @Expose()
  value: any;

  @ApiProperty()
  @Expose()
  required: boolean;
}

export class WarehouseTransferResponseDto extends WarehouseTransferResponse {
  @ApiProperty()
  @Expose()
  approvedAt: Date;

  @ApiProperty()
  @Expose()
  receiptDate: Date;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  @Type(() => Factory)
  sourceFactory: Factory;

  @ApiProperty()
  @Expose()
  @Type(() => Factory)
  destinationFactory: Factory;

  @Expose()
  @Type(() => Item)
  items: Item[];

  @ApiProperty({ type: ItemExport, isArray: true })
  @ApiProperty({
    type: () => ItemResponse,
    isArray: true,
  })
  @Expose()
  @Type(() => ItemExport)
  itemsExport: ItemExport[];

  @ApiProperty({
    type: () => WarehouseTransferDetailResponseDto,
    isArray: true,
  })
  @Expose()
  @IsArray()
  @Type(() => WarehouseTransferDetailResponseDto)
  warehouseTransferDetails: WarehouseTransferDetailResponseDto[];

  @ApiProperty({
    type: () => WarehouseTransferDetailLotResponseDto,
    isArray: true,
  })
  @Expose()
  @IsArray()
  @Type(() => WarehouseTransferDetailLotResponseDto)
  warehouseTransferDetailLots: WarehouseTransferDetailLotResponseDto[];

  @ApiProperty({ type: WarehouseTransferDetailResponseDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => AttributeResponse)
  attributes: AttributeResponse[];
}
