import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class ItemLotsOrderImport {
  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  storedQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;
}

class LocationOrderImport {
  @ApiProperty()
  @Expose()
  locationName: string;

  @ApiProperty()
  @Expose()
  locationCode: string;

  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty({ type: ItemLotsOrderImport, isArray: true })
  @Expose()
  @Type(() => ItemLotsOrderImport)
  lots: ItemLotsOrderImport[];
}

class ItemsOrderImport {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  storedQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty({ type: LocationOrderImport, isArray: true })
  @Expose()
  @Type(() => LocationOrderImport)
  locations: LocationOrderImport[];
}
class TransferWarehouse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

export class SuggestStoredResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty({ description: 'O: chuển kho 1 bước | 1: chuyển kho 2 bước' })
  @Expose()
  type: number;

  @ApiProperty({ description: 'Ngày dự kiến chuyển' })
  @Expose()
  transferOn: string;

  @ApiProperty({ description: 'Ngày tạo' })
  @Expose()
  createdOn: string;

  @ApiProperty({ description: 'Ngày  xác nhận' })
  @Expose()
  approvedAt: string;

  @ApiProperty({ description: 'Mô tả' })
  @Expose()
  description: string;

  @ApiProperty({ type: TransferWarehouse })
  @Expose()
  @Type(() => TransferWarehouse)
  sourceWarehouse: TransferWarehouse;

  @ApiProperty()
  @Expose()
  @Type(() => TransferWarehouse)
  destinationWarehouse: TransferWarehouse;

  @ApiProperty({ type: ItemsOrderImport, isArray: true })
  @Expose()
  @Type(() => ItemsOrderImport)
  items: ItemsOrderImport[];
}
