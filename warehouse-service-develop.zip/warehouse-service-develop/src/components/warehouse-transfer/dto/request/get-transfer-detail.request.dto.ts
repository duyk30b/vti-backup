import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty, IsOptional, IsNumber } from 'class-validator';

export class GetTransferDetailParamDto extends BaseDto {
  @IsNumber()
  @IsOptional()
  @Transform((data) => parseInt(data.value))
  type: number;

  @IsOptional()
  @IsInt()
  @Transform((data) => +data.value)
  locatorId: number;
}

export class GetTransferDetailRequestDto extends GetTransferDetailParamDto {
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
