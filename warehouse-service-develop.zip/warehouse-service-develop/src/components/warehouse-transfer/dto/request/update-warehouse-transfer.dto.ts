import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateTransferRequestDto } from './create-transfer.request.dto';

export class UpdateWarehouseTransferBodyDto extends CreateTransferRequestDto {}
export class UpdateWarehouseTransferRequestDto extends UpdateWarehouseTransferBodyDto {
  @ApiProperty({ example: 'id:1', description: 'Id Lệnh Chuyển Kho' })
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
