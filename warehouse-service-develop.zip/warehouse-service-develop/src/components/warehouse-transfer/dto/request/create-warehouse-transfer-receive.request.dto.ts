import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';

export class WarehouseTransferReceiveItemRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  quantity: number;
}

export class CreateWarehouseTransferReceiveRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseTransferId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  referenceDoc: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  postedAt: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  doorId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  warehouseId?: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  note: string;

  @ApiProperty({
    type: WarehouseTransferReceiveItemRequestDto,
    isArray: true,
  })
  @IsArray()
  @ArrayUnique<WarehouseTransferReceiveItemRequestDto>((item) => item.itemId)
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => WarehouseTransferReceiveItemRequestDto)
  items: WarehouseTransferReceiveItemRequestDto[];
}

export class CreateWarehouseTransferReceiveItemEntityRequestDto extends WarehouseTransferReceiveItemRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseTransferReceiveId: number;
}
