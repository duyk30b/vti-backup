import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';

class Lot {
  @ApiPropertyOptional({ example: 'Lô 1' })
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty({ example: 2.2 })
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  quantity: number;
}
export class SwiftItemRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  quantity: number;

  @ApiProperty({
    type: Lot,
    isArray: true,
  })
  @IsArray()
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => Lot)
  lots: Lot[];
}

export class SubmitSwiftLocatorBodyDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  sourceLocatorId: number;

  @ApiProperty()
  @IsInt()
  destinationLocatorId: number;

  @ApiProperty({
    type: SwiftItemRequestDto,
    isArray: true,
  })
  @IsArray()
  @ArrayUnique<SwiftItemRequestDto>((item) => item.itemId)
  @ArrayNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => SwiftItemRequestDto)
  items: SwiftItemRequestDto[];

  @ApiProperty()
  @IsInt()
  warehouseId: number;
}

export class SubmitSwiftLocatorRequestDto extends SubmitSwiftLocatorBodyDto {}
