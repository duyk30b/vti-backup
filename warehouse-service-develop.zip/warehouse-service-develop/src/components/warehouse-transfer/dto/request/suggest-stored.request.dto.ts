import { SuggestCollected } from "./suggest-collected.request.dto";

export class SuggestStored extends SuggestCollected {}