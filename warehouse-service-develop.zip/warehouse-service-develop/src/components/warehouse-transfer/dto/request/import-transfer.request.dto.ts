import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { plus } from '@utils/common';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsBoolean,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';
export class ImportTransferBodyDto extends BaseDto {}
export class ImportTransferRequestDto extends ImportTransferBodyDto {
  @IsInt()
  @IsNotEmpty()
  id: number;

  @IsInt()
  @IsNotEmpty()
  createdByUserId: number;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  note: string;

  @ArrayNotEmpty()
  @Type(() => Item)
  @ValidateNested()
  @ArrayUnique<Item>((i) =>
    [i.itemId, i.locatorId, i.lotNumber || ''].join('_'),
  )
  items: Item[];
}

class Item {
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @ApiProperty({ example: 'Lô 1' })
  @IsOptional()
  @IsString()
  @MaxLength(20)
  @Transform(({ value }) => value.toUpperCase())
  lotNumber: string;

  @ApiProperty({ example: 2.2 })
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  quantity: number;

  @ApiProperty({ example: 1, description: 'Id tầng' })
  @IsInt()
  @IsNotEmpty()
  locatorId: number;
}
