import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayUnique,
  IsArray,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class ItemLot {
  @ApiProperty()
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  quantity: number;
}

class ItemImport {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  @ValidateNested()
  lots: ItemLot[];
}

export class SuggestCollectedBodyDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  @ValidateNested()
  @ArrayUnique((item: ItemImport) => item.itemId)
  @Type(() => ItemImport)
  items: ItemImport[];

  @ApiProperty()
  @IsOptional()
  @IsArray()
  locatorIds: number[];
}

export class SuggestCollected extends SuggestCollectedBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  @IsNumber()
  warehouseTransferId: number;
}
