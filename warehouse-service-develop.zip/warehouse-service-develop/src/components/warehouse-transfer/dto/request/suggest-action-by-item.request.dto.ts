import { WarehouseTransfersTypeEnum } from '../../warehouse-transfer.contant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsInt } from 'class-validator';
export class SuggestActionByItemRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsInt()
  warehouseTransferId: number;

  @ApiProperty()
  @IsEnum(WarehouseTransfersTypeEnum)
  type: number;
}
