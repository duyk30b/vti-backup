import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty, IsNumber } from 'class-validator';

export class SubmitWarehouseTransferReceiveRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}

export class UpdateWarehouseTransferReceiveItemRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  receivedQuantity: number;
}
