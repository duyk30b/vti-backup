import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsEnum, IsOptional } from 'class-validator';
import { BaseDto } from './../../../../core/dto/base.dto';
export class GetLocatorByOrderIdRequestDto extends BaseDto {
  id: number;

  @ApiProperty()
  @IsEnum(['0', '1'])
  type: number;

  @ApiProperty()
  @Transform(({ value }) => value.split(',').map((v) => Number(v)))
  itemIds: number[];
}
