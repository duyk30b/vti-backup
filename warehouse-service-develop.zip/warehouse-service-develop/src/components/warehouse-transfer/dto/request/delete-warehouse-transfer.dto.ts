import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';

export class DeleteWarehouseTransferDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'Mã id lệnh chuyển kho cần xóa' })
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
