import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Length,
  MaxLength,
  ValidateNested,
} from 'class-validator';
export class UpdateTransferExportBody extends BaseDto {}
export class UpdateTransferRequestDto extends UpdateTransferExportBody {
  @IsInt()
  @IsNotEmpty()
  id: number;

  @IsInt()
  @IsNotEmpty()
  createdByUserId: number;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  note: string;

  @ArrayNotEmpty()
  @Type(() => Item)
  @ValidateNested()
  @ArrayUnique<Item>((i) =>
    [i.itemId, i.locatorId, i.lotNumber || ''].join('_'),
  )
  items: Item[];
}

class Item {
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @IsNumber()
  @IsNotEmpty()
  quantity: number;

  @ApiProperty({ example: 1, description: 'Id tầng' })
  @IsInt()
  @IsNotEmpty()
  locatorId: number;

  @ApiProperty({ example: 'Lô 1' })
  @IsOptional()
  @IsString()
  @MaxLength(20)
  @Transform(({ value }) => value?.toUpperCase())
  lotNumber: string;
}
