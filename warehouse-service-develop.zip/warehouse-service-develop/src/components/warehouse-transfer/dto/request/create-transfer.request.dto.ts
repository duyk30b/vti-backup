import { WarehouseTransferTypeEnum } from '@components/warehouse-transfer/warehouse-transfer.contant';
import { CheckSameWarehouseEnum } from '@components/warehouse/warehouse.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsDateString,
  IsEnum,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  Length,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { isJson } from 'src/helper/string.helper';

export class AttributeRequest {
  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  id: number;

  @ApiProperty()
  value: any;
}

export class Item {
  @Transform((obj) => Number(obj.value))
  @IsInt()
  itemId: number;

  @Transform((obj) => Number(obj.value))
  @IsInt()
  locatorId: number;

  @Transform((obj) => Number(obj.value))
  @IsNumber()
  quantity: number;

  @ApiProperty()
  @IsString()
  @Length(10)
  lotNumber: string;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  mfg: Date;

  @ApiProperty()
  @IsOptional()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  packageId: number;

  @ApiPropertyOptional()
  @Transform((obj) => Number(obj.value))
  @IsOptional()
  @IsEnum([['0', '1']])
  isExistInDestinationWarehouse: number;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  storageDate: Date;

  @ApiProperty()
  @IsOptional()
  @ValidateNested()
  @IsArray()
  @Type(() => Location)
  locations: Location[];
}

class Location {
  @ApiProperty({ example: 2.2 })
  @IsNumber()
  quantity: number;

  @ApiProperty({ example: 1, description: 'Id' })
  @IsInt()
  id: number;
}

export class CreateTransferBodyDto extends BaseDto {
  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(255)
  @IsOptional()
  name: string;

  @ApiProperty({ example: '', description: '' })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  sourceWarehouseId: number;

  @ApiProperty({ example: '', description: '' })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  destinationWarehouseId: number;

  @ApiProperty({ example: '', description: '' })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  bussinessTypeId: number;

  @ApiProperty()
  @IsDateString()
  receiptDate: Date;

  @ApiProperty({ example: '', description: '' })
  @IsOptional()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  sourceId: number;

  @ApiProperty({ example: '', description: '' })
  @IsOptional()
  @IsString()
  receiver: string;

  @ApiProperty({ example: '', description: '' })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  reasonId: number;

  @ApiProperty({ example: '', description: '' })
  @IsOptional()
  @IsString()
  explanation: string;

  @ApiProperty({ example: '', description: '' })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  @IsEnum(WarehouseTransferTypeEnum)
  type: WarehouseTransferTypeEnum;

  @IsInt()
  @IsOptional()
  createdByUserId: number;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  transferOn: Date;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;

  @IsOptional()
  @IsInt()
  @IsEnum(CheckSameWarehouseEnum)
  isSameWarehouse: CheckSameWarehouseEnum;

  @ArrayNotEmpty()
  @ArrayUnique<Item>()
  @Transform(({ value }) => {
    if (isJson(value)) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    }
  })
  @Type(() => Item)
  @ValidateNested()
  items: Item[];
}

export class CreateTransferRequestDto extends CreateTransferBodyDto {
  @ApiProperty()
  @ValidateNested()
  @Transform(({ value }) => {
    if (isJson(value)) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    }
  })
  @Type(() => AttributeRequest)
  attributes: AttributeRequest[];
}
