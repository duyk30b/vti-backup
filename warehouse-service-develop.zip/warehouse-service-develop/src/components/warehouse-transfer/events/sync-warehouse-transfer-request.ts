import { Expose, Type } from 'class-transformer';

class Warehouse {
  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  manageByLot: number;
}

class DataResponse {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  accountant: string;
}

class ItemResponse {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  planQuantity: number;

  @Expose()
  code: string;

  @Expose()
  itemType: any;

  @Expose()
  itemGroup: any;

  @Expose()
  itemUnit: any;
}

class LotExport {
  @Expose()
  id: number;

  @Expose()
  mfg: string;

  @Expose()
  inventoryQuantity: number;

  @Expose()
  actualQuantity: number;

  @Expose()
  exportedQuantity: number;

  @Expose()
  collectedQuantity: number;

  @Expose()
  receivedQuantity: number;

  @Expose()
  planQuantity: number;

  @Expose()
  lotNumber: string;

  @Expose()
  price: any;

  @Expose()
  amount: any;
}
class ItemExport {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  price: string;

  @Expose()
  planQuantity: number;

  @Expose()
  actualQuantity: number;

  @Expose()
  exportedQuantity: number;

  @Expose()
  debitAccount: any;

  @Expose()
  creditAccount: string;

  @Expose()
  quantity: number;

  @Expose()
  @Type(() => ItemResponse)
  item: ItemResponse;

  @Expose()
  @Type(() => LotExport)
  lots: LotExport[];
}

export class SyncWarehouseTransferRequest {
  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  itemUnitName: string;

  @Expose()
  status: number;

  @Expose()
  type: number;

  @Expose()
  quantity: Date;

  @Expose()
  @Type(() => Warehouse)
  sourceWarehouse: Warehouse;

  @Expose()
  @Type(() => Warehouse)
  destinationWarehouse: Warehouse;

  @Expose()
  createdAt: Date;

  @Expose()
  updatedAt: Date;

  @Expose()
  approvedAt: Date;

  @Expose()
  warehouseTransferReceiveId: number;

  @Expose()
  sourceId: number;

  @Expose()
  reasonId: number;

  @Expose()
  @Type(() => DataResponse)
  source: DataResponse;

  @Expose()
  @Type(() => DataResponse)
  reason: DataResponse;

  @Expose()
  receiver: string;

  @Expose()
  explanation: string;

  @Expose()
  description: string;

  @Expose()
  @Type(() => ItemExport)
  warehouseTransferDetails: ItemExport[];

  @Expose()
  @Type(() => DataResponse)
  company: DataResponse;

  @Expose()
  @Type(() => DataResponse)
  warehouseExportProposals: DataResponse;

  @Expose()
  @Type(() => DataResponse)
  construction: DataResponse;

  @Expose()
  @Type(() => DataResponse)
  departmentReceipt: DataResponse;

  @Expose()
  syncCode: string;

  @Expose({ name: 'ebsId' })
  ebsNumber: string;

  @Expose()
  qrCode: string;

  @Expose()
  receiptDate: Date;
}
