import { ActionTypeEnum } from '@components/sync-from-hq/sync-data-from-hq.constant';
import { Job } from 'bull';
import { UrlSyncDataEnum } from '../sync-data.constant';

export interface SyncDataServiceInterface {
  syncMasterData(
    job: Job,
    urlSyncData: UrlSyncDataEnum,
    actionTypeEnum: ActionTypeEnum,
  ): Promise<any>;
  syncWarehouseTransfer(
    job: Job,
    urlSyncData: UrlSyncDataEnum,
    actionTypeEnum: ActionTypeEnum,
  ): Promise<any>;
  syncWarehouseTransferHQ(
    job: Job,
    urlSyncData: UrlSyncDataEnum,
    actionTypeEnum: ActionTypeEnum,
  ): Promise<any>;

  updateStatusSync(job: Job, response): Promise<any>;
}
