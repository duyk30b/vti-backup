import { JOB_SYNC_STATUS_ENUM } from '@components/datasync/datasync.constant';
import { DatasyncServiceInterface } from '@components/datasync/interface/datasync.service.interface';
import { ActionTypeEnum } from '@components/sync-from-hq/sync-data-from-hq.constant';
import { QUEUES_NAME_ENUM } from '@constant/common';
import {
  OnQueueActive,
  OnQueueCompleted,
  OnQueueError,
  OnQueueFailed,
  Process,
  Processor,
} from '@nestjs/bull';
import { Inject, Logger } from '@nestjs/common';
import { Job } from 'bull';
import { StatusSyncResponseDto } from './dto/response/status-sync.response.dto';
import { SyncDataServiceInterface } from './interface/sync-data.interface';
import { ProcessSyncDataEnum, UrlSyncDataEnum } from './sync-data.constant';

@Processor(QUEUES_NAME_ENUM.SYNC_DATA_QUEUE)
export class SyncDataConsumer {
  private logger = new Logger(SyncDataConsumer.name);
  constructor(
    @Inject('SyncDataServiceInterface')
    private readonly syncDataService: SyncDataServiceInterface,

    @Inject('DatasyncServiceInterface')
    private datasyncService: DatasyncServiceInterface,
  ) {}

  @Process(ProcessSyncDataEnum.CreateWarehouse)
  async syncCreateItem(job: Job) {
    await this.syncDataService.syncMasterData(
      job,
      UrlSyncDataEnum.Warehouse,
      ActionTypeEnum.CREATE,
    );
  }

  @Process(ProcessSyncDataEnum.UpdateWarehouse)
  async syncUpdateItem(job: Job) {
    await this.syncDataService.syncMasterData(
      job,
      UrlSyncDataEnum.Warehouse,
      ActionTypeEnum.UPDATE,
    );
  }

  @Process(ProcessSyncDataEnum.DeleteWarehouse)
  async syncDeleteItem(job: Job) {
    await this.syncDataService.syncMasterData(
      job,
      UrlSyncDataEnum.Warehouse,
      ActionTypeEnum.DELETE,
    );
  }

  @Process(ProcessSyncDataEnum.ConfirmWarehouse)
  async syncConfirmItem(job: Job) {
    await this.syncDataService.syncMasterData(
      job,
      UrlSyncDataEnum.Warehouse,
      ActionTypeEnum.CONFIRM,
    );
  }

  @Process(ProcessSyncDataEnum.RejectWarehouse)
  async syncRejectItem(job: Job) {
    await this.syncDataService.syncMasterData(
      job,
      UrlSyncDataEnum.Warehouse,
      ActionTypeEnum.REJECT,
    );
  }

  @Process(ProcessSyncDataEnum.UpdateWarehouseTransfer)
  async syncWarehouseTransfer(job: Job) {
    await this.syncDataService.syncWarehouseTransfer(
      job,
      UrlSyncDataEnum.WarehouseTransfer,
      ActionTypeEnum.UPDATE,
    );
  }

  @Process(ProcessSyncDataEnum.UpdateWarehouseTransferHQ)
  async syncWarehouseTransferHQ(job: Job) {
    await this.syncDataService.syncWarehouseTransferHQ(
      job,
      UrlSyncDataEnum.WarehouseTransfer,
      ActionTypeEnum.UPDATE,
    );
  }

  @Process(ProcessSyncDataEnum.DeleteWarehouseTransfer)
  async syncDeleteWarehouseTransfer(job: Job) {
    await this.syncDataService.syncWarehouseTransfer(
      job,
      UrlSyncDataEnum.WarehouseTransfer,
      ActionTypeEnum.DELETE,
    );
  }

  @Process(ProcessSyncDataEnum.DeleteWarehouseTransferHQ)
  async syncDeleteWarehouseTransferHQ(job: Job) {
    await this.syncDataService.syncWarehouseTransferHQ(
      job,
      UrlSyncDataEnum.WarehouseTransfer,
      ActionTypeEnum.DELETE,
    );
  }

  @OnQueueActive()
  async onActive(job: Job) {
    await this.datasyncService.updateJobStatus(
      job.data?.jobSyncId,
      JOB_SYNC_STATUS_ENUM.IN_PROGRESS,
    );
    this.logger.log('Active Job sync data: ' + job.data?.jobSyncId);
  }

  @OnQueueCompleted()
  async onCompleted(job: Job) {
    this.logger.log('Complete Job sync data: ' + job.data?.jobSyncId);
  }

  @OnQueueFailed()
  async onFailed(job: Job) {
    await this.datasyncService.updateJobStatus(
      job.data?.jobSyncId,
      JOB_SYNC_STATUS_ENUM.ERROR_TRANSACTION,
    );
    this.logger.warn('Failed Job sync data: ' + job.data?.jobSyncId);
  }

  @OnQueueError()
  onError(error: Error) {
    this.logger.error('Error job sync data: ' + error.message);
  }
}
