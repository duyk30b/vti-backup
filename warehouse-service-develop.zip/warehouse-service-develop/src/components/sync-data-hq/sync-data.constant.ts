export const NUMBER_RETRY_QUEUE = 5;

export enum UrlSyncDataEnum {
  Warehouse = 'warehouses/sync/warehouse',
  WarehouseTransfer = 'reports/sync/orders/warehouse-transfer',
}

export enum RepositorySyncDataEnum {
  Warehouse = 'Warehouse',
  WarehouseTransfer = 'WarehouseTransfer',
}

export enum ProcessSyncDataEnum {
  CreateWarehouse = 'sync_data-create_warehouse',
  UpdateWarehouse = 'sync_data-update_warehouse',
  DeleteWarehouse = 'sync_data-delete_warehouse',
  ConfirmWarehouse = 'sync_data-confirm_warehouse',
  RejectWarehouse = 'sync_data-reject_warehouse',

  UpdateWarehouseTransfer = 'sync_data-update_warehouse-transfer',
  UpdateWarehouseTransferHQ = 'sync_data_hq-update_warehouse-transfer',
  DeleteWarehouseTransfer = 'sync_data-delete_warehouse-transfer',
  DeleteWarehouseTransferHQ = 'sync_data_hq-delete_warehouse-transfer',
}

export enum RequestMethodEnum {
  POST = 'POST',
  PUT = 'PUT',
  DELETE = 'DELETE',
}

export enum TypeTransactionDataSyncEnum {
  WAREHOUSE_TRANSFER = 'Chuyển kho',
  PO_IMPORT = 'Phiếu nhập kho',
  SO_EXPORT = 'Phiếu xuất kho',
  TRANSACTION = 'Giao dịch',
  MASTER_DATA_WAREHOUSE = 'Kho',
}

export enum SYNC_TO_SYSTEM_ENUM {
  COMPANY_HQ = 'Tổng công ty',
  COMPANY = 'Công ty con',
  EBS = 'EBS',
  ECAT = 'ECAT',
}

export enum SYNC_FROM_SYSTEM_ENUM {
  COMPANY_HQ = 'Tổng công ty',
  WMS = 'WMS',
}
