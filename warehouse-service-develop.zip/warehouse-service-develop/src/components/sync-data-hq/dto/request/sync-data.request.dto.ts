import { RepositorySyncDataEnum } from '@components/sync-data-hq/sync-data.constant';
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsInt, IsString } from 'class-validator';

export class SyncDataRequestDto {
  @ApiProperty({ example: 'warehouse' })
  @IsString()
  @IsEnum(RepositorySyncDataEnum)
  masterData: string;

  @ApiProperty()
  @IsInt()
  id: number;

  data: any;

  jobSyncId: string;
}
