import { JOB_SYNC_STATUS_ENUM } from '@components/datasync/datasync.constant';

export class StatusSyncResponseDto {
  jobId?: number;
  status?: JOB_SYNC_STATUS_ENUM;
  message?: string;
  createdAt: Date;
}
