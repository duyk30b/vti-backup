import { SyncDataFromHqModule } from '@components/sync-from-hq/sync-data-from-hq.module';
import { UserService } from '@components/user/user.service';
import { ConfigService } from '@config/config.service';
import { QUEUES_NAME_ENUM } from '@constant/common';
import { WarehouseTransfer } from '@entities/warehouse-transfer/warehouse-transfer.entity';
import { Warehouse } from '@entities/warehouse/warehouse.entity';
import { BullModule } from '@nestjs/bull';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WarehouseTransferRepository } from '@repositories/warehouse-transfer.repository';
import { WarehouseRepository } from '@repositories/warehouse.repository';
import { SyncDataConsumer } from './sync-data.consumer';
import { SyncDataService } from './sync-data.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([Warehouse, WarehouseTransfer]),
    BullModule.registerQueue({
      name: QUEUES_NAME_ENUM.SYNC_DATA_QUEUE,
    }),
    SyncDataFromHqModule,
  ],
  providers: [
    {
      provide: 'SyncDataServiceInterface',
      useClass: SyncDataService,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'WarehouseTransferRepositoryInterface',
      useClass: WarehouseTransferRepository,
    },
    ConfigService,
    SyncDataConsumer,
  ],
  exports: [
    {
      provide: 'SyncDataServiceInterface',
      useClass: SyncDataService,
    },
    ConfigService,
    SyncDataConsumer,
  ],
  controllers: [],
})
export class SyncDataModule {}
