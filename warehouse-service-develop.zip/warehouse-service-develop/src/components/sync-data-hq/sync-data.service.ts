import { ApiError } from '@utils/api.error';
import { I18nService } from 'nestjs-i18n';
import { WarehouseTransferRepositoryInterface } from './../warehouse-transfer/interface/warehouse-transfer.repository.interface';
import { WarehouseRepositoryInterface } from './../warehouse/interface/warehouse.repository.interface';
import { ConfigService } from '@config/config.service';
import { APIPrefix } from '@constant/common';
import { HttpClientCronService } from '@core/components/http-client/http-client.cron.service';
import { Inject, Logger } from '@nestjs/common';
import { SyncDataRequestDto } from './dto/request/sync-data.request.dto';
import { SyncDataServiceInterface } from './interface/sync-data.interface';
import { RepositorySyncDataEnum, UrlSyncDataEnum } from './sync-data.constant';
import Job from 'bull';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import {
  ActionTypeEnum,
  CompanyCreatedEnum,
  MasterDataTypeEnum,
  OrderType,
} from '@components/sync-from-hq/sync-data-from-hq.constant';
import { SyncDataFromHqRequest } from '@components/sync-from-hq/request/sync-from-hq.request.abstract.dto';
import { Workbook } from 'exceljs';
import * as moment from 'moment';
import * as FormData from 'form-data';
import { ResponseBuilder } from '@utils/response-builder';
import { DatasyncServiceInterface } from '@components/datasync/interface/datasync.service.interface';
import { JOB_SYNC_STATUS_ENUM } from '@components/datasync/datasync.constant';
import {
  StatusSyncOrderToEbsEnum,
  STATUS_SYNC_ACCEPT_SYNC_WAREHOUSE_TRANSFER_TO_EBS,
} from '@components/warehouse-transfer/warehouse-transfer.contant';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';

export class SyncDataService implements SyncDataServiceInterface {
  private readonly logger = new Logger(SyncDataService.name);
  constructor(
    private configService: ConfigService,

    private readonly httpClientService: HttpClientCronService,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('WarehouseTransferRepositoryInterface')
    private readonly warehouseTransferRepository: WarehouseTransferRepositoryInterface,

    @Inject('DatasyncServiceInterface')
    private datasyncService: DatasyncServiceInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    private readonly i18n: I18nService,
  ) {}
  protected urlConfig = this.configService.get('hqWarehouseService');
  protected url = `http://${
    this.urlConfig.options.host + ':' + this.urlConfig.options.port
  }`;

  private getURL(url): string {
    return `${this.url}/${APIPrefix.Version}/${url}`;
  }

  async postRequest(request, url): Promise<any> {
    return await this.httpClientService.post(this.getURL(url), request, {
      sync: true,
    });
  }

  async putRequest(request, url): Promise<any> {
    return await this.httpClientService.put(this.getURL(url), request, {
      sync: true,
    });
  }

  async deleteRequest(request, url): Promise<any> {
    return await this.httpClientService.delete(this.getURL(url), request);
  }

  async syncMasterData(
    job: Job,
    urlSyncData: UrlSyncDataEnum,
    actionTypeEnum: ActionTypeEnum,
  ): Promise<any> {
    const data = await this.getDataJob(job);
    const syncItem = [];
    let masterDataType;
    let orderType;
    switch (urlSyncData) {
      case UrlSyncDataEnum.Warehouse:
        masterDataType = MasterDataTypeEnum.WAREHOUSE;
        break;
      case UrlSyncDataEnum.WarehouseTransfer:
        orderType = OrderType.TRANSFER;
      default:
        break;
    }
    if (data?.data?.id) {
      data.data.id = undefined;
    }
    const company = await this.userService.getCompanyDefault();
    syncItem.push({
      actionType: actionTypeEnum,
      masterDataType,
      orderType,
      createdFrom: company?.code,
      data: data.data,
    });
    const request: SyncDataFromHqRequest<any> = {
      items: syncItem,
      meta: { total: 1, syncTime: new Date() },
      request: null,
      responseError: null,
    } as any;

    const response = await this.postRequest(request, urlSyncData);
    await this.updateStatusSync(job, response);
  }

  async syncWarehouseTransfer(
    job: Job,
    urlSyncData: UrlSyncDataEnum,
    actionTypeEnum: ActionTypeEnum,
  ): Promise<any> {
    const data = await this.getDataJob(job);
    let orderType;
    this.urlConfig = this.configService.get('reportService');
    this.url = `http://${
      this.urlConfig.options.host + ':' + this.urlConfig.options.port
    }`;
    switch (urlSyncData) {
      case UrlSyncDataEnum.WarehouseTransfer:
        orderType = OrderType.TRANSFER;
      default:
        break;
    }
    let response = {};
    response = await this.postRequest(
      {
        actionType: actionTypeEnum,
        orderType,
        createdFrom: CompanyCreatedEnum.BUON_KUOP,
        data: data.data,
      },
      urlSyncData,
    );
    await this.updateStatusSync(job, response);
  }

  async syncWarehouseTransferHQ(
    job: Job,
    urlSyncData: UrlSyncDataEnum,
    actionTypeEnum: ActionTypeEnum,
  ): Promise<any> {
    const data = await this.getDataJob(job);
    let orderType;
    this.urlConfig = this.configService.get('hqReportService');
    this.url = `http://${
      this.urlConfig.options.host + ':' + this.urlConfig.options.port
    }`;
    switch (urlSyncData) {
      case UrlSyncDataEnum.WarehouseTransfer:
        orderType = OrderType.TRANSFER;
      default:
        break;
    }
    let response = {};
    response = await this.postRequest(
      {
        actionType: actionTypeEnum,
        orderType,
        createdFrom: CompanyCreatedEnum.BUON_KUOP,
        data: data.data,
      },
      urlSyncData,
    );
    await this.updateStatusSync(job, response);
  }

  // Get repository của job đồng bộ
  private getRepoMasterData(data: SyncDataRequestDto) {
    const { masterData } = data;
    let repository;
    switch (masterData) {
      case RepositorySyncDataEnum.Warehouse:
        repository = this.warehouseRepository;
        break;
      case RepositorySyncDataEnum.WarehouseTransfer:
        repository = this.warehouseTransferRepository;
        break;
      default:
        break;
    }
    return repository;
  }

  async syncWarehouseTransferToEbs(
    id: number,
    data: any,
    headers: any,
  ): Promise<any> {
    let sync, file, fileName;
    const order = await this.warehouseTransferRepository.findOneById(id);

    if (
      !STATUS_SYNC_ACCEPT_SYNC_WAREHOUSE_TRANSFER_TO_EBS.includes(
        order.syncStatus,
      )
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PURCHASE_ORDER_STATUS_IS_INVALID'),
      ).toResponse();
    }
    try {
      const configEndpointEbs = this.configService.get('endpointSyncEbs');
      const urlSyncEbs = `http://${configEndpointEbs.endpointEbs}/${configEndpointEbs.warehouseTransfer}`;
      fileName = `Inter-organizationTransferIN_${id}_${moment().unix()}`;
      file = await this.createBufferCsv(data, headers);
      const form = new FormData();
      form.append('file', file, fileName);
      sync = await this.httpClientService.post(urlSyncEbs, form, {
        callInternalService: false,
        headers: {
          'Content-type': 'text/csv',
          apiKey: configEndpointEbs.apiKey,
          siteid: configEndpointEbs.siteId,
          fileName: fileName,
        },
      });
      const infoLog = {
        fileName,
      };
      this.logger.log(
        `SYNC WAREHOUSE TRANSFER TO EBS. Request: ${JSON.stringify(
          infoLog,
        )} Response: ${JSON.stringify(sync)}`,
      );
    } catch (error) {
      console.log(error);
      this.logger.error(
        `SYNC WAREHOUSE TRANSFER TO EBS ERROR: ${error?.message}`,
      );
      // order.syncStatus = StatusSyncOrderToEbsEnum.SYNC_WSO2_ERROR;
      await this.warehouseTransferRepository.create(order);

      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.INTERNAL_ERROR'),
      );
    }

    try {
      const form = new FormData();
      form.append('file', file, `${fileName}`);
      form.append('service', 'warehouse-service');
      form.append('resource', 'sync-warehouse-transfer');
      const configFileService = this.configService.get('fileService');
      const urlFile = `http://${configFileService.options.host}:${configFileService.options.port}/api/v1/files/single-file`;
      await this.httpClientService.post(urlFile, form, {
        callInternalService: false,
        sync: true,
      });
    } catch (error) {
      console.log(error);
    }

    order.syncStatus =
      sync?.code === ResponseCodeEnum.SUCCESS
        ? StatusSyncOrderToEbsEnum.SYNC_WSO2_SUCCESS
        : order.syncStatus;
    await this.warehouseTransferRepository.create(order);

    if (sync?.code === ResponseCodeEnum.SUCCESS) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } else {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(sync.message)
        .build();
    }
  }

  private async createBufferCsv(
    data: any,
    headers: any,
  ): Promise<Buffer | any> {
    const workbook = new Workbook();
    let countRowData = 1;
    let countSheet = 1;
    data.forEach((element) => {
      let worksheet = workbook.getWorksheet('Sheet' + countSheet);
      if (countRowData == 1) {
        worksheet = workbook.addWorksheet('Sheet' + countSheet);
        const headerRow = worksheet.getRow(1);
        headerRow.values = headers.map((header) => header.title);
      }
      worksheet.columns = headers;
      worksheet.addRow({
        ...element,
      });

      countRowData++;
      if (countRowData == 1000) {
        countSheet++;
        countRowData = 1;
      }
    });
    return await workbook.csv.writeBuffer();
  }

  // Update trạng thái đồng bộ master data
  async updateStatusSync(job: Job, response): Promise<any> {
    this.logger.log(
      `INFO SYNC: data(${JSON.stringify(job.data)}), response(${response})`,
    );
    await this.datasyncService.updateJobStatus(
      job.data?.jobSyncId,
      this.getStatusByResponse(response),
    );
  }

  private getStatusByResponse(response): JOB_SYNC_STATUS_ENUM {
    let status;
    switch (response.statusCode) {
      case ResponseCodeEnum.SUCCESS:
        status = JOB_SYNC_STATUS_ENUM.SUCCESS;
        break;
      default:
        status = JOB_SYNC_STATUS_ENUM.ERROR_SYNC;
        break;
    }
    return status;
  }

  private async getDataJob(job: Job): Promise<any> {
    const data = await this.datasyncService.getDetailJob(job.data.jobSyncId);
    return data?.object;
  }

  private getMessageByResponse(response): string {
    return response.message;
  }
}
