import { ResponsePayload } from '@utils/response-payload';
import { LocatorResponseDto } from '@components/warehouse-layout/dto/response/locator.response.dto';
import { CloneLocatorWarehouseRequestDto } from '../dto/request/clone-locator-warehouse.request.dto';
import { CreateLocatorByWarehouseRequestDto } from '../dto/request/create-locator-by-warehouse.request.dto';
export interface WarehouseLayoutServiceInterface {
  getLocatorByIds(ids: number[], serilize?: boolean): Promise<any>;
  getLocatorById(id: number): Promise<any>;
  getLocatorsByRootIds(
    rootIds: number[],
    locatorIds?: number[],
    type?: number,
  ): Promise<any>;
  getLocatorByCode(payload: any): Promise<any>;
  getLocatorByKeyword(
    locatorCode: string,
    warehouseIds: number[],
    onlyId?: boolean,
    serilize?: boolean,
  ): Promise<any>;
  getLocatorVirtualByWarehouseId(
    warehouseId: number,
  ): Promise<LocatorResponseDto | any>;
  getLocatorsByRootId(rootId: number): Promise<any>;
  createLocatorByWarehouse(
    request: CreateLocatorByWarehouseRequestDto,
  ): Promise<LocatorResponseDto | any>;
  cloneLocatorWarehouse(
    request: CloneLocatorWarehouseRequestDto,
  ): Promise<ResponsePayload<any>>;
}
