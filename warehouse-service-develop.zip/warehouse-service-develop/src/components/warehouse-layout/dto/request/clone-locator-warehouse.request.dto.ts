export class CloneLocatorWarehouseRequestDto {
  sourceWarehouseId: number;
  destinationWarehouseId: number;
  locatorIds: number[];

  constructor(
    sourceWarehouseId: number,
    destinationWarehouseId: number,
    locatorIds: number[],
  ) {
    this.sourceWarehouseId = sourceWarehouseId;
    this.destinationWarehouseId = destinationWarehouseId;
    this.locatorIds = locatorIds;
  }
}
