import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsString } from 'class-validator';

export class CreateLocatorByWarehouseRequestDto {
  @ApiProperty({ example: '', description: '' })
  @IsInt()
  userId: number;

  @ApiProperty({ example: '', description: '' })
  @IsInt()
  warehouseId: number;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  name: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  code: string;

  constructor(userId: number, warehouseId: number, name: string, code: string) {
    this.userId = userId;
    this.warehouseId = warehouseId;
    this.name = name;
    this.code = code;
  }
}
