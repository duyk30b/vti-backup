export enum LocatorTypeEnum {
  REAL_LOCATION = 0,
  VIRTUAL_LOCATION = 1,
}
