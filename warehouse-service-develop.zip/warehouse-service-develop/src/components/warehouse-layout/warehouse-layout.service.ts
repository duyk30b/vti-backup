import { NATS_WAREHOUSE_LAYOUT } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { flatMap, isEmpty, keyBy, map, uniq } from 'lodash';
import { CloneLocatorWarehouseRequestDto } from './dto/request/clone-locator-warehouse.request.dto';
import { CreateLocatorByWarehouseRequestDto } from './dto/request/create-locator-by-warehouse.request.dto';
import { LocatorResponseDto } from './dto/response/locator.response.dto';
import { WarehouseLayoutServiceInterface } from './interface/warehouse-layout.service.interface';
@Injectable()
export class WarehouseLayoutService implements WarehouseLayoutServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getLocatorByIds(ids: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE_LAYOUT}.get_locator_by_ids`,
      {
        locatorIds: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];

    const dataReturn = plainToInstance(
      LocatorResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );

    return serilize ? keyBy(dataReturn, 'locatorId') : dataReturn;
  }

  public async getLocatorById(locatorId: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE_LAYOUT}.get_detail`,
      {
        locatorId: locatorId,
      },
    );
    if (response.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return response.data;
  }

  public async getLocatorByCode(payload: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE_LAYOUT}.get_locator_by_code`,
      payload,
    );
    if (response.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return response.data;
  }

  public async getLocatorsByRootIds(
    rootIds: number[],
    locatorIds?: number[],
    type?: number,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE_LAYOUT}.get_locators_by_root_ids`,
      { rootIds, locatorIds, type },
    );
    if (response.statusCode != ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  public async getLocatorsByRootId(rootId: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE_LAYOUT}.get_locators_by_root_id`,
      { rootId: rootId },
    );
    if (response.statusCode != ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async getLocatorByKeyword(
    locatorCode: string,
    warehouseIds: number[],
    onlyId?: boolean,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE_LAYOUT}.get_locator_by_keyword`,
      {
        locatorCodeKeyword: locatorCode,
        rootId: warehouseIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (!isEmpty(response.data) && onlyId === true) {
      return uniq(map(flatMap(response.data), 'id'));
    }

    if (serilize) {
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
      const serilizeWarehouses = [];
      response.data.forEach((warehouse) => {
        serilizeWarehouses[warehouse.id] = warehouse;
      });

      return serilizeWarehouses;
    }

    return response.data;
  }

  async getLocatorVirtualByWarehouseId(
    warehouseId: number,
  ): Promise<LocatorResponseDto | any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE_LAYOUT}.get_locator_virtual_by_warehouse_id`,
      {
        warehouseId,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return {};
    }
    const dataReturn = plainToInstance(LocatorResponseDto, response.data, {
      excludeExtraneousValues: true,
    });
    return dataReturn;
  }

  async createLocatorByWarehouse(
    request: CreateLocatorByWarehouseRequestDto,
  ): Promise<LocatorResponseDto | any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE_LAYOUT}.create_locator_by_warehouse`,
      request,
    );
    return response;
  }

  async cloneLocatorWarehouse(
    request: CloneLocatorWarehouseRequestDto,
  ): Promise<ResponsePayload<any>> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE_LAYOUT}.clone_locator_warehouse`,
      request,
    );
    return response;
  }
}
