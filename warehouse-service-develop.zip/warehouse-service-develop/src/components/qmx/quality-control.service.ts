import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { CreateQcMovementTransactionRequestDto } from './dto/request/create-qc-movement-transaction.request';
import UpdateActualQuantityRequestDto from './dto/request/update-actual-quantity.request.dto';
import { QualityControlServiceInterface } from './interface/quality-control.service.interface';

@Injectable()
export class QualityControlService implements QualityControlServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async updateActualQuantity(
    data: UpdateActualQuantityRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'actual_quality_plan_ioqc_update',
      data,
    );

    return response;
  }

  async createQcMovementTransaction(
    data: CreateQcMovementTransactionRequestDto[],
  ): Promise<any> {
    return await this.natsClientService.send(
      'create_qc_movement_transaction',
      data,
    );
  }
}
