import { CreateQcMovementTransactionRequestDto } from '../dto/request/create-qc-movement-transaction.request';
import UpdateActualQuantityRequestDto from '../dto/request/update-actual-quantity.request.dto';

export interface QualityControlServiceInterface {
  updateActualQuantity(data: UpdateActualQuantityRequestDto): Promise<any>;
  createQcMovementTransaction(
    data: CreateQcMovementTransactionRequestDto[],
  ): Promise<any>;
}
