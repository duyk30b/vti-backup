import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty, IsString } from 'class-validator';

export class CreateQcMovementTransactionRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  warehouseId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  warehouseSectorId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  warehouseShelfId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  warehouseShelfFloorId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  warehouseStockMovementId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  movementType: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  orderId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  lotNumber: string;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  collectedQuantity: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  qcPassQuantity: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  qcRejectQuantity: number;
}
