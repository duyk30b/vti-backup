import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsArray, IsInt, IsNotEmpty, ValidateNested } from 'class-validator';

class ActualQuantity {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  qcStageId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  orderId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  actualQuantity: number;
}

class UpdateActualQuantityRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  @ValidateNested()
  @Type(() => ActualQuantity)
  data: ActualQuantity[];
}

export default UpdateActualQuantityRequestDto;
