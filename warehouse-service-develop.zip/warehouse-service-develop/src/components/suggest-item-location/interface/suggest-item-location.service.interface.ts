import { ResponsePayload } from '@utils/response-payload';
import { CreateSuggestItemLocationRequestDto } from '../dto/request/create-suggest-item-location.request.dto';
import { GetSuggestItemLocationDetailRequestDto } from '../dto/request/get-detail-suggest-item-location.request.dto';
import { GetListSuggestItemLocationRequestDto } from '../dto/request/get-list-suggest-item-location.request.dto';
import { GetSuggestItemLocationByListConditionRequestDto } from '../dto/request/get-suggest-item-location-by-list-condition.request.dto';
import { GetLocationByIdsRequestDto } from '../dto/request/get-location-by-ids.request.dto';
import { UpdateSuggestItemLocationRequestDto } from '../dto/request/update-suggest-item-location.request.dto';

export interface SuggestItemLocationServiceInterface {
  create(
    request: CreateSuggestItemLocationRequestDto,
  ): Promise<ResponsePayload<any>>;
  getList(
    payload: GetListSuggestItemLocationRequestDto,
  ): Promise<ResponsePayload<any>>;
  getDetail(
    payload: GetSuggestItemLocationDetailRequestDto,
  ): Promise<ResponsePayload<any>>;
  delete(
    payload: GetSuggestItemLocationDetailRequestDto,
  ): Promise<ResponsePayload<any>>;
  update(
    request: UpdateSuggestItemLocationRequestDto | any,
  ): Promise<ResponsePayload<any>>;
  getSuggestItemLocationByListCondition(
    request: GetSuggestItemLocationByListConditionRequestDto,
  ): Promise<any>;
  getLocationByIds(
    request: GetLocationByIdsRequestDto,
  ): Promise<ResponsePayload<any>>;
}
