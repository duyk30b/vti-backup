import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { SuggestItemLocationEntity } from '@entities/suggest-item-location/suggest-item-location.entity';
import { CreateSuggestItemLocationRequestDto } from '../dto/request/create-suggest-item-location.request.dto';
import { GetSuggestItemLocationDetailRequestDto } from '../dto/request/get-detail-suggest-item-location.request.dto';
import { GetListSuggestItemLocationRequestDto } from '../dto/request/get-list-suggest-item-location.request.dto';
import { UpdateSuggestItemLocationRequestDto } from '../dto/request/update-suggest-item-location.request.dto';

export interface SuggestItemLocationRepositoryInterface
  extends BaseInterfaceRepository<SuggestItemLocationEntity> {
  createEntity(
    request: CreateSuggestItemLocationRequestDto | any,
  ): SuggestItemLocationEntity;
  getList(
    request: GetListSuggestItemLocationRequestDto,
  ): Promise<[data: any[], count: number]>;
  getDetail(request: GetSuggestItemLocationDetailRequestDto): Promise<any>;
  updateEntity(
    locationUpdate: SuggestItemLocationEntity,
    request: UpdateSuggestItemLocationRequestDto,
  ): SuggestItemLocationEntity;
}
