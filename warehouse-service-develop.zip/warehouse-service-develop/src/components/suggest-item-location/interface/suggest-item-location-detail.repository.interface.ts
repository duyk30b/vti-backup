import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { SuggestItemLocationDetailEntity } from '@entities/suggest-item-location/suggest-item-location-detail.entity';

export interface SuggestItemLocationDetailRepositoryInterface
  extends BaseInterfaceRepository<SuggestItemLocationDetailEntity> {
  createEntities(request: any): SuggestItemLocationDetailEntity[];
  getSuggestItemLocationByListCondition(
    listLocationIdAndItemId: any[],
  ): Promise<any>;
}
