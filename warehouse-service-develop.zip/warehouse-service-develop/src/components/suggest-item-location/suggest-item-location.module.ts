import { ItemModule } from '@components/item/item.module';
import { ItemService } from '@components/item/item.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { SuggestItemLocationDetailEntity } from '@entities/suggest-item-location/suggest-item-location-detail.entity';
import { SuggestItemLocationEntity } from '@entities/suggest-item-location/suggest-item-location.entity';
import { WarehouseSectorEntity } from '@entities/warehouse-sector/warehouse-sector.entity';
import { WarehouseShelfFloorEntity } from '@entities/warehouse-shelf-floor/warehouse-shelf-floor.entity';
import { WarehouseShelfEntity } from '@entities/warehouse-shelf/warehouse-shelf.entity';
import { Warehouse } from '@entities/warehouse/warehouse.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SuggestItemLocationDetailRepository } from '@repositories/suggest-item-location-detail.repository';
import { SuggestItemLocationRepository } from '@repositories/suggest-item-location.repository';
import { WarehouseSectorRepository } from '@repositories/warehouse-sector.repository';
import { WarehouseShelfFloorRepository } from '@repositories/warehouse-shelf-floor.repository';
import { WarehouseShelfRepository } from '@repositories/warehouse-shelf.repository';
import { WarehouseRepository } from '@repositories/warehouse.repository';
import { SuggestItemLocationController } from './suggest-item-location.controller';
import { SuggestLocationService } from './suggest-item-location.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      SuggestItemLocationEntity,
      SuggestItemLocationDetailEntity,
      Warehouse,
      WarehouseSectorEntity,
      WarehouseShelfEntity,
      WarehouseShelfFloorEntity,
    ]),
    UserModule,
    ItemModule,
    WarehouseModule,
  ],
  exports: [],
  providers: [
    {
      provide: 'SuggestItemLocationServiceInterface',
      useClass: SuggestLocationService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'WarehouseSectorRepositoryInterface',
      useClass: WarehouseSectorRepository,
    },
    {
      provide: 'WarehouseShelfRepositoryInterface',
      useClass: WarehouseShelfRepository,
    },
    {
      provide: 'WarehouseShelfFloorRepositoryInterface',
      useClass: WarehouseShelfFloorRepository,
    },
    {
      provide: 'SuggestItemLocationRepositoryInterface',
      useClass: SuggestItemLocationRepository,
    },
    {
      provide: 'SuggestItemLocationDetailRepositoryInterface',
      useClass: SuggestItemLocationDetailRepository,
    },
  ],
  controllers: [SuggestItemLocationController],
})
export class SuggestItemLocationModule {}
