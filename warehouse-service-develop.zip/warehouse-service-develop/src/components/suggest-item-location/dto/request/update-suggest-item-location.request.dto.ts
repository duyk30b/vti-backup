import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateSuggestItemLocationRequestDto } from './create-suggest-item-location.request.dto';

export class UpdateSuggestItemLocationBodyDto extends CreateSuggestItemLocationRequestDto {}

export class UpdateSuggestItemLocationRequestDto extends UpdateSuggestItemLocationBodyDto {
  @ApiProperty({ example: 1, description: 'Mã id vị trí cần update' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
