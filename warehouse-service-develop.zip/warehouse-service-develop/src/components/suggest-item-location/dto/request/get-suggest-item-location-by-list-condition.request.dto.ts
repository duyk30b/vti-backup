import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNotEmpty } from 'class-validator';

export class GetSuggestItemLocationByListConditionRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  listCondition: any[];
}
