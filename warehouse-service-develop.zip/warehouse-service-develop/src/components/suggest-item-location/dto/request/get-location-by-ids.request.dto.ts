import { BaseDto } from '@core/dto/base.dto';
import { Type } from 'class-transformer';
import { ArrayNotEmpty } from 'class-validator';

export class GetLocationByIdsRequestDto extends BaseDto {
  @Type(() => Number)
  @ArrayNotEmpty()
  ids: number[];
}
