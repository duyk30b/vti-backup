import { ITEM_LOCATION_ENUM } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsArray,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';

class ItemLocation {
  @ApiProperty({ example: 1, description: 'Kho' })
  @IsInt()
  @IsNotEmpty()
  warehouseId: number;

  @ApiProperty({ example: 1, description: 'Khu vực' })
  @IsInt()
  @IsNotEmpty()
  warehouseSetorId: number;

  @ApiProperty({ example: 1, description: 'Kệ' })
  @IsInt()
  @IsOptional()
  warehouseShelfId: number;

  @ApiProperty({ example: 1, description: 'Tầng' })
  @IsInt()
  @IsOptional()
  warehouseShelfFloorId: number;
}

export class CreateSuggestItemLocationRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @MaxLength(255)
  @IsString()
  name: string;

  @ApiProperty()
  @IsNotEmpty()
  @MaxLength(20)
  @IsString()
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(ITEM_LOCATION_ENUM)
  type: number;

  @ApiProperty()
  @MaxLength(255)
  @IsString()
  @IsOptional()
  description: string;

  @ApiProperty()
  @IsArray()
  @IsOptional()
  @Type(() => Number)
  itemIds: number[];

  @ApiProperty({ type: ItemLocation, isArray: true })
  @IsArray()
  @ArrayNotEmpty()
  @IsOptional()
  @ValidateNested()
  @Type(() => ItemLocation)
  itemLocations: ItemLocation[];
}
