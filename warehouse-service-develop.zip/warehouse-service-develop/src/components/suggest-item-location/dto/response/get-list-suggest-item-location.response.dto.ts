import { ApiProperty } from '@nestjs/swagger';
import { Meta } from '@utils/common.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { SuggestItemLocationResponseDto } from './suggest-item-location.response.dto';

export class SuggestItemLocationDataResponse {
  @ApiProperty({ type: SuggestItemLocationResponseDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => SuggestItemLocationResponseDto)
  items: SuggestItemLocationResponseDto[];

  @ApiProperty({ type: Meta })
  @Expose()
  @Type(() => Meta)
  meta: Meta;
}

export class GetListSuggestItemLocationResponseDto extends SuccessResponse {
  @ApiProperty({ type: SuggestItemLocationDataResponse })
  @Expose()
  @Type(() => SuggestItemLocationDataResponse)
  data: SuggestItemLocationDataResponse;
}
