import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
class Items {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

class Warehouse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

class WarehouseSector {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

class WarehouseShelf {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

class WarehouseShelfFloor {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

class ItemLocations {
  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  @Type(() => Warehouse)
  warehouse: Warehouse;

  @ApiProperty()
  @Expose()
  warehouseSetorId: number;

  @ApiProperty()
  @Expose()
  @Type(() => WarehouseSector)
  warehouseSetor: WarehouseSector;

  @ApiProperty()
  @Expose()
  warehouseShelfId: number;

  @ApiProperty()
  @Expose()
  @Type(() => WarehouseShelf)
  warehouseShelf: WarehouseShelf;

  @ApiProperty()
  @Expose()
  warehouseShelfFloorId: number;

  @ApiProperty()
  @Expose()
  @Type(() => WarehouseShelfFloor)
  warehouseShelfFloor: WarehouseShelfFloor;
}
export class GetDetailSuggestItemLocationResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  @Type(() => Items)
  items: Items[];

  @ApiProperty()
  @Expose()
  @Type(() => ItemLocations)
  itemLocations: ItemLocations[];
}
