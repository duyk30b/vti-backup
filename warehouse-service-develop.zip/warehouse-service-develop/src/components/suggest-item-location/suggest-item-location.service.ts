import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { UserService } from '@components/user/user.service';
import { WarehouseSectorRepositoryInterface } from '@components/warehouse-sector/interface/warehouse-sector.repository.interface';
import { WarehouseShelfFloorRepositoryInterface } from '@components/warehouse-shelf-floor/interface/warehouse-shelf-floor.repository.interface';
import { WarehouseShelfRepositoryInterface } from '@components/warehouse-shelf/interface/warehouse-shelf.repository.interface';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { SuggestItemLocationDetailEntity } from '@entities/suggest-item-location/suggest-item-location-detail.entity';
import { SuggestItemLocationEntity } from '@entities/suggest-item-location/suggest-item-location.entity';
import { Inject } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { isEmpty, keyBy, map, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, ILike, In, Not } from 'typeorm';
import { CreateSuggestItemLocationRequestDto } from './dto/request/create-suggest-item-location.request.dto';
import { GetSuggestItemLocationDetailRequestDto } from './dto/request/get-detail-suggest-item-location.request.dto';
import { GetListSuggestItemLocationRequestDto } from './dto/request/get-list-suggest-item-location.request.dto';
import { GetSuggestItemLocationByListConditionRequestDto } from './dto/request/get-suggest-item-location-by-list-condition.request.dto';
import { GetLocationByIdsRequestDto } from './dto/request/get-location-by-ids.request.dto';
import { UpdateSuggestItemLocationRequestDto } from './dto/request/update-suggest-item-location.request.dto';
import { GetDetailSuggestItemLocationResponseDto } from './dto/response/get-detail-suggest-item-location.response.dto';
import { SuggestItemLocationResponseDto } from './dto/response/suggest-item-location.response.dto';
import { SuggestItemLocationDetailRepositoryInterface } from './interface/suggest-item-location-detail.repository.interface';
import { SuggestItemLocationRepositoryInterface } from './interface/suggest-item-location.repository.interface';
import { SuggestItemLocationServiceInterface } from './interface/suggest-item-location.service.interface';

export class SuggestLocationService
  implements SuggestItemLocationServiceInterface
{
  constructor(
    @Inject('UserServiceInterface')
    private readonly userService: UserService,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('WarehouseShelfRepositoryInterface')
    private readonly warehouseShelfRepository: WarehouseShelfRepositoryInterface,

    @Inject('WarehouseSectorRepositoryInterface')
    private readonly warehouseSectorRepository: WarehouseSectorRepositoryInterface,

    @Inject('WarehouseShelfFloorRepositoryInterface')
    private readonly warehouseShelfFloorRepository: WarehouseShelfFloorRepositoryInterface,

    @Inject('SuggestItemLocationRepositoryInterface')
    private readonly suggestItemLocationRepository: SuggestItemLocationRepositoryInterface,

    @Inject('SuggestItemLocationDetailRepositoryInterface')
    private readonly suggestItemLocationDetailRepository: SuggestItemLocationDetailRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,

    @InjectDataSource()
    private readonly connection: DataSource,
  ) {}

  async create(
    request: CreateSuggestItemLocationRequestDto,
  ): Promise<ResponsePayload<any>> {
    const isLocationExist =
      await this.suggestItemLocationRepository.findOneByCondition({
        code: ILike(request.code),
      });
    if (isLocationExist) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_IS_EXIST'),
      ).toResponse();
    }

    // validate items
    const itemIds = request?.itemIds || [];
    const itemsExist = request?.itemIds
      ? await this.itemService.getItems(itemIds)
      : [];

    if (uniq(itemIds).length !== itemsExist.length) {
      const itemIdsExist = itemsExist ? itemsExist.map((e) => e.itemId) : [];
      return new ResponseBuilder({
        invalidItems: request.itemIds.filter((e) => !itemIdsExist.includes(e)),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }
    const validateLocation = await this.validateLocation(request.itemLocations);
    if (validateLocation) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.LOCATION_IS_EXIST'),
      ).toResponse();
    }
    // validate relationship warehouse
    const checkSectorShelfFloor = await this.validatePosition(
      request.itemLocations,
    );

    if (checkSectorShelfFloor.statusCode !== ResponseCodeEnum.SUCCESS) {
      return checkSectorShelfFloor;
    }

    // validate warehouse shelf floor
    const warehouseShelfFloorIds = uniq(
      map(request.itemLocations, 'warehouseShelfFloorId'),
    );
    const isWarehouseShelfFloor =
      await this.suggestItemLocationDetailRepository.findWithRelations({
        where: {
          warehouseShelfFloorId: In(warehouseShelfFloorIds),
        },
      });

    if (!isEmpty(isWarehouseShelfFloor)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.HAS_WAREHOUSE_SHELF_FLOOR_IN_LOCATION',
        ),
      ).toResponse();
    }

    let tempArr: any[] = [];

    request?.itemLocations.forEach((location: any) => {
      const arrItem = itemIds.map((itemId) => {
        return {
          ...location,
          itemId: itemId,
        };
      });
      tempArr = tempArr.concat(arrItem);
    });

    if (isEmpty(tempArr)) {
      tempArr = request.itemLocations;
    }

    const itemLocations =
      this.suggestItemLocationDetailRepository.createEntities(tempArr);

    const suggestEntity = await this.suggestItemLocationRepository.createEntity(
      { ...request, itemLocations },
    );

    return await this.save(suggestEntity, []);
  }

  async update(
    request: UpdateSuggestItemLocationRequestDto | any,
  ): Promise<ResponsePayload<any>> {
    const locationFind = await this.suggestItemLocationRepository.findOneById(
      request.id,
    );

    if (!locationFind) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const isLocationExist =
      await this.suggestItemLocationRepository.findOneByCondition({
        code: ILike(request.code),
        id: Not(request.id),
      });

    if (isLocationExist) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_IS_EXIST'),
      ).toResponse();
    }
    const validateLocation = await this.validateLocation(request.itemLocations);
    if (validateLocation) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.LOCATION_IS_EXIST'),
      ).toResponse();
    }
    // validate item
    const itemIds = request?.itemIds || [];
    const itemsExist = request?.itemIds
      ? await this.itemService.getItems(itemIds)
      : [];

    if (uniq(itemIds).length !== itemsExist.length) {
      const itemIdsExist = itemsExist ? itemsExist.map((e) => e.itemId) : [];
      return new ResponseBuilder({
        invalidItems: request.itemIds.filter((e) => !itemIdsExist.includes(e)),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }

    // validate relationship warehouse
    const checkSectorShelfFloor = await this.validatePosition(
      request.itemLocations,
    );

    if (checkSectorShelfFloor.statusCode !== ResponseCodeEnum.SUCCESS) {
      return checkSectorShelfFloor;
    }
    // validate warehouse shelf floor
    const warehouseShelfFloorIds = uniq(
      map(request.itemLocations, 'warehouseShelfFloorId'),
    );
    const isWarehouseShelfFloor =
      await this.suggestItemLocationDetailRepository.findWithRelations({
        where: {
          warehouseShelfFloorId: In(warehouseShelfFloorIds),
          id: Not(request.locationId),
        },
      });

    if (!isEmpty(isWarehouseShelfFloor)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.HAS_WAREHOUSE_SHELF_FLOOR_IN_LOCATION',
        ),
      ).toResponse();
    }

    const itemLocationDetail =
      await this.suggestItemLocationDetailRepository.findWithRelations({
        where: {
          locationId: request.id,
        },
      });

    const itemLocationDetailIds = uniq(map(itemLocationDetail, 'id'));

    let tempArr: any[] = [];

    request?.itemLocations.forEach((location: any) => {
      const arrItem = itemIds.map((itemId) => {
        return {
          ...location,
          itemId: itemId,
        };
      });
      tempArr = tempArr.concat(arrItem);
    });

    if (isEmpty(tempArr)) {
      tempArr = request.itemLocations;
    }

    const itemLocations =
      this.suggestItemLocationDetailRepository.createEntities(tempArr);

    const suggestEntity = await this.suggestItemLocationRepository.updateEntity(
      locationFind,
      { ...request, itemLocations },
    );

    return await this.save(suggestEntity, itemLocationDetailIds);
  }

  private async validateLocation(itemLocations: any) {
    const warehouseIds = uniq(map(itemLocations, 'warehouseId'));
    const warehouses = await this.warehouseRepository.findWithRelations({
      where: {
        id: In(warehouseIds),
      },
    });
    const warehouseSetorIds = uniq(map(itemLocations, 'warehouseSetorId'));
    const warehouseSetors =
      await this.warehouseSectorRepository.findWithRelations({
        where: {
          id: In(warehouseSetorIds),
        },
      });

    const warehouseShelfIds = uniq(map(itemLocations, 'warehouseShelfId'));
    const warehouseShelfs =
      await this.warehouseShelfRepository.findWithRelations({
        where: {
          id: In(warehouseShelfIds),
        },
      });
    const warehouseShelfFloorIds = uniq(
      map(itemLocations, 'warehouseShelfFloorId'),
    );
    const warehouseShelfFloors =
      await this.warehouseShelfFloorRepository.findWithRelations({
        where: {
          id: In(warehouseShelfFloorIds),
        },
      });

    const isValid =
      warehouses.length < warehouseIds.length ||
      warehouseSetors.length < warehouseSetorIds.length ||
      warehouseShelfs.length < warehouseShelfIds.length ||
      warehouseShelfFloors.length < warehouseShelfFloorIds.length;

    return isValid;
  }

  private async validatePosition(items): Promise<any> {
    const itemIds = [];
    const listSectorIdShelfIdFloorId = [];

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.id) {
        itemIds.push(item.id);
      }
      const position = {} as any;
      position.warehouseId = item.warehouseId;
      if (item.warehouseSetorId) {
        position.warehouseSectorId = item.warehouseSetorId;
      }
      if (item.warehouseShelfId) {
        position.warehouseShelfId = item.warehouseShelfId;
      }
      if (item.warehouseShelfFloorId) {
        position.id = item.warehouseShelfFloorId;
      }
      if (!isEmpty(position)) {
        listSectorIdShelfIdFloorId.push(position);
      }
    }

    const warehouseShelfFloors =
      await this.warehouseShelfFloorRepository.checkSectorShelfFloorInWarehouse(
        listSectorIdShelfIdFloorId,
      );

    let checkSectorShelfFloor = true;
    listSectorIdShelfIdFloorId.forEach((condition) => {
      const attributes = Object.keys(condition);
      const floor = warehouseShelfFloors.find((floor) => {
        let isPassed = true;
        attributes.forEach((attribute) => {
          if (floor[attribute] !== condition[attribute]) {
            isPassed = false;
          }
        });
        return isPassed;
      });
      if (!floor) {
        checkSectorShelfFloor = false;
      }
    });

    if (!checkSectorShelfFloor) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.SECTOR_SHELF_FLOOR_NOT_IN_WAREHOUSE',
          ),
        )
        .build();
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async save(
    entity: SuggestItemLocationEntity,
    ids: any,
  ): Promise<ResponsePayload<any> | any> {
    const code = ResponseCodeEnum.SUCCESS;

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (!isEmpty(ids)) {
        await queryRunner.manager.delete(SuggestItemLocationDetailEntity, {
          locationId: entity.id,
        });
      }
      const result = await queryRunner.manager.save(entity);
      await queryRunner.commitTransaction();
      return new ResponseBuilder(result)
        .withCode(code)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  async getList(
    payload: GetListSuggestItemLocationRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { page } = payload;
    const [data, count] = await this.suggestItemLocationRepository.getList(
      payload,
    );

    const dataReturn = plainToInstance(SuggestItemLocationResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDetail(
    payload: GetSuggestItemLocationDetailRequestDto,
  ): Promise<ResponsePayload<any>> {
    const location = await this.suggestItemLocationRepository.getDetail(
      payload,
    );

    if (!location)
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();

    // detail item
    const itemIds = uniq(map(location.items, 'itemId'));
    const items = await this.itemService.getItems(
      itemIds.filter((itemId) => itemId),
    );
    const itemMap = keyBy(items, 'itemId');

    const resultItem = !isEmpty(itemMap)
      ? location.items.map((item) => ({
          itemId: itemMap[item.itemId].itemId,
          code: itemMap[item.itemId].code,
          name: itemMap[item.itemId].name,
        }))
      : [];

    // detail warehouse
    const warehouseIds = uniq(map(location.itemLocations, 'warehouseId'));
    const warehouses = await this.warehouseRepository.findWithRelations({
      where: {
        id: In(warehouseIds),
      },
    });
    const warehouseMap = keyBy(warehouses, 'id');

    const warehouseSetorIds = uniq(
      map(location.itemLocations, 'warehouseSetorId'),
    );
    const warehouseSetors =
      await this.warehouseSectorRepository.findWithRelations({
        where: {
          id: In(warehouseSetorIds),
        },
      });
    const warehouseSectorMap = keyBy(warehouseSetors, 'id');

    const warehouseShelfIds = uniq(
      map(location.itemLocations, 'warehouseShelfId'),
    );
    const warehouseShelfs =
      await this.warehouseShelfRepository.findWithRelations({
        where: {
          id: In(warehouseShelfIds),
        },
      });
    const warehouseShelfMap = keyBy(warehouseShelfs, 'id');

    const warehouseShelfFloorIds = uniq(
      map(location.itemLocations, 'warehouseShelfFloorId'),
    );
    const warehouseShelfFloors =
      await this.warehouseShelfFloorRepository.findWithRelations({
        where: {
          id: In(warehouseShelfFloorIds),
        },
      });
    const warehouseShelfFloorMap = keyBy(warehouseShelfFloors, 'id');

    const resultLocations = location.itemLocations.map((item) => ({
      ...item,
      warehouse: warehouseMap[item.warehouseId],
      warehouseSetor: warehouseSectorMap[item.warehouseSetorId],
      warehouseShelf: warehouseShelfMap[item.warehouseShelfId],
      warehouseShelfFloor: warehouseShelfFloorMap[item.warehouseShelfFloorId],
    }));

    const dataReturn = plainToInstance(
      GetDetailSuggestItemLocationResponseDto,
      { ...location, items: resultItem, itemLocations: resultLocations },
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async delete(
    payload: GetSuggestItemLocationDetailRequestDto,
  ): Promise<ResponsePayload<any>> {
    const location = await this.suggestItemLocationRepository.findOneById(
      payload.id,
    );
    if (!location) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.delete(SuggestItemLocationEntity, payload.id);
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
  }

  async getSuggestItemLocationByListCondition(
    request: GetSuggestItemLocationByListConditionRequestDto,
  ): Promise<any> {
    const data =
      await this.suggestItemLocationDetailRepository.getSuggestItemLocationByListCondition(
        request.listCondition,
      );
    return new ResponseBuilder(data).withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async getLocationByIds(
    request: GetLocationByIdsRequestDto,
  ): Promise<ResponsePayload<any>> {
    const locations = await this.suggestItemLocationRepository.findByCondition({
      id: In(request.ids),
    });

    return new ResponseBuilder(locations)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
