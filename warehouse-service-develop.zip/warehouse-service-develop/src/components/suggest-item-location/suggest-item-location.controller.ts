import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import {
  CREATE_SUGGEST_ITEM_LOCATION_PERMISSION,
  DELETE_SUGGEST_ITEM_LOCATION_PERMISSION,
  DETAIL_SUGGEST_ITEM_LOCATION_PERMISSION,
  LIST_SUGGEST_ITEM_LOCATION_PERMISSION,
  UPDATE_SUGGEST_ITEM_LOCATION_PERMISSION,
} from '@utils/permissions/suggest-item-location';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateSuggestItemLocationRequestDto } from './dto/request/create-suggest-item-location.request.dto';
import { GetSuggestItemLocationDetailRequestDto } from './dto/request/get-detail-suggest-item-location.request.dto';
import { GetListSuggestItemLocationRequestDto } from './dto/request/get-list-suggest-item-location.request.dto';
import { GetSuggestItemLocationByListConditionRequestDto } from './dto/request/get-suggest-item-location-by-list-condition.request.dto';
import { GetLocationByIdsRequestDto } from './dto/request/get-location-by-ids.request.dto';
import { UpdateSuggestItemLocationBodyDto } from './dto/request/update-suggest-item-location.request.dto';
import { GetDetailSuggestItemLocationResponseDto } from './dto/response/get-detail-suggest-item-location.response.dto';
import { SuggestItemLocationResponseDto } from './dto/response/suggest-item-location.response.dto';
import { SuggestItemLocationServiceInterface } from './interface/suggest-item-location.service.interface';
import { NATS_WAREHOUSE } from '@config/nats.config';

@Controller('suggest-item-locations')
export class SuggestItemLocationController {
  constructor(
    @Inject('SuggestItemLocationServiceInterface')
    private readonly suggestItemLocationService: SuggestItemLocationServiceInterface,
  ) {}
  @Post('/create')
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: SuggestItemLocationResponseDto,
  })
  @PermissionCode(CREATE_SUGGEST_ITEM_LOCATION_PERMISSION.code)
  @MessagePattern(`${NATS_WAREHOUSE}.create_suggest_item_location`)
  public async createSuggestItemLocation(
    @Body() body: CreateSuggestItemLocationRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suggestItemLocationService.create(request);
  }

  @PermissionCode(LIST_SUGGEST_ITEM_LOCATION_PERMISSION.code)
  @Get('/list')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'suggest item location list',
    description: 'Danh sách vị trí',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: SuggestItemLocationResponseDto,
  })
  // @MessagePattern('list_suggest_item_location')
  public async getList(
    @Query() payload: GetListSuggestItemLocationRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suggestItemLocationService.getList({
      ...request,
      id: Number(request.id),
    });
  }

  @MessagePattern(`${NATS_WAREHOUSE}.get_location_by_ids`)
  public async getLocationByIds(
    @Body() payload: GetLocationByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suggestItemLocationService.getLocationByIds(request);
  }

  @PermissionCode(DETAIL_SUGGEST_ITEM_LOCATION_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'detail suggest item location',
    description: 'Chi tiết vi trí',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: GetDetailSuggestItemLocationResponseDto,
  })
  // @MessagePattern('detail_suggest_item_location')
  public async getDetail(
    @Param() payload: GetSuggestItemLocationDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suggestItemLocationService.getDetail(request);
  }

  @PermissionCode(DELETE_SUGGEST_ITEM_LOCATION_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'Delete Suggest Item Location',
    description: 'Xóa vị trí',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  // @MessagePattern('detele_suggest_item_location')
  public async delete(
    @Param() payload: GetSuggestItemLocationDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suggestItemLocationService.delete(request);
  }

  @PermissionCode(UPDATE_SUGGEST_ITEM_LOCATION_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Warehouse'],
    summary: 'update suggest item location',
    description: 'Sửa thiết lập vị trí',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: CreateSuggestItemLocationRequestDto,
  })
  // @MessagePattern('update_suggest_item_location')
  public async updateSuggestItemLocation(
    @Param('id', new ParseIntPipe()) id,
    @Body() body: UpdateSuggestItemLocationBodyDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = Number(id);
    return await this.suggestItemLocationService.update(request);
  }

  @MessagePattern(
    `${NATS_WAREHOUSE}.get_suggest_item_locator_by_list_condition`,
  )
  public async getSuggestItemLocationByListCondition(
    @Body() body: GetSuggestItemLocationByListConditionRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suggestItemLocationService.getSuggestItemLocationByListCondition(
      request,
    );
  }
}
