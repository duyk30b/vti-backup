import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { isEmpty } from 'lodash';
import { GetListReportStockQueryDto } from './dto/query/get-list-report-stock.query.dto';
import { ReportItemQuery } from './dto/query/report-item.query';
import { WarehouseReportDetailQuery } from './dto/query/warehouse-report-detail.query';
import { WarehouseReportQuery } from './dto/query/warehouse-report.query';
import { CreateReportBodyDto } from './dto/request/create-report.request.dto';
import { DeleteReportRequestDto } from './dto/request/delete-report.request.dto';
import { WarehouseReportServiceInterface } from './interface/warehouse-report.service.interface';
import {
  CREATE_WAREHOUSE_REPORT_PERMISSION,
  DELETE_WAREHOUSE_REPORT_PERMISSION,
  DETAIL_WAREHOUSE_REPORT_PERMISSION,
  LIST_WAREHOUSE_REPORT_PERMISSION,
} from '@utils/permissions/warehouse-report';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { LIST_WAREHOUSE_REPORT_STOCK_PERMISSION } from '@utils/permissions/warehouse-report-stock';
import { ReportGapsInStockQuery } from './dto/query/report-gaps-in-stock.query';
import { ReportMonthMovementCountQuery } from './dto/query/report-month-movement-count.query';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ApiOperation, ApiQuery, ApiResponse } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { DETAIL_WAREHOUSE_SPACE_PERMISSION } from '@utils/permissions/warehouse-space';
import { WarehouseSectorVolumeReportResponse } from '@components/warehouse-sector/dto/response/get-warehouse-sector-volume-report.response.dto';
import { GetWarehouseSectorVolumeReportRequestDto } from '@components/warehouse-sector/dto/request/get-warehouse-sector-volume-report.request.dto';
import { WarehouseSectorServiceInterface } from '@components/warehouse-sector/interface/warehouse-sector.sevice.interface';
import { SEARCH_INVENTORY_MANAGEMENT_PERMISSION } from '@utils/permissions/inventory-management';

@Controller('reports')
export class WarehouseReportController {
  constructor(
    @Inject('WarehouseReportServiceInterface')
    private readonly warehouseReportService: WarehouseReportServiceInterface,

    @Inject('WarehouseSectorServiceInterface')
    private readonly warehouseSectorService: WarehouseSectorServiceInterface,
  ) {}

  // @MessagePattern('create_daily_report')
  @Post('/daily')
  @ApiOperation({
    tags: ['Report', 'Warehouse'],
    summary: 'Create report',
    description: 'Tạo báo cáo - quản lý tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: SuccessResponse,
  })
  public async createDailyReport(): Promise<any> {
    return await this.warehouseReportService.createDailyReport();
  }

  @PermissionCode(CREATE_WAREHOUSE_REPORT_PERMISSION.code)
  // @MessagePattern('create_report')
  @Post('/')
  @ApiOperation({
    tags: ['Report', 'Warehouse'],
    summary: 'Create report',
    description: 'Tạo báo cáo - quản lý tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: SuccessResponse,
  })
  public async createReport(
    @Body() payload: CreateReportBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseReportService.createReport({
      ...request,
      createdBy: request.userId,
    });
  }

  @PermissionCode(LIST_WAREHOUSE_REPORT_PERMISSION.code)
  // @MessagePattern('get_reports')
  @Get('')
  @ApiOperation({
    tags: ['Report', 'Warehouse'],
    summary: 'Get list report',
    description: 'Lấy danh sách báo cáo',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  @ApiQuery({
    example: {
      keyword: 'demo',
      warehouseId: 1,
      page: 2,
    },
  })
  public async getReports(@Query() query: WarehouseReportQuery): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseReportService.getReports(request);
  }

  @PermissionCode(DETAIL_WAREHOUSE_REPORT_PERMISSION.code)
  // @MessagePattern('get_report')
  @Get('/:reportId')
  @ApiOperation({
    tags: ['Report', 'Warehouse'],
    summary: 'Get single report',
    description: 'Xem chi tiết 1 báo cáo',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async getReport(
    @Param() param: WarehouseReportDetailQuery,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseReportService.getReport(request);
  }

  @PermissionCode(DELETE_WAREHOUSE_REPORT_PERMISSION.code)
  // @MessagePattern('delete_report')
  @Delete('/:reportId')
  @ApiOperation({
    tags: ['Report', 'Warehouse'],
    summary: 'Delete report',
    description: 'Xóa 1 report',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteReport(
    @Param() param: DeleteReportRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseReportService.deleteReport(request.reportId);
  }

  @PermissionCode(DELETE_WAREHOUSE_REPORT_PERMISSION.code)
  // @MessagePattern('delete_report_multiple')
  @Delete('/multiple')
  public async deleteMultipleReport(
    @Query() query: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseReportService.deleteMultipleReport(request);
  }

  @PermissionCode(SEARCH_INVENTORY_MANAGEMENT_PERMISSION.code)
  // @MessagePattern('get_report_stock')
  @Get('/stock')
  @ApiOperation({
    tags: ['Report', 'Warehouse'],
    summary: 'Get list stock by day',
    description: 'Lấy danh sách item tồn kho theo ngày,Tra cứu tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  @ApiQuery({
    example: {
      reportDate: '2021-06-07T00:00:00.000Z',
      page: 1,
    },
  })
  public async getReportStock(
    @Query() query: GetListReportStockQueryDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseReportService.getReportStock(request);
  }
  //TODO
  // @MessagePattern('month_movement_count')
  public async reportMonthMovementCount(
    @Body() payload: ReportMonthMovementCountQuery,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseReportService.reportMonthMovementCount(request);
  }

  @Get('/reports/report-tranfer')
  // @MessagePattern('report_count_item_tranfer')
  public async reportCountItemTransfer(
    @Query() payload: ReportItemQuery,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseReportService.reportCountItemTransfer(request);
  }

  // @MessagePattern('report_item_stock')
  @Get('/report-stock')
  public async reportItemStock(@Query() query: ReportItemQuery): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseReportService.reportItemStock(request);
  }

  // @MessagePattern('report_gaps_in_stock')
  @Get('sectors-fullments')
  public async reportGapsInStock(
    @Query() param: ReportGapsInStockQuery,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseReportService.reportGapsInStock(request);
  }

  //TODO remove when refactor done
  @MessagePattern('report_gaps_in_stock')
  public async reportGapsInStockTcp(
    @Body() payload: ReportGapsInStockQuery,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseReportService.reportGapsInStock(request);
  }

  @Get('/reports/report-stock')
  public async reportItemStockTcp(
    @Query() payload: ReportItemQuery,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseReportService.reportItemStock(request);
  }

  @Get('/report-tranfer')
  @MessagePattern('report_count_item_tranfer')
  public async reportCountItemTransferTcp(
    @Query() payload: ReportItemQuery,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseReportService.reportCountItemTransfer(request);
  }

  @Get('/month-movement')
  @MessagePattern('month_movement_count')
  public async reportMonthMovementCountTcp(
    @Query() payload: ReportMonthMovementCountQuery,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.warehouseReportService.reportMonthMovementCount(request);
  }

  // @PermissionCode(DETAIL_WAREHOUSE_SPACE_PERMISSION.code)
  // @MessagePattern('get_sector_volume_report')
  @Get(':warehouseId/sectors/volumes')
  @ApiOperation({
    tags: ['Report', 'Warehouse', 'Sector', 'Volume'],
    summary: 'Get warehouse sector volume report',
    description: 'Báo cáo khoảng trống tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: WarehouseSectorVolumeReportResponse,
  })
  public async getSectorVolumeReport(
    @Param() param: GetWarehouseSectorVolumeReportRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.warehouseSectorService.getSectorVolumeReport(request);
  }
}
