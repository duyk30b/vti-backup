import { Expose, Type } from 'class-transformer';

export class GapsInStockResponse {
  @Expose()
  warehouseSectorId: number;

  @Expose()
  warehouseSectorCode: string;

  @Expose()
  @Type(() => Number)
  warehouseSectorFullmentPercent: number;
}
