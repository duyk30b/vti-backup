import { Expose } from 'class-transformer';

export class WarehousReportDetailResponse {
  @Expose()
  itemId: number;

  @Expose()
  itemName: string;

  @Expose()
  itemType: string;

  @Expose()
  itemUnit: string;

  @Expose()
  warehouseId: number;

  @Expose()
  warehouseName: string;

  @Expose()
  stockStart: number;

  @Expose()
  stockEnd: number;

  @Expose()
  stockIn: number;

  @Expose()
  stockOut: number;
}
