import { Expose } from 'class-transformer';

export class WarehouseItemReport {
  @Expose()
  warehouseId: number;

  @Expose()
  itemId: number;

  @Expose()
  quantityStart: number;

  @Expose()
  quantityEnd: number;

  @Expose()
  quantityIn: number;

  @Expose()
  quantityOut: number;
}
