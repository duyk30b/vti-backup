import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';

class WarehouseTypeReport {
  @Expose()
  id: number;

  @Expose()
  name: string;
}

class Package {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: number;
}
class Locator {
  @Expose()
  locatorId: number;

  @Expose()
  name: string;

  @Expose()
  code: string;
}

export class ReportStockResponse {
  @Expose()
  itemId: number;

  @Expose()
  itemName: string;

  @Expose()
  itemCode: string;

  @Expose()
  itemTypeId: number;

  @Expose()
  itemTypeName: string;

  @Expose()
  warehouseId: number;

  @Expose()
  warehouseName: string;

  @Expose()
  @Type(() => WarehouseTypeReport)
  warehouseTypes: WarehouseTypeReport[];

  @Expose()
  itemGroupId: number;

  @Expose()
  itemGroupName: string;

  @Expose()
  stock: number;

  @Expose()
  itemUnitId: number;

  @Expose()
  itemUnitName: string;

  @Expose()
  quantity: number;

  @Expose()
  cost: number;

  @Expose()
  checkInventory: boolean;

  @Expose()
  checkWarning: boolean;

  @Expose()
  locatorId: boolean;

  @Expose()
  lotNumber: string;

  @Expose()
  type: string;

  @Expose()
  purpose: string;

  @Expose()
  amount: number;

  @Expose()
  totalAmount: number;

  @Expose()
  @Type(() => Locator)
  locator: Locator;
}
