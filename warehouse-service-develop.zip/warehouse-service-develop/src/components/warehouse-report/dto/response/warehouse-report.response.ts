import { PagingResponse } from '@utils/paging.response';
import { Expose, Type } from 'class-transformer';

export class CreatedBy {
  @Expose()
  id: number;

  @Expose()
  username: string;

  @Expose()
  fullName: string;
}
export class WarehousReportResponse {
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  startDate: Date;

  @Expose()
  endDate: Date;

  @Expose()
  @Type(() => CreatedBy)
  createdBy: CreatedBy;

  @Expose()
  note: string;

  @Expose()
  createdOn: string;

  @Expose()
  @Type(() => WarehouseReport)
  warehouses: WarehouseReport[];

  @Expose()
  @Type(() => PagingResponse)
  reportDetails?: PagingResponse;
}

class Factory {
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  name: string;
}

export class WarehouseReport {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Type(() => Factory)
  @Expose()
  factory: Factory;
}
