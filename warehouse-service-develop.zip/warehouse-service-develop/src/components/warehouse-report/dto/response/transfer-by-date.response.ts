import { Expose } from 'class-transformer';

export class TransferByDateResponse {
  @Expose()
  date: string;

  @Expose()
  quantity: number;
}
