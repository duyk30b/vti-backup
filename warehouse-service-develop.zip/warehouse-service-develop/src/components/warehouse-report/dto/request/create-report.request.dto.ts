import { BaseDto } from '@core/dto/base.dto';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

export class CreateReportBodyDto extends BaseDto {
  @IsNotEmpty()
  code: string;

  @MaxLength(255)
  @IsNotEmpty()
  name: string;

  @IsInt({ each: true })
  @ArrayNotEmpty()
  @ArrayUnique<number>((i) => i)
  warehouseIds: number[];

  @IsDateString()
  @IsNotEmpty()
  startDate: Date;

  @IsDateString()
  @IsNotEmpty()
  endDate: Date;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  note: string;
}

export class CreateReportRequestDto extends CreateReportBodyDto {
  @IsInt()
  @IsNotEmpty()
  createdBy: number;

  // @ArrayNotEmpty()
  // @Type(() => ReportItem)
  // @ValidateNested()
  // @ArrayUnique<ReportItem>((i) => `${i.itemId}_${i.warehouseId}`)
  // reportItems: ReportItem[];
}

// export class ReportItem {
//   @IsInt()
//   @IsNotEmpty()
//   itemId: number;

//   @IsNumber()
//   @IsNotEmpty()
//   warehouseId: number;
// }
