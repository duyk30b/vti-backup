import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';
import { IsNotEmpty } from 'class-validator';

export class DeleteReportRequestDto extends BaseDto {
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  reportId: number;
}
