import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';
import { WarehouseReportQuery } from './warehouse-report.query';

export class WarehouseReportDetailQuery extends WarehouseReportQuery {
  @IsInt()
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  reportId: number;
}
