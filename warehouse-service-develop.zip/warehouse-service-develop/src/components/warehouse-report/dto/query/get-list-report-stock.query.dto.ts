import { PaginationQuery } from '@utils/pagination.query';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsDateString, IsEnum } from 'class-validator';

export class GetListReportStockQueryDto extends PaginationQuery {
  @ApiProperty({ example: '2021-06-07T00:00:00.000Z' })
  @IsOptional()
  @IsDateString()
  reportDate: Date;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;
}
