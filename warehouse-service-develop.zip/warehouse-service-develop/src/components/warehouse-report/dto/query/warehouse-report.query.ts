import { ApiProperty } from '@nestjs/swagger';
import { EnumSort } from '@utils/common';
import { PaginationQuery } from '@utils/pagination.query';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
} from 'class-validator';

class Sort {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  column: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  @IsEnum(EnumSort)
  order: any;
}

class Filter {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  column: string;

  @IsString()
  @ApiProperty()
  @IsNotEmpty()
  text: string;
}
export class WarehouseReportQuery extends PaginationQuery {
  @ApiProperty({ example: 'item type', description: '' })
  @IsOptional()
  @IsString()
  keyword?: string;

  @ApiProperty({
    example: [{ column: 'code', text: 'item type' }],
    description: '',
  })
  @IsOptional()
  @IsArray()
  @Type(() => Filter)
  filter?: Filter[];

  @ApiProperty({
    example: [{ column: 'code', order: 'DESC' }],
    description: '',
  })
  @Type(() => Sort)
  @IsArray()
  @IsOptional()
  sort?: Sort[];
}
