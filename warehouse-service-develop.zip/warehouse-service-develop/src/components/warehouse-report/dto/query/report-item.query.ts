import {
  TransactionType,
  ReportType,
} from '@components/warehouse-report/warehouse-report.constant';
import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';
import {
  IsDateString,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsOptional,
} from 'class-validator';

export class ReportItemQuery extends BaseDto {
  @IsEnum(TransactionType)
  @Transform((data) => Number(data.value))
  @IsOptional()
  transactionType: TransactionType;

  @IsInt()
  @Transform((data) => Number(data.value))
  @IsOptional()
  itemTypeId: number;

  @IsEnum(ReportType)
  @Transform((data) => Number(data.value))
  @IsNotEmpty()
  reportType: ReportType;

  @IsDateString()
  @IsOptional()
  startDate: Date;

  @IsDateString()
  @IsOptional()
  endDate: Date;
}
