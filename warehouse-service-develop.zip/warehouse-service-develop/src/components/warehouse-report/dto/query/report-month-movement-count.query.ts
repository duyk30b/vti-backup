import { BaseDto } from '@core/dto/base.dto';
import { IsDateString, IsOptional } from 'class-validator';

export class ReportMonthMovementCountQuery extends BaseDto {
  @IsDateString()
  @IsOptional()
  startDate: Date;

  @IsDateString()
  @IsOptional()
  endDate: Date;
}
