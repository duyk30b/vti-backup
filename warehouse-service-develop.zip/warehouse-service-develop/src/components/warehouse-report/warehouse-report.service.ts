import {
  WarehouseMovementTypeEnum,
  WAREHOUSE_EXPORT_MOVEMENT_TYPES,
  WAREHOUSE_IMPORT_MOVEMENT_TYPES,
  WAREHOUSE_TRANSFER_MOVEMENT_TYPES,
} from '@components/warehouse/warehouse.constant';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { WarehouseStockMovementRepository } from '@repositories/warehouse-stock-movement.repository';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { DataSource, In } from 'typeorm';
import * as moment from 'moment';
import { WarehouseReportQuery } from './dto/query/warehouse-report.query';
import { CreateReportRequestDto } from './dto/request/create-report.request.dto';
import { WarehousReportDetailResponse } from './dto/response/warehouse-report-detail.response';
import {
  CreatedBy,
  WarehouseReport,
  WarehousReportResponse,
} from './dto/response/warehouse-report.response';
import { WarehouseReportDetailRepositoryInterface } from './interface/warehouse-report-detail.repository.interface';
import { WarehouseReportRepositoryInterface } from './interface/warehouse-report.repository.interface';
import { WarehouseReportServiceInterface } from './interface/warehouse-report.service.interface';
import { WarehouseDailyReportRepositoryInterface } from './interface/warehouse-daily-report.repository.interface';
import { WarehouseItemReport } from './dto/response/warehouse-item-report.response';
import { WarehouseReportDetailQuery } from './dto/query/warehouse-report-detail.query';
import { DeleteReportRequestDto } from './dto/request/delete-report.request.dto';
import {
  ReportByDay,
  ReportTransfer,
  ReportStockByDay,
  StockMovementIdByDate,
  RangeDate,
  ReportCountTranfer,
} from './dto/response/report-by-type.response';
import { WarehouseTransferRepositoryInterface } from '@components/warehouse-transfer/interface/warehouse-transfer.repository.interface';
import { ReportItemQuery } from './dto/query/report-item.query';
import {
  ReportType,
  SYNC_REPORT_DAILY_LIMIT_RECORDS,
  SYNC_REPORT_DAILY_TOPIC,
  TransactionType,
} from './warehouse-report.constant';
import { TransferByDateResponse } from './dto/response/transfer-by-date.response';
import { div, formatUnitMeasures, mul, plus } from '@utils/common';
import { Cron } from '@nestjs/schedule';
import { GetListReportStockQueryDto } from './dto/query/get-list-report-stock.query.dto';
import { ReportStockResponse } from './dto/response/warehouse-report-stock.response';
import { WarehouseDailyReportDetailRepositoryInterface } from './interface/warehouse-daily-report-detail.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { isEmpty, uniq, has, values } from 'lodash';
import { I18nService } from 'nestjs-i18n';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { WarehouseDataResponseDto } from '@components/warehouse/dto/response/warehouse-data.response.dto';
import { ReportGapsInStockQuery } from './dto/query/report-gaps-in-stock.query';
import { GapsInStockResponse } from './dto/response/report-gaps-in-stock.response';
import { WarehouseSectorRepositoryInterface } from '@components/warehouse-sector/interface/warehouse-sector.repository.interface';
import { ReportMonthMovementCountQuery } from './dto/query/report-month-movement-count.query';
import { ItemCronService } from '@components/item/item-cron.service';
import { WarehouseShelfFloorRepositoryInterface } from '@components/warehouse-shelf-floor/interface/warehouse-shelf-floor.repository.interface';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { stringFormat } from '@utils/object.util';
import { WarehouseReport as WarehouseReportEntity } from '@entities/warehouse-report/warehouse-report.entity';
import { WarehouseReportDetail } from '@entities/warehouse-report/warehouse-report-detail.entity';
import { WarehouseReportWarehouse } from '@entities/warehouse-report/warehouse-report-warehouse.entity';
import { InjectDataSource } from '@nestjs/typeorm';
import { Producer } from 'kafkajs';
import { GetItemStockMovementInWarehouseLocatorByDay } from '@components/item/dto/request/get-item-stock-warehouse-locator-by-day.request.dto';
import { WarehouseLayoutServiceInterface } from '@components/warehouse-layout/interface/warehouse-layout.service.interface';
import { GetItemWarehouseStockRequestDto } from '@components/item/dto/request/get-item-stock.dto';
import { ConfigService } from '@config/config.service';

@Injectable()
export class WarehouseReportService implements WarehouseReportServiceInterface {
  private readonly logger = new Logger(WarehouseReportService.name);

  constructor(
    private readonly configService: ConfigService,

    private readonly itemService: ItemCronService,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('WarehouseReportRepositoryInterface')
    private readonly warehouseReportRepository: WarehouseReportRepositoryInterface,

    @Inject('WarehouseReportDetailRepositoryInterface')
    private readonly warehouseReportDetailRepository: WarehouseReportDetailRepositoryInterface,

    @Inject('WarehouseDailyReportRepositoryInterface')
    private readonly warehouseDailyReportRepository: WarehouseDailyReportRepositoryInterface,

    @Inject('WarehouseDailyReportDetailRepositoryInterface')
    private readonly warehouseDailyReportDetailRepository: WarehouseDailyReportDetailRepositoryInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('WarehouseStockMovementRepositoryInterface')
    private readonly warehouseStockMovementRepository: WarehouseStockMovementRepository,

    @Inject('WarehouseTransferRepositoryInterface')
    private readonly warehouseTransferRepository: WarehouseTransferRepositoryInterface,

    @Inject('WarehouseSectorRepositoryInterface')
    private readonly warehouseSectorRepository: WarehouseSectorRepositoryInterface,

    // @Inject('KAFKA_PRODUCER')
    // private kafkaProducer: Producer,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nService,
  ) {}

  async deleteReport(
    request: DeleteReportRequestDto,
  ): Promise<ResponsePayload<any>> {
    const report = await this.warehouseReportRepository.findOneWithRelations({
      where: {
        id: request.reportId,
      },
      relations: ['warehouseReportDetails', 'warehouseReportWarehouses'],
    });

    if (!report)
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.remove(report.warehouseReportDetails);
      await queryRunner.manager.remove(report.warehouseReportWarehouses);
      await queryRunner.manager.remove(report);
      await queryRunner.commitTransaction();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      this.logger.log('===Transaction Release');
      await queryRunner.release();
    }
  }

  /**
   * Delete
   */
  public async deleteMultipleReport(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const reports = await this.warehouseReportRepository.findWithRelations({
      where: {
        id: In(ids),
      },
      relations: ['warehouseReportDetails', 'warehouseReportWarehouses'],
    });

    const reportIds = reports.map((report) => report.id);
    if (reports.length !== ids.length) {
      ids.forEach((id) => {
        if (!reportIds.includes(id)) failIdsList.push(id);
      });
    }

    const validIds = reports
      .filter((report) => !failIdsList.includes(report.id))
      .map((report) => report.id);

    const queryRunner = await this.connection.createQueryRunner();
    try {
      if (!isEmpty(validIds)) {
        await queryRunner.startTransaction();
        await queryRunner.manager.delete(WarehouseReportDetail, {
          warehouseReportId: In(validIds),
        });
        await queryRunner.manager.delete(WarehouseReportWarehouse, {
          warehouseReportId: In(validIds),
        });
        await queryRunner.manager.delete(WarehouseReportEntity, validIds);
        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    await queryRunner.release();
    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  @Cron('30 00 * * *', {
    name: 'daily_report',
    timeZone: 'UTC',
  })
  async createDailyReport(): Promise<ResponsePayload<any>> {
    const date = moment()
      .subtract(1, 'day')
      .set({ minute: 0, hour: 0, second: 0, millisecond: 0 })
      .format('YYYY-MM-DD HH:mm:ss');
    this.logger.debug(`CRON JOB RUNNING AT 10 04 * * * ${date}`);
    const listWarehouseCreateError = [];
    let reportResult: any = {};
    let page = 1;

    const company = await this.userService.getCompanyDefault();
    while ((!isEmpty(reportResult.data) && page > 1) || page === 1) {
      reportResult = await this.creareDailyReportWarehouse(company, date, page);
      page++;
      if (!reportResult.success) {
        listWarehouseCreateError.push(reportResult.message);
      }
    }
    this.logger.debug(
      'CRON JOB STOP',
      JSON.stringify(listWarehouseCreateError),
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async creareDailyReportWarehouse(
    company,
    date,
    page: number,
  ): Promise<any> {
    try {
      const itemServiceRespone =
        await this.itemService.getItemLotWarehouseStockReport({
          page,
          limit: SYNC_REPORT_DAILY_LIMIT_RECORDS,
        } as GetItemWarehouseStockRequestDto);
      const itemStockWarehouseDaily = {};
      const itemStockLocatorDaily = {};
      const itemLotStockLocatorDaily = [];
      itemServiceRespone?.items?.forEach((itemStock) => {
        itemStock.locations.forEach((location) => {
          const warehouse = location?.warehouse;
          const locator = location?.locator;
          location.lots.forEach((lot) => {
            itemLotStockLocatorDaily.push({
              reportDate: date,
              lotNumber: lot.lotNumber,
              locatorName: locator?.name,
              locatorCode: locator?.code,
              itemCode: itemStock?.code,
              itemName: itemStock?.name,
              stockQuantity: lot.quantity,
              account: location?.accounting,
              companyCode: company.code,
              companyName: company.name,
              companyAddress: company.address,
              storageCost: lot.totalAmount,
              warehouseName: warehouse?.name,
              warehouseCode: warehouse?.code,
              unit: itemStock?.itemUnit?.name,
              minInventoryLimit: 0,
              inventoryLimit: 0,
              origin: lot?.origin,
              storageDate: lot.storageDate,
            });
            const keyItemWarehouse = [warehouse.code, itemStock.code].join('-');
            if (!has(itemStockWarehouseDaily, keyItemWarehouse)) {
              itemStockWarehouseDaily[keyItemWarehouse] = {
                reportDate: date,
                stockQuantity: 0,
                minInventoryLimit: 0,
                inventoryLimit: 0,
                storageCost: 0,
                companyCode: company.code,
                companyName: company.name,
                companyAddress: company.address,
                itemCode: itemStock?.code,
                itemName: itemStock?.name,
                warehouseName: warehouse?.name,
                warehouseCode: warehouse?.code,
                unit: itemStock?.itemUnit?.name,
              };
            }
            itemStockWarehouseDaily[keyItemWarehouse].storageCost = plus(
              itemStockWarehouseDaily[keyItemWarehouse].storageCost,
              lot.totalAmount,
            );
            itemStockWarehouseDaily[keyItemWarehouse].stockQuantity = plus(
              itemStockWarehouseDaily[keyItemWarehouse].stockQuantity,
              lot.quantity,
            );

            const keyItemWarehouseLocator = [
              warehouse.code,
              itemStock.code,
              itemStock.lotNumber,
            ].join('-');
            if (!has(itemStockLocatorDaily, keyItemWarehouseLocator)) {
              itemStockLocatorDaily[keyItemWarehouseLocator] = {
                reportDate: date,
                stockQuantity: 0,
                minInventoryLimit: 0,
                inventoryLimit: 0,
                storageCost: 0,
                companyCode: company.code,
                companyName: company.name,
                companyAddress: company.address,
                itemCode: itemStock?.code,
                itemName: itemStock?.name,
                warehouseName: warehouse?.name,
                warehouseCode: warehouse?.code,
                unit: itemStock?.itemUnit?.name,
                locatorName: locator?.name,
                locatorCode: locator?.code,
              };
            }
            itemStockLocatorDaily[keyItemWarehouseLocator].storageCost = plus(
              itemStockLocatorDaily[keyItemWarehouseLocator].storageCost,
              lot.totalAmount,
            );
            itemStockLocatorDaily[keyItemWarehouseLocator].stockQuantity = plus(
              itemStockLocatorDaily[keyItemWarehouseLocator].stockQuantity,
              lot.quantity,
            );
          });
        });
      });
      // await this.kafkaProducer.send({
      //   topic: SYNC_REPORT_DAILY_TOPIC,
      //   messages: [
      //     {
      //       key: 'data',
      //       value: JSON.stringify({
      //         itemStockLocatorDaily: values(itemStockLocatorDaily),
      //         itemStockWarehouseDaily: values(itemStockWarehouseDaily),
      //         itemLotStockLocatorDaily,
      //       }),
      //     },
      //   ],
      // });

      return {
        success: true,
        data: itemStockLocatorDaily,
      };
    } catch (error) {
      console.log(error);
      return {
        success: false,
        data: [],
        message: error.message,
      };
    }
  }

  async createReport(
    report: CreateReportRequestDto,
  ): Promise<ResponsePayload<any>> {
    const reportCode = await this.warehouseReportRepository.findOneByCondition({
      code: report.code,
    });

    if (reportCode)
      return new ApiError(
        ResponseCodeEnum.CODE_EXIST,
        await this.i18n.translate('error.CODE_EXIST'),
      ).toResponse();

    const warehouses = await this.warehouseRepository.findByCondition({
      id: In(report.warehouseIds),
    });

    if (!warehouses || warehouses.length !== report.warehouseIds.length) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (report.startDate > report.endDate)
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.INVALID_DATE_RANGE'),
      ).toResponse();

    let reportWarehouseItems: WarehouseItemReport[] = [];
    for (let i = 0; i < report.warehouseIds.length; i++) {
      const itemIdsQuery =
        await this.warehouseDailyReportRepository.getWarehouseItems(
          report.warehouseIds[i],
        );
      if (!itemIdsQuery.length) continue;
      const reportDetailRaw =
        await this.warehouseDailyReportRepository.getReportByWarehouse(
          report.startDate,
          report.endDate,
          report.warehouseIds[i],
          itemIdsQuery.map((e) => e.itemId),
        );
      const reportDetail = plainToInstance(
        WarehouseItemReport,
        reportDetailRaw,
        {
          excludeExtraneousValues: true,
        },
      );
      reportWarehouseItems = [...reportWarehouseItems, ...reportDetail];
    }
    try {
      const warehouseReport = this.warehouseReportRepository.createEntity(
        reportWarehouseItems,
        report,
      );

      const reportSave = await this.warehouseReportRepository.create(
        warehouseReport,
      );

      return new ResponseBuilder(reportSave.id)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      console.error('ERRROR 2 JOB', error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async getReports(
    report: WarehouseReportQuery,
  ): Promise<ResponsePayload<any>> {
    const filterCreatedBy = report.filter?.find(
      (item) => item.column === 'createdBy',
    );

    let filterByUserIds = [];

    if (!isEmpty(filterCreatedBy)) {
      filterByUserIds = await this.userService.getUsersByUsernameOrFullName(
        filterCreatedBy,
        true,
      );

      if (isEmpty(filterByUserIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: report.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    const [data, count] = await this.warehouseReportRepository.getReports(
      report,
      filterByUserIds,
    );

    const userIds = data.map((e) => e.createdBy);
    const users = await this.userService.getUserByIds(uniq(userIds), true);
    const warehouseInventoryReports = data.map((e) => ({
      ...e,
      createdBy: users[e.createdBy],
    }));
    const dataReturn = plainToInstance(
      WarehousReportResponse,
      warehouseInventoryReports,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: report.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getReport(
    request: WarehouseReportDetailQuery,
  ): Promise<ResponsePayload<any>> {
    const reportRaw = await this.warehouseReportRepository.findOneWithRelations(
      {
        where: {
          id: request.reportId,
        },
        relations: ['warehouseReportWarehouses'],
      },
    );

    if (!reportRaw)
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();

    const userIds = [reportRaw.createdBy];
    const users = await this.userService.getUserByIds(uniq(userIds), true);

    const report = plainToInstance(WarehousReportResponse, reportRaw, {
      excludeExtraneousValues: true,
    });

    report.createdBy = plainToInstance(CreatedBy, users[reportRaw.createdBy], {
      excludeExtraneousValues: true,
    });

    report.warehouses = [];
    const reportWarehouseIds = reportRaw.warehouseReportWarehouses.map(
      (e) => e.warehouseId,
    );

    if (reportWarehouseIds.length > 0) {
      const warehouseData = await this.warehouseRepository.findByCondition({
        id: In(reportWarehouseIds),
      });

      const factoryIds = warehouseData.map((warehouse) => warehouse.factoryId);

      const factory = await this.userService.getFactoriesByIds(
        factoryIds,
        true,
      );

      warehouseData.forEach((warehouse) => {
        warehouse['factory'] = factory[warehouse.factoryId];
      });

      report.warehouses = plainToInstance(WarehouseReport, warehouseData, {
        excludeExtraneousValues: true,
      });
    }
    const [reportDetailRaw, count] =
      await this.warehouseReportDetailRepository.getReportDetail(request);

    let reportDetails = plainToInstance(
      WarehousReportDetailResponse,
      reportDetailRaw,
      {
        excludeExtraneousValues: true,
      },
    );

    const listItemId = reportDetails.map((e) => e.itemId);
    if (listItemId.length > 0) {
      const itemsInfo = await this.itemService.getItemsInfo(listItemId);
      reportDetails = reportDetails
        .map((e) => {
          const itemInfoFind = itemsInfo.find((e2) => e.itemId === e2.itemId);
          if (itemInfoFind) {
            e.itemName = itemInfoFind.name;
            e.itemType = itemInfoFind.itemType.name;
            e.itemUnit = itemInfoFind.itemUnit.name;
          }
          return e;
        })
        .filter((e) => e.itemName !== undefined);
    }

    report.reportDetails = {
      items: reportDetails,
      meta: { total: count, page: request.page },
    };

    return new ResponseBuilder(report)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getReportStock(
    request: GetListReportStockQueryDto,
  ): Promise<ResponsePayload<any>> {
    let dataReport: ReportStockResponse[] = [];
    let count = 0;
    if (
      !request.reportDate ||
      moment(request.reportDate).format('YYYYMMDD') >=
        moment().format('YYYYMMDD')
    ) {
      const dataStockRawRes = await this.itemService.getStock(request);
      if (dataStockRawRes.statusCode === ResponseCodeEnum.SUCCESS) {
        count = dataStockRawRes?.data?.meta?.total || count;
        dataReport = plainToInstance(
          ReportStockResponse,
          <any[]>dataStockRawRes?.data?.items,
          {
            excludeExtraneousValues: true,
          },
        );

        const warehouseIds = dataReport.map((e) => e.warehouseId);
        if (warehouseIds.length > 0) {
          const warehousesDataRaw =
            await this.warehouseRepository.findWithRelations({
              where: { id: In(warehouseIds) },
              relations: ['warehouseTypeSettings'],
            });
          const warehousesData = plainToInstance(
            WarehouseDataResponseDto,
            warehousesDataRaw,
            {
              excludeExtraneousValues: true,
            },
          );

          dataReport.forEach((e) => {
            const warehouseData = warehousesData.find(
              (e2) => e2.id === e.warehouseId,
            );
            e.warehouseName = warehouseData?.name;
            e.warehouseTypes = warehouseData?.warehouseTypeSettings;
          });
        }
      }
    } else {
      const [dataReportRaw, countData] =
        await this.warehouseDailyReportDetailRepository.getReportStock(request);
      count = countData;

      dataReport = plainToInstance(ReportStockResponse, dataReportRaw, {
        excludeExtraneousValues: true,
      });
    }

    return new ResponseBuilder({
      items: dataReport,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async reportMonthMovementCount(
    request: ReportMonthMovementCountQuery,
  ): Promise<ResponsePayload<any>> {
    const startOfMonth =
      request.startDate || moment().startOf('month').toDate();
    const endOfMonth = request.endDate || moment().endOf('month').toDate();
    const countDaysInMonth = moment().daysInMonth();
    const monthDataImportRaw =
      await this.warehouseStockMovementRepository.getCountOfMonth(
        startOfMonth,
        endOfMonth,
        WAREHOUSE_IMPORT_MOVEMENT_TYPES,
      );

    const monthDataImport = plainToInstance(ReportByDay, monthDataImportRaw, {
      excludeExtraneousValues: true,
    });

    const monthDataExportRaw =
      await this.warehouseStockMovementRepository.getCountOfMonth(
        startOfMonth,
        endOfMonth,
        WAREHOUSE_EXPORT_MOVEMENT_TYPES,
      );

    const monthDataExport = plainToInstance(ReportByDay, monthDataExportRaw, {
      excludeExtraneousValues: true,
    });
    const monthDataTranferRaw =
      await this.warehouseStockMovementRepository.getCountOfMonth(
        startOfMonth,
        endOfMonth,
        WAREHOUSE_TRANSFER_MOVEMENT_TYPES,
      );

    const monthDataTranfer = plainToInstance(ReportByDay, monthDataTranferRaw, {
      excludeExtraneousValues: true,
    });

    const dataReportMonth: ReportCountTranfer[] = [];
    for (let i = 1; i <= countDaysInMonth; i++) {
      const dayImport = monthDataImport.find((e) => e.day == i)?.count || 0;
      const dayExport = monthDataExport.find((e) => e.day == i)?.count || 0;
      const dayTranfer = monthDataTranfer.find((e) => e.day == i)?.count || 0;
      dataReportMonth.push(
        new ReportCountTranfer(i.toString(), dayImport, dayExport, dayTranfer),
      );
    }

    return new ResponseBuilder(dataReportMonth)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  async reportCountItemTransfer(
    request: ReportItemQuery,
  ): Promise<ResponsePayload<any>> {
    const { transactionType, itemTypeId, reportType } = request;
    let typeImport: number[] = [],
      typeExport: number[] = [];
    const { listRangeDate, startDate, endDate } = this.getRangeDateByDateType(
      reportType,
      request.startDate,
      request.endDate,
    );
    switch (transactionType) {
      case TransactionType.PO:
        typeImport = [WarehouseMovementTypeEnum.PO_IMPORT];
        typeExport = [WarehouseMovementTypeEnum.PO_EXPORT];
        break;

      case TransactionType.PRO:
        typeImport = [WarehouseMovementTypeEnum.PRO_IMPORT];
        typeExport = [WarehouseMovementTypeEnum.PRO_EXPORT];
        break;

      case TransactionType.SO:
        typeImport = [WarehouseMovementTypeEnum.SO_IMPORT];
        typeExport = [WarehouseMovementTypeEnum.SO_EXPORT];
        break;

      case TransactionType.OO:
        typeImport = [WarehouseMovementTypeEnum.IMO_IMPORT];
        typeExport = [WarehouseMovementTypeEnum.EXO_EXPORT];
        break;

      case TransactionType.TRANFER:
        typeImport = [];
        typeExport = [];
        break;

      default:
        typeImport = WAREHOUSE_IMPORT_MOVEMENT_TYPES;
        typeExport = WAREHOUSE_EXPORT_MOVEMENT_TYPES;
        break;
    }

    try {
      const dataImportRaw =
        await this.warehouseStockMovementRepository.getIdGroupByDay(
          startDate,
          endDate,
          typeImport,
        );

      const dataImport = plainToInstance(StockMovementIdByDate, dataImportRaw, {
        excludeExtraneousValues: true,
      });

      const dataExportRaw =
        await this.warehouseStockMovementRepository.getIdGroupByDay(
          startDate,
          endDate,
          typeExport,
        );

      const dataExport = plainToInstance(StockMovementIdByDate, dataExportRaw, {
        excludeExtraneousValues: true,
      });

      let tranferImport: TransferByDateResponse[] = [];
      if (dataImport.length > 0) {
        const dataImportItemService =
          await this.itemService.getTranferByDateAndIds(dataImport, itemTypeId);

        if (dataImportItemService?.statusCode !== ResponseCodeEnum.SUCCESS)
          throw dataImportItemService?.message;

        tranferImport = plainToInstance(
          TransferByDateResponse,
          <any[]>dataImportItemService?.data,
          {
            excludeExtraneousValues: true,
          },
        );
      }

      let tranferExport: TransferByDateResponse[] = [];
      if (dataExport.length > 0) {
        const dataExportItemService =
          await this.itemService.getTranferByDateAndIds(dataExport, itemTypeId);

        if (dataExportItemService?.statusCode !== ResponseCodeEnum.SUCCESS)
          throw dataExportItemService?.message;

        tranferExport = plainToInstance(
          TransferByDateResponse,
          <any[]>dataExportItemService?.data,
          {
            excludeExtraneousValues: true,
          },
        );
      }
      let itemIds: number[] = [];
      if (itemTypeId !== undefined) {
        const listItemTranferWarehouse =
          await this.warehouseTransferRepository.getListItemTranfer(
            startDate,
            endDate,
          );

        const listItemId = listItemTranferWarehouse.map((e) => e.itemId);
        if (listItemId.length > 0) {
          const itemIdsFromService = await this.itemService.getItemByItemType(
            listItemId,
            itemTypeId,
          );
          if (itemIdsFromService?.statusCode !== ResponseCodeEnum.SUCCESS)
            throw itemIdsFromService?.message;

          itemIds = itemIdsFromService?.data;
        }
      }

      const dataTranferWarehouse =
        await this.warehouseTransferRepository.getTransferCountByDate(
          startDate,
          endDate,
          itemIds,
        );

      const tranferWarehouse = plainToInstance(
        TransferByDateResponse,
        dataTranferWarehouse,
        {
          excludeExtraneousValues: true,
        },
      );

      const reportData: ReportTransfer[] = [];
      listRangeDate.forEach((rangeDate) => {
        const rangeDateImport = tranferImport
          .filter(
            (e) =>
              Number(e.date) >= Number(rangeDate.startDate) &&
              Number(e.date) <= Number(rangeDate.endDate),
          )
          .map((e) => e.quantity)
          .reduce((a, b) => plus(a, b), 0);
        const rangeDateExport = tranferExport
          .filter(
            (e) =>
              Number(e.date) >= Number(rangeDate.startDate) &&
              Number(e.date) <= Number(rangeDate.endDate),
          )
          .map((e) => e.quantity)
          .reduce((a, b) => plus(a, b), 0);
        const rangeDateWarehouse = tranferWarehouse
          .filter(
            (e) =>
              Number(e.date) >= Number(rangeDate.startDate) &&
              Number(e.date) <= Number(rangeDate.endDate),
          )
          .map((e) => e.quantity)
          .reduce((a, b) => plus(a, b), 0);
        reportData.push(
          new ReportTransfer(
            reportType,
            rangeDate.tag,
            this.getRangeDate(
              rangeDate.startDate,
              rangeDate.endDate,
              reportType,
            ),
            rangeDateImport,
            rangeDateExport,
            rangeDateWarehouse,
          ),
        );
      });

      return new ResponseBuilder(reportData)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  private getRangeDate(
    startDate: string,
    endDate: string,
    reportType: number,
  ): string {
    switch (reportType) {
      case ReportType.WEEK:
        return moment(startDate, 'YYYYMMDD').format('DD/MM/YYYY');
      default:
        return `${moment(startDate, 'YYYYMMDD').format('DD/MM')}-${moment(
          endDate,
          'YYYYMMDD',
        ).format('DD-MM')}`;
    }
  }

  async reportItemStock(
    request: ReportItemQuery,
  ): Promise<ResponsePayload<any>> {
    try {
      const { itemTypeId, reportType } = request;

      const { listRangeDate, startDate, endDate } = this.getRangeDateByDateType(
        reportType,
        request.startDate,
        request.endDate,
      );

      let listItemIdsFilter: number[] = [];
      if (itemTypeId !== undefined) {
        const itemIdsFromService = await this.itemService.getItemByItemType(
          [],
          itemTypeId,
        );

        if (itemIdsFromService?.statusCode !== ResponseCodeEnum.SUCCESS)
          throw itemIdsFromService?.message;

        listItemIdsFilter = itemIdsFromService?.data;
      }

      const dataStockRaw =
        await this.warehouseDailyReportRepository.getStockByDate(
          startDate,
          endDate,
          listItemIdsFilter,
        );

      const today = moment();
      if (
        today.isSameOrBefore(endDate, 'day') &&
        today.isSameOrAfter(startDate, 'day')
      ) {
        const dataStockToday = await this.getReportItemStockByDate(request);
        const indexDataStockRawToday = dataStockRaw.findIndex((e) =>
          moment(e.date, 'YYYYMMDD').isSame(today, 'day'),
        );
        if (indexDataStockRawToday === -1) {
          dataStockRaw.push({
            quantity: dataStockToday,
            date: today.format('YYYYMMDD'),
          });
        } else {
          dataStockRaw[indexDataStockRawToday]['quantity'] = dataStockToday;
        }
      }

      const dataStock = plainToInstance(TransferByDateResponse, dataStockRaw, {
        excludeExtraneousValues: true,
      });

      const reportData: ReportStockByDay[] = [];
      listRangeDate.forEach((rangeDate) => {
        const { startDate: startRangeDate, endDate: endRangeDate } = rangeDate;
        const rangeDateStock = dataStock.filter(
          (e) =>
            moment(e.date, 'YYYYMMDD').isSameOrAfter(
              moment(startRangeDate, 'YYYYMMDD'),
            ) &&
            moment(e.date, 'YYYYMMDD').isSameOrBefore(
              moment(endRangeDate, 'YYYYMMDD'),
            ),
        );
        let totalQuantity = 0;
        if (!isEmpty(rangeDateStock)) {
          rangeDateStock.forEach((e) => {
            totalQuantity = plus(totalQuantity, Number(e.quantity));
          });
        }
        reportData.push(
          new ReportStockByDay(
            reportType,
            rangeDate.tag,
            totalQuantity,
            this.getRangeDate(startRangeDate, endRangeDate, reportType),
          ),
        );
      });

      return new ResponseBuilder(reportData)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  private async getReportItemStockByDate(request: any): Promise<any> {
    const { itemTypeId } = request;
    const itemServiceRespone = await this.itemService.getQuantityItemWarehouse(
      itemTypeId,
    );
    if (itemServiceRespone.statusCode === ResponseCodeEnum.SUCCESS) {
      return itemServiceRespone.data.quantity || 0;
    }
    return 0;
  }

  private getRangeDateByDateType(
    reportType: number,
    startDate?: Date,
    endDate?: Date,
  ): {
    listRangeDate: RangeDate[];
    startDate: Date;
    endDate: Date;
  } {
    const listRangeDate: RangeDate[] = [];
    let unit: 'day' | 'week' | 'month' = 'day';
    switch (reportType) {
      case ReportType.MONTH:
        unit = 'week';
        break;
      case ReportType.QUARTER:
        unit = 'month';
        break;
      default:
        break;
    }
    const from = startDate
      ? moment(startDate)
      : reportType === ReportType.MONTH
      ? moment().month(moment().month()).startOf('month')
      : reportType === ReportType.QUARTER
      ? moment().quarter(moment().quarter()).startOf('quarter')
      : moment().isoWeek(moment().isoWeek()).startOf('isoWeek');

    const to = endDate
      ? moment(endDate)
      : reportType === ReportType.MONTH
      ? moment().month(moment().month()).endOf('month')
      : reportType === ReportType.QUARTER
      ? moment().quarter(moment().quarter()).endOf('quarter')
      : moment().isoWeek(moment().isoWeek()).endOf('isoWeek');
    let tag = 1;
    for (
      let date = from.clone();
      date.isSameOrBefore(to, 'day');
      date = date.clone().add(1, unit)
    ) {
      listRangeDate.push(
        new RangeDate(
          reportType,
          `${tag}`,
          date.clone().format('YYYYMMDD'),
          date.clone().add(1, unit).subtract(1, 'day').format('YYYYMMDD'),
        ),
      );
      tag++;
    }
    return { listRangeDate, startDate: from.toDate(), endDate: to.toDate() };
  }

  async reportGapsInStock(
    request: ReportGapsInStockQuery,
  ): Promise<ResponsePayload<any>> {
    const { warehouseId } = request;
    const warehouse = await this.warehouseRepository.findOneById(warehouseId);

    if (!warehouse) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'),
      ).toResponse();
    }

    const result = await this.warehouseSectorRepository.getGapsInStock(request);

    const shelfsBySector = {};
    result.forEach((sector) => {
      shelfsBySector[sector.warehouseSectorId] = sector.warehouseShelfFloors;
    });

    const floorsBySector = {};
    for (const key in shelfsBySector) {
      floorsBySector[key] = shelfsBySector[key]
        .map((shelf) => shelf.warehouseShelfFloors)
        .flat();
    }

    const totalVolumeFloorBySector = {};
    for (const key in floorsBySector) {
      let totalVolumeFloor = 0;
      floorsBySector[key].forEach((floor) => {
        const volumeFloor = formatUnitMeasures(
          floor.volume.value,
          floor.volume.unit,
        );
        totalVolumeFloor = plus(
          totalVolumeFloor || 0,
          mul(volumeFloor || 0, div(floor.fullmentPercent || 0, 100)),
        );
      });
      totalVolumeFloorBySector[key] = totalVolumeFloor;
    }

    const data = result.map((e) => {
      const totalVolumeFloor = totalVolumeFloorBySector[e.warehouseSectorId];
      const volumeSector = formatUnitMeasures(e.volume.value, e.volume.unit);
      return {
        ...e,
        warehouseSectorFullmentPercent: mul(
          div(totalVolumeFloor || 0, volumeSector || 1),
          100,
        ),
      };
    });

    const dataReturn = plainToInstance(GapsInStockResponse, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
