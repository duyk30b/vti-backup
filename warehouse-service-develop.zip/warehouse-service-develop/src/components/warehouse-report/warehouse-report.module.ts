import { ConfigService } from '@config/config.service';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ItemModule } from '@components/item/item.module';
import { WarehouseReport } from '@entities/warehouse-report/warehouse-report.entity';
import { WarehouseReportDetail } from '@entities/warehouse-report/warehouse-report-detail.entity';
import { WarehouseReportRepository } from '@repositories/warehouse-report.repository';
import { WarehouseReportService } from './warehouse-report.service';
import { WarehouseReportController } from './warehouse-report.controller';
import { WarehouseReportDetailRepository } from '@repositories/warehouse-report-detail.repository';
import { Warehouse } from '@entities/warehouse/warehouse.entity';
import { WarehouseRepository } from '@repositories/warehouse.repository';
import { WarehouseStockMovement } from '@entities/warehouse/warehouse-stock-movement.entity';
import { WarehouseStockMovementRepository } from '@repositories/warehouse-stock-movement.repository';
import { WarehouseDailyReportRepository } from '@repositories/warehouse-daily-report.repository';
import { WarehouseDailyReport } from '@entities/warehouse-report/warehouse-daily-report.entity';
import { WarehouseTransfer } from '@entities/warehouse-transfer/warehouse-transfer.entity';
import { WarehouseTransferRepository } from '@repositories/warehouse-transfer.repository';
import { WarehouseDailyReportDetail } from '@entities/warehouse-report/warehouse-daily-report-detail.entity';
import { WarehouseDailyReportDetailRepository } from '@repositories/warehouse-daily-report-detail.repository';
import { UserService } from '@components/user/user.service';
import { WarehouseSectorRepository } from '@repositories/warehouse-sector.repository';
import { WarehouseSectorEntity } from '@entities/warehouse-sector/warehouse-sector.entity';
import { ItemCronService } from '@components/item/item-cron.service';
import { WarehouseShelfRepository } from '@repositories/warehouse-shelf.repository';
import { WarehouseShelfFloorRepository } from '@repositories/warehouse-shelf-floor.repository';
import { WarehouseShelfEntity } from '@entities/warehouse-shelf/warehouse-shelf.entity';
import { WarehouseShelfFloorEntity } from '@entities/warehouse-shelf-floor/warehouse-shelf-floor.entity';
import { WarehouseSectorService } from '@components/warehouse-sector/warehouse-sector.service';
import { WarehouseSectorModule } from '@components/warehouse-sector/warehouse-sector.module';
import { ClientKafka, ClientsModule, Transport } from '@nestjs/microservices';
import { WarehouseLayoutService } from '@components/warehouse-layout/warehouse-layout.service';
import * as fs from 'fs';
import * as path from 'path';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      WarehouseReport,
      WarehouseReportDetail,
      Warehouse,
      WarehouseStockMovement,
      WarehouseDailyReport,
      WarehouseDailyReportDetail,
      WarehouseTransfer,
      WarehouseSectorEntity,
      WarehouseShelfEntity,
      WarehouseShelfFloorEntity,
    ]),
    // ClientsModule.register([
    //   {
    //     name: 'CLIENT_KAFKA',
    //     transport: Transport.KAFKA,
    //     options: {
    //       client: {
    //         clientId: 'sync_report',
    //         brokers: process.env.KAFKA_BROKERS.split(','),
    //         ssl: {
    //           rejectUnauthorized: false,
    //           ca: [
    //             fs.readFileSync(path.join(__dirname, '/../../cert/kafka.crt'), 'utf-8'),
    //           ],
    //           key: fs.readFileSync(
    //             path.join(__dirname, '/../../cert/kafka.key'),
    //             'utf-8',
    //           ),
    //           cert: fs.readFileSync(
    //             path.join(__dirname, '/../../cert/kafka.pem'),
    //             'utf-8',
    //           ),
    //         },
    //       },
    //     },
    //   },
    // ]),
    ItemModule,
    WarehouseSectorModule,
  ],
  providers: [
    {
      provide: 'WarehouseReportRepositoryInterface',
      useClass: WarehouseReportRepository,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'WarehouseReportDetailRepositoryInterface',
      useClass: WarehouseReportDetailRepository,
    },
    {
      provide: 'WarehouseDailyReportRepositoryInterface',
      useClass: WarehouseDailyReportRepository,
    },
    {
      provide: 'WarehouseDailyReportDetailRepositoryInterface',
      useClass: WarehouseDailyReportDetailRepository,
    },
    {
      provide: 'WarehouseStockMovementRepositoryInterface',
      useClass: WarehouseStockMovementRepository,
    },
    {
      provide: 'WarehouseTransferRepositoryInterface',
      useClass: WarehouseTransferRepository,
    },
    {
      provide: 'WarehouseSectorRepositoryInterface',
      useClass: WarehouseSectorRepository,
    },
    {
      provide: 'WarehouseShelfRepositoryInterface',
      useClass: WarehouseShelfRepository,
    },
    {
      provide: 'WarehouseShelfFloorRepositoryInterface',
      useClass: WarehouseShelfFloorRepository,
    },
    {
      provide: 'WarehouseReportServiceInterface',
      useClass: WarehouseReportService,
    },
    {
      provide: 'WarehouseSectorServiceInterface',
      useClass: WarehouseSectorService,
    },
    {
      provide: 'WarehouseLayoutServiceInterface',
      useClass: WarehouseLayoutService,
    },
    ItemCronService,
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    ConfigService,
    // {
    //   provide: 'KAFKA_PRODUCER',
    //   useFactory: async (kafkaClient: ClientKafka) => {
    //     return kafkaClient.connect();
    //   },
    //   inject: ['CLIENT_KAFKA'],
    // },
  ],
  controllers: [WarehouseReportController],
})
export class WarehouseReportModule {}
