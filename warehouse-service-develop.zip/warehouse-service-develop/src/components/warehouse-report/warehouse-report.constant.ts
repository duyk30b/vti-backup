export enum ReportType {
  WEEK = 0,
  MONTH = 1,
  QUARTER = 2,
}

export enum TransactionType {
  PO = 1,
  PRO = 2,
  SO = 3,
  TRANFER = 4,
  OO = 5, // Other Order
}

export const SYNC_REPORT_DAILY_TOPIC = 'SYNC_REPORT_DAILY';

export const SYNC_REPORT_DAILY_LIMIT_RECORDS = 100;
