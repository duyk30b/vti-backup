import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ResponsePayload } from '@utils/response-payload';
import { GetListReportStockQueryDto } from '../dto/query/get-list-report-stock.query.dto';
import { ReportGapsInStockQuery } from '../dto/query/report-gaps-in-stock.query';
import { ReportItemQuery } from '../dto/query/report-item.query';
import { ReportMonthMovementCountQuery } from '../dto/query/report-month-movement-count.query';
import { WarehouseReportDetailQuery } from '../dto/query/warehouse-report-detail.query';
import { WarehouseReportQuery } from '../dto/query/warehouse-report.query';
import { CreateReportRequestDto } from '../dto/request/create-report.request.dto';
import { DeleteReportRequestDto } from '../dto/request/delete-report.request.dto';

export interface WarehouseReportServiceInterface {
  createDailyReport(): Promise<ResponsePayload<any>>;
  createReport(report: CreateReportRequestDto): Promise<ResponsePayload<any>>;
  deleteReport(request: DeleteReportRequestDto): Promise<ResponsePayload<any>>;
  deleteMultipleReport(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  getReports(request: WarehouseReportQuery): Promise<ResponsePayload<any>>;
  getReport(request: WarehouseReportDetailQuery): Promise<ResponsePayload<any>>;
  getReportStock(
    request: GetListReportStockQueryDto,
  ): Promise<ResponsePayload<any>>;
  reportMonthMovementCount(
    request: ReportMonthMovementCountQuery,
  ): Promise<ResponsePayload<any>>;
  reportCountItemTransfer(
    request: ReportItemQuery,
  ): Promise<ResponsePayload<any>>;
  reportItemStock(request: ReportItemQuery): Promise<ResponsePayload<any>>;
  reportGapsInStock(
    request: ReportGapsInStockQuery,
  ): Promise<ResponsePayload<any>>;
}
