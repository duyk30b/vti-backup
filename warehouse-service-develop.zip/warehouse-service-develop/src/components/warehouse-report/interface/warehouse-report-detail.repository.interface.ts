import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WarehouseReportDetail } from '@entities/warehouse-report/warehouse-report-detail.entity';
import { WarehouseReportDetailQuery } from '../dto/query/warehouse-report-detail.query';

export interface WarehouseReportDetailRepositoryInterface
  extends BaseInterfaceRepository<WarehouseReportDetail> {
  getReportDetail(
    request: WarehouseReportDetailQuery,
  ): Promise<[any[], number]>;
}
