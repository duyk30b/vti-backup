import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WarehouseReport } from '@entities/warehouse-report/warehouse-report.entity';
import { WarehouseReportQuery } from '../dto/query/warehouse-report.query';
import { CreateReportRequestDto } from '../dto/request/create-report.request.dto';
import { WarehouseItemReport } from '../dto/response/warehouse-item-report.response';

export interface WarehouseReportRepositoryInterface
  extends BaseInterfaceRepository<WarehouseReport> {
  findReportByCurrentDay(warehouseId: number): Promise<any>;
  getReports(
    report: WarehouseReportQuery,
    filterByUserIds?: any,
  ): Promise<[any[], number]>;
  createEntity(
    reportDetail: WarehouseItemReport[],
    request: CreateReportRequestDto,
  ): WarehouseReport;
}
