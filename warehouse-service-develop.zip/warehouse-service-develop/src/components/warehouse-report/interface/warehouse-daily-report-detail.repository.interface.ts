import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WarehouseDailyReportDetail } from '@entities/warehouse-report/warehouse-daily-report-detail.entity';
import { GetListReportStockQueryDto } from '../dto/query/get-list-report-stock.query.dto';

export interface WarehouseDailyReportDetailRepositoryInterface
  extends BaseInterfaceRepository<WarehouseDailyReportDetail> {
  getReportStock(request: GetListReportStockQueryDto): Promise<[any[], number]>;
}
