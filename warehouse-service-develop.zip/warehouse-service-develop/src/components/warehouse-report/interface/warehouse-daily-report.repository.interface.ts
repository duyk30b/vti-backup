import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WarehouseDailyReport } from '@entities/warehouse-report/warehouse-daily-report.entity';
import { WarehouseStockDailyRespone } from '../dto/response/warehouse-stock-daily.response';

export interface WarehouseDailyReportRepositoryInterface
  extends BaseInterfaceRepository<WarehouseDailyReport> {
  createEntity(
    warehouseId: number,
    warehouseStockDaily: WarehouseStockDailyRespone[],
    reportDate: Date,
  ): WarehouseDailyReport;
  getReportByWarehouse(
    startDate: Date,
    endDate: Date,
    warehouseId: number,
    itemIds: number[],
  ): Promise<any[]>;
  getWarehouseItems(warehouseId: number): Promise<any[]>;
  getStockByDate(
    startDate: Date,
    endDate: Date,
    itemIds: number[],
  ): Promise<any[]>;
}
