export interface WarehouseReportDetailServiceInterface {}
