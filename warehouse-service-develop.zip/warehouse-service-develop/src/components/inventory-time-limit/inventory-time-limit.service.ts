import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { CreateInventoryTimeLimitRequestDto } from './dto/request/create-inventory-time-limit.request.dto';
import { InventoryTimeLimitServiceInterface } from './interface/inventory-time-limit.service.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { InventoryTimeLimitRepositoryInterface } from './interface/inventory-time-limit.repository.interface';
import { UpdateInventoryTimeLimitRequestDto } from './dto/request/update-inventory-time-limit.request.dto';
import { DeleteInventoryTimeLimitRequestDto } from './dto/request/delete-inventory-time-limit.request.dto';
import { GetInventoryTimeLimitRequestDto } from './dto/request/get-inventory-time-limit-detail.request.dto';
import { InventoryTimeLimitResponseDto } from './dto/response/inventory-time-limit.response.dto';
import { plainToClass } from 'class-transformer';
import { GetInventoryTimeLimitListRequestDto } from './dto/request/get-inventory-time-limit.request.dto';
import { PagingResponse } from '@utils/paging.response';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { InventoryTimeLimitEntity } from '@entities/inventory-time-limit/inventory-time-limit.entity';
import { DataSource } from 'typeorm';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { isEmpty } from 'lodash';
import { GetInventoryTimeLimitByWarehouseRequestDto } from './dto/request/get-inventory-time-limit-by-warehouse.request.dto';

@Injectable()
export class InventoryTimeLimitService
  implements InventoryTimeLimitServiceInterface
{
  constructor(
    @InjectDataSource()
    private readonly connection: DataSource,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @Inject('InventoryTimeLimitRepositoryInterface')
    private readonly inventoryTimeLimitRepository: InventoryTimeLimitRepositoryInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateInventoryTimeLimitRequestDto): Promise<any> {
    if (request.expiryWarningWarehouse >= request.expiryWarehouse) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.EXPIRY_WARNING_WAREHOUSE_MUST_BE_LESS_THAN_EXPIRY_WAREHOUSE',
          ),
        )
        .build();
    }
    const existingInventoryTimeLimitEntity =
      await this.inventoryTimeLimitRepository.findOneByCondition({
        warehouseId: request.warehouseId,
      });
    if (existingInventoryTimeLimitEntity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.INVENTORY_TIME_LIMIT_ON_CURRENT_WAREHOUSE_EXIST',
          ),
        )
        .build();
    }
    const inventoryTimeLimit =
      this.inventoryTimeLimitRepository.createEntity(request);
    return await this.save(inventoryTimeLimit);
  }

  async update(request: UpdateInventoryTimeLimitRequestDto): Promise<any> {
    if (request.expiryWarningWarehouse >= request.expiryWarehouse) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.EXPIRY_WARNING_WAREHOUSE_MUST_BE_LESS_THAN_EXPIRY_WAREHOUSE',
          ),
        )
        .build();
    }
    const existingInventoryTimeLimitEntity =
      await this.inventoryTimeLimitRepository.findOneById(request.id);

    if (!existingInventoryTimeLimitEntity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const inventoryTimeLimit = this.inventoryTimeLimitRepository.updateEntity(
      existingInventoryTimeLimitEntity,
      request,
    );
    return await this.save(inventoryTimeLimit);
  }

  async delete(request: DeleteInventoryTimeLimitRequestDto): Promise<any> {
    const reason = await this.inventoryTimeLimitRepository.findOneById(
      request.id,
    );
    if (!reason) {
      return new ResponseBuilder(reason)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    await this.inventoryTimeLimitRepository.softRemove(request.id);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDetail(request: GetInventoryTimeLimitRequestDto): Promise<any> {
    const inventoryTimeLimit =
      await this.inventoryTimeLimitRepository.findOneWithRelations({
        where: { id: request.id },
        relations: ['warehouse'],
      });

    if (!inventoryTimeLimit) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const result = plainToClass(
      InventoryTimeLimitResponseDto,
      inventoryTimeLimit,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(request: GetInventoryTimeLimitListRequestDto): Promise<any> {
    const { page, filter } = request;

    if (!isEmpty(filter)) {
      const columnFilterItemServices = ['itemName', 'itemId', 'itemCode'];

      const filters = filter.filter((e) =>
        columnFilterItemServices.includes(e.column),
      );

      if (!isEmpty(filters)) {
        const inventoryTimeNorms = await this.itemService.getInventoryNormList(
          filters,
        );
        request.warehouseIds = inventoryTimeNorms.map((e) => e.warehouse.id);
      }
    }

    const [data, count] = await this.inventoryTimeLimitRepository.getList(
      request,
    );

    const dataReturn = plainToClass(InventoryTimeLimitResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async save(
    inventoryTimeLimitEntity: InventoryTimeLimitEntity,
  ): Promise<ResponsePayload<any> | any> {
    const existingWarehouse = await this.warehouseRepository.findOneById(
      inventoryTimeLimitEntity.warehouseId,
    );
    if (!existingWarehouse) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
        .build();
    }
    try {
      const result = await this.inventoryTimeLimitRepository.create(
        inventoryTimeLimitEntity,
      );
      result.warehouse = existingWarehouse;
      const response = plainToClass(InventoryTimeLimitResponseDto, result, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(response)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    }
  }

  async getDetailByWarehouse(
    request: GetInventoryTimeLimitByWarehouseRequestDto,
  ): Promise<any> {
    const inventoryTimeLimit =
      await this.inventoryTimeLimitRepository.findOneWithRelations({
        where: { warehouseId: request.warehouseId },
        relations: ['warehouse'],
      });

    if (!inventoryTimeLimit) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const result = plainToClass(
      InventoryTimeLimitResponseDto,
      inventoryTimeLimit,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
