import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InventoryTimeLimitController } from './inventory-time-limit.controller';
import { InventoryTimeLimitService } from './inventory-time-limit.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { InventoryTimeLimitRepository } from '@repositories/inventory-time-limit.repository';
import { InventoryTimeLimitEntity } from '@entities/inventory-time-limit/inventory-time-limit.entity';
import { Warehouse } from '@entities/warehouse/warehouse.entity';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { WarehouseRepository } from '@repositories/warehouse.repository';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([InventoryTimeLimitEntity, Warehouse]),
    UserModule,
    WarehouseModule,
  ],
  exports: [],
  providers: [
    {
      provide: 'InventoryTimeLimitRepositoryInterface',
      useClass: InventoryTimeLimitRepository,
    },
    {
      provide: 'InventoryTimeLimitsServiceInterface',
      useClass: InventoryTimeLimitService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
  ],
  controllers: [InventoryTimeLimitController],
})
export class InventoryTimeLimitModule {}
