import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateInventoryTimeLimitRequestDto } from './dto/request/create-inventory-time-limit.request.dto';
import { isEmpty } from 'lodash';
import { InventoryTimeLimitServiceInterface } from './interface/inventory-time-limit.service.interface';
import { UpdateInventoryTimeLimitBodyDto } from './dto/request/update-inventory-time-limit.request.dto';
import { DeleteInventoryTimeLimitRequestDto } from './dto/request/delete-inventory-time-limit.request.dto';
import { GetInventoryTimeLimitListRequestDto } from './dto/request/get-inventory-time-limit.request.dto';
import { InventoryTimeLimitResponseDto } from './dto/response/inventory-time-limit.response.dto';
import { GetInventoryTimeLimitRequestDto } from './dto/request/get-inventory-time-limit-detail.request.dto';

import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_INVENTORY_TIME_LIMIT_PERMISSION,
  UPDATE_INVENTORY_TIME_LIMIT_PERMISSION,
  DELETE_INVENTORY_TIME_LIMIT_PERMISSION,
  DETAIL_INVENTORY_TIME_LIMIT_PERMISSION,
  LIST_INVENTORY_TIME_LIMIT_PERMISSION,
} from '@utils/permissions/inventory-time-limit';
import { GetInventoryTimeLimitByWarehouseRequestDto } from './dto/request/get-inventory-time-limit-by-warehouse.request.dto';
import { MessagePattern } from '@nestjs/microservices';
import { NATS_WAREHOUSE } from '@config/nats.config';

@Controller('inventory-time-limits')
export class InventoryTimeLimitController {
  constructor(
    @Inject('InventoryTimeLimitsServiceInterface')
    private readonly inventoryTimeLimitService: InventoryTimeLimitServiceInterface,
  ) {}

  @PermissionCode(CREATE_INVENTORY_TIME_LIMIT_PERMISSION.code)
  @Post('create')
  @ApiOperation({
    tags: ['InventoryTimeLimit'],
    summary: 'Create new thời hạn lưu kho',
    description: 'Tạo 1 inventoryTimeLimit mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async create(
    @Body() body: CreateInventoryTimeLimitRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryTimeLimitService.create(request);
  }

  @PermissionCode(UPDATE_INVENTORY_TIME_LIMIT_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['InventoryTimeLimit'],
    summary: 'Update thời hạn lưu kho',
    description: 'Sửa thời hạn lưu kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async update(
    @Body() body: UpdateInventoryTimeLimitBodyDto,
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryTimeLimitService.update({ ...request, id });
  }

  @PermissionCode(DELETE_INVENTORY_TIME_LIMIT_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['InventoryTimeLimit'],
    summary: 'Delete thời hạn lưu kho',
    description: 'Xóa thời hạn lưu kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async delete(
    @Param() param: DeleteInventoryTimeLimitRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryTimeLimitService.delete(request);
  }

  @PermissionCode(DETAIL_INVENTORY_TIME_LIMIT_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['InventoryTimeLimit'],
    summary: 'Delete thời hạn lưu kho',
    description: 'Xóa thời hạn lưu kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: InventoryTimeLimitResponseDto,
  })
  public async getDetail(
    @Param() param: GetInventoryTimeLimitRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryTimeLimitService.getDetail(request);
  }

  @PermissionCode(LIST_INVENTORY_TIME_LIMIT_PERMISSION.code)
  @Get('list')
  @ApiOperation({
    tags: ['InventoryTimeLimit'],
    summary: 'Get list thời hạn lưu kho',
    description: 'Lấy danh sách thời hạn lưu kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
    type: null,
  })
  public async getList(
    @Query() query: GetInventoryTimeLimitListRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryTimeLimitService.getList(request);
  }

  @MessagePattern(`${NATS_WAREHOUSE}.get_inventory_time_limit_by_warehouse`)
  @ApiOperation({
    tags: ['InventoryTimeLimit'],
    summary: 'Get detail thời hạn lưu kho',
    description: 'Lấy chi tiết thời hạn lưu kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get detail successfully',
    type: null,
  })
  public async getDetailByWarehouse(
    @Body() body: GetInventoryTimeLimitByWarehouseRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryTimeLimitService.getDetailByWarehouse(request);
  }
}
