import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class Warehouse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

export class InventoryTimeLimitResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  @Type(() => Warehouse)
  warehouse: Warehouse;

  @ApiProperty()
  @Expose()
  expiryWarehouse: number;

  @ApiProperty()
  @Expose()
  expiryWarningWarehouse: number;
}
