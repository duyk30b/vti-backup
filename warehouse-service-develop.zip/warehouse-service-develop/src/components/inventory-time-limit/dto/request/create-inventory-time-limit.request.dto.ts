import { INVENTORY_TIME_LIMIT_RULES } from '@components/inventory-time-limit/inventory-time-limit.constants';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsPositive, Max, Min } from 'class-validator';

export class CreateInventoryTimeLimitRequestDto extends BaseDto {
  @ApiProperty({ example: '', description: '' })
  @IsPositive()
  @IsInt()
  warehouseId: number;

  @ApiProperty({ example: '', description: '' })
  @Max(INVENTORY_TIME_LIMIT_RULES.EXPIRY_WAREHOUSE.MAX_VALUE)
  @Min(INVENTORY_TIME_LIMIT_RULES.EXPIRY_WAREHOUSE.MIN_VALUE)
  @IsInt()
  expiryWarehouse: number;

  @ApiProperty({ example: '', description: '' })
  @IsPositive()
  @IsInt()
  expiryWarningWarehouse: number;
}
