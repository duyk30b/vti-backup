import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';
import { CreateInventoryTimeLimitRequestDto } from './create-inventory-time-limit.request.dto';

export class UpdateInventoryTimeLimitBodyDto extends CreateInventoryTimeLimitRequestDto {}
export class UpdateInventoryTimeLimitRequestDto extends UpdateInventoryTimeLimitBodyDto {
  @ApiProperty({ example: '', description: '' })
  @Transform(({ value }) => Number(value))
  @IsInt()
  id: number;
}
