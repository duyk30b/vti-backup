import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { InventoryTimeLimitEntity } from '@entities/inventory-time-limit/inventory-time-limit.entity';
import { CreateInventoryTimeLimitRequestDto } from '../dto/request/create-inventory-time-limit.request.dto';
import { GetInventoryTimeLimitListRequestDto } from '../dto/request/get-inventory-time-limit.request.dto';
import { UpdateInventoryTimeLimitRequestDto } from '../dto/request/update-inventory-time-limit.request.dto';

export interface InventoryTimeLimitRepositoryInterface
  extends BaseInterfaceRepository<InventoryTimeLimitEntity> {
  createEntity(
    request: CreateInventoryTimeLimitRequestDto,
  ): InventoryTimeLimitEntity;
  updateEntity(
    inventoryTimeLimit: InventoryTimeLimitEntity,
    request: UpdateInventoryTimeLimitRequestDto,
  ): InventoryTimeLimitEntity;
  getList(request: GetInventoryTimeLimitListRequestDto): Promise<any>;
}
