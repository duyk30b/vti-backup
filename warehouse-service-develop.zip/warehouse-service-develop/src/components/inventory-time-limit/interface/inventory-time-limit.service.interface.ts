import { CreateInventoryTimeLimitRequestDto } from '../dto/request/create-inventory-time-limit.request.dto';
import { DeleteInventoryTimeLimitRequestDto } from '../dto/request/delete-inventory-time-limit.request.dto';
import { GetInventoryTimeLimitByWarehouseRequestDto } from '../dto/request/get-inventory-time-limit-by-warehouse.request.dto';
import { GetInventoryTimeLimitRequestDto } from '../dto/request/get-inventory-time-limit-detail.request.dto';
import { GetInventoryTimeLimitListRequestDto } from '../dto/request/get-inventory-time-limit.request.dto';
import { UpdateInventoryTimeLimitRequestDto } from '../dto/request/update-inventory-time-limit.request.dto';

export interface InventoryTimeLimitServiceInterface {
  getDetail(request: GetInventoryTimeLimitRequestDto): Promise<any>;
  getList(request: GetInventoryTimeLimitListRequestDto): Promise<any>;
  create(request: CreateInventoryTimeLimitRequestDto): Promise<any>;
  update(request: UpdateInventoryTimeLimitRequestDto): Promise<any>;
  delete(request: DeleteInventoryTimeLimitRequestDto): Promise<any>;
  getDetailByWarehouse(
    request: GetInventoryTimeLimitByWarehouseRequestDto,
  ): Promise<any>;
}
